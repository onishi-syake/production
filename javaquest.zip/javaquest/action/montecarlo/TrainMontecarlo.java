package action.montecarlo;

import java.util.Scanner;
import java.util.Random;

import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import battle.InputAction.Auto;
import character.Player;
import data.item.StartItemSet;
import log.TrainTemporaryLog;
import train.Train;
import train.TrainState;

public class TrainMontecarlo {
    public static int mctsAct(TrainState state, TrainState beforeState, int N, boolean parallel, boolean text, Scanner scanner, Random rand){
        final int parallelNum = 8;
        class Node{
            int readNum = N;
            int nodeLimit = 10000000;
            TrainState state;
            TrainState beforeState;//turnUpdata直後のstate
            double w;
            int n;
            List<Node> childNodes;
            List<Integer> actions;//探索の行動記録
            Node(TrainState state, TrainState beforeState,  List<Integer> actions){
                this.state = state;
                this.beforeState = beforeState;
                this.w = 0;
                this.n = 0;
                this.childNodes = new ArrayList<Node>();
                this.actions = actions;
            }
            
            int evaluate(){
                //まずはactionsから盤面の復元
                TrainState copyState = state.modifiableCopy();
                TrainState copyBeforeState = beforeState.modifiableCopy();
                TrainState[] copyStateNB;
                copyState.setAuto(Auto.aiRandom);
                copyState.setBattleAuto(Auto.playout);


                for(int i = 0; i < actions.size(); i++){
                    copyState.addChargeAction(actions.get(i));
                    copyState.setSpendAction(copyState.getChargeAction());
                    copyState.setUseSpendAction(true);
                    copyStateNB = Train.oneTurnTrain(copyState, copyBeforeState, new TrainTemporaryLog(), text, scanner, rand);
                    copyState = copyStateNB[0];
                    copyBeforeState = copyStateNB[1];
                }

                if (copyState.isEnd()){
                    Player self = copyState.getSelf();
                    self.trainToBattleStatus();
                    int value = self.generalPower(true);
                    this.w += value;
                    this.n++;
                    return value;
                }
                if (this.childNodes.size() == 0){
                    copyState.setAuto(Auto.playout);
                    copyState.setBattleAuto(Auto.playout);
                    int value = 0;
                    
                    if(parallel && this.n > parallelNum){
                        TrainState[] stateArray = new TrainState[parallelNum];
                        for(int i = 0; i < parallelNum; i++){
                            stateArray[i] = copyState.modifiableCopy();
                        }
                        value = Arrays.stream(stateArray).parallel()
                            .map(parallelState -> train.Train.trainForAI(parallelState, StartItemSet.Tairyokuzai2, text, scanner, rand))
                            .map(log -> log.getSelf())
                            .mapToInt(self -> self.generalPower(true))
                            .sum();
                            this.n += parallelNum;
                    }else{
                        value = train.Train.trainForAI(copyState, StartItemSet.Tairyokuzai2, text, scanner, rand).getSelf().generalPower(true);
                        this.n++;
                    }
                    this.w += value;
                    if (this.n == nodeLimit){
                        this.expand();
                    }
                    return value;
                } else{
                    int value = this.nextChildNode().evaluate();
                    this.w += value;
                    this.n++;
                    return value;
                }
            }

            void expand(){
                int[] legalActions = state.legalActions();//aiLegalActions
                for(int action: legalActions){
                    List<Integer> AL = new ArrayList<>(this.actions);
                    AL.add(action);
                    this.childNodes.add(new Node(this.state.modifiableCopy(), this.beforeState.modifiableCopy(),  AL));
                }
            }

            //次に探索すべき評価値最大の子ノードを取得
            private Node nextChildNode(){
                for(Node childNode: this.childNodes){
                    if(childNode.n == 0){
                        return childNode;
                    }
                }
                int t = 0;
                for(Node c: childNodes){
                    t += c.n;
                }
                List<Double> ucb1Values = new ArrayList<>();
                for(Node childNode: this.childNodes){
                    ucb1Values.add((double)childNode.w / (double)childNode.n + Math.pow(2 * Math.log(t) / childNode.n, 0.5));
                }
                double max = Double.NEGATIVE_INFINITY;
                int maxIndex = -1;
                for(int i = 0; i < ucb1Values.size(); i++){
                    if(ucb1Values.get(i) > max){
                        max = ucb1Values.get(i);
                        maxIndex = i;
                    }
                }
                return this.childNodes.get(maxIndex);
            }

            public int run(){
                expand();
                for(int i = 0; i < readNum; i++){
                    evaluate();
                }
                int[] legalActions = state.legalActions();//aiLegalActions
                int[] nList = new int[this.childNodes.size()];
                for(int i = 0; i < this.childNodes.size(); i++){
                    nList[i] = this.childNodes.get(i).n;
                }
                int maxIndex = -1;
                double maxScore = Double.NEGATIVE_INFINITY;
                for (int i = 0; i < nList.length; i++){
                    if (maxScore < nList[i]){
                        maxScore = nList[i];
                        maxIndex = i;
                    }
                }
                return legalActions[maxIndex];
            }
        }

        Node rootNode = new Node(state, beforeState, new ArrayList<Integer>());
        return rootNode.run();
    }
}
