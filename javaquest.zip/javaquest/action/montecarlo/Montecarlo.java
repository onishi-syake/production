package action.montecarlo;

import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import battle.Battle;
import battle.StateForAI;
import battle.InputAction.Auto;
import log.BattleTemporaryLog;

public final class Montecarlo {
    public static int mcsAct(StateForAI state, boolean self_is_player1, boolean text, Scanner scanner, Random rand){
        final int N = 300;
        int[] selfLegalActions = state.getLegalAction(self_is_player1);
        int[] enemyLegalActions = state.getLegalAction(!self_is_player1);
        double[] scores = new double[selfLegalActions.length];
        for (int i = 0; i < scores.length; i++){
            scores[i] = 0;
        }
        StateForAI copyState = state.modifiableCopy();
        copyState.setAuto(Auto.random);
        int[] SEAction = new int[2];
        for (int i = 0; i < scores.length; i++){
            SEAction[self_is_player1 ? 0 : 1] = selfLegalActions[i];
            for (int j = 0; j < N / selfLegalActions.length; j++){
                SEAction[self_is_player1 ? 1 : 0] = enemyLegalActions[(int) (rand.nextDouble() * enemyLegalActions.length)];
                copyState = Battle.oneTurnBattle(state, SEAction, new BattleTemporaryLog(), text, scanner, rand).forAI();
                copyState = Battle.battleForAI(copyState, text, scanner, rand).forAI();
                scores[i] += copyState.isWin(self_is_player1) * Math.pow(0.9, copyState.getTurn());
            }
        }
        int maxIndex = -1;
        double maxScore = Double.NEGATIVE_INFINITY;
        for (int i = 0; i < scores.length; i++){
            if (maxScore < scores[i]){
                maxScore = scores[i];
                maxIndex = i;
            }
        }
        return selfLegalActions[maxIndex];
    }

    public static int mctsAct(StateForAI state, boolean self_is_player1, int N, int childReadNum, int limReadDepth, boolean parallel, boolean text, Scanner scanner, Random rand){
        final int parallelNum = 8;
        class Node{
            int readNum = N;
            int nodeLimit = 10000000;
            StateForAI state;
            boolean player1;
            double w;
            int n;
            double enemyW;
            int enemyN;
            List<Node> childNodes;
            List<Node> enemyChildNodes;
            List<Integer> actions;//探索の行動記録
            List<Integer> enemyActions;
            int readDepth;
            Node(StateForAI state, boolean player1, List<Integer> actions, List<Integer> enemyActions, int readDepth){
                this.state = state;
                this.player1 = player1;
                this.w = 0;
                this.n = 0;
                this.childNodes = new ArrayList<Node>();
                this.enemyChildNodes = new ArrayList<Node>();
                this.actions = actions;
                this.enemyActions = enemyActions;
                this.readDepth = readDepth;
            }
            
            int evaluate(){
                //まずはactionsから盤面の復元
                StateForAI copyState = state.modifiableCopy();
                copyState.setAuto(Auto.aiRandom);
                int[] SEAction = new int[2];
                int[] enemyLegalActions;

                for(int i = 0; i < actions.size(); i++){
                    enemyLegalActions = state.aiLegalActions(!player1);
                    SEAction[player1 ? 0 : 1] = actions.get(i);
                    SEAction[player1 ? 1 : 0] = readDepth > 0 ? enemyActions.get(i): enemyLegalActions[(int)(rand.nextDouble() * enemyLegalActions.length)]; 
                    copyState = Battle.oneTurnBattle(copyState, SEAction, new BattleTemporaryLog(), text, scanner, rand).forAI();
                }

                if (copyState.isEnd(false, false)){
                    int value = copyState.isWin(player1);
                    this.w += value;
                    this.n++;
                    return value;
                }
                if (this.childNodes.size() == 0){
                    copyState.setAuto(Auto.playout);
                    int value = 0;
                    if(parallel && this.n > parallelNum){
                        StateForAI[] stateArray = new StateForAI[parallelNum];
                        for(int i = 0; i < parallelNum; i++){
                            stateArray[i] = copyState.modifiableCopy();
                        }
                        value = Arrays.stream(stateArray).parallel()
                            .map(parallelState -> Battle.battleForAI(parallelState, text, scanner, rand))
                            .mapToInt(log -> log.isWin(player1))
                            .sum();
                            this.n += parallelNum;
                    }else{
                        value = Battle.battleForAI(copyState, text, scanner, rand).isWin(player1);
                        this.n++;
                    }
                    this.w += value;
                    if (this.n == nodeLimit){
                        this.expand();
                    }
                    return value;
                } else{
                    int value = this.nextChildNode().evaluate();
                    this.w += value;
                    this.n++;
                    return value;
                }
            }

            void expand(){
                List<Integer> EAL = new ArrayList<>(this.enemyActions);
                if(readDepth > 0){
                    Node enemyNode = new Node(this.state.modifiableCopy(), !player1, new ArrayList<>(this.enemyActions), new ArrayList<>(this.actions), readDepth - 1) ;
                    enemyNode.readNum = childReadNum;
                    int enemyAct = enemyNode.run();
                    EAL.add(enemyAct);
                    this.enemyChildNodes = new ArrayList<>(enemyNode.childNodes);
                    this.childNodes = new ArrayList<>(enemyNode.enemyChildNodes);
                    for(int i = 0; i < this.childNodes.size(); i++){
                        this.childNodes.get(i).enemyActions.set(this.childNodes.get(i).enemyActions.size() - 1, enemyAct);
                    }
                    this.n += enemyNode.enemyN;
                    this.w += enemyNode.enemyW;
                    this.enemyN = enemyNode.n;
                    this.enemyW = enemyNode.w;
                }
                if(this.childNodes.size() > 0) return;
                if(this.actions.size() == EAL.size()){
                    EAL.add(-1);
                }
                int[] legalActions = state.aiLegalActions(player1);
                for(int action: legalActions){
                    List<Integer> AL = new ArrayList<>(this.actions);
                    AL.add(action);
                    Node n = new Node(this.state.modifiableCopy(), this.player1, AL, EAL, limReadDepth);
                    if(AL.size() == 1){
                        n.expand();
                    }
                    this.childNodes.add(n);

                }
            }

            //次に探索すべき評価値最大の子ノードを取得
            private Node nextChildNode(){
                for(Node childNode: this.childNodes){
                    if(childNode.n == 0){
                        return childNode;
                    }
                }
                int t = 0;
                for(Node c: childNodes){
                    t += c.n;
                }
                List<Double> ucb1Values = new ArrayList<>();
                for(Node childNode: this.childNodes){
                    ucb1Values.add((double)childNode.w / (double)childNode.n + Math.pow(2 * Math.log(t) / childNode.n, 0.5));
                }
                double max = Double.NEGATIVE_INFINITY;
                int maxIndex = -1;
                for(int i = 0; i < ucb1Values.size(); i++){
                    if(ucb1Values.get(i) > max){
                        max = ucb1Values.get(i);
                        maxIndex = i;
                    }
                }
                return this.childNodes.get(maxIndex);
            }

            public int run(){
                expand();
                for(int i = 0; i < readNum; i++){
                    evaluate();
                }
                int[] selfLegalActions = this.state.aiLegalActions(this.player1);
                int[] nList = new int[this.childNodes.size()];
                for(int i = 0; i < this.childNodes.size(); i++){
                    nList[i] = this.childNodes.get(i).n;
                }
                int maxIndex = -1;
                double maxScore = Double.NEGATIVE_INFINITY;
                for (int i = 0; i < nList.length; i++){
                    if (maxScore < nList[i]){
                        maxScore = nList[i];
                        maxIndex = i;
                    }
                }
                return selfLegalActions[maxIndex];
            }
        }

        Node rootNode = new Node(state, self_is_player1, new ArrayList<Integer>(), new ArrayList<Integer>(), limReadDepth);
       return rootNode.run();
    }
}