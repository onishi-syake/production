package action;

import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.Callable;

import action.montecarlo.Montecarlo;
import battle.State;

public class ActionSelectMulti implements Callable<String> {
    State state;
    boolean self_is_player1;
    boolean text;
    Scanner scanner;
    Random rand;
    // submitメソッドが呼び出された際に行うタスク
    public String call() throws Exception {
        return String.valueOf(Montecarlo.mctsAct(state.forAI(), self_is_player1, 200, 100, 5, false, false, scanner, rand));
    }
    public void setField(State state, boolean self_is_player1, boolean text, Scanner scanner, Random rand){
        this.state = state.modifiableCopy();
        this.self_is_player1 = self_is_player1;
        this.text = text;
        this.scanner = scanner;
        this.rand = rand;
    }
}
