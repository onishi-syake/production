package action.ai.layer;

public abstract class Layer {
    
}
