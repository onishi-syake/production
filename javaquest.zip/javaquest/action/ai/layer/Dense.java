package action.ai.layer;

import java.util.Random;

public class Dense extends Layer{
    public final int input;
    public final int output;
    private double[][] wight;
    private double[] bias;

    public Dense(int input, int output, Random rand){
        this.input = input;
        this.output = output;
        this.wight = new double[output][input];
        this.bias = new double[output];
        this.ini(rand);
    }

    private void ini(Random rand){
        for (int i = 0; i < this.output; i++) {
            for (int j = 0; j < this.input; j++) {
                this.wight[i][j] = rand.nextGaussian();
            }
            this.bias[i] = rand.nextGaussian();
        }
    }
}
