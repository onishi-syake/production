package action.ai;

import java.util.Random;
import java.util.Scanner;

import battle.InputAction.Auto;

public class Test {
    public static void main(String[] args) {
        //DataMaker.makeData(Auto.aiRandom, Auto.aiRandom, false, new Scanner(System.in), new Random());
        System.out.println(Function.reLu.getClass());
    }
}
