package action.ai;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import battle.Battle;
import battle.State;
import battle.InputAction.Auto;
import character.Character;
import character.CharacterTester;
import character.Character.Attribute;
import data.action.Spell;
import data.item.BattleItem;
import text.Print.Color;

public final class DataMaker {
    private static final int division = 200;
    private static final int baseStatus = 400;
    static State[][] makeData(Auto autoP1, Auto autoP2, boolean text, Scanner scanner, Random rand){
        State[][] data = new State[Model.battleTime][];
        Character self;
        Character enemy;
        List<List<Character>> se = new ArrayList<>();
        int[] mainStatus = new int[] {1000, 1000, 300, 300, 100, 1, 10, 100, 2};
        for(int i = 0; i < Model.battleTime; i++){
            int e = rand.nextInt(20);
            double eCoef = 100.0 / (100.0 - e);
            int status = (int)(baseStatus / Math.cbrt(eCoef));//3乗根
            double aCoef = Math.pow(2, (rand.nextDouble() * 2) - 1);
            int d = 100;
            double sCoef = Math.pow(2, (rand.nextDouble() * 2) - 1);
            double hpCoef = 1 / aCoef / sCoef;
            mainStatus[0] = (int)(hpCoef * status * 10);
            mainStatus[1] = (int)(hpCoef * status * 10);
            mainStatus[4] = (int)(aCoef * status);
            mainStatus[5] = d;
            mainStatus[6] = e;
            mainStatus[7] = (int)(sCoef * status);
            self = new CharacterTester("魔王", Color.blue, Attribute.Null, 3, false, mainStatus, new EnumMap<>(Spell.class){{
                for(int i = 0; i < 10; i++){
                    Spell spell = Spell.values()[rand.nextInt(Spell.NUM)];
                    put(spell, spell.baseLevel);
                }
            }}, BattleItem.Zoukyouzai);
            for(BattleItem key : BattleItem.values()){
                self.getItemList().put(key, 1);
            }
            e = rand.nextInt(20);
            eCoef = 100.0 / (100.0 - e);
            status = (int)(baseStatus / Math.cbrt(eCoef));//3乗根
            aCoef = Math.pow(2, (rand.nextDouble() * 2) - 1);
            d = 100;
            sCoef = Math.pow(2, (rand.nextDouble() * 2) - 1);
            hpCoef = 1 / aCoef / sCoef;
            mainStatus[0] = (int)(hpCoef * status * 10);
            mainStatus[1] = (int)(hpCoef * status * 10);
            mainStatus[4] = (int)(aCoef * status);
            mainStatus[5] = d;
            mainStatus[6] = e;
            mainStatus[7] = (int)(sCoef * status);
            enemy = new CharacterTester("ゴブリン", Color.yellow, Attribute.Null, 3, false, mainStatus, new EnumMap<>(Spell.class){{
                for(int i = 0; i < 10; i++){
                    Spell spell = Spell.values()[rand.nextInt(Spell.NUM)];
                    put(spell, spell.baseLevel);
                }
            }}, BattleItem.Zoukyouzai);
            for(BattleItem key : BattleItem.values()){
                enemy.getItemList().put(key, 1);
            }
            se.add(Arrays.asList(new Character[]{self,enemy}));
        }
        State[][] array;
        for(int i = 0; i < Model.battleTime; i += division){
            array = se.parallelStream().skip(i).limit(division).map(s -> Battle.startBattleForAI(s.get(0), s.get(1), autoP1, autoP2, false, scanner, rand)).toArray(State[][]::new);
            System.arraycopy(array, 0, data, i, array.length);
        }
        return data;
    }
}
