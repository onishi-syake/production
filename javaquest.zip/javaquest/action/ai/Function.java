package action.ai;

public enum Function{
    reLu{
        @Override
        public double forWard(double x){
            return x > 0 ? x : 0;
        }
        @Override
        public double backWard(double x){
            return x > 0 ? x : 0;
        }
    },
    step{
        @Override
        public double forWard(double x){
            return x > 0 ? 1 : 0;
        }
        @Override
        public double backWard(double x){
            return 0;
        }
    }
    ;
    public abstract double forWard(double x);
    public abstract double backWard(double x);
}
