package action.ai;

public final class Model {
    private static final int epoch = 100;
    private static final double learningRate = Math.pow(0.1, 5);
     static final int battleTime = 2000;//1サイクルごとの対局数
    private static final double randomAction = 0.9;
    private static final int learnTime =20;//サイクル数
}