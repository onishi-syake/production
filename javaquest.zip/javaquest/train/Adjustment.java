package train;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import battle.InputAction.Auto;
import character.Player;
import character.Character.Attribute;
import character.Skill;
import data.action.Spell;
import data.item.StartItemSet;
import data.stage.Stage;
import log.GameLog;
import log.GameLogResult;
import train.TrainState.Mode;

public final class Adjustment {
    private static final int num = 10;//1000
    private static final int division = 5;//200
    private static final boolean parallel = true;
    private static final Auto Train_AUTO = Auto.mctsS;
    private static final Auto Battle_AUTO = Auto.mctsS;
    public static void main(String[] args) {
        Random rand = new Random();
        Scanner scanner = new Scanner(System.in);
        List<TrainState> stateList = new ArrayList<>();
        List<GameLog> log = new ArrayList<>();
        Mode mode = Mode.easy;
        Stage stage = Stage.last;
        for(int i = 0; i < num; i++){
            if(parallel){
                stateList.add(new TrainState(new Player("勇者", Attribute.A, Skill.NULL, new int[] {1000, 1000, 100, 100, 100, 100, 10, 100, 2, 100, 100, 100, 100, 100, 100, 0}, new EnumMap<Spell, Integer>(Spell.class), mode), stage, mode, Train_AUTO, Battle_AUTO, rand));
            }else{
                log.add(Train.train(new TrainState(new Player("勇者", Attribute.A, Skill.NULL, new int[] {1000, 1000, 100, 100, 100, 100, 10, 100, 2, 100, 100, 100, 100, 100, 100, 0}, new EnumMap<Spell, Integer>(Spell.class), mode), stage, mode, Train_AUTO, Battle_AUTO, rand), StartItemSet.Tairyokuzai2,false, scanner, rand));
                System.out.println((i + 1));
            }
        }
        if(parallel){
            for(int i = 0; i < num; i += division){
                Collections.addAll(log, stateList.parallelStream().skip(i).limit(division).map(s -> Train.train(s, StartItemSet.Tairyokuzai2, false, scanner, rand)).toArray(GameLog[]::new));
                System.out.println((i + division));
            }
        }
        GameLogResult result = new GameLogResult(log);
        System.out.println("平均ターン数" + result.turn);

        List<List<Integer>> keys = new ArrayList<List<Integer>>();
        apple: for(List<Integer> key: result.actions.keySet()){
            if(keys.size() == 0){
                keys.add(key);
                continue;
            }
            int size = keys.size();//サイズが増える前に保存する
            for(int i = 0; i < size; i++){
                for(int j = 0; j < keys.get(i).size(); j++){
                    if(keys.get(i).get(j) < key.get(j)){
                        break;
                    }else if(keys.get(i).get(j) > key.get(j)){
                        keys.add(i, key);
                        continue apple;
                    }
                }
            }
            keys.add(key);
        }

        List<String> namedKeys = new ArrayList<String>();
        for(List<Integer> key: keys){
            namedKeys.add(TrainState.actionName(stateList.get(0), key, mode));
        }

        /*for(List<Integer> key: keys){
            System.out.print("< ");
            for(int action: key){
                System.out.print(action + " ");
            }
            System.out.println("> : " + result.actions.get(key));
        }
        scanner.close();*/

        for(int i = 0; i < keys.size(); i++){
            System.out.print(namedKeys.get(i));
            System.out.println(" : " + result.actions.get(keys.get(i)));
        }
        scanner.close();
    }
}
