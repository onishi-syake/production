package train;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

import action.montecarlo.TrainMontecarlo;

import java.util.Random;

import battle.Battle;
import battle.CalculateDamage;
import battle.InputAction;
import battle.InputAction.Action;
import battle.InputAction.Auto;
import battle.state_change.ChangeBattleStatus;
import battle.State;
import character.Skill;
import character.Enemy;
import character.Player;
import character.Character;
import character.Character.Attribute;
import character.Character.MainStatus;
import character.Player.TrainStatus;
import data.action.Spell;
import data.card.Card;
import data.card.CardWithParams;
import data.card.Guild;
import data.card.RestMenu;
import data.card.TrainEvent;
import data.card.TrainMenu;
import data.card.TrainMenuCategory;
import data.card.TrainMenu.TrainResult;
import data.enemy.BaseMonster;
import data.enemy.Boss;
import data.enemy.Monster;
import data.event.Event;
import data.item.BattleItem;
import data.item.DisposableItem;
import data.item.ImmediateItem;
import data.item.Item;
import data.item.StartItemSet;
import data.item.Item.Shop;
import data.stage.Stage;
import game.LocationCategory;
import game.GameState;
import limitation.TrainLimitation;
import limitation.TrainLimitation.TrainLimitationCounter;
import log.BattleLog;
import log.TrainTemporaryLog;
import log.GameLog;
import log.TrainLog;
import text.Print;
import text.Print.Color;
import train.TrainState.Mode;
import train.TrainState.TimeFrame;
import train.TrainState.shuffleModeWithAddCard;

//ステータス変更時には必ずtrainToBattleStatusかbattleToTrainStatusでステータスを共有すること
public final class Train {
    public enum TrainTurnAction {
        train("訓練"),
        battle("ギルド"),
        item("アイテム"),
        buyItem("購入"),
        useItem("使用"),
        save("中断"),
        ;

        public final String jName;

        private TrainTurnAction(String name) {
            this.jName = name;
        }
    }

    public static void train(GameState gameState, StartItemSet itemSet){
        gameState.sendNextAction();
        TrainState trainState = gameState.trainState;
        Random rand = gameState.rand;
        boolean text = gameState.text;
        Scanner scanner = gameState.scanner;
        final int MAIN = 1;
        switch(gameState.getSavedLocation(LocationCategory.train)){
            case LocationCategory.NO_CHOICE:
                if(trainState.getTurn() == 0) {
                    trainState.openStartItemSet(itemSet, text, scanner, rand);
                    if(trainState.getSelf().getSkill() == Skill.KJA){
                        trainState.getSelf().getSpellLevel().replace(Spell.KJA, 1);
                    }
                    trainState.setTurn(1);
                    gameState.beforeTrainState = trainState.modifiableCopy();
                    gameState.log = new ArrayList<>();
                    gameState.buyLog = new TrainTemporaryLog();
                }
                gameState.saveLocation(LocationCategory.train, MAIN);
                train(gameState, itemSet);
                return;

            case MAIN:
                if(trainState.getTurn() <= trainState.getTurnLimit() + 1){
                    TrainState[] trainStateNB = oneTurnTrain(trainState, gameState.beforeTrainState, gameState.buyLog, text, scanner, rand);
                    gameState.trainState = trainStateNB[0];
                    gameState.beforeTrainState = trainStateNB[1];
                    if(gameState.trainState.getSavedLocation(LocationCategory.gameClear) == LocationCategory.TRUE){
                        gameState.saveLocation(LocationCategory.train, LocationCategory.FINISH);
                        gameState.saveLocation(LocationCategory.gameClear, LocationCategory.TRUE);
                    }
                    if(trainState.getSavedLocation(LocationCategory.saveLog) == 1){//???
                        gameState.log.add(new TrainLog(trainState, gameState.beforeTrainState, gameState.buyLog));
                        gameState.buyLog = new TrainTemporaryLog();
                        gameState.trainState.saveLocation(LocationCategory.saveLog, LocationCategory.NO_CHOICE);
                    }
                    if(gameState.trainState.isEnd() && gameState.trainState.getResuscitated()){
                        gameState.saveLocation(LocationCategory.train, LocationCategory.FINISH);
                    }
                }else{
                    gameState.saveLocation(LocationCategory.train, LocationCategory.FINISH);
                }
                return;

            default:
                System.out.println("error train");
                return;
                
        }
    }

    public static GameLog train(TrainState trainState, StartItemSet itemSet, boolean text, Scanner scanner,Random rand) {
        if(trainState.getTurn() == 0) {
            // trainState.addBattleMenus(makeBattleMenu(trainState, rand));
            // bossesUpdate(trainState, rand);
            trainState.openStartItemSet(itemSet, text, scanner, rand);
            if(trainState.getSelf().getSkill() == Skill.KJA){
                trainState.getSelf().getSpellLevel().replace(Spell.KJA, 1);
            }
            /*if (trainState.getMode() == Mode.easy) {
                Player self = trainState.getSelf();
                self.setUseSpell(true);
                self.setUseItem(true);
                self.setUseSpecial(true);
            }*/
            trainState.setTurn(1);
        }
        // if(trainState.getTurn() == 1){
        //     if (trainState.getTrainLimitations().get(TrainLimitation.tutorial).get(TrainLimitationCounter.flag) == 1 && !trainState.getSave()) {//ログなし
        //         trainState = Event.tutorialBattle.execute(trainState, trainState.modifiableCopy(), new TrainTemporaryLog(), text, scanner, rand);
        //         CalculateDamage.trainDamage(trainState.getSelf(), TrainStatus.maxHp, -100, true);
        //         Print.nextLine(scanner, text);
        //     }
        // }
        TrainState[] trainStateNB = new TrainState[]{trainState, trainState.modifiableCopy()};
        List<TrainLog> log = new ArrayList<>();
        while (trainStateNB[0].getTurn() <= trainStateNB[0].getTurnLimit()) {
            TrainTemporaryLog buyLog = new TrainTemporaryLog();
            trainStateNB = oneTurnTrain(trainStateNB[0], trainStateNB[1], buyLog, text, scanner, rand);//trainStateNB[1] != trainState
            log.add(new log.TrainLog(trainState, trainStateNB[0], buyLog));
            if (trainStateNB[0].isEnd()) {
                Print.println("GAME OVER", Print.lowSpeed, text);
                Print.clearStaticText(text);
                break;
            }
            trainState = trainStateNB[0];
        }
        save(trainState, true, text, scanner);
        return new GameLog(log);
    }

    public static TrainState trainForAI(TrainState trainState, StartItemSet itemSet, boolean text, Scanner scanner,Random rand) {
        // trainState.addBattleMenus(makeBattleMenu(trainState, rand));
        // bossesUpdate(trainState, rand);
        trainState.openStartItemSet(itemSet, text, scanner, rand);
        TrainState[] trainStateNB = new TrainState[]{trainState, trainState.modifiableCopy()};
        while (trainStateNB[0].getTurn() <= trainStateNB[0].getTurnLimit()) {
            trainStateNB = oneTurnTrain(trainStateNB[0], trainStateNB[1], new TrainTemporaryLog(), text, scanner, rand);
            if (trainStateNB[0].isEnd()) {
                Print.println("GAME OVER", Print.lowSpeed, text);
                Print.clearStaticText(text);
                break;
            }
        }
        return trainStateNB[0];
    }

    // TODO このメソッド要る（一行動選択肢につき1関数の人工知能用の法則から）（どの選択肢かはEnum型を用意してこの関数の引数にする？）
    public static TrainState[] oneTurnTrain(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner,Random rand) {
        if(trainState.getSavedLocation(LocationCategory.trainOneTurnRefreshed) == LocationCategory.NO_CHOICE){
            trainState = trainState.modifiableCopy();
            beforeTrainState = beforeTrainState.modifiableCopy();
            trainState.setChargeAction(new ArrayList<>());
            trainState.getSelf().trainToBattleStatus();
            trainState.saveLocation(LocationCategory.trainOneTurnRefreshed, 1);
        }
        TrainState[] trainStateNB = new TrainState[]{trainState, beforeTrainState};
        if (!(trainStateNB[0].getUseSpendAction() && trainStateNB[0].getSpendAction().get(0) > 3)) {
            // Print.println("<br>" + trainStateNB[0].getTurn() + "/" + trainStateNB[0].getTurnLimit() + "ターン目" + (trainStateNB[0].getTimeFrame().jName) + "<br>", Print.highSpeed, text);
            // Print.print("    次の勇者ターン:", Print.highSpeed, text);
            // String bossTurn = "???";
            // for(int bTurn : trainState.getBossTurn()){
            //     if(trainState.getTurn() < bTurn){
            //         bossTurn = bTurn + "";
            //         break;
            //     }else if(trainState.getTurn() == bTurn){
            //         bossTurn = "この";
            //     }
            // }
            // Print.println(bossTurn + "ターン", Print.highSpeed, text);
            // Print.println("<br>総合力：" + trainStateNB[0].getSelf().generalPower(true) + "<br>",Print.highSpeed, text);
            // Print.displayTrainStatus(trainStateNB[0], text);
            // Print.println("<br>====================================================================================================================================", Print.highSpeed, text);
            // Print.println("行動を選択してください", Print.highSpeed, text);
            /*
             * if(trainState.getMode() == Mode.easy){
             * if(trainState.getTurn() % 4 == 0){
             * Print.print("<br>1:---  2:" + TrainTurnAction.battle.jName, Print.highSpeed,
             * text);
             * }else{
             * Print.print("<br>1:" + TrainTurnAction.train.jName + "  2:---",
             * Print.highSpeed, text);
             * }
             * if(trainState.getTurn() < 4){
             * Print.println("  3:--- 4:" + TrainTurnAction.save.jName, Print.highSpeed,
             * text);
             * }else{
             * Print.println("  3:" + TrainTurnAction.item.jName + " 4:" +
             * TrainTurnAction.save.jName, Print.highSpeed, text);
             * }
             * }else{
             *
            if(trainState.getMode() == Mode.easy){
                Print.println("<br>1:" + TrainTurnAction.train.jName + "  2:---  3:"
                        + TrainTurnAction.item.jName + " 4:" + TrainTurnAction.save.jName, Print.highSpeed, text);
            }else{
                Print.println("<br>1:" + TrainTurnAction.train.jName + "  2:" + TrainTurnAction.battle.jName + "  3:"
                        + TrainTurnAction.item.jName + " 4:" + TrainTurnAction.save.jName, Print.highSpeed, text);
            }
            * } */
            /*Print.println("<br>1:" + TrainTurnAction.train.jName + "  2:"
            + TrainTurnAction.item.jName + " 3:" + TrainTurnAction.save.jName, Print.highSpeed, text);*/
        }
        // 敵とトレーニングを表示する

        int act;
        int step = trainStateNB[0].getStep();
        if(!trainStateNB[0].getUseSpendAction()){
            trainStateNB[0].setUseSpendAction(true);
            trainStateNB[0].setSpendAction(new ArrayList<>(){{
                add(1);
            }});
        }
        act = makeAction(trainStateNB[0], trainStateNB[1], scanner, text, rand);// makeAction時にstep増加
        trainStateNB[0].setStep(trainStateNB[0].getStep() + 1);
        if (trainStateNB[0].getAuto() != Auto.select && !trainStateNB[0].getUseSpendAction()) {
            trainStateNB[0].setChargeAction(new ArrayList<Integer>());// 2行前に追加されたchargeActionを削除
            List<Integer> spendAction = new ArrayList<Integer>();
            if (step % 4 == 0 || step % 4 == 1) {
                spendAction.add(3);
                spendAction.add(1);
                spendAction.add(act);
            } else if (step % 4 == 2) {
                spendAction.add(3);
                spendAction.add(2);
                spendAction.add(act);
            } else if (step % 4 == 3) {
                if (act < TrainMenu.NUM + RestMenu.NUM + TrainEvent.NUM) {
                    spendAction.add(1);
                    spendAction.add(act);
                } else {
                    spendAction.add(2);
                    spendAction.add(act - (TrainMenu.NUM + RestMenu.NUM + TrainEvent.NUM));
                }
            }
            trainStateNB[0].setSpendAction(spendAction);
            trainStateNB[0].setUseSpendAction(true);
            act = makeAction(trainStateNB[0], trainStateNB[1], scanner, text, rand);
        }

        switch (act) {
            case 1:
                /*
                 * if(trainState.getMode() == Mode.easy && trainState.getTurn() % 4 == 0){
                 * Print.println("選べません", Print.highSpeed, text);
                 * Print.nextLine(scanner, text);
                 * break;
                 * }
                 */
                final int CHOICE_TRAINING = 1;
                final int DO_TRAINING = 2;
                switch(trainState.getSavedLocation(LocationCategory.trainCardChoiced)){
                    case LocationCategory.NO_CHOICE:
                        // trainState.trainings = choiceTrainings(trainState, beforeTrainState, log, text, scanner, rand);
                        trainState.saveLocation(LocationCategory.trainCardChoiced, CHOICE_TRAINING);
                        oneTurnTrain(trainState, beforeTrainState, log, text, scanner, rand);
                        break;

                    case CHOICE_TRAINING:
                        trainState.trainings = choiceTrainings(trainState, beforeTrainState, log, text, scanner, rand);
                        if(trainState.getSavedLocation(LocationCategory.choiceTrainings) == LocationCategory.FINISH){
                            trainState.saveLocation(LocationCategory.choiceTrainings, LocationCategory.NO_CHOICE);
                            trainState.saveLocation(LocationCategory.trainCardChoiced, DO_TRAINING);
                            oneTurnTrain(trainState, beforeTrainState, log, text, scanner, rand);
                        }
                        break;
                        
                    case DO_TRAINING:
                        trainStateNB = doTrainings(trainStateNB[0], trainStateNB[1], log, text, scanner, rand);
                        if(trainStateNB[0].getSavedLocation(LocationCategory.doTrainings) == LocationCategory.FINISH){
                            trainState.saveLocation(LocationCategory.doTrainings, LocationCategory.NO_CHOICE);
                            trainState.saveLocation(LocationCategory.trainCardChoiced, LocationCategory.NO_CHOICE);
                        }
                        break;
                }
                break;
            /*case 2:
                
                if(trainState.getMode() == Mode.easy){
                Print.println("選べません", Print.highSpeed, text);
                Print.nextLine(scanner, text);
                break;
                }
                
                trainStateNB = normalBattle(trainStateNB[0], trainStateNB[1], log, text, scanner, rand);
                break;*/
            case 2:
                /*
                 * if(trainState.getMode() == Mode.easy && trainState.getTurn() < 4){
                 * Print.println("まだ選べません", Print.highSpeed, text);
                 * Print.nextLine(scanner, text);
                 * break;
                 * }
                 */
                item(trainStateNB[0], trainStateNB[1], log, text, scanner, rand);
                break;
            case 3:
                save(trainStateNB[0], false, text, scanner);
                break;
            case 4:
                // ここに送ってturnUpdateする必要は無い
                // if (trainStateNB[0].getUseSpendAction()) {
                //     int category = makeAction(trainStateNB[0], trainStateNB[1], scanner, text, rand);
                //     if (category == 1) {// 鍛錬後イベント
                //         int beforeTrainMenu = makeAction(trainStateNB[0], trainStateNB[1], scanner, text, rand);
                //         trainStateNB = turnUpdate(trainStateNB[0], trainStateNB[1], false, log, text,
                //                 scanner, rand,
                //                 (TrainStatus) TrainMenu.values()[beforeTrainMenu].trainCategory.keySet().toArray()[0]);
                //     } else if (category == 2) {// 戦闘後、宿屋あり
                //         trainStateNB = turnUpdate(trainStateNB[0], trainStateNB[1], true, log, text,
                //                 scanner, rand, null);
                //     } else if (category == 3) {// 戦闘後、宿屋なし
                //         trainStateNB = turnUpdate(trainStateNB[0], trainStateNB[1], true, log, text,
                //                 scanner, rand, null);
                //     } else {// バグってる
                //         System.out.println("不正アクセス！");
                //     }
                //     break;
                // }
            case 5:
                // ここでする必要が無い
                // if (trainStateNB[0].getUseSpendAction()) {
                //     trainStateNB = battleInn(trainStateNB, log, text, scanner, rand);
                //     break;
                // }
                // 外側にbreakが無いのは仕様です（通常では4を入力しても意味はない）
            default:
                Print.displayDetailStatus(trainStateNB[0], false, false, text, scanner);
                showActions(trainStateNB[0], text, scanner);
                Print.println("", Print.highSpeed, text);
                Print.println("その他", Print.highSpeed, text);
                Print.println("1:スキル詳細", Print.highSpeed, text);
                Print.println("2:中断", Print.highSpeed, text);
                Print.println("3:諦める", Print.highSpeed, text);
                Print.println("4:勇者", Print.highSpeed, text);
                act = Print.input(scanner, text);
                switch (act) {
                    case 1:
                        trainStateNB[0].getSelf().getSkill().infomation(trainState, text);
                        Print.nextLine(scanner, text);
                        break;
                    case 2:
                        save(trainStateNB[0], false, text, scanner);
                        Print.nextLine(scanner, text);
                        break;
                    case 3:
                        Print.println("本当に諦めますか？", Print.lowSpeed, text);
                        
                        Print.println("Enter:はい" + Print.space(2, text) + "1:いいえ", Print.highSpeed, text);
                        if(makeAction(trainState, beforeTrainState, scanner, text, rand) == 0){
                            CalculateDamage.trainDamage(trainStateNB[0].getSelf(), TrainStatus.maxHp, 100, text);
                        }
                        Print.nextLine(scanner, text);
                        break;
                    case 4:
                        Print.displayEnemyStatus(trainStateNB[0].getBoss(), false, text);
                        Print.nextLine(scanner, text);
                        break;
                }
                break;
        }
        Collections.addAll(log.getAction(),
            trainStateNB[0].getChargeAction().toArray(new Integer[trainStateNB[0].getChargeAction().size()]));
        return trainStateNB;
    }

    // private static TrainState[] training(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner,Random rand) {
    //     TrainState[] trainStateNB = new TrainState[]{trainState, beforeTrainState};
    //     System.out.println("イベント出現確率倍率" + (trainState.getMissedEventChainNum() + 1) + "倍");
    //     Player self = trainStateNB[0].getSelf();
    //     // List<Integer> bossTurn = trainStateNB[0].getBossTurn();
    //     List<Integer> trainMenus = trainStateNB[0].getTrainMenus().get(trainStateNB[0].getTurn() - 1);
    //     int trainMenuNum = Math.min(trainStateNB[0].getTrainMenuNum(), trainMenus.size());
    //     trainMenus = new ArrayList<>(trainMenus.subList(0, trainMenuNum));
    //     // Collections.sort(trainMenus);
    //     // TODO sortすると前回解放の要素が一番最初に来なくなる
    //     int battleMenuNum = trainStateNB[0].getBattleMenuNum();
    //     List<Integer> battleMenus = trainStateNB[0].getBattleMenus().get(trainStateNB[0].getTurn() - 1);
    //     List<Integer> spendAction;
    //     /*if (bossTurn.contains(trainStateNB[0].getTurn())) {
    //         Print.println("勇者が近づいている!!<br>そんなことをしている場合ではない!!!", Print.highSpeed, text);
    //         return trainStateNB;
    //     }*/
    //     Print.println("<br>1ターンを消費して各種ステータスを上昇・回復させます", Print.highSpeed, text);
    //     Print.print("<br>精神力ボーナス：" + Math.pow(trainStateNB[0].getSelf().getTrainStatus().get(TrainStatus.motivation), 2) / 10000 + "倍",
    //             Print.highSpeed, text);
    //     if(trainStateNB[0].getTrainLimitations().get(TrainLimitation.chainTrain)){
    //         Print.print("    連続鍛錬ボーナス："
    //             + Math.round(Math.pow(TrainMenu.chainTrainCoef, trainStateNB[0].getChainTrainNum()) * 100) / 100.0 + "倍",
    //             Print.highSpeed, text);
    //         if(trainStateNB[0].getTrainLimitations().get(TrainLimitation.sameTrain)){
    //             Print.print(
    //                 " (同行動：" + Math.round((Math.pow(TrainMenu.chainTrainCoef, trainStateNB[0].getChainTrainNum()))
    //                 * (Math.pow(TrainMenu.sameTrainCoef,
    //                 trainStateNB[0].getChainSameTrainNum() + (trainStateNB[0].getChainTrainNum() == 0 ? 0 : 1)))
    //                 * 100) / 100.0 + "倍)",
    //                 Print.highSpeed, text);
    //         }
    //     }else if(trainStateNB[0].getTrainLimitations().get(TrainLimitation.sameTrain)){
    //         Print.print("    連続同行動ボーナス："
    //             + Math.round((Math.pow(TrainMenu.chainTrainCoef, trainStateNB[0].getChainTrainNum())) * (Math.pow(TrainMenu.sameTrainCoef, trainStateNB[0].getChainSameTrainNum() 
    //             + (trainStateNB[0].getChainTrainNum() == 0 ? 0 : 1))) * 100) / 100.0 + "倍",
    //             Print.highSpeed, text);
    //     }
    //     Print.println("    行動力：" + trainStateNB[0].getSelf().getTrainStatus().get(TrainStatus.activity) + " → 行動可能数："
    //             + trainMenuNum + "<br>", Print.highSpeed, text);
    //     if(self.getInvincibleTurn() != 0){
    //         Print.println("残りモンスターターン : " + self.getInvincibleTurn() + "<br>", Print.highSpeed, text);
    //     }
    //     /*if(trainState.getMode() != Mode.easy){
    //         Print.print("0:戦闘メニュー", Print.highSpeed, text);
    //         for(int i = 0; i < battleMenuNum && i < battleMenus.length; i++){
    //             if(trainStateNB[0].getMode() == Mode.easy){
    //                 Print.print("    " + Monster.easyValues()[battleMenus.get(i)].jName, Print.highSpeed, text);
    //             }else{
    //                 Print.print("    " + Monster.values()[battleMenus.get(i)].jName, Print.highSpeed, text);
    //             }
    //         }
    //         Print.println("", Print.highSpeed, text);
    //     }*/
    //     // Print.println("", 0, text);
    //     // Print.println("0:スキル詳細<br>", Print.highSpeed, text);
    //     if(self.getSkill() == Skill.zeroInn){
    //         Print.print("0:", Print.highSpeed, text);
    //         RestMenu.inn.miniExplain(trainStateNB[0], text);
    //     }
    //     for (int i = 0; i < trainMenuNum; i++) {
    //         Print.println("", 0, text);
    //         if (trainMenus.get(i) < TrainMenu.NUM) {
    //             Print.print((i + 1) + ":", Print.highSpeed, text);
    //             TrainMenu.values()[trainMenus.get(i)].miniExplain(trainStateNB[0], text);
    //         } else if (trainMenus.get(i) < TrainMenu.NUM + RestMenu.NUM) {
    //             Print.print((i + 1) + ":", Print.highSpeed, text);
    //             RestMenu.values()[trainMenus.get(i) - TrainMenu.NUM].miniExplain(trainStateNB[0], text);
    //         } else if(trainMenus.get(i) < TrainMenu.NUM + RestMenu.NUM + TrainEvent.NUM){
    //             Print.print((i + 1) + ":", Print.highSpeed, text);
    //             TrainEvent.values()[trainMenus.get(i) - TrainMenu.NUM - RestMenu.NUM].miniExplain(trainStateNB[0], text);
    //         } else if(trainMenus.get(i) < TrainMenu.NUM + RestMenu.NUM + TrainEvent.NUM + (trainStateNB[0].getTrainLimitations().get(TrainLimitation.battle) ? 1 : 0)){
    //             //TODO ここで出現する敵を表示したほうが良いかも
    //             Print.println((i + 1) + Print.format(":ギルド", 26) + Print.format("消費ターン：", 11) + Print.toRed(Print.format(TrainTurnAction.battle.baseTurn + "", 10)), Print.highSpeed, text);
    //         }/* else if(trainMenus.get(i) < TrainMenu.NUM + RestMenu.NUM + TrainEvent.NUM + (trainStateNB[0].getTrainLimitations().get(TrainLimitation.battle) ? 1 : 0) + (bossTurn.contains(trainStateNB[0].getTurn()) ? 1 : 0)){
    //             Print.println((i + 1) + Print.format(":ギルド", 26) + Print.format("消費ターン：", 11) + Print.toRed(Print.format(TrainTurnAction.battle.baseTurn + "", 10)), Print.highSpeed, text);
    //         } */else{
    //             System.out.println("異常なアクセスです");
    //         }
    //     }
        
    //     Print.println("<br>====================================================================================================================================", Print.highSpeed, text);

    //     Print.print("<br>" + (trainMenuNum + 1) + ":" + "アイテム", Print.highSpeed, text);
    //     // Print.println("<br>" + (trainMenuNum + 2) + ":" + "中断", Print.highSpeed, text);
    //     // Print.println("<br>" + (trainMenuNum + 3) + ":" + "諦める", Print.highSpeed, text);
    //     Print.println("    " + (trainMenuNum + 2) + ":" + "データ", Print.highSpeed, text);

    //     int idx;
    //     idx = makeAction(trainStateNB[0], trainStateNB[1], scanner, text, rand);
    //     if (trainStateNB[0].getAuto() != Auto.select) {
    //         for (int i = 0; i < trainMenuNum; i++) {
    //             if (idx == trainMenus.get(i)) {
    //                 idx = i + 1;
    //                 break;
    //             }
    //         }
    //     }

    //     /*if(idx == 0 && trainState.getMode() != Mode.easy){
    //         return normalBattle(trainStateNB[0], trainStateNB[1], log, text, scanner, rand);
    //     }*/

    //     /* if(idx == 0){
    //         self.getSkill().infomation(trainState, text);
    //         Print.nextLine(scanner, text);
    //         return training(trainState, beforeTrainState, log, text, scanner, rand);
    //     } */

    //     if(idx == 0 && self.getSkill() != Skill.zeroInn){
    //         return training(trainState, beforeTrainState, log, text, scanner, rand);
    //     }

    //     if (idx < -(trainMenuNum + 1) || idx > trainMenuNum + 1) {
    //         /*if (idx != Math.min(Math.min(trainMenuNum, trainMenus.length), trainMenus.length) + 1) {
    //             System.out.println("正しく入力してください1");
    //             Print.input(scanner, text);
    //         }*/
    //         spendAction = new ArrayList<Integer>();
    //         spendAction.add(6);
    //         trainStateNB[0].setSpendAction(spendAction);
    //         trainStateNB[0].setUseSpendAction(true);
    //         return trainStateNB;
    //     }
    //     if (idx < 0) {
    //         if(idx == -(trainMenuNum + 1)){
    //             Print.println("アイテムを購入・使用できる<br>アイテムの使用は1ターンに1度のみ。アイテムの値段は1ターンごとに5%上昇する。", Print.highSpeed, text);
    //         } /* else if(idx == -(trainMenuNum + 2)){
    //             Print.println("現在の状況をセーブして中断できる<br>不正を防ぐ為に1ターンに1度しかセーブ出来ず、一度ロードしたセーブデータは破棄される", Print.highSpeed, text);
    //         } else if(idx == -(trainMenuNum + 3)){
    //             Print.println("HPを0にしてゲームを終了させる<br>進行不可能になった時などにどうぞ", Print.highSpeed, text);
    //         }  */else if (trainMenus.get(-idx - 1) < TrainMenu.NUM) {
    //             TrainMenu.values()[trainMenus.get(-idx - 1)].explain(trainStateNB[0], text);
    //         } else if (trainMenus.get(-idx - 1) < TrainMenu.NUM + RestMenu.NUM) {
    //             RestMenu.values()[trainMenus.get(-idx - 1) - TrainMenu.NUM].explain(trainStateNB[0], text);
    //         } else if(trainMenus.get(-idx - 1) < TrainMenu.NUM + RestMenu.NUM + TrainEvent.NUM){
    //             TrainEvent.values()[trainMenus.get(-idx - 1) - TrainMenu.NUM - RestMenu.NUM].explain(trainStateNB[0], text);
    //         } else if(trainMenus.get(-idx - 1) < TrainMenu.NUM + RestMenu.NUM + TrainEvent.NUM + (trainStateNB[0].getTrainLimitations().get(TrainLimitation.battle) ? 1 : 0)){
    //             //TODO 詳細な説明がいるかも
    //             Print.print("戦闘を行う。<br>敵リスト:", Print.highSpeed, text);
    //             for(int i = 0; i < battleMenuNum && i < battleMenus.size(); i++){
    //                 /*if(trainStateNB[0].getMode() == Mode.easy){
    //                     Print.print("    " + Monster.easyValues()[battleMenus.get(i)].jName, Print.highSpeed, text);
    //                 }else{
    //                     Print.print("    " + Monster.values()[battleMenus.get(i)].jName, Print.highSpeed, text);
    //                 }*/
    //                 Print.print("    " + Monster.values()[battleMenus.get(i)].jName, Print.highSpeed, text);
    //             }
    //         }/* else if(trainMenus.get(-idx - 1) < TrainMenu.NUM + RestMenu.NUM + TrainEvent.NUM + (trainStateNB[0].getTrainLimitations().get(TrainLimitation.battle) ? 1 : 0) + (bossTurn.contains(trainStateNB[0].getTurn()) ? 1 : 0)){
    //             if(trainStateNB[0].getBossTurn().contains(trainStateNB[0].getTurn())){
    //                 Print.print("勇者との戦闘。さあ、今まで鍛え上げた力を示す時だ！<br>敵詳細:", Print.highSpeed, text);
    //                 Print.displayBossStatus(trainStateNB[0].getBosses()[trainStateNB[0].getBossTurn().indexOf(trainStateNB[0].getTurn())], text);
    //                 Print.input(scanner, text);
    //             }else{
    //                 System.out.println("異常なアクセスです");
    //             }
    //         }  */else{
    //             System.out.println("異常なアクセスです");
    //         }
    //         Print.nextLine(scanner, text);
    //         return training(trainStateNB[0], beforeTrainState, log, text, scanner, rand);
    //     }
        
    //     if(idx == 0 && self.getSkill() == Skill.zeroInn){
    //         RestMenu restAct = RestMenu.inn;

    //         trainStateNB = restAct.execute(trainStateNB, log, true, true, text, scanner, rand);
    //         Print.input(scanner, text);
    //     }else if(idx == trainMenuNum + 1){
    //         item(trainStateNB[0], trainStateNB[1], log, text, scanner, rand);
    //         return trainStateNB;
    //     } /* else if(idx == trainMenuNum + 2){
    //         trainStateNB[0] = save(trainState, false, text, scanner);
    //         return trainStateNB;
    //     } else if(idx == trainMenuNum + 3){
    //         Print.println("本当に諦めますか？<br>1:はい" + Print.space(2, text) + "2:いいえ", Print.lowSpeed, text);
    //         if(makeAction(trainState, beforeTrainState, scanner, text, rand) == 1){
    //             CalculateDamage.trainDamage(self, TrainStatus.maxHp, 100, text);
    //         }
    //         return trainStateNB;
    //     }  */else if (trainMenus.get(idx - 1) < TrainMenu.NUM) {
    //         TrainMenu trainAct = TrainMenu.values()[trainMenus.get(idx - 1)];
    //         // TODO 後で直す
    //         if(TimeFrame.checkLegal(trainState.getTimeFrame(), trainState.getMode(), trainAct.spendActionNum)){
    //             System.out.println("その行動は選択できません");
    //             Print.nextLine(scanner, text);
    //             return training(trainState, beforeTrainState, log, text, scanner, rand);
    //         }
    //         trainStateNB[0] = trainAct.execute(trainStateNB[0], text);
    //         Print.input(scanner, text);
    //         // trainState = turnUpdate(trainState, trainStateCopy, log, text, scanner, rand,
    //         // (TrainStatus)trainAct.trainCategory.keySet().toArray()[0]);
    //         // eventに強制連行
    //         spendAction = new ArrayList<Integer>();
    //         spendAction.add(4);
    //         spendAction.add(1);// 鍛錬後のイベント
    //         for(int i = 0; i < TrainMenu.NUM; i++){
    //             if(TrainMenu.values()[i] == trainAct){
    //                 spendAction.add(i);
    //             }
    //         }
    //         trainStateNB[0].setSpendAction(spendAction);
    //         trainStateNB[0].setUseSpendAction(true);
    //         trainStateNB[0].addBeforeTurnAction(trainAct.ordinal());
    //     } else if (trainMenus.get(idx - 1) < TrainMenu.NUM + RestMenu.NUM) {
    //         RestMenu restAct = RestMenu.values()[trainMenus.get(idx - 1) - TrainMenu.NUM];
    //         trainStateNB[0].addBeforeTurnAction(TrainMenu.NUM + restAct.ordinal());

    //         trainStateNB = restAct.execute(trainStateNB, log, true, true, text, scanner, rand);
    //         Print.input(scanner, text);
    //     } else if(trainMenus.get(idx - 1) < TrainMenu.NUM + RestMenu.NUM + TrainEvent.NUM) {
    //         TrainEvent eventAct = TrainEvent.values()[trainMenus.get(idx - 1) - TrainMenu.NUM - RestMenu.NUM];
    //         trainStateNB[0].addBeforeTurnAction(TrainMenu.NUM + RestMenu.NUM + eventAct.ordinal());
    //         trainStateNB = eventAct.execute(trainStateNB[0], trainStateNB[1], log, text, scanner, rand);
    //         Print.input(scanner, text);
    //     } else if(trainMenus.get(idx - 1) < TrainMenu.NUM + RestMenu.NUM + TrainEvent.NUM + (trainStateNB[0].getTrainLimitations().get(TrainLimitation.battle) ? 1 : 0)){
    //         //通常戦
    //         if(!trainState.getMorning()){
    //             System.out.println("その行動は選択できません");
    //             Print.nextLine(scanner, text);
    //             return training(trainState, beforeTrainState, log, text, scanner, rand);
    //         }
    //         trainStateNB[0].addBeforeTurnAction(TrainMenu.NUM + RestMenu.NUM + TrainEvent.NUM);
    //         return normalBattle(trainStateNB[0], trainStateNB[1], log, text, scanner, rand);
    //     } /* else if(trainMenus[idx - 1] < TrainMenu.NUM + RestMenu.NUM + TrainEvent.NUM + (trainStateNB[0].getTrainLimitations().get(TrainLimitation.battle) ? 1 : 0) + (bossTurn.contains(trainStateNB[0].getTurn()) ? 1 : 0)){
    //         //勇者戦
    //         return normalBattle(trainStateNB[0], trainStateNB[1], log, text, scanner, rand);
    //     } */
    //     if (trainStateNB[0].isEnd() && !trainStateNB[0].getResuscitated()) {
    //         boolean useSpendAction = trainStateNB[0].getUseSpendAction();
    //         trainStateNB[0].setUseSpendAction(false);
    //         Print.println("復活権を使用し、ステータスを全回復してこのターンをやり直しますか<br>1:はい" + Print.space(2, text) + "2:いいえ", Print.middleSpeed, text);
    //         int act = makeAction(trainStateNB[0], trainStateNB[1], scanner, text, rand);
    //         trainStateNB[0].setUseSpendAction(useSpendAction);
    //         if (act == 1) {
    //             trainStateNB[1].resuscitate(true, text);
    //             trainStateNB[0] = trainStateNB[1].modifiableCopy();
    //             return trainStateNB;
    //         }
    //     }
    //     return trainStateNB;
    // }

    private static List<CardWithParams> choiceTrainings(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner,Random rand) {
        return choiceTrainings(trainState, beforeTrainState, trainState.trainings, log, text, scanner, rand);
    };
    private static List<CardWithParams> choiceTrainings(TrainState trainState, TrainState beforeTrainState, List<CardWithParams> choiceList, TrainTemporaryLog log, boolean text, Scanner scanner,Random rand) {
        /**
         * 鍛錬を選択するメソッド
         * 選択した鍛錬のインデックスをリストとして返す
         * 唯一アイテムの購入はtrainStateを破壊的に変更して行う
         * 今は2回同じ行動選べる？
         */
        TrainState[] trainStateNB = new TrainState[]{trainState, beforeTrainState};
        // System.out.println("イベント出現確率倍率" + (trainState.getMissedEventChainNum() + 1) + "倍");
        Player self = trainStateNB[0].getSelf();
        // List<Integer> bossTurn = trainStateNB[0].getBossTurn();
        List<CardWithParams> hands = trainStateNB[0].getHands();
        int trainMenuNum = hands.size();
        hands = new ArrayList<>(hands.subList(0, trainMenuNum));
        int battleMenuNum = trainStateNB[0].getBattleMenuNum();
        List<Integer> battleMenus;
        List<Integer> spendAction;
        int indentionCount;
        CardWithParams choicedCard;
        
        final int SCENARIO = 1;
        final int EXPLAIN = 2;
        final int SHOW_DETAIL = 3;
        final int CHOICE_MENU = 4;
        final int CHOICE_MENU_FINAL_CHECK_EXPLAIN = 5;
        final int CHOICE_MENU_FINAL_CHECK = 6;
        final int CHANGE_SPELL = 7;
        final int SAVE = 8;
        final int GIVEUP = 9;
        final int SET_PASSIVE_ITEM = 10;
        final int EXPLAIN_CARD = 11;
        final int ITEM = 12;
        switch(trainStateNB[0].getSavedLocation(LocationCategory.choiceTrainings)){
            case LocationCategory.NO_CHOICE:
                Print.skipStart(true, text);
                for(int i = 0; i < 3; i++){
                    Print.println("", true, Print.highSpeed, text);
                }
                Print.skipEnd(true, text);
                trainState.trainings = new ArrayList<>();
                trainState.provisionalTimeFrame = trainState.getMode().timeFrameList.get(0);
                trainState.saveLocation(LocationCategory.choiceTrainings, SCENARIO);
                if(new ArrayList<>(){{
                    add(1);
                    add(9);
                    add(17);
                    add(21);
                }}.contains(trainState.getTurn())){
                    Print.clearStaticText(text);
                    Print.changeWaitTextToLT(text);
                    return choiceList;
                }else{
                    return choiceTrainings(trainState, beforeTrainState, trainState.trainings, log, text, scanner, rand);
                }

            case SCENARIO:
                // debug 
                if(trainState.getTurn() % 4 == 1){
                    boolean isDynamic = true;
                    switch(trainState.getTurn() / 4){
                        case 0:
                            Print.printBigSeparater(isDynamic, text);
                            Print.skipStart(isDynamic, text);
                            Print.println(Color.gray.toColor("表示中にEnterで早送りできます"), isDynamic, Print.highSpeed, text);
                            Print.skipEnd(isDynamic, text);
                            Print.println("", isDynamic, Print.highSpeed, text);
                            Print.println("", isDynamic, Print.highSpeed, text);
                            Print.changeFontSizeStart(4, isDynamic, text);
                            Print.slowStart(isDynamic, text);
                            switch(trainStateNB[0].getSavedLocation(LocationCategory.scenario)){
                                case LocationCategory.NO_CHOICE:
                                    Print.println("王様「そこの勇者よ、 8 日後に 魔王を倒してくれ」" + Print.sleep(10), isDynamic, Print.highSpeed, text);
                                    Print.println("", isDynamic, Print.highSpeed, text);
                                    
                                    Print.println("普通の勇者「 8 日後に 魔王を倒すぞ！」" + Print.sleep(10), isDynamic, Print.highSpeed, text);
                                    Print.println("", isDynamic, Print.highSpeed, text);
                                    
                                    Print.println("王様 「あ、そこの勇者は 4 日後に頼んだ」" + Print.sleep(10), isDynamic, Print.highSpeed, text);
                                    Print.println("", isDynamic, Print.highSpeed, text);
                                    
                                    Print.println("見習い勇者「は、はい…！」" + Print.sleep(10), isDynamic, Print.highSpeed, text);
                                    
                                    Print.slowEnd(isDynamic, text);
                                    Print.changeFontSizeEnd(isDynamic, text);
                                    Print.printBigSeparater(isDynamic, text);
                                    trainState.saveLocation(LocationCategory.scenario, LocationCategory.NO_CHOICE);
                                    trainState.saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                                    Print.changeWaitTextToLT(text);
                                    return choiceList;

                                default:
                                    Print.changeFontSizeEnd(isDynamic, text);
                                    System.out.println("error scenario 1-1");
                                    trainState.saveLocation(LocationCategory.scenario, LocationCategory.NO_CHOICE);
                                    trainState.saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                                    return choiceTrainings(trainState, beforeTrainState, trainState.trainings, log, text, scanner, rand);
                            }

                        case 2:
                            Print.printBigSeparater(isDynamic, text);
                            Print.skipStart(isDynamic, text);
                            Print.println(Color.gray.toColor("表示中にEnterで早送りできます"), isDynamic, Print.highSpeed, text);
                            Print.skipEnd(isDynamic, text);
                            Print.println("", isDynamic, Print.highSpeed, text);
                            Print.println("", isDynamic, Print.highSpeed, text);
                            Print.changeFontSizeStart(4, isDynamic, text);
                            switch(trainStateNB[0].getSavedLocation(LocationCategory.scenario)){
                                case LocationCategory.NO_CHOICE:
                                    Print.println("王様「おお、お主が伝説の勇者か」" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                    Print.println("", isDynamic, Print.highSpeed, text);

                                    Print.println("王様「最強と聞いておるぞ！ 16 日後に魔王を倒してくれ」" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                    Print.println("", isDynamic, Print.highSpeed, text);

                                    Print.println("伝説の勇者「承った。 16 日後に 魔王を倒そう」" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                    Print.println("", isDynamic, Print.highSpeed, text);
                                    
                                    Print.println("最強の勇者「最強は俺です！」" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                    Print.println("", isDynamic, Print.highSpeed, text);
                                    
                                    Print.println("最強の勇者「 12 日後に魔王を倒してきます！」" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                    
                                    Print.changeFontSizeEnd(isDynamic, text);
                                    Print.printBigSeparater(isDynamic, text);
                                    trainState.saveLocation(LocationCategory.scenario, LocationCategory.NO_CHOICE);
                                    trainState.saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                                    Print.changeWaitTextToLT(text);
                                    return choiceList;

                                default:
                                    Print.changeFontSizeEnd(isDynamic, text);
                                    System.out.println("error scenario 1-2");
                                    trainState.saveLocation(LocationCategory.scenario, LocationCategory.NO_CHOICE);
                                    trainState.saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                                    return choiceTrainings(trainState, beforeTrainState, trainState.trainings, log, text, scanner, rand);
                            }

                        case 4:
                            Print.printBigSeparater(isDynamic, text);
                            Print.skipStart(isDynamic, text);
                            Print.println(Color.gray.toColor("表示中にEnterで早送りできます"), isDynamic, Print.highSpeed, text);
                            Print.skipEnd(isDynamic, text);
                            Print.println("", isDynamic, Print.highSpeed, text);
                            Print.println("", isDynamic, Print.highSpeed, text);
                            Print.changeFontSizeStart(4, isDynamic, text);
                            switch(trainStateNB[0].getSavedLocation(LocationCategory.scenario)){
                                case LocationCategory.NO_CHOICE:
                                    Print.println("…" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                    Print.println("", isDynamic, Print.highSpeed, text);

                                    Print.println("終焉の勇者 「…これで終わらせる。」" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                    
                                    Print.changeFontSizeEnd(isDynamic, text);
                                    Print.printBigSeparater(isDynamic, text);
                                    trainState.saveLocation(LocationCategory.scenario, LocationCategory.NO_CHOICE);
                                    trainState.saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                                    Print.changeWaitTextToLT(text);
                                    return choiceList;

                                default:
                                    Print.changeFontSizeEnd(isDynamic, text);
                                    System.out.println("error scenario 1-3");
                                    trainState.saveLocation(LocationCategory.scenario, LocationCategory.NO_CHOICE);
                                    trainState.saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                                    return choiceTrainings(trainState, beforeTrainState, trainState.trainings, log, text, scanner, rand);
                            }

                        case 5:
                            Print.printBigSeparater(isDynamic, text);
                            Print.skipStart(isDynamic, text);
                            Print.println(Color.gray.toColor("表示中にEnterで早送りできます"), isDynamic, Print.highSpeed, text);
                            Print.skipEnd(isDynamic, text);
                            Print.println("", isDynamic, Print.highSpeed, text);
                            Print.println("", isDynamic, Print.highSpeed, text);
                            Print.changeFontSizeStart(4, isDynamic, text);
                            switch(trainStateNB[0].getSavedLocation(LocationCategory.scenario)){
                                case LocationCategory.NO_CHOICE:
                                    Print.println("？？？「…！」" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                    
                                    Print.changeFontSizeEnd(isDynamic, text);
                                    Print.printBigSeparater(isDynamic, text);
                                    trainState.saveLocation(LocationCategory.scenario, LocationCategory.NO_CHOICE);
                                    trainState.saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                                    Print.changeWaitTextToLT(text);
                                    return choiceList;

                                default:
                                    Print.changeFontSizeEnd(isDynamic, text);
                                    System.out.println("error scenario 1-3");
                                    trainState.saveLocation(LocationCategory.scenario, LocationCategory.NO_CHOICE);
                                    trainState.saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                                    return choiceTrainings(trainState, beforeTrainState, trainState.trainings, log, text, scanner, rand);
                            }

                        default:
                            trainState.saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                            return choiceTrainings(trainState, beforeTrainState, trainState.trainings, log, text, scanner, rand);
                            
                    }
                }else{
                    trainState.saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                    return choiceTrainings(trainState, beforeTrainState, trainState.trainings, log, text, scanner, rand);
                }

            case EXPLAIN:
                if(trainState.provisionalTimeFrame == TimeFrame.nextTurn || CardWithParams.sumSpendAction(Card.remainingCards(hands, choiceList)) == 0){
                    if(CardWithParams.sumSpendAction(hands) == 0){
                        Print.println("手札の行動出来るカードが 0枚になってしまった", true, Print.highSpeed, text);
                        Print.println("特別に手札が追加された", true, Print.highSpeed, text);
                        Print.changeWaitTextToLT(text);
                        trainState.getHands().addAll(CardWithParams.changeCardToCardWithParams(trainState, trainState.getHands(), CardWithParams.takeCard(CardWithParams.startHand), false));
                        return choiceList;
                    }
                    trainState.provisionalTimeFrame = trainState.getMode().timeFrameList.get(0);
                    trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, LocationCategory.FINISH);
                    // 選んだ選択肢を手札から削除
                    List<Integer> sortIndexList = CardWithParams.indexList(choiceList);
                    Collections.sort(sortIndexList, Collections.reverseOrder());
                    for(int idx : sortIndexList){
                        trainStateNB[0].getHands().remove(idx);
                    }
                    return choiceList;
                }
                Print.displayTrainStatusCustom(trainStateNB[0], true, text);
                TrainStatus beforeTrainMenu;
                boolean choiced = false;
                int choicedTime;
                if(self.getSkill() == Skill.zeroInn){
                    if(CardWithParams.containsIndex(choiceList, 0)){
                        choiced = true;
                        CardWithParams card = CardWithParams.getFromIndex(choiceList, 0);
                        choicedTime = choiceList.indexOf(card);
                        beforeTrainMenu = trainState.getProvisionalBeforeTrainMenu(choicedTime);
                    }else{
                        beforeTrainMenu = trainState.getProvisionalBeforeTrainMenu();
                        choicedTime = -1;
                    }
                    Print.print("0:", Print.highSpeed, text);
                    boolean isNew = false;
                    RestMenu.maintenance.miniExplain(trainStateNB[0], new ArrayList<>(), trainState.provisionalTimeFrame, beforeTrainMenu, choiced, choicedTime, isNew, log, text, rand);
                }
                // 手札の表示開始
                Print.setFrameStart(text);
                Print.startTable(text);
                int leftNum = 0;
                TimeFrame cardTimeFrame;
                boolean[] skipLR = new boolean[]{false, false};
                int[] countLR = new int[]{0, 0};
                for (int i = 0; i < trainMenuNum; i++) {
                    leftNum++;
                    if(CardWithParams.cardsSize(hands.subList(0, leftNum)) >= Card.maxHandNum / 2){
                        break;
                    }
                }
                out:
                for (int non = 0; non < 100; non++) {// 無限ループで良いが、何かあった時の為に100で止める
                    Print._startTableRow(false, text);
                    for(int i = 0; i < 2; i++){
                        if(!skipLR[i]){
                            int id;
                            if(i == 0){
                                id = countLR[0];
                                if(id >= leftNum){
                                    Print._endTableRow(text);
                                    break out;
                                }
                            }else{// i == 1
                                id = countLR[1] + leftNum;
                                if(id >= hands.size()){
                                    Print._endTableRow(text);
                                    continue out;
                                }
                            }
                            if(hands.get(id).card.getCardSize() == 2){
                                Print._startTableDataDoubleVertical(false, text);
                                skipLR[i] = true;
                            }else{
                                Print._startTableData(false, text);
                            }
                            choiced = false;
                            if(CardWithParams.containsIndex(choiceList, id)){
                                choiced = true;
                                CardWithParams card = CardWithParams.getFromIndex(choiceList, id);
                                choicedTime = choiceList.indexOf(card);
                                beforeTrainMenu = trainState.getProvisionalBeforeTrainMenu(choicedTime);
                                cardTimeFrame = trainState.getMode().timeFrameList.get((CardWithParams.sumSpendAction(choiceList.subList(0, choicedTime))));
                            }else{
                                choicedTime = -1;
                                beforeTrainMenu = trainState.getProvisionalBeforeTrainMenu();
                                cardTimeFrame = trainState.provisionalTimeFrame;
                            }
                            if(choiced){
                                Print.print(Color.yellow.toColor((id + 1) + ": "), Print.highSpeed, text);
                            }else if(!hands.get(id).card.getLegal(trainStateNB[0], cardTimeFrame, trainStateNB[0].getMode())){
                                Print.print(Color.gray.toColor((id + 1) + ": "), Print.highSpeed, text);
                            }else{
                                Print.print((id + 1) + ": ", Print.highSpeed, text);
                            }
                            hands.get(id).card.miniExplain(trainStateNB[0], hands.get(id).unlimitTrainLimitation, cardTimeFrame, beforeTrainMenu, choiced, choicedTime, hands.get(id).isNew, log, text, rand);
                            Print._endTableData(text);
                            countLR[i]++;
                        }else{
                            skipLR[i] = false;
                        }
                    }
                    Print._endTableRow(text);
                }
                Print.endTable(text);

        
                
                // Print.println("<br>====================================================================================================================================", Print.highSpeed, text);
    
                String shopSubText;
                if(!trainState.isUsedShopFirstFree){
                    shopSubText = "初回無料";
                }else if(trainState.isBossRewardShopFree()){
                    shopSubText = "勇者パス: " + trainState.getBossRewardShopFree() + "枚";
                }else{
                    shopSubText = "所持金: " + trainStateNB[0].getSelf().getTrainStatus().get(TrainStatus.money) + " 円";
                }

                Print.printHorizontalLine(false, text);
                Print.print((Card.maxHandNum + 1) + Print.format(": ショップ ( " + shopSubText + " )", 16), Print.highSpeed, text);
                Print.print(Print.space(4, text) + (Card.maxHandNum + 2) + ": デッキ情報 ( " + trainStateNB[0].deck.size() + "枚 )", Print.highSpeed, text);
                Print.print(Print.space(4, text) + (Card.maxHandNum + 3) + ": ステータス詳細", Print.highSpeed, text);
                Print.println(Print.space(4, text) + (Card.maxHandNum + 4) + Print.format(": その他", 18), Print.highSpeed, text);
                Print.setFrameEnd(text);


                Print.skipStart(true, text);
                Print.println(Color.yellow.toColor(trainState.provisionalTimeFrame.jName + "の行動カードを選択してください"), true, Print.highSpeed, text);
                
                if(trainState.provisionalTimeFrame == TimeFrame.night){
                    Print.println(Color.scarlet.toColor("注 : 夜は訓練コストと効果が2倍になります"), true, Print.highSpeed, text);
                }
                Print.skipEnd(true, text);
                // Print.print("現在選択中の選択肢 : ", Print.highSpeed, text);
                // for(int choice : choiceList){
                //     Print.print(choice + "  ", Print.highSpeed, text);
                // }
                // Print.println("<br>", Print.highSpeed, text);
                trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, CHOICE_MENU);
                return choiceList;
                
            case CHOICE_MENU:

                // TODO 正確には指定ターン数になるように行動を選択させなければならない
                // TODO 朝夜をtrainStateからではなくこの内部で判定する
    
                int idx;
                idx = makeAction(trainStateNB[0], trainStateNB[1], scanner, text, rand);
                if(idx == LocationCategory.NO_CHOICE){
                    return choiceList;
                }
                if (trainStateNB[0].getAuto() != Auto.select) {
                    for (int i = 0; i < trainMenuNum; i++) {
                        if (idx == hands.get(i).card.getOrdinalNumber()) {
                            idx = i + 1;
                            break;
                        }
                    }
                }
        
                if(idx == 0 && self.getSkill() != Skill.zeroInn){
                    trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                    return choiceTrainings(trainStateNB[0], trainStateNB[1], choiceList, log, text, scanner, rand);
                }
        
                if (idx < -(Card.maxHandNum + 3) || idx > Card.maxHandNum + 3) {
                    // Print.displayDetailStatus(trainStateNB[0], false, text, scanner);
                    // showActions(trainStateNB[0], text, scanner);
                    // Print.println("", Print.highSpeed, text);
                    // Print.println("", Print.highSpeed, text);
                    Print.displayTrainStatusCustom(trainStateNB[0], true, text);
                    Print.startFrame(false, text);
                    Print.println("その他", Print.highSpeed, text);
                    
                    Print.println("1:オーブセット", Print.highSpeed, text);
                    
                    Print.println("2:タイトルに戻る", Print.highSpeed, text);
                    Print.endFrame(false, text);
                    Print.skipStart(true, text);
                    Print.println(Color.yellow.toColor("選択してください"), true, Print.highSpeed, text);
                    Print.skipEnd(true, text);
                    
                    trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, SHOW_DETAIL);
                    return choiceList;
                }
                if (idx < 0) {
                    if(idx == -(Card.maxHandNum + 1)){
                        Print.println("アイテムを購入", Print.highSpeed, text);
                        Print.println("アイテムの価格は 4 日ごとに上昇する", Print.highSpeed, text);
                        Print.nextLine(scanner, text);
                        trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                        return choiceTrainings(trainStateNB[0], trainStateNB[1], choiceList, log, text, scanner, rand);
                    }else if(idx == -(Card.maxHandNum + 2)){
                        Print.println("現在のデッキの情報を確認出来る", Print.highSpeed, text);
                        Print.nextLine(scanner, text);
                        trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                        return choiceTrainings(trainStateNB[0], trainStateNB[1], choiceList, log, text, scanner, rand);
                    }else if(idx == -(Card.maxHandNum + 3)){
                        Print.println("現在のステータスを確認出来る。次の勇者のステータスも確認できる", Print.highSpeed, text);
                        Print.nextLine(scanner, text);
                        trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                        return choiceTrainings(trainStateNB[0], trainStateNB[1], choiceList, log, text, scanner, rand);
                    }else if(-trainMenuNum <= idx){
                        trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN_CARD);
                        trainStateNB[0].saveLocation(LocationCategory.explainCardCategory, -idx - 1);
                        Print.displayTrainStatusCustom(trainStateNB[0], true, text);
                        hands.get(-idx - 1).card.explain(trainStateNB[0], hands.get(-idx - 1).unlimitTrainLimitation, trainStateNB[0].provisionalTimeFrame, text, scanner);
                        if(trainStateNB[0].getSavedLocation(LocationCategory.explainCard) == LocationCategory.FINISH){
                            trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                            trainStateNB[0].saveLocation(LocationCategory.explainCardCategory, LocationCategory.NO_CHOICE);
                            return choiceTrainings(trainStateNB[0], trainStateNB[1], choiceList, log, text, scanner, rand);
                        }
                        return choiceList;

                    }else{
                        System.out.println("正しく入力してください");
                        Print.nextLine(scanner, text);
                        trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                        return choiceTrainings(trainStateNB[0], trainStateNB[1], choiceList, log, text, scanner, rand);
                    }
                }
                
                if(idx == 0 && self.getSkill() == Skill.zeroInn){//宿屋
                    if(CardWithParams.containsIndex(choiceList, idx-1)){
                        Print.println("選択を解除した", true, Print.highSpeed, text);
                        
                        CardWithParams.removeFromIndex(choiceList, idx-1);
                        Print.nextLine(scanner, text);
                        trainStateNB[0].provisionalTimeFrame = TimeFrame.returnBackTimeFrame(trainStateNB[0].provisionalTimeFrame, trainState.getMode(), RestMenu.maintenance.spendActionNum);
                        trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                        return choiceTrainings(trainState, beforeTrainState, choiceList, log, text, scanner, rand);
                    }else if(RestMenu.maintenance.getLegal(trainState, trainStateNB[0].provisionalTimeFrame, trainState.getMode())){
                        choiceList.add(new CardWithParams(idx-1, RestMenu.maintenance, new ArrayList<>(), false));
                        trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, CHOICE_MENU_FINAL_CHECK_EXPLAIN);
                        return choiceTrainings(trainState, beforeTrainState, choiceList, log, text, scanner, rand);
                    }else{
                        System.out.println("その手札は選択出来ません");
                        Print.nextLine(scanner, text);
                        trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                        return choiceTrainings(trainState, beforeTrainState, choiceList, log, text, scanner, rand);
                    }
                }else if(idx == Card.maxHandNum + 1){//アイテム
                    trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, ITEM);
                    item(trainStateNB[0], trainStateNB[1], log, text, scanner, rand);
                    return choiceList;
                }else if(idx == Card.maxHandNum + 2){//デッキ
                    Print.displayTrainStatusCustom(trainStateNB[0], true, text);
                    Print.displayDeck(trainState, text);
                    Print.nextLine(scanner, text);
                    Print.changeWaitTextToLT(text);
                    trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                    return choiceList;
                }else if(idx == Card.maxHandNum + 3){//ステータス
                    Print.displayTrainStatusCustom(trainStateNB[0], true, text);
                    boolean isTrainState = true;
                    boolean isDynamic = false;
                    boolean isFreeWidthFrame = false;
                    Print.displayDoubleCharacterStatus(trainState, trainState.getBoss(), isTrainState, isDynamic, isFreeWidthFrame, text, scanner);
                    Print.nextLine(scanner, text);
                    Print.changeWaitTextToLT(text);
                    trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                    return choiceList;
                }else if(idx <= trainMenuNum){
                    CardWithParams cardWithParams = hands.get(idx - 1);
                    if(CardWithParams.containsIndex(choiceList, idx - 1)){
                        Print.println("選択を解除した", true, Print.highSpeed, text);
                        
                        CardWithParams.removeFromIndex(choiceList, idx-1);
                        Print.nextLine(scanner, text);
                        trainStateNB[0].provisionalTimeFrame = TimeFrame.returnBackTimeFrame(trainStateNB[0].provisionalTimeFrame, trainState.getMode(), cardWithParams.card.getSpendActionNum());
                        trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                        return choiceTrainings(trainState, beforeTrainState, choiceList, log, text, scanner, rand);
                    }else if(cardWithParams.card.getLegal(trainState, trainStateNB[0].provisionalTimeFrame, trainState.getMode())){
                        choiceList.add(new CardWithParams(idx-1, cardWithParams.card, cardWithParams.unlimitTrainLimitation, cardWithParams.isNew));
                        trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, CHOICE_MENU_FINAL_CHECK_EXPLAIN);
                        return choiceTrainings(trainState, beforeTrainState, choiceList, log, text, scanner, rand);
                    }else{
                        System.out.println("その行動は選択できません");
                        Print.nextLine(scanner, text);
                        trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                        return choiceTrainings(trainState, beforeTrainState, choiceList, log, text, scanner, rand);
                    }
                } else{
                    Print.println("正しく入力してください", true, Print.highSpeed, text);
                    trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                    return choiceTrainings(trainState, beforeTrainState, choiceList, log, text, scanner, rand);
                }

            case CHOICE_MENU_FINAL_CHECK_EXPLAIN:
                choicedCard = choiceList.get(choiceList.size() - 1);
                Print.displayTrainStatusCustom(trainStateNB[0], true, text);
                choicedCard.card.explain(trainState, choicedCard.unlimitTrainLimitation, trainStateNB[0].provisionalTimeFrame, text, scanner);
                Print.println("", Print.highSpeed, text);
                Print.println("", Print.highSpeed, text);
                Print.println("Enter:決定 1:キャンセル", Print.highSpeed, text);
                Print.changeWaitTextToLT(text);
                trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, CHOICE_MENU_FINAL_CHECK);
                return choiceList;
            
            case CHOICE_MENU_FINAL_CHECK:
                idx = trainState.takeNextAction();
                if(idx == 0){
                    choicedCard = choiceList.get(choiceList.size() - 1);
                    trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                    trainStateNB[0].provisionalTimeFrame = TimeFrame.returnNextTimeFrame(trainStateNB[0].provisionalTimeFrame, trainState.getMode(), choicedCard.card.getSpendActionNum());
                    return choiceTrainings(trainState, beforeTrainState, choiceList, log, text, scanner, rand);
                }else if(idx == 1){
                    choicedCard = choiceList.get(choiceList.size() - 1);
                    Print.println("選択を解除した", true, Print.highSpeed, text);
                    
                    choiceList.remove(choicedCard);
                    Print.nextLine(scanner, text);
                    trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                    return choiceTrainings(trainState, beforeTrainState, choiceList, log, text, scanner, rand);
                }else{
                    trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, CHOICE_MENU_FINAL_CHECK_EXPLAIN);
                    return choiceTrainings(trainState, beforeTrainState, choiceList, log, text, scanner, rand);
                }

            case SHOW_DETAIL:
                
                int act = trainStateNB[0].takeNextAction();
                switch (act) {
                    case 1:
                        trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, CHANGE_SPELL);
                        InputAction.changeSpell(self, text, scanner);
                        return choiceList;

                    case 2:
                        Print.displayTrainStatusCustom(trainStateNB[0], true, text);
                        Print.startFrame(false, text);
                        Print.println("本当にタイトルに戻りますか？", false, Print.lowSpeed, text);
                        Print.println(Color.scarlet.toColor("※セーブされていない内容は失われます"), false, Print.lowSpeed, text);
                        Print.println("Enter:はい" + Print.space(2, text) + "1:いいえ", false, Print.lowSpeed, text);
                        Print.changeWaitTextToLT(text);
                        Print.endFrame(false, text);
                        trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, GIVEUP);
                        return choiceList;
                }
                trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                return choiceTrainings(trainState, beforeTrainState, choiceList, log, text, scanner, rand);

            case CHANGE_SPELL:
                trainState.sendNextActionToSelf();
                InputAction.changeSpell(self, text, scanner);
                if(self.getSavedLocation(LocationCategory.changeSpell) == LocationCategory.FINISH){
                    self.saveLocation(LocationCategory.changeSpell, LocationCategory.NO_CHOICE);
                    trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                    return choiceTrainings(trainState, beforeTrainState, choiceList, log, text, scanner, rand);
                }
                return choiceList;
            
            case SAVE:
                save(trainStateNB[0], false, text, scanner);
                if(trainStateNB[0].getSavedLocation(LocationCategory.save) == LocationCategory.FINISH){
                    trainStateNB[0].saveLocation(LocationCategory.save, LocationCategory.NO_CHOICE);
                    trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                    Print.nextLine(scanner, text);
                    return choiceTrainings(trainState, beforeTrainState, choiceList, log, text, scanner, rand);
                }
                if(trainStateNB[0].getSavedLocation(LocationCategory.save) == LocationCategory.EXIT){
                    trainStateNB[0].saveLocation(LocationCategory.save, LocationCategory.NO_CHOICE);
                    trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                    Print.nextLine(scanner, text);
                    System.exit(0);
                }
                return choiceList;

            case GIVEUP:
                if(makeAction(trainState, beforeTrainState, scanner, text, rand) == 0){
                    CalculateDamage.trainDamage(trainStateNB[0].getSelf(), TrainStatus.maxHp, 100, false);
                    trainStateNB[0].noResuscitate();
                    trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, LocationCategory.FINISH);
                    trainStateNB[0].saveLocation(LocationCategory.returnGameMenu, LocationCategory.TRUE);
                    return choiceList;
                }
                trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                Print.nextLine(scanner, text);
                return choiceTrainings(trainState, beforeTrainState, choiceList, log, text, scanner, rand);

            case SET_PASSIVE_ITEM:
                BattleItem.setPassiveItem(trainStateNB, scanner, text, rand);
                if(trainStateNB[0].getSavedLocation(LocationCategory.setPassiveItem) == LocationCategory.FINISH){
                    trainStateNB[0].saveLocation(LocationCategory.setPassiveItem, LocationCategory.NO_CHOICE);
                    trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                    return choiceTrainings(trainState, beforeTrainState, choiceList, log, text, scanner, rand);
                }
                return choiceList;

            case EXPLAIN_CARD:
                CardWithParams card = trainStateNB[0].getHands().get(trainStateNB[0].getSavedLocation(LocationCategory.explainCardCategory));
                Print.displayTrainStatusCustom(trainStateNB[0], true, text);
                card.card.explain(trainStateNB[0], card.unlimitTrainLimitation, trainStateNB[0].provisionalTimeFrame, text, scanner);
                if(trainStateNB[0].getSavedLocation(LocationCategory.explainCard) == LocationCategory.FINISH){
                    trainStateNB[0].saveLocation(LocationCategory.explainCard, LocationCategory.NO_CHOICE);
                    trainStateNB[0].saveLocation(LocationCategory.explainCardCategory, LocationCategory.NO_CHOICE);
                    trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                    Print.nextLine(scanner, text);
                    return choiceTrainings(trainState, beforeTrainState, choiceList, log, text, scanner, rand);
                }
                return choiceList;

            case ITEM:
                item(trainStateNB[0], trainStateNB[1], log, text, scanner, rand);
                if(trainStateNB[0].getSavedLocation(LocationCategory.item) == LocationCategory.FINISH){
                    trainStateNB[0].saveLocation(LocationCategory.item, LocationCategory.NO_CHOICE);
                    trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                    Print.nextLine(scanner, text);
                    return choiceTrainings(trainState, beforeTrainState, choiceList, log, text, scanner, rand);
                }
                return choiceList;

            default:
                System.out.println("error choiceTrainings" + trainStateNB[0].getSavedLocation(LocationCategory.choiceTrainings));
                Print.println("error choiceTrainings" + trainStateNB[0].getSavedLocation(LocationCategory.choiceTrainings), true, 0, true);
                trainStateNB[0].saveLocation(LocationCategory.choiceTrainings, EXPLAIN);
                return choiceTrainings(trainState, beforeTrainState, choiceList, log, text, scanner, rand);
        }
    }


    private static TrainState[] doTrainings(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner,Random rand) {
        TrainState[] trainStateNB = new TrainState[]{trainState, beforeTrainState};

        CardWithParams cardWithIndex;

        final int EXECUTE_CARD_PREPARE = 1;
        final int NO_CARD_TURN_UPDATE = 2;
        final int EXECUTE_CARD = 3;
        final int TURN_UPDATE = 4;
        final int EXPLAIN_RESUSCITSTE = 5;
        final int RESUSCITSTE = 6;
        switch(trainStateNB[0].getSavedLocation(LocationCategory.doTrainings)){
            case LocationCategory.NO_CHOICE:
                trainStateNB[0].drawTrainResult(rand);
                trainStateNB[0].setBeforeTrainStatus();
                trainStateNB[0].saveLocation(LocationCategory.doTrainings, EXECUTE_CARD_PREPARE);
                Print.printHorizontalLine(true, text);
                Print.skipStart(true, text);
                Print.println(Color.gray.toColor("表示中にEnterで早送りできます"), true, Print.highSpeed, text);
                Print.skipEnd(true, text);
                Print.println("", true, Print.highSpeed, text);
                Print.println("", true, Print.highSpeed, text);
                return doTrainings(trainStateNB[0], trainStateNB[1], log, text, scanner, rand);


            case EXECUTE_CARD_PREPARE:
                if(trainStateNB[0].isEnd()){
                    trainStateNB[0].saveLocation(LocationCategory.doTrainings, LocationCategory.FINISH);
                    return trainStateNB;
                }
                if(trainStateNB[0].trainings.size() == 0){
                    if(trainStateNB[0].getTimeFrame() != trainStateNB[0].getMode().timeFrameList.get(0)){
                        trainStateNB[0].saveLocation(LocationCategory.doTrainings, NO_CARD_TURN_UPDATE);
                        return doTrainings(trainStateNB[0], trainStateNB[1], log, text, scanner, rand);
                    }
                    trainStateNB[0].saveLocation(LocationCategory.doTrainings, LocationCategory.FINISH);
                    return trainStateNB;
                }
                cardWithIndex = trainStateNB[0].trainings.get(0);
                if(!cardWithIndex.card.getLegal(trainState, trainState.getTimeFrame(), trainState.getMode())){
                    System.out.println("異常な手札が選択されています1");
                    Print.nextLine(scanner, text);
                    trainStateNB[0].trainings.remove(0);
                    return doTrainings(trainStateNB[0], trainStateNB[1], log, text, scanner, rand);
                }
                Print.slowStart(true, text);
                Print.println(cardWithIndex.card.jName() + "を消費した", true, Print.highSpeed, text);
                Print.slowEnd(true, text);
                trainStateNB[0].saveLocation(LocationCategory.doTrainings, EXECUTE_CARD);
                return doTrainings(trainStateNB[0], trainStateNB[1], log, text, scanner, rand);

            case NO_CARD_TURN_UPDATE:
                trainStateNB = turnUpdate(trainStateNB[0], trainStateNB[1], trainStateNB[0].getMode().timeFrameList.size() - trainStateNB[0].getMode().timeFrameList.indexOf(trainStateNB[0].getTimeFrame()), false, log, text,
                scanner, rand, null);// TODO
                if(trainStateNB[0].getSavedLocation(LocationCategory.turnUpDate) == LocationCategory.FINISH){
                    trainStateNB[0].saveLocation(LocationCategory.turnUpDate, LocationCategory.NO_CHOICE);
                    trainStateNB[0].saveLocation(LocationCategory.doTrainings, LocationCategory.FINISH);
                    return trainStateNB;
                }else{
                    return trainStateNB;
                }

            case EXECUTE_CARD:
                cardWithIndex = trainStateNB[0].trainings.get(0);
                trainStateNB = cardWithIndex.card.execute(trainStateNB[0], trainStateNB[1], log, text, scanner, rand);
                cardWithIndex.unlimitTrainLimitation(trainStateNB[0]);
                if(trainStateNB[0].getSavedLocation(LocationCategory.executeCard) == LocationCategory.FINISH){
                    trainStateNB[0].saveLocation(LocationCategory.executeCard, LocationCategory.NO_CHOICE);
                    cardWithIndex.card.addCardToDeckWithExecute(trainStateNB[0], text);
                    trainStateNB[0].addTodaysFinishTrain(cardWithIndex.card);
                    Print.nextLine(scanner, text);
                    if (trainStateNB[0].isEnd()) {
                        Print.printBigSeparater(true, text);
                        Print.slowStart(true, text);
                        Print.println(cardWithIndex.card.jName() + "でHPが 0 になってしまった！", true, Print.highSpeed, text);
                        Print.slowEnd(true, text);
                        
                        if(!trainStateNB[0].getResuscitated()){
                            trainStateNB[0].saveLocation(LocationCategory.doTrainings, EXPLAIN_RESUSCITSTE);
                            return doTrainings(trainStateNB[0], trainStateNB[1], log, text, scanner, rand);
                        }
                    }
                    trainStateNB[0].saveLocation(LocationCategory.doTrainings, TURN_UPDATE);
                    return doTrainings(trainStateNB[0], trainStateNB[1], log, text, scanner, rand);
                }
                return trainStateNB;

            case TURN_UPDATE:
                cardWithIndex = trainStateNB[0].trainings.get(0);
                TrainStatus beforeTrainMenu = null;
                if(cardWithIndex.card instanceof TrainMenu){
                    TrainMenu menu = (TrainMenu)cardWithIndex.card;
                    beforeTrainMenu = (TrainStatus)menu.trainCategory.keySet().toArray()[0];
                }
                trainStateNB = Train.turnUpdate(trainState, beforeTrainState, cardWithIndex.card.getSpendActionNum(), false, log, text,
                scanner, rand, beforeTrainMenu);
                if(trainStateNB[0].getSavedLocation(LocationCategory.turnUpDate) == LocationCategory.FINISH){
                    trainStateNB[0].saveLocation(LocationCategory.turnUpDate, LocationCategory.NO_CHOICE);
                    trainStateNB[0].saveLocation(LocationCategory.doTrainings, EXECUTE_CARD_PREPARE);
                    trainStateNB[0].trainings.remove(0);
                    return doTrainings(trainStateNB[0], trainStateNB[1], log, text, scanner, rand);
                }else{
                    return trainStateNB;
                }

            case EXPLAIN_RESUSCITSTE:
                Print.clearStaticText(text);
                Print.println("復活のお守りを消費して復活出来ます。復活しますか？", true, Print.middleSpeed, text);
                Print.println("", true, Print.middleSpeed, text);
                Print.println("Enter:はい" + Print.space(2, text) + "1:いいえ", true, Print.middleSpeed, text);
                Print.changeWaitTextToLT(text);
                trainStateNB[0].saveLocation(LocationCategory.doTrainings, RESUSCITSTE);
                return trainStateNB;

            case RESUSCITSTE:
                int act = trainState.takeNextAction();
                if(act == 0){
                    trainStateNB[0].resuscitate(true, text);
                }else if(act == 1){
                    trainStateNB[0].noResuscitate();
                }else{
                    trainStateNB[0].saveLocation(LocationCategory.doTrainings, EXPLAIN_RESUSCITSTE);
                    return doTrainings(trainStateNB[0], trainStateNB[1], log, text, scanner, rand);
                }
                trainStateNB[0].saveLocation(LocationCategory.doTrainings, TURN_UPDATE);
                return doTrainings(trainStateNB[0], trainStateNB[1], log, text, scanner, rand);
                

            default:
                System.out.println("error doTrainings");

        }
        return trainStateNB;
    }

    public static TrainState battle(TrainState trainState, TrainState beforeTrainState, Enemy enemy, boolean event, TrainTemporaryLog log,
            boolean text, Scanner scanner, Random rand) {
        
        Player self;

        final int NORMAL_BATTLE = 1;
        final int SKIP_BATTLE = 2;
        final int AFTER_BATTLE_ONE = 3;
        final int RESUSCITATE = 4;
        final int AFTER_BATTLE_TWO = 5;
        final int IS_CHANGE_SPELL = 6;
        final int CHANGE_SPELL = 7;
        switch(trainState.getSavedLocation(LocationCategory.battleInTrain)){
            case LocationCategory.NO_CHOICE:
                trainState.getSelf().trainToBattleStatus();
                if (trainState.getBattleAuto() != Auto.playout) {
                    trainState.battleState = new State(trainState.getSelf(), enemy, trainState.getBattleAuto(), enemy.auto);
                    ChangeBattleStatus.reset(trainState.battleState);
                    trainState.saveLocation(LocationCategory.battleInTrain, NORMAL_BATTLE);
                    Print.slowStart(false, text);
                }else{
                    trainState.saveLocation(LocationCategory.battleInTrain, SKIP_BATTLE);
                }
                return battle(trainState, beforeTrainState, enemy, event, log, text, scanner, rand);

            case NORMAL_BATTLE:
                trainState.sendNextActionToBattleState();
                State battleState = Battle.battle(trainState.battleState, text, scanner, rand, -123);// 〇〇は倒れたを入れる
                Print.slowEnd(false, text);
                trainState.battleState = battleState;
                if(battleState.getSavedLocation(LocationCategory.battle) != LocationCategory.FINISH){
                    return trainState;
                }
                battleState.saveLocation(LocationCategory.battle, LocationCategory.NO_CHOICE);
                boolean isDynamic = true;
                Print.println("", isDynamic, Print.highSpeed, text);
                if(trainState.getSavedLocation(LocationCategory.turnUpDate) != LocationCategory.NO_CHOICE){
                    if(battleState.getPlayer2().getMainStatus().get(MainStatus.hp) <= 0){
                        Print.println(Color.blue.toColor(Print.sleepEachCharacter(battleState.getPlayer2().getJName() + "は倒れた！！", 5)) + Print.sleep(15), isDynamic, Print.highSpeed, text);
                        
                    }else if(battleState.getPlayer1().getMainStatus().get(MainStatus.hp) <= 0){
                        Print.println(battleState.getPlayer1().getJName() + "は倒れた！" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                        
                    }
                }else{
                    for(Character chara : new Character[]{battleState.getPlayer1(), battleState.getPlayer2()}){
                        if(chara.getMainStatus().get(MainStatus.hp) <= 0){
                            Print.println(chara.getJName() + "は倒れた！" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                            
                        }
                    }
                }
                Print.printBigSeparater(true, text);
                Print.changeWaitTextToLT(text);
                // if (event) {
                //     log.setEventBattleLog(battleLog);
                // } else {
                //     log.setBattleLog(battleLog);
                // }
                // State state = battleLog.endState.modifiableCopy();
                // self = new Player(state.getPlayer1(), self);
                self = (Player) battleState.getPlayer1();
                trainState.setSelf(self);
                enemy = (Enemy) battleState.getPlayer2();
                if (battleState.getP1Escape() || battleState.getP2Escape()) {
                    self.battleToTrainStatus();
                    trainState.saveLocation(LocationCategory.battleInTrain, LocationCategory.FINISH);
                    trainState.battleState = null;
                    return trainState;
                }
                trainState.saveLocation(LocationCategory.battleInTrain, AFTER_BATTLE_ONE);
                return trainState;

            case SKIP_BATTLE:
                self = trainState.getSelf();
                if (trainState.getSelf().generalPower(false) * rand.nextDouble() < enemy.generalPower(true) * 0.1) {
                    Map<MainStatus, Integer> mainStatus = self.getMainStatus();
                    mainStatus.replace(MainStatus.hp, 0);
                    self.setMainStatus(mainStatus);
                    self.battleToTrainStatus();
                }
                trainState.setSelf(self);
                trainState.saveLocation(LocationCategory.battleInTrain, AFTER_BATTLE_ONE);
                return battle(trainState, beforeTrainState, enemy, event, log, text, scanner, rand);

            case AFTER_BATTLE_ONE:
                self = trainState.getSelf();
                enemy = (Enemy)trainState.battleState.getPlayer2();
                if (self.getMainStatus().get(MainStatus.hp) <= 0) {
                    Print.nextLine(scanner, text);
                    if (!trainState.getResuscitated()) {
                        // Print.println("育成中1度だけ復活出来ます。復活して同じ敵と戦います", Print.middleSpeed, text);
                        // Print.nextLine(scanner, text);
                        // trainState.resuscitate(false, text);
                        // trainState.saveLocation(LocationCategory.battleInTrain, LocationCategory.NO_CHOICE);
                        // return battle(trainState, beforeTrainState, enemy, event, log, text, scanner, rand);
                        Print.println("復活のお守りを消費して復活出来ます。復活して同じ敵と戦いますか？", true, Print.middleSpeed, text);
                        
                        Print.println("", true, Print.highSpeed, text);
                        
                        Print.println("Enter:はい  1:いいえ", true, Print.highSpeed, text);
                        Print.changeWaitTextToLT(text);
                        
                        trainState.saveLocation(LocationCategory.battleInTrain, RESUSCITATE);
                        return trainState;
                    }
                    // trainStateに保存
                    self.battleToTrainStatus();
                    trainState.setSelf(self);
                    /*
                    * if(!event){ 多分ここいらない
                    * trainState.setSelf(self);
                    * trainState = turnUpdate(trainState, trainStateCopy, log, text, scanner, rand,
                    * null);
                    * self = trainState.getSelf();
                    * }
                    */
                    trainState.saveLocation(LocationCategory.battleInTrain, LocationCategory.FINISH);
                    trainState.battleState = null;
                    return trainState;
                }
                
                self.battleToTrainStatus();
                CalculateDamage.trainDamage(self, TrainStatus.money, -enemy.money, false);
                if(enemy.money != 0){
                    Print.println((int)(enemy.money) + "円手に入れた！", true, Print.middleSpeed, text);
                }
                if(trainState.getSavedLocation(LocationCategory.turnUpDate) != LocationCategory.NO_CHOICE){
                    Print.println("勇者パスを手に入れた！", true, Print.highSpeed, text);
                    
                    trainState.winBossRewardShopFree();
                }
                Spell lastSpell = enemy.getLastSpell();
                boolean learned = false;
                if (lastSpell != Spell.NULL) {
                    Print.println("★ ★ ★ " + lastSpell.jName + "のオーブを拾った！" + " ★ ★ ★" + Print.sleep(5), true, Print.middleSpeed, text);
                    if(Spell.strengthenSpellCategory().containsKey(lastSpell)){
                        List<Spell> strengthenSpells = Spell.strengthenSpellCategory().get(lastSpell);
                        for(Spell spell : strengthenSpells){
                            if(self.getLearnedSpellLevel().containsKey(spell)){
                                learned = true;
                                if(strengthenSpells.indexOf(spell) != strengthenSpells.size() - 1){
                                    ImmediateItem.strengthenSpell(self, spell, strengthenSpells.get(strengthenSpells.indexOf(spell) + 1));
                                    Print.println(spell.jName + "が" + strengthenSpells.get(strengthenSpells.indexOf(spell) + 1).jName + "に強化された！！" + Print.sleep(10), true, Print.highSpeed, text);
                                    
                                }else{
                                    Print.println(spell.jName + "の呪文は既に極め切っている", true, Print.highSpeed, text);
                                    
                                }
                                break;
                            }
                        }
                    }
                    if(!learned){
                        Map<Spell, Integer> spellLevel = self.getSpellLevel();
                        int nowSpellLevel = spellLevel.get(lastSpell);
                        if (nowSpellLevel < Spell.maxLevel) {
                            spellLevel.replace(lastSpell, nowSpellLevel + 1);
                            if(nowSpellLevel == 0){
                                Print.println("オーブをセットしますか", true, Print.highSpeed, text);
                                
                                Print.skipStart(true, text);
                                Print.println(Color.scarlet.toColor("※ オーブはスロットにセットしないと呪文を使えません"), true, Print.highSpeed, text);
                                Print.skipEnd(true, text);
                                
                                Print.println("", true, Print.highSpeed, text);
                                
                                Print.println("Enter:はい" + Print.space(2, text) + "1:いいえ", true, Print.highSpeed, text);
                                Print.changeWaitTextToLT(text);
                                
                                trainState.setSelf(self);
                                trainState.saveLocation(LocationCategory.battleInTrain, IS_CHANGE_SPELL);
                                return trainState;
                            }else{
                                Print.println(lastSpell.jName + "のレベルが増加した", true, Print.middleSpeed, text);
                                
                            }
                        }
                    }
                }
                trainState.setSelf(self);
                trainState.saveLocation(LocationCategory.battleInTrain, AFTER_BATTLE_TWO);
                return battle(trainState, beforeTrainState, enemy, event, log, text, scanner, rand);

            case AFTER_BATTLE_TWO:
                trainState.saveLocation(LocationCategory.battleInTrain, LocationCategory.FINISH);
                return trainState;

            case RESUSCITATE:
                int act = trainState.takeNextAction();
                if (act == 0) {
                    trainState.resuscitate(false, text);
                    trainState.saveLocation(LocationCategory.battleInTrain, LocationCategory.NO_CHOICE);
                    // battleToTrainStatus前なのでそのまま入れてOK
                    return battle(trainState, beforeTrainState, enemy, event, log, text, scanner, rand);
                }else if(act != 1){
                    Print.println("正しく入力してください", true, Print.highSpeed, true);
                    Print.changeWaitTextToLT(text);

                    return trainState;
                }
                Print.println("復活しなかった", true, Print.highSpeed, text);
                
                trainState.noResuscitate();
                trainState.getSelf().battleToTrainStatus();
                Print.nextLine(scanner, text);
                trainState.saveLocation(LocationCategory.battleInTrain, LocationCategory.FINISH);
                trainState.battleState = null;
                return trainState;
            
            case IS_CHANGE_SPELL:
                if (trainState.getAuto() == Auto.select && trainState.takeNextAction() == 0) {
                    trainState.saveLocation(LocationCategory.battleInTrain, CHANGE_SPELL);
                }else{
                    trainState.saveLocation(LocationCategory.battleInTrain, AFTER_BATTLE_TWO);
                }
                return battle(trainState, beforeTrainState, enemy, event, log, text, scanner, rand);

            case CHANGE_SPELL:
                trainState.sendNextActionToSelf();
                self = trainState.getSelf();
                InputAction.changeSpell(self, text, scanner);
                if(self.getSavedLocation(LocationCategory.changeSpell) == LocationCategory.FINISH){
                    self.saveLocation(LocationCategory.changeSpell, LocationCategory.NO_CHOICE);
                    trainState.setSelf(self);
                    trainState.saveLocation(LocationCategory.battleInTrain, AFTER_BATTLE_TWO);
                    return battle(trainState, beforeTrainState, enemy, event, log, text, scanner, rand);
                }
                trainState.setSelf(self);
                return trainState;
        }
        return trainState;
    }

    private static void item(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner, Random rand) {
        final int CHOICE_USE = 1;
        final int SHOP = 2;
        final int USE_ITEM = 3;
        switch(trainState.getSavedLocation(LocationCategory.item)){
            case LocationCategory.NO_CHOICE:
                trainState.saveLocation(LocationCategory.item, SHOP);
                item(trainState, beforeTrainState, log, text, scanner, rand);
                return;
                // Print.println("", Print.highSpeed, text);
                // Print.println("所持金 : " + trainState.getSelf().getTrainStatus().get(TrainStatus.money) + "円", Print.highSpeed, text);
                // Print.println("", Print.highSpeed, text);
                // Print.println("1:" + TrainTurnAction.buyItem.jName + "  2:" + TrainTurnAction.useItem.jName, Print.highSpeed,
                //         text);
                // trainState.saveLocation(LocationCategory.item, CHOICE_USE);
                // return;

            case CHOICE_USE:
                int act = makeAction(trainState, beforeTrainState, scanner, text, rand);
                switch (act) {
                    case 0:
                        trainState.saveLocation(LocationCategory.item, LocationCategory.FINISH);
                        return;
                    case 1:
                        trainState.saveLocation(LocationCategory.item, SHOP);
                        shop(trainState, beforeTrainState, log, text, scanner, rand);
                        return;
                    case 2:
                        trainState.saveLocation(LocationCategory.item, USE_ITEM);
                        useItem(trainState, beforeTrainState, text, scanner, rand);
                        return;
                    default:
                        System.out.println("正しく入力してください3");
                        Print.nextLine(scanner, text);
                        trainState.saveLocation(LocationCategory.item, LocationCategory.FINISH);
                        return;
                }

            case SHOP:
                shop(trainState, beforeTrainState, log, text, scanner, rand);
                if(trainState.getSavedLocation(LocationCategory.shopStep) == LocationCategory.FINISH){
                    trainState.saveLocation(LocationCategory.shopStep, LocationCategory.NO_CHOICE);
                    trainState.saveLocation(LocationCategory.item, LocationCategory.FINISH);
                }
                return;
            case USE_ITEM:
                useItem(trainState, beforeTrainState, text, scanner, rand);
                if(trainState.getSavedLocation(LocationCategory.useItemStep) == LocationCategory.FINISH){
                    trainState.saveLocation(LocationCategory.useItemStep, LocationCategory.NO_CHOICE);
                    trainState.saveLocation(LocationCategory.item, LocationCategory.FINISH);
                }
                return;
            default:
                System.out.println("error item");
                trainState.saveLocation(LocationCategory.item, LocationCategory.FINISH);
                return;
        }
    }

    public static void shop(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner,Random rand) {
        int idx, num, cost;
        Item item;
        Player self = trainState.getSelf();
        double inflation = Item.inflationCoef(trainState.getTurn());
        boolean isDynamic = false;
        final int CHOICE_ITEM = 1;
        final int CHOICE_NUM = 2;
        final int IS_CHANGE_SPELL = 3;
        final int CHANGE_SPELL = 4;
        switch(trainState.getSavedLocation(LocationCategory.shopStep)){
            case LocationCategory.NO_CHOICE:
                //TODO ショップを統合したい
                Print.tempSlowLiftStart(true, text);
                Print.displayTrainStatusCustom(trainState, false, text);
                
                Print.startFrame(isDynamic, text);
                Print.skipStart(true, text);
                Print.println(Color.yellow.toColor("購入するものを選択してください"), true, Print.highSpeed, text);
                
                Print.println(Color.scarlet.toColor("注: 2ターンごとに物価が上昇します"), true, Print.highSpeed, text);
                Print.skipEnd(true, text);
                Print.println("現在の所持金 : " + self.getTrainStatus().get(TrainStatus.money) + " 円", isDynamic, Print.highSpeed, text);
                Print.println("", isDynamic, Print.highSpeed, text);
                // Print.println("<br>永続アイテム<br>", Print.highSpeed, text);
                Print.startTable(isDynamic, text);
                for (int i = 0; i < Item.shopNUM(trainState, Shop.Normal, trainState.getMode()); i++) {
                    Print.startRow(isDynamic, text);
                    item = Item.shopItemList(trainState, Shop.Normal).get(i);
                    /*
                    * if(trainState.getMode() == Mode.easy){
                    * if(trainState.getTurn() < 4 && item instanceof ImmediateItem){
                    * continue;
                    * }else if(trainState.getTurn() < 7 && item instanceof BattleItem){
                    * continue;
                    * }else if(trainState.getTurn() <= 10 && item instanceof DisposableItem){
                    * continue;
                    * }
                    * }
                    */
                    if (!trainState.getBuyAble().get(item)
                            || (item instanceof ImmediateItem && !((ImmediateItem) item).useAble(trainState))) {
                        Print.println((i + 1) + ":うりきれ", isDynamic, Print.highSpeed, text);
                    } else {
                        if(item.getDoInflate()){
                            cost = (int)Math.round(item.getCost(self) * inflation);
                            cost *= trainState.getMode().scale;
                        }else{
                            cost = (int)(item.getCost(self) * Math.pow(4, (trainState.getTurn() - 1) / 8));
                        }
                        if(self.getSkill() == Skill.trader){
                            cost *= 3;
                            cost /= 4;
                        }
                        String costText;
                        if(!item.isAbleFree()){
                            costText = cost + " 円";
                        }else if(!trainState.isUsedShopFirstFree){
                            costText = "初回無料";
                        }else if(trainState.isBossRewardShopFree()){
                            costText = "勇者パス 1枚";
                        }else{
                            costText = cost + " 円";
                        }
                        Print.println((i + 1) + ":" + item.getJName(trainState), isDynamic, Print.highSpeed, text);
                        Print.separateRow(isDynamic, text);
                        Print.println(costText, isDynamic, Print.highSpeed, text);
                        
                    }
                    Print.endRow(isDynamic, text);
                    // if (item instanceof ImmediateItem && i + 1 < Item.shopNUM(trainState, Shop.Normal, trainState.getMode()) && Item.shopItemList(trainState, Shop.Normal).get(i + 1) instanceof DisposableItem) {
                    //     Print.println("<br>消費アイテム<br>", Print.highSpeed, text);
                    // }
                    // if (item instanceof DisposableItem && i + 1 < Item.shopNUM(trainState, Shop.Normal, trainState.getMode()) && Item.shopItemList(trainState, Shop.Normal).get(i + 1) instanceof BattleItem) {
                    //     Print.println("<br>戦闘用アイテム<br>", Print.highSpeed, text);
                    // }
                }
                Print.endTable(isDynamic, text);
                Print.endFrame(isDynamic, text);
                trainState.saveLocation(LocationCategory.shopStep, CHOICE_ITEM);
                return;

            case CHOICE_ITEM:
                idx = makeAction(trainState, beforeTrainState, scanner, text, rand);
                if(idx == 0){
                    Print.clearStaticText(text);
                    Print.tempSlowLiftEnd(true, text);
                    Print.printHorizontalLine(true, text);
                    trainState.saveLocation(LocationCategory.shopStep, LocationCategory.FINISH);
                    return;
                }
                if (idx < -Item.shopNUM(trainState, Shop.Normal, trainState.getMode()) || idx == 0 || idx > Item.shopNUM(trainState, Shop.Normal, trainState.getMode())) {
                    if (idx != 0) {
                        System.out.println("正しく入力してください4");
                    }
                    trainState.saveLocation(LocationCategory.shopStep, LocationCategory.NO_CHOICE);
                    shop(trainState, beforeTrainState, log, text, scanner, rand);
                    return;
                }
                if (idx < 0) {
                    Item.shopItemList(trainState, Shop.Normal).get(-idx - 1).explain(text);
                    Print.nextLine(scanner, text);
                    trainState.saveLocation(LocationCategory.shopStep, LocationCategory.NO_CHOICE);
                    shop(trainState, beforeTrainState, log, text, scanner, rand);
                    return;
                }
                item = Item.shopItemList(trainState, Shop.Normal).get(idx - 1);

                Print.displayTrainStatusCustom(trainState, false, text);
                Print.startFrame(isDynamic, text);
                Print.println(item.getJName(), isDynamic, Print.highSpeed, text);
                item.explain(text);
                Print.endFrame(isDynamic, text);
                Print.println("", isDynamic, Print.highSpeed, text);

                if (!trainState.getBuyAble().get(item)
                        || (item instanceof ImmediateItem && !((ImmediateItem) item).useAble(trainState))) {
                    Print.println("うりきれです", isDynamic, Print.highSpeed, text);
                    trainState.saveLocation(LocationCategory.shopStep, LocationCategory.NO_CHOICE);
                    shop(trainState, beforeTrainState, log, text, scanner, rand);
                    return;
                }

                if (item.getSomeBuyAble() && trainState.isUsedShopFirstFree && !trainState.isBossRewardShopFree()) {
                    Print.println(item.getJName(trainState) + "を何個購入しますか", isDynamic, Print.highSpeed, text);
                    
                    // if(!trainState.isUsedShopFirstFree){
                    //     Print.println(Color.scarlet.toColor("注:初回無料時は 2 個以上を選択できません"), isDynamic, Print.highSpeed, text);
                        
                    // }else if(trainState.isBossRewardShopFree()){
                    //     Print.println(Color.scarlet.toColor("注:勇者パス利用時は 2 個以上を選択できません"), isDynamic, Print.highSpeed, text);
                        
                    // }
                    if (item instanceof DisposableItem) {
                        Print.println("現在の所持個数: " + self.getDisposableItemList().get((DisposableItem) item), isDynamic, Print.highSpeed,
                                text);
                        
                    } else if (item instanceof BattleItem) {
                        Print.println("現在の所持個数: " + self.getItemList().get((BattleItem) item), isDynamic, Print.highSpeed, text);
                        
                    }
                    trainState.saveLocation(LocationCategory.shopStep, CHOICE_NUM);
                    trainState.saveLocation(LocationCategory.buyingItem, idx);
                    return;
                } else {
                    // Print.println(item.getJName(trainState) + "は複数個購入出来ません", isDynamic, Print.highSpeed, text);
                    
                    Print.println("購入しますか?", isDynamic, Print.highSpeed, text);
                    Print.println("", isDynamic, Print.highSpeed, text);
                    Print.println("Enter:はい 1:いいえ", isDynamic, Print.highSpeed, text);
                    Print.changeWaitTextToLT(text);
                    trainState.saveLocation(LocationCategory.shopStep, CHOICE_NUM);
                    trainState.saveLocation(LocationCategory.buyingItem, idx);
                    return;
                }
            
            case CHOICE_NUM:
                boolean buyBaseSpellItem = false;
                item = Item.shopItemList(trainState, Shop.Normal).get(trainState.getSavedLocation(LocationCategory.buyingItem) - 1);
                trainState.saveLocation(LocationCategory.buyingItem, LocationCategory.NO_CHOICE);
                if (item.getSomeBuyAble() && trainState.isUsedShopFirstFree && !trainState.isBossRewardShopFree()) {
                    num = makeAction(trainState, beforeTrainState, scanner, text, rand);
        
                    if(num == 0){
                        Print.println("買わなかった", true, Print.middleSpeed, text);
                        trainState.saveLocation(LocationCategory.shopStep, LocationCategory.NO_CHOICE);
                        shop(trainState, beforeTrainState, log, text, scanner, rand);
                        return;
                    }
        
                    if (num < 0) {
                        Print.println("不正に資金を入手しようとするんじゃありません!", true, Print.middleSpeed, text);
                        trainState.saveLocation(LocationCategory.shopStep, LocationCategory.NO_CHOICE);
                        shop(trainState, beforeTrainState, log, text, scanner, rand);
                        return;
                    }
        
                    if (num > 99) {
                        Print.println("一度に 100 個以上購入することはできません", true, Print.middleSpeed, text);
                        trainState.saveLocation(LocationCategory.shopStep, LocationCategory.NO_CHOICE);
                        shop(trainState, beforeTrainState, log, text, scanner, rand);
                        return;
                    }
        
                    // if(!trainState.isUsedShopFirstFree && num > 1){
                    //     Print.println("初回無料時は 2 個以上を選択できません", true, Print.highSpeed, text);
                    //     trainState.saveLocation(LocationCategory.shopStep, LocationCategory.NO_CHOICE);
                    //     shop(trainState, beforeTrainState, log, text, scanner, rand);
                    //     return;
                    // }else if(trainState.isBossRewardShopFree() && num > 1){
                    //     Print.println("勇者パス利用時は 2 個以上を選択できません", true, Print.highSpeed, text);
                    //     trainState.saveLocation(LocationCategory.shopStep, LocationCategory.NO_CHOICE);
                    //     shop(trainState, beforeTrainState, log, text, scanner, rand);
                    //     return;
                    // }
                } else {
                    if (!(makeAction(trainState, beforeTrainState, scanner, text, rand) == 0)) {
                        trainState.saveLocation(LocationCategory.shopStep, LocationCategory.NO_CHOICE);
                        shop(trainState, beforeTrainState, log, text, scanner, rand);
                        return;
                    }
                    num = 1;
                }

                if(item == ImmediateItem.HPMedicine || item == ImmediateItem.ConMedicine || item == ImmediateItem.MotivMedicine || 
                item == ImmediateItem.labHP || item == ImmediateItem.labCon || item == ImmediateItem.labMoti){
                    int cardSize = 1;
                    if(item == ImmediateItem.labHP || item == ImmediateItem.labCon || item == ImmediateItem.labMoti){
                        cardSize = 2;
                    }
                    if(num * cardSize + CardWithParams.cardsSize(trainState.getHands()) > Card.maxHandNum){
                        Print.println("手札の枚数上限を超えたアイテムカードの購入は出来ません (手札上限枚数 : " + Card.maxHandNum + " )", true, Print.middleSpeed, text);
                        trainState.saveLocation(LocationCategory.shopStep, LocationCategory.NO_CHOICE);
                        shop(trainState, beforeTrainState, log, text, scanner, rand);
                        return;
                    }
                }

                if(item.getDoInflate()){
                    cost = (int) Math.round(item.getCost(self) * inflation) * num;
                    cost *= trainState.getMode().scale;
                }else{
                    cost = (int)(item.getCost(self) * Math.pow(4, (trainState.getTurn() - 1) / 8));
                }
                if(self.getSkill() == Skill.trader){
                    cost *= 3;
                    cost /= 4;
                }
                if(!item.isAbleFree()){
                    
                }else if(!trainState.isUsedShopFirstFree){
                    cost = 0;
                    trainState.isUsedShopFirstFree = true;
                }else if(trainState.isBossRewardShopFree()){
                    cost = 0;
                    trainState.useBossRewardShopFree();
                }
                if (self.getTrainStatus().get(TrainStatus.money) < cost) {
                    Print.println("所持金が足りません", true, Print.middleSpeed, text);
                    Print.nextLine(scanner, text);
                    trainState.saveLocation(LocationCategory.shopStep, LocationCategory.NO_CHOICE);
                    shop(trainState, beforeTrainState, log, text, scanner, rand);
                    return;
                }
        
                CalculateDamage.trainDamage(self, TrainStatus.money, cost, false);
                Print.println(cost + " 円になります", true, Print.middleSpeed, text);
                Print.println(item.getJName() + "を購入した", true, Print.middleSpeed, text);
        
                if (item instanceof BattleItem) {
                    if (!log.getBuyB().containsKey((BattleItem) item)) {
                        log.getBuyB().put((BattleItem) item, num);
                    } else {
                        log.getBuyB().replace((BattleItem) item, log.getBuyB().get((BattleItem) item) + num);
                    }
                    self.getItemList().replace((BattleItem) item, self.getItemList().get((BattleItem) item) + num);
                    BattleItem.dromItem(self, trainState.getAuto(), rand, scanner, text);
                }
                if (item instanceof DisposableItem) {
                    if (!log.getBuyD().containsKey((DisposableItem) item)) {
                        log.getBuyD().put((DisposableItem) item, num);
                    } else {
                        log.getBuyD().replace((DisposableItem) item, log.getBuyD().get((DisposableItem) item) + num);
                    }
                    self.getDisposableItemList().replace((DisposableItem) item,
                            self.getDisposableItemList().get((DisposableItem) item) + num);
                }
                if (item instanceof ImmediateItem) {
                    if (!log.getBuyI().containsKey((ImmediateItem) item)) {
                        log.getBuyI().put((ImmediateItem) item, num);
                    } else {
                        log.getBuyI().replace((ImmediateItem) item, log.getBuyI().get((ImmediateItem) item) + num);
                    }
                    for (int i = 0; i < num; i++) {
                        trainState.setSelf(self);
                        ((ImmediateItem) item).execute(trainState, text, scanner, rand);
                        self = trainState.getSelf();
                    }
                    if(ImmediateItem.baseSpellItem.contains((ImmediateItem) item)){
                        buyBaseSpellItem = true;
                    }
                }
                
                trainState.setSelf(self);
                if(buyBaseSpellItem){
                    trainState.saveLocation(LocationCategory.shopStep, IS_CHANGE_SPELL);
                    Print.println("オーブをセットしますか？", true, Print.highSpeed, text);
                    Print.println("", true, Print.highSpeed, text);
                    Print.println("Enter:はい 1:いいえ", true, Print.highSpeed, text);
                    Print.clearStaticText(text);
                    Print.changeWaitTextToLT(text);
                }else{
                    trainState.saveLocation(LocationCategory.shopStep, LocationCategory.NO_CHOICE);
                    shop(trainState, beforeTrainState, log, text, scanner, rand);
                }
                return;

            case IS_CHANGE_SPELL:
                idx = makeAction(trainState, beforeTrainState, scanner, text, rand);
                if(idx == 0){
                    trainState.saveLocation(LocationCategory.shopStep, CHANGE_SPELL);
                }else{
                    trainState.saveLocation(LocationCategory.shopStep, LocationCategory.NO_CHOICE);
                }
                shop(trainState, beforeTrainState, log, text, scanner, rand);
                return;

            case CHANGE_SPELL:
                trainState.sendNextActionToSelf();
                InputAction.changeSpell(self, text, scanner);
                if(self.getSavedLocation(LocationCategory.changeSpell) == LocationCategory.FINISH){
                    self.saveLocation(LocationCategory.changeSpell, LocationCategory.NO_CHOICE);
                    trainState.saveLocation(LocationCategory.shopStep, LocationCategory.NO_CHOICE);
                    shop(trainState, beforeTrainState, log, text, scanner, rand);
                }
                return;

            default:
                trainState.saveLocation(LocationCategory.shopStep, LocationCategory.NO_CHOICE);
                shop(trainState, beforeTrainState, log, text, scanner, rand);
                return;
        }
    }

    private static void useItem(TrainState trainState, TrainState beforeTrainState, boolean text, Scanner scanner, Random rand) {
        Player self = trainState.getSelf();
        final int CHOICE_ITEM = 1;
        int count;
        List<BattleItem> battleItemList;
        List<DisposableItem> disposableItemList;
        switch(trainState.getSavedLocation(LocationCategory.useItemStep)){
            case LocationCategory.NO_CHOICE:
                if (trainState.getUseItem()) {
                    Print.println("アイテムは 1 日に 1 回までしか使えません", Print.highSpeed, text);
                    if (trainState.getSpendAction().size() != 0) {
                        trainState.takeSpendAction();// spendActionの廃棄
                        if (trainState.getSpendAction().size() == 0) {
                            trainState.setUseSpendAction(false);
                        }
                    }
                    Print.nextLine(scanner, text);
                    trainState.saveLocation(LocationCategory.useItemStep, LocationCategory.FINISH);
                    return;
                }
                battleItemList = new ArrayList<BattleItem>();
                disposableItemList = new ArrayList<DisposableItem>();
                count = 0;
                Print.println("", Print.highSpeed, text);
                Print.println("何を使用しますか", Print.highSpeed, text);
                // for (BattleItem key : BattleItem.values()) {
                //     if (self.getItemList().get(key) != 0) {
                //         count++;
                //         Print.println(count + ":" + key.jName + "  " + self.getItemList().get(key) + "個",
                //                 Print.highSpeed, text);
                //         battleItemList.add(key);
                //         legalActionsList.add(count);
                //     }
                // }
                for (DisposableItem key : DisposableItem.values()) {
                    if (self.getDisposableItemList().get(key) != 0) {
                        count++;
                        Print.println(count + ":" + key.jName + "  " + self.getDisposableItemList().get(key) + "個",
                                Print.highSpeed, text);
                        disposableItemList.add(key);
                    }
                }
                // for (DisposableItem key : DisposableItem.values()) {
                //     if (self.getDisposableItemList().get(key) != 0) {
                //         count++;
                //         Print.println(count + ":" + key.jName + "  " + self.getDisposableItemList().get(key) + "個",
                //                 Print.highSpeed, text);
                //         itemList.add(key);
                //         if (key.useAble(trainState)) {
                //             legalActionsList.add(count);
                //         }
                //     }
                // }
                
                trainState.saveLocation(LocationCategory.useItemStep, CHOICE_ITEM);
                return;
            case CHOICE_ITEM:
                count = 0;
                battleItemList = new ArrayList<BattleItem>();
                disposableItemList = new ArrayList<DisposableItem>();
                for (DisposableItem key : DisposableItem.values()) {
                    if (self.getDisposableItemList().get(key) != 0) {
                        count++;
                        disposableItemList.add(key);
                    }
                }
                int idx = makeAction(trainState, beforeTrainState, scanner, text, rand);
                if (trainState.getAuto() != Auto.select) {
                    if (idx == BattleItem.NUM + DisposableItem.NUM) {// アイテムを使わない
                    // if (idx == DisposableItem.NUM) {// アイテムを使わない
                        
                        trainState.saveLocation(LocationCategory.useItemStep, LocationCategory.FINISH);
                        return;
                    }
                    for (int i = 0; i < count; i++) {
                        if(i < BattleItem.NUM){
                            if (battleItemList.get(i) == BattleItem.values()[idx]) {
                            // if (itemList.get(i) == DisposableItem.values()[idx]) {
                                idx = i + 1;
                                break;
                            }
                        }else{
                            if (disposableItemList.get(i - battleItemList.size()) == DisposableItem.values()[idx - BattleItem.NUM]) {
                            // if (itemList.get(i) == DisposableItem.values()[idx]) {
                                idx = i + 1;
                                break;
                            }
                        }
                    }
                }
                if (idx < -count || idx == 0 || count < idx) {
                    if (idx != 0 && idx != BattleItem.NUM + DisposableItem.NUM) {
                    // if (idx != 0 && idx != DisposableItem.NUM) {
                        System.out.println("正しく入力してください5");
                        Print.input(scanner, text);
                    }
                    trainState.saveLocation(LocationCategory.useItemStep, LocationCategory.FINISH);
                    return;
                }
                if (idx < 0) {
                    idx = -idx + 1;
                    if(idx < battleItemList.size()){
                        Print.println(battleItemList.get(idx).battleExplain, Print.highSpeed, text);
                    }else{
                        Print.println(disposableItemList.get(idx - battleItemList.size()).explain, Print.highSpeed, text);
                    }
                    trainState.saveLocation(LocationCategory.useItemStep, LocationCategory.NO_CHOICE);
                    useItem(trainState, beforeTrainState, text, scanner, rand);
                    return;
                }
                idx--;
                if(idx < battleItemList.size()){
                    BattleItem item = battleItemList.get(idx);
                    trainState.setSelf(self);
                    Print.println(item.getJName(trainState) + "を使った", Print.middleSpeed, text);
                    trainState = item.trainExecute(trainState, rand, text);
                    self = trainState.getSelf();
                    Map<BattleItem, Integer> itemListMap = self.getItemList();
                    itemListMap.replace(item, itemListMap.get(item) - 1);
                    self.setItemList(itemListMap);
                }else{
                    idx -= battleItemList.size();
                    DisposableItem item = disposableItemList.get(idx);
                    if (!item.useAble(trainState)) {
                        Print.println("そのアイテムは使用できません", Print.middleSpeed, text);
                        trainState.saveLocation(LocationCategory.useItemStep, LocationCategory.NO_CHOICE);
                        useItem(trainState, beforeTrainState, text, scanner, rand);
                        return;
                    }
                    trainState.setSelf(self);
                    Print.println(item.getJName(trainState) + "を使った", Print.middleSpeed, text);
                    trainState = item.execute(trainState, rand, text);
                    self = trainState.getSelf();
                    Map<DisposableItem, Integer> itemListMap = self.getDisposableItemList();
                    itemListMap.replace(item, itemListMap.get(item) - 1);
                    self.setDisposableItemList(itemListMap);
                }
                trainState.setUseItem(true);
                Print.nextLine(scanner, text);
                trainState.setSelf(self);
                trainState.saveLocation(LocationCategory.useItemStep, LocationCategory.FINISH);
                return;
            default:
                System.out.println("error 不正な入力です useItem");
                return;
        }
    }

    private static void save(TrainState trainState, boolean last, boolean text, Scanner scanner) {
        if (last || !trainState.getSave()) {
            int input;
            final int IS_SAVE = 1;
            final int CHOICE_SAVEDATA_NUM = 2;
            switch(trainState.getSavedLocation(LocationCategory.save)){
                case LocationCategory.NO_CHOICE:
                    if (last) {
                        Print.print("今回のデータをセーブしますか?", Print.highSpeed, text);
                    }else{
                        Print.print("現在のデータをセーブして、中断しますか?", Print.highSpeed, text);
                        Print.print("(既に存在するデータは上書きされます)", Print.highSpeed, text);
                    }
                    Print.println("", Print.highSpeed, text);
                    Print.println("", true, Print.highSpeed, text);
                    Print.println("Enter: はい    1: いいえ", Print.highSpeed, text);
                    Print.changeWaitTextToLT(text);
                    trainState.saveLocation(LocationCategory.save, IS_SAVE);
                    return;
                case IS_SAVE:
                    input = trainState.takeNextAction();
                    if(input == 0){
                        int num = Integer.MIN_VALUE;
                        if (last) {
                            Print.println(Color.yellow.toColor("セーブデータの番号を指定してください"), Print.highSpeed, text);
                            Print.println("(注意!!既に存在する番号を指定するとデータが上書きされてしまいます!)", Print.highSpeed, text);
                            Print.print("既に使用されている番号:", Print.highSpeed, text);
                            for(int idx : TrainState.saveDataNums()){
                                Print.print(idx + "  ", Print.highSpeed, text);
                            }
                            Print.println("", Print.highSpeed, text);
                            trainState.saveLocation(LocationCategory.save, CHOICE_SAVEDATA_NUM);
                            return;
                        } else {
                            trainState.setSave(true);
                            trainState.save(num, text);
                            trainState.saveLocation(LocationCategory.save, LocationCategory.EXIT);
                            return;
                            // System.exit(0);
                        }
                    }else{
                        trainState.saveLocation(LocationCategory.save, LocationCategory.FINISH);
                        return;
                    }
                case CHOICE_SAVEDATA_NUM:
                    input = trainState.takeNextAction();
                    trainState.save(input, text);
                    trainState.saveLocation(LocationCategory.save, LocationCategory.FINISH);
                    return;

            }
        } else {
            Print.println("この日既に" + TrainTurnAction.save.jName + "しています", Print.highSpeed, text);
            trainState.saveLocation(LocationCategory.save, LocationCategory.FINISH);
        }
        return;
    }

    private static void showActions(TrainState trainState, boolean text, Scanner scanner) {
        Print.println("", Print.highSpeed, text);
        Print.println("", Print.highSpeed, text);
        Print.println(Train.TrainTurnAction.train.jName + "メニュー", Print.highSpeed, text);
        List<CardWithParams> trainMenus = trainState.getHands();
        //int[] battleMenus = trainState.getBattleMenus()[trainState.getTurn() - 1];
        int trainMenuNum = trainMenus.size();
        //int battleMenuNum = Math.min(trainState.getBattleMenuNum(), battleMenus.length);
        for (int i = 0; i < trainMenuNum; i++) {
            Print.println(" " + (i + 1) + ":" + trainMenus.get(i).card.jName(), Print.highSpeed, text);
        }
        /*Print.println("<br>ギルドメニュー", Print.highSpeed, text);
        for (int i = 0; i < battleMenuNum; i++) {//
            Print.println(" " + (i + 1) + ":" + (Monster.values())[battleMenus.get(i)].jName, Print.highSpeed, text);
        }*/
    }

    public static TrainState[] turnUpdate(TrainState trainState, TrainState beforeTrainState, int spendActionNum, boolean noDamage,
            TrainTemporaryLog log, boolean text, Scanner scanner, Random rand, TrainStatus beforeTrainMenu) {

        final int NEXT_TURN = 1;
        final int DRAW_CARD = 2;
        final int BEFORE_BOSS_SCENARIO = 3;
        final int BOSS_BATTLE_PREPARE = 4;
        final int CHANGE_SPELL = 5;
        final int BOSS_BATTLE_PREPARE_2 = 6;
        final int BOSS_BATTLE = 7;
        final int GET_BOSS_SKILL = 8;
        final int GET_BOSS_SKILL_SELECT = 9;
        final int GET_BOSS_SPECIAL = 10;
        final int GET_BOSS_SPECIAL_SELECT = 11;
        final int OTHER_BOSS_REWARD = 12;
        final int MAKE_NEW_BOSS = 13;
        final int SHOP = 14;
        final int SCENARIO = 15;
        final int ROOP_END = 16;
        final int FOR_ALL_TURN_UP_DATE = 17;

        
        Player self = trainState.getSelf();
        Enemy boss;
        BattleItem passiveItem;
        Attribute attribute;
        boolean isDynamic;

        switch(trainState.getSavedLocation(LocationCategory.turnUpDate)){
            case LocationCategory.NO_CHOICE:
                if (trainState.isEnd()) {
                    trainState.saveLocation(LocationCategory.turnUpDate, LocationCategory.FINISH);
                    return new TrainState[]{trainState, beforeTrainState};
                }
                if(spendActionNum == 0){
                    trainState.saveLocation(LocationCategory.turnUpDate, LocationCategory.FINISH);
                    return new TrainState[]{trainState, beforeTrainState};
                }
                trainState.setTimeFrame(TimeFrame.returnNextTimeFrame(trainState.getTimeFrame(), trainState.getMode(), spendActionNum));
                if(trainState.getTimeFrame() == TimeFrame.nextTurn){
                    trainState.saveLocation(LocationCategory.turnUpDate, NEXT_TURN);
                    return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);
                }else{
                    trainState.saveLocation(LocationCategory.turnUpDate, FOR_ALL_TURN_UP_DATE);
                    return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);
                }

            case NEXT_TURN:
                // その他のターン終了処理
                Print.clearStaticText(text);
                Print.slowStart(true, text);
                
                boolean todayDidTrain = false;
                for(Card finishCard : trainState.pullTodaysFinishTrain()){
                    if(finishCard instanceof TrainMenu && ((TrainMenu)finishCard) != TrainMenu.mp){
                        todayDidTrain = true;
                        break;
                    }
                }
                // ここからが訓練カード無しだとだめな場所
                if(todayDidTrain){
                    Print.println("", true, Print.highSpeed, text);
                    Print.println(Print.sleep(5), true, Print.highSpeed, text);
                    Print.print("今日の訓練は" + Print.sleep(10), true, Print.highSpeed, text);
                    
                    Print.println("", true, Print.highSpeed, text);
                    Print.println("", true, Print.highSpeed, text);
                    Print.changeFontSizeStart(6, true, text);
                    TrainResult result = trainState.getTrainResult();
                    String resultText = result.jName + (result == TrainResult.fault ? "" : (result == TrainResult.success ? "！" : "！！"));
                    resultText = Print.sleepEachCharacter(resultText, 5);
                    resultText = result.color.toColor(resultText);
                    Print.print(resultText + Print.sleep(10), true, Print.highSpeed, text);
                    Print.changeFontSizeEnd(true, text);
                    Print.skipStart(true, text);
                    Print.println("", true, Print.highSpeed, text);
                    Print.println("", true, Print.highSpeed, text);
                    Print.skipEnd(true, text);
                    
                    if(result == TrainResult.greatSuccess){
                        Print.println("高い " + Color.whiteOrange.toColor("[集中力]") + " で体力の消耗を抑えて訓練出来た！" + Print.sleep(10), true, Print.highSpeed, text);
                    }
                    if(result == TrainResult.success){
                        Print.println("並の " + Color.whiteOrange.toColor("[集中力]") + " を保って訓練することができた！" + Print.sleep(10), true, Print.highSpeed, text);
                    }
                    if(result == TrainResult.fault){
                        Print.println(Color.whiteOrange.toColor("[集中力]") + " が途切れてしまった..." + Print.sleep(10), true, Print.highSpeed, text);
                    }
                }
                // ここまでが訓練カード無しだとだめな場所
                if(trainState.getDefinitedGreatSuccessTrainMenu().size() != 0){
                    boolean isFirst = true;
                    Print.print("※ ", true, Print.highSpeed, text);
                    for(TrainMenu greatSucceededMenu : trainState.getDefinitedGreatSuccessTrainMenu()){
                        if(!isFirst){
                            Print.print("・", true, Print.highSpeed, text);
                        }
                        Print.print(greatSucceededMenu.jName(), true, Print.highSpeed, text);
                        isFirst = false;
                    }
                    Print.println(" は確定大成功" + Print.sleep(10), true, Print.highSpeed, text);
                    
                }
                trainState.resetDefinitedGreatSuccessTrainMenu();
                if(trainState.getGutsTrainMenu().size() != 0){
                    Color.blue.startColor(true, text);
                    Print.println("崖っぷち訓練発動！！" + Print.sleep(10), true, Print.highSpeed, text);
                    
                    for(TrainMenu gutsMenu : trainState.getGutsTrainMenu()){
                        Print.println(gutsMenu.jName() + "の訓練効果 100%増加！" + Print.sleep(10), true, Print.highSpeed, text);
                        
                    }
                    Color.blue.endColor(true, text);
                }
                trainState.resetGutsTrainMenu();

                Print.println("", true, Print.highSpeed, text);
                trainState.unlimitSaveUnlimits(text, scanner);
                if(trainState.getTurn() % 2 == 0){
                    Print.println("ショップの物価が上昇しました" + Print.sleep(10), true, Print.highSpeed, text);
                }
                Print.println("", true, Print.highSpeed, text);
                if(trainState.getTurn() % 8 == 0 && trainState.getLabFromTurn() <= trainState.getTurn()){
                    trainState.resetUnbeatenGuild();
                }
                trainState.updateGuild();
                
                Map<TrainStatus, Integer> changeTrainStatusMount = trainState.getChangedMountTrainStatus();
                Map<TrainStatus, Integer> beforeStatusMount = trainState.getBeforeTrainStatus();
                int changeMount;
                int beforeMount;
                Color numColor;
                Print.skipStart(true, text);
                changeTrainStatusMount.remove(TrainStatus.money);
                if(changeTrainStatusMount.size() != 0){
                    Print.startTable(true, text);
                    Print.startRow(true, text);
                    Print.startTable(true, text);
                    for(TrainStatus key : new TrainStatus[] {TrainStatus.hp, TrainStatus.concentration, TrainStatus.motivation}){
                        if(changeTrainStatusMount.containsKey(key)){
                            Print.startRow(true, text);
                            changeMount = changeTrainStatusMount.get(key);
                            beforeMount = beforeStatusMount.get(key);
                            numColor = changeMount > 0 ? Color.blue : Color.red;
                            Print.print(key.jName, true, Print.highSpeed, text);
                            Print.separateRow(true, text);
                            Print.print(":", true, Print.highSpeed, text);
                            Print.separateRow(true, text);
                            Print.print(String.valueOf(beforeMount), true, Print.highSpeed, text);
                            Print.separateRow(true, text);
                            Print.print("→", true, Print.highSpeed, text);
                            Print.separateRow(true, text);
                            Print.print(numColor.toColor(String.valueOf(beforeMount + changeMount)), true, Print.highSpeed, text);
                            Print.endRow(true, text);
                        }
                    }
                    Print.endTable(true, text);
                    Print.separateRow(true, text);
                    Print.startTable(true, text);
                    for(TrainStatus key : new TrainStatus[] {TrainStatus.maxHp, TrainStatus.a, TrainStatus.s}){
                        if(changeTrainStatusMount.containsKey(key)){
                            Print.startRow(true, text);
                            changeMount = changeTrainStatusMount.get(key);
                            beforeMount = beforeStatusMount.get(key);
                            numColor = changeMount > 0 ? Color.blue : Color.red;
                            Print.print(key.jName, true, Print.highSpeed, text);
                            Print.separateRow(true, text);
                            Print.print(":", true, Print.highSpeed, text);
                            Print.separateRow(true, text);
                            Print.print(String.valueOf(beforeMount), true, Print.highSpeed, text);
                            Print.separateRow(true, text);
                            Print.print("→", true, Print.highSpeed, text);
                            Print.separateRow(true, text);
                            Print.print(numColor.toColor(String.valueOf(beforeMount + changeMount)), true, Print.highSpeed, text);
                            Print.endRow(true, text);
                        }
                    }
                    Print.endTable(true, text);
                    Print.endRow(true, text);
                    Print.endTable(true, text);
                    Print.print("", true, Print.highSpeed, text);
                }
                Print.skipEnd(true, text);
                Print.print(Print.sleep(20), true, Print.highSpeed, text);

                Print.println("", true, Print.highSpeed, text);
                
                
                Print.printHorizontalLine(true, text);
                Print.println(Print.sleep(5), true, Print.highSpeed, text);
                trainState.addCardToDeck(false, text);
                self.setElixirTurn(self.getElixirTurn() - 1 < 0 ? 0 : self.getElixirTurn() - 1);
                trainState.setTurn(trainState.getTurn() + 1);
                trainState.setTimeFrame(trainState.getMode().timeFrameList.get(0));
                Print.println("", true, Print.highSpeed, text);
                Print.printHorizontalLine(true, text);
                Print.println(Print.sleep(5), true, Print.highSpeed, text);
                Print.slowEnd(true, text);
                // if(self.getElixirTurn() > 0){
                //     dropBattle(trainState, trainState.getTurn(), rand);
                // }
                trainState.setBeforeUnlimitActions(new ArrayList<>());
                //changeTrainMenuForEasy(trainState, rand);
                Collections.addAll(log.getAction(),
                trainState.getChargeAction().toArray(new Integer[trainState.getChargeAction().size()]));
                if(trainState.getTurn() % 8 == 1 && trainState.getLabFromTurn() < trainState.getTurn()){
                    trainState.saveLocation(LocationCategory.turnUpDate, BEFORE_BOSS_SCENARIO);
                    Print.changeWaitTextToLT(text);
                    return new TrainState[]{trainState, beforeTrainState};
                    // return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);
                }else{
                    trainState.saveLocation(LocationCategory.turnUpDate, DRAW_CARD);
                    return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);
                }


            case DRAW_CARD:
                makeChoice(trainState, text, rand);
                if(trainState.getTurn() % 4 == 1 && trainState.getLabFromTurn() < trainState.getTurn()){
                    trainState.saveLocation(LocationCategory.turnUpDate, BEFORE_BOSS_SCENARIO);
                    Print.changeWaitTextToLT(text);
                    return new TrainState[]{trainState, beforeTrainState};
                    // return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);
                }else{
                    trainState.saveLocation(LocationCategory.turnUpDate, FOR_ALL_TURN_UP_DATE);
                    Print.changeWaitTextToLT(text);
                    return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);
                }

            case BEFORE_BOSS_SCENARIO:
                isDynamic = true;

                Print.printBigSeparater(isDynamic, text);

                Print.changeFontSizeStart(4, isDynamic, text);
                if(trainState.getBoss().getJName().equals(Boss.ApprenticeBrave.jName)){
                    Print.println("見習い勇者 「僕だって…！」" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                    Print.println("", isDynamic, Print.highSpeed, text);
                }else if(trainState.getBoss().getJName().equals(Boss.normalBrave.jName)){
                    Print.println("普通の勇者 「魔王を 倒すんだ！」" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                    Print.println("", isDynamic, Print.highSpeed, text);
                }else if(trainState.getBoss().getJName().equals(Boss.StrongestBrave.jName)){
                    Print.println("最強の勇者 「最強は１人で十分だ」" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                    Print.println("", isDynamic, Print.highSpeed, text);
                }else if(trainState.getBoss().getJName().equals(Boss.LegendaryBrave.jName)){
                    Print.println("伝説の勇者 「仕事の時間だ」" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                    Print.println("", isDynamic, Print.highSpeed, text);
                }else if(trainState.getBoss().getJName().equals(Boss.DemiseBrave.jName)){
                    Print.println("終焉の勇者 「全てを終わらせる…」" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                    Print.println("", isDynamic, Print.highSpeed, text);
                }else if(trainState.getBoss().getJName().equals(Boss.FastidiousHero.jName)){
                    Print.println("こだわりの勇者 「私は…こだわり…続けなければ…」" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                    Print.println("", isDynamic, Print.highSpeed, text);
                }else{
                    System.out.println("error 一言シナリオが出ない");
                }
                Print.changeFontSizeEnd(isDynamic, text);

                Print.printBigSeparater(isDynamic, text);
                Print.changeWaitTextToLT(text);
                trainState.saveLocation(LocationCategory.turnUpDate, BOSS_BATTLE_PREPARE);
                return new TrainState[]{trainState, beforeTrainState};

            case BOSS_BATTLE_PREPARE:

                Print.println("勇者に備えてHPを全回復した", true, Print.highSpeed, text);
                
                Print.nextLine(scanner, text);
                CalculateDamage.trainDamage(self, TrainStatus.maxHp, -100, false);
                CalculateDamage.trainDamage(self, TrainStatus.maxMp, -100, false);
                Print.nextLine(scanner, text);

                self.trainToBattleStatus();

                if(self.getLearnedSpellLevel().size() == 0){
                    Print.displayBattleStatusBeforeBattle(self, trainState.getBoss(), true, text);
                    // Print.println("勇者との戦いが始まる...", true, Print.highSpeed, text);
                    Print.changeWaitTextToLT(text);
                    trainState.saveLocation(LocationCategory.turnUpDate, BOSS_BATTLE_PREPARE_2);
                    return new TrainState[]{trainState, beforeTrainState};
                }else{
                    Print.displayBattleStatusBeforeBattle(self, trainState.getBoss(), true, text);
                    Print.skipStart(true, text);
                    Print.println(Color.yellow.toColor("オーブをセットしてください"), true, Print.highSpeed, text);
                    
                    Print.println(Color.scarlet.toColor("※ オーブはスロットにセットしないと呪文を使えません"), true, Print.highSpeed, text);
                    Print.skipEnd(true, text);
                    
                    trainState.saveLocation(LocationCategory.turnUpDate, CHANGE_SPELL);
                    return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);
                }

            
            // case IS_CHANGE_SPELL:
            //     if (trainState.getAuto() == Auto.select && trainState.takeNextAction() == 1) {
            //         trainState.saveLocation(LocationCategory.turnUpDate, CHANGE_SPELL);
            //     }else{
            //         trainState.saveLocation(LocationCategory.turnUpDate, BOSS_BATTLE_PREPARE_2);
            //     }
            //     return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);

            case CHANGE_SPELL:
                trainState.sendNextActionToSelf();
                self = trainState.getSelf();
                InputAction.changeSpell(self, text, scanner);
                if(self.getSavedLocation(LocationCategory.changeSpell) == LocationCategory.FINISH){
                    self.saveLocation(LocationCategory.changeSpell, LocationCategory.NO_CHOICE);
                    trainState.setSelf(self);
                    trainState.saveLocation(LocationCategory.turnUpDate, BOSS_BATTLE_PREPARE_2);
                    return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);
                }
                trainState.setSelf(self);
                return new TrainState[]{trainState, beforeTrainState};

            case BOSS_BATTLE_PREPARE_2:
                Print.printBigSeparater(true, text);
                Print.println(trainState.getBoss().getJName() + "が現れた！", true, Print.highSpeed, text);
                Print.deleteSlow(text);
                trainState.getSelf().trainToBattleStatus();
                trainState.saveLocation(LocationCategory.turnUpDate, BOSS_BATTLE);
                return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);
            
            case BOSS_BATTLE:
                trainState = battle(trainState, beforeTrainState, trainState.getBoss(), true, log, text, scanner, rand);
                if(trainState.getSavedLocation(LocationCategory.battleInTrain) != LocationCategory.FINISH){
                    return new TrainState[]{trainState, beforeTrainState};
                }
                trainState.saveLocation(LocationCategory.battleInTrain, LocationCategory.NO_CHOICE);
                self = trainState.getSelf();
                if(trainState.isEnd()){
                    trainState.saveLocation(LocationCategory.turnUpDate, LocationCategory.FINISH);
                    trainState.setTurn(trainState.getTurn() - 1);
                    return new TrainState[]{trainState, beforeTrainState};
                }
                Print.nextLine(scanner, text);
                trainState.saveLocation(LocationCategory.turnUpDate, GET_BOSS_SKILL);
                return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);

            case GET_BOSS_SKILL:
                boss = trainState.getBoss();
                passiveItem = boss.passiveItem;
                Print.clearStaticText(text);
                if(passiveItem == BattleItem.None || self.passiveItem == passiveItem){
                    trainState.saveLocation(LocationCategory.turnUpDate, GET_BOSS_SPECIAL);
                    return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);
                }
                if(self.passiveItem == BattleItem.None){
                    Print.println("★ ★ ★ スキル玉:" + passiveItem.jName + "を入手した ★ ★ ★" + Print.sleep(5), true, Print.highSpeed, text);
                    
                    Print.changeWaitTextToLT(text);
                    self.passiveItem = passiveItem;
                    trainState.saveLocation(LocationCategory.turnUpDate, GET_BOSS_SPECIAL);
                    return new TrainState[]{trainState, beforeTrainState};
                }else{
                    Print.println("★ ★ ★ スキル玉:" + passiveItem.jName + "を入手した ★ ★ ★" + Print.sleep(5), true, Print.highSpeed, text);
                    
                    Print.println("現在のスキルと入れ替えますか？", true, Print.highSpeed, text);
                    
                    Print.println("現在のスキル:" + self.passiveItem.jName, true, Print.highSpeed, text);
                    
                    Print.println("", true, Print.highSpeed, text);
                    
                    Print.println("Enter:はい" + Print.space(2, text) + "1:いいえ", true, Print.highSpeed, text);
                    Print.changeWaitTextToLT(text);
                    
                    trainState.saveLocation(LocationCategory.turnUpDate, GET_BOSS_SKILL_SELECT);
                    return new TrainState[]{trainState, beforeTrainState};
                }

            case GET_BOSS_SKILL_SELECT:
                if(trainState.takeNextAction() == 0){
                    boss = trainState.getBoss();
                    passiveItem = boss.passiveItem;
                    self.passiveItem = passiveItem;
                    Print.println(passiveItem.jName + "をセットした", true, Print.highSpeed, text);
                    
                }else{
                    Print.println("入れ替えなかった", true, Print.highSpeed, text);
                }
                Print.nextLine(scanner, text);
                trainState.saveLocation(LocationCategory.turnUpDate, GET_BOSS_SPECIAL);
                return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);


            case GET_BOSS_SPECIAL:
                boss = trainState.getBoss();
                attribute = boss.getAttribute();
                if(attribute == Attribute.Null || self.getAttribute() == attribute){
                    trainState.saveLocation(LocationCategory.turnUpDate, OTHER_BOSS_REWARD);
                    return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);
                }
                if(self.getAttribute() == Attribute.Null){
                    Print.println("★ ★ ★ 必殺技石:" + attribute.jName + "を入手した ★ ★ ★" + Print.sleep(5), true, Print.highSpeed, text);
                    Print.changeWaitTextToLT(text);
                    self.setAttribute(attribute);
                    trainState.saveLocation(LocationCategory.turnUpDate, OTHER_BOSS_REWARD);
                    return new TrainState[]{trainState, beforeTrainState};
                }else{
                    Print.println("★ ★ ★ 必殺技石:" + attribute.jName + "を入手した ★ ★ ★" + Print.sleep(5), true, Print.highSpeed, text);
                    
                    Print.println("現在の必殺技と入れ替えますか？", true, Print.highSpeed, text);
                    
                    Print.println("現在の必殺技:" + self.getAttribute().jName, true, Print.highSpeed, text);
                    
                    Print.println("", true, Print.highSpeed, text);
                    
                    Print.println("Enter:はい" + Print.space(2, text) + "1:いいえ", true, Print.highSpeed, text);
                    Print.changeWaitTextToLT(text);
                    
                    trainState.saveLocation(LocationCategory.turnUpDate, GET_BOSS_SPECIAL_SELECT);
                    return new TrainState[]{trainState, beforeTrainState};
                }

            case GET_BOSS_SPECIAL_SELECT:
                if(trainState.takeNextAction() == 0){
                    boss = trainState.getBoss();
                    attribute = boss.getAttribute();
                    self.setAttribute(attribute);
                    Print.println(attribute.jName + "をセットした", true, Print.highSpeed, text);
                    
                }else{
                    Print.println("入れ替えなかった", true, Print.highSpeed, text);
                    
                }
                Print.nextLine(scanner, text);
                trainState.saveLocation(LocationCategory.turnUpDate, OTHER_BOSS_REWARD);
                return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);

            case OTHER_BOSS_REWARD:
                Print.printHorizontalLine(true, text);
                Print.println("", true, Print.highSpeed, text);
                Print.nextLine(scanner, text);
                int intermediateTurn = 8;
                if(trainState.getTurn() % intermediateTurn == 1){
                    if(trainState.getTurn() == trainState.getTurnLimit() + 1){
                        Print.println("こだわりの勇者報酬で", true, Print.highSpeed, text);
                        Print.println("最大HPが 2000 上がった", true, Print.highSpeed, text);
                        Print.println("攻撃力が 200 上がった", true, Print.highSpeed, text);
                        Print.println("素早さが 200 上がった", true, Print.highSpeed, text);
                        
                        CalculateDamage.trainProgress(self, TrainStatus.maxHp, false, 2000, false);
                        CalculateDamage.trainProgress(self, TrainStatus.a, false, 200, false);
                        CalculateDamage.trainProgress(self, TrainStatus.s, false, 200, false);
                    }else{
                        int bossRewardLevelUp = 1;
                        boolean isWithStar = false;
                        for(TrainMenuCategory menu : TrainMenuCategory.values()){
                            if(menu == TrainMenuCategory.MP){
                                continue;
                            }
                            TrainMenu.levelUp(trainState, menu, bossRewardLevelUp, isWithStar, text);
                        }
                        if(trainState.getResuscitated()){
                            Print.println("勇者から復活のお守りを手に入れた！", true, Print.highSpeed, text);
                            
                            trainState.resetResuscitated();
                        }
                        trainState.saveAddCard(new ArrayList<>(Card.startDeck(rand)), shuffleModeWithAddCard.Last);
                        trainState.addCardToDeck(true, text);
                        trainState.setHands(CardWithParams.changeCardToCardWithParams(trainState, trainState.getHands(), CardWithParams.takeCard(CardWithParams.startHand), false));
                    }
                    // Print.println("勇者戦後に全回復した", true, Print.highSpeed, text);
                    CalculateDamage.trainDamage(self, TrainStatus.maxHp, -100, false);
                    CalculateDamage.trainDamage(self, TrainStatus.maxMotivation, -100, false);
                    CalculateDamage.trainDamage(self, TrainStatus.maxConcentration, -100, false);
                    CalculateDamage.trainDamage(self, TrainStatus.maxMp, -100, false);
                }else{
                    int bossRewardLevelUp = 1;
                    boolean isWithStar = false;
                    for(TrainMenuCategory menu : TrainMenuCategory.values()){
                        if(menu == TrainMenuCategory.MP){
                            continue;
                        }
                        TrainMenu.levelUp(trainState, menu, bossRewardLevelUp, isWithStar, text);
                    }
                    // Print.println("勇者戦後にHPを全回復した", true, Print.highSpeed, text);
                    CalculateDamage.trainDamage(self, TrainStatus.maxHp, -100, false);
                    CalculateDamage.trainDamage(self, TrainStatus.maxMp, -100, false);
                    trainState.saveAddCard(new ArrayList<>(){{
                        boolean isChangeBerserker = rand.nextBoolean();
                        boolean isNaked = rand.nextBoolean();
                        List<Guild> adventurers = new ArrayList<>(){{
                            add(Guild.red);
                            add(Guild.brown);
                            add(Guild.green);
                        }};
                        List<Guild> berserkers = new ArrayList<>(){{
                            add(Guild.berserkerHP);
                            add(Guild.berserkerA);
                            add(Guild.berserkerS);
                        }};
                        for(int i = 0; i < 2; i++){
                            int idx = rand.nextInt(adventurers.size());
                            if(i == 0 && !isChangeBerserker){
                                if(isNaked){
                                    add(adventurers.get(idx).toNaked());
                                }else{
                                    add(adventurers.get(idx).toJewelry());
                                }
                            }else{
                                add(adventurers.get(idx));
                            }
                            adventurers.remove(idx);
                        }
                        for(int i = 0; i < 1; i++){
                            int idx = rand.nextInt(berserkers.size());
                            if(i == 0 && isChangeBerserker){
                                if(isNaked){
                                    add(berserkers.get(idx).toNaked());
                                }else{
                                    add(berserkers.get(idx).toJewelry());
                                }
                            }else{
                                add(berserkers.get(idx));
                            }
                            berserkers.remove(idx);
                        }
                        add(RestMenu.maintenance);
                    }}, shuffleModeWithAddCard.Last);
                    trainState.addCardToDeck(true, text);
                }
                // Print.println("ショップでの物価が上昇した", true, Print.highSpeed, text);
                
                trainState.saveLocation(LocationCategory.turnUpDate, MAKE_NEW_BOSS);
                return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);

            case MAKE_NEW_BOSS:
                int bossIdx = trainState.getTurn() / 4;
                List<Enemy> bosses = trainState.getStage().getBosses(trainState.getMode().bossAuto, rand, BattleItem.values()[rand.nextInt(BattleItem.NUM - 1)]);
                if(bossIdx < bosses.size()){
                    trainState.setBoss(bosses.get(bossIdx));
                }
                if(trainState.getTurn() % 8 == 1){
                    trainState.saveLocation(LocationCategory.turnUpDate, SCENARIO);
                    if(new ArrayList<>(){{
                        add(17);
                        add(25);
                    }}.contains(trainState.getTurn())){
                        Print.changeWaitTextToLT(text);
                        return new TrainState[]{trainState, beforeTrainState};
                    }else{
                        return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);
                    }
                }else{
                    trainState.saveLocation(LocationCategory.turnUpDate, SHOP);
                    Print.printHorizontalLine(true, text);
                    Print.changeWaitTextToLT(text);
                    return new TrainState[]{trainState, beforeTrainState};
                }
                // return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);

            case SHOP:
                shop(trainState, beforeTrainState, log, text, scanner, rand);
                if(trainState.getSavedLocation(LocationCategory.shopStep) == LocationCategory.FINISH){
                    trainState.saveLocation(LocationCategory.shopStep, LocationCategory.NO_CHOICE);
                    trainState.saveLocation(LocationCategory.turnUpDate, FOR_ALL_TURN_UP_DATE);
                    Print.println("ショップを出た", true, Print.highSpeed, text);
                    Print.changeWaitTextToLT(text);
                    // Print.printTips(rand, text);
                    return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);
                }
                return new TrainState[]{trainState, beforeTrainState};
                
            case SCENARIO:
                if(trainState.getTurn() % 8 == 1){
                    isDynamic = true;
                    switch(trainState.getTurn() / 8){
                        case 2:
                            Print.printBigSeparater(isDynamic, text);
                            Print.changeFontSizeStart(4, isDynamic, text);
                            switch(trainState.getSavedLocation(LocationCategory.scenario)){
                                case LocationCategory.NO_CHOICE:
                                    Print.println("…こうして伝説の勇者は倒れ、世界は闇に包まれた！" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                    Print.println("", isDynamic, Print.highSpeed, text);

                                    Print.changeFontSizeEnd(isDynamic, text);
                                    Print.printBigSeparater(isDynamic, text);
                                    trainState.saveLocation(LocationCategory.scenario, LocationCategory.NO_CHOICE);
                                    trainState.saveLocation(LocationCategory.turnUpDate, ROOP_END);
                                    Print.changeWaitTextToLT(text);
                                    return new TrainState[]{trainState, beforeTrainState};

                                default:
                                    Print.changeFontSizeEnd(isDynamic, text);
                                    System.out.println("error scenario 2-1");
                                    trainState.saveLocation(LocationCategory.scenario, LocationCategory.NO_CHOICE);
                                    trainState.saveLocation(LocationCategory.turnUpDate, ROOP_END);
                                    return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);
                            }
                        
                        case 3:
                            Print.printBigSeparater(isDynamic, text);
                            Print.changeFontSizeStart(4, isDynamic, text);
                            switch(trainState.getSavedLocation(LocationCategory.scenario)){
                                case LocationCategory.NO_CHOICE:
                                    Print.println("魔王はまがまがしい世界を手に入れた！！" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                    Print.println("", isDynamic, Print.highSpeed, text);

                                    Print.changeFontSizeEnd(isDynamic, text);
                                    Print.printBigSeparater(isDynamic, text);
                                    trainState.saveLocation(LocationCategory.scenario, LocationCategory.NO_CHOICE);
                                    trainState.saveLocation(LocationCategory.turnUpDate, ROOP_END);
                                    Print.changeWaitTextToLT(text);
                                    return new TrainState[]{trainState, beforeTrainState};

                                default:
                                    Print.changeFontSizeEnd(isDynamic, text);
                                    System.out.println("error scenario 2-2");
                                    trainState.saveLocation(LocationCategory.scenario, LocationCategory.NO_CHOICE);
                                    trainState.saveLocation(LocationCategory.turnUpDate, ROOP_END);
                                    return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);
                            }

                        default:
                            Print.printHorizontalLine(isDynamic, text);
                            trainState.saveLocation(LocationCategory.turnUpDate, ROOP_END);
                            return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);
                    }
                }else{
                    trainState.saveLocation(LocationCategory.turnUpDate, FOR_ALL_TURN_UP_DATE);
                    return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);
                }

            case ROOP_END:
                TrainLimitation.resetLabLimitation(trainState);
                TrainLimitation.resetSpellLimitation(trainState);
                TrainLimitation.resetStrengthenLimitation(trainState);
                trainState.getSelf().resetNoCostStatus();
                trainState.getSelf().resetMoney();
                trainState.resetJewelryAndNaked();
                if(trainState.getTurn() == trainState.getTurnLimit() + 1){
                    trainState.saveLocation(LocationCategory.gameClear, LocationCategory.TRUE);
                }
                trainState.saveLocation(LocationCategory.delimiterSave, LocationCategory.TRUE);
                trainState.saveLocation(LocationCategory.turnUpDate, FOR_ALL_TURN_UP_DATE);
                return turnUpdate(trainState, beforeTrainState, spendActionNum, noDamage, log, text, scanner, rand, beforeTrainMenu);
                

            case FOR_ALL_TURN_UP_DATE:
                if (trainState.isEnd()) {
                    trainState.saveLocation(LocationCategory.turnUpDate, LocationCategory.FINISH);
                    return new TrainState[]{trainState, beforeTrainState};
                }
                trainState.setUseItem(false);
                trainState.setSave(false);
                trainState.setBeforeTrainMenu(beforeTrainMenu);
                if(trainState.getTurn() % 8 == 1 && trainState.getLabFromTurn() < trainState.getTurn()){
                    trainState.resetBeforeTrainMenu();
                }
                // 連続鍛錬処理
                if (beforeTrainMenu == null || beforeTrainMenu == TrainStatus.mp) {
                    trainState.setChainTrainNum(0);
                    trainState.setChainSameTrainNum(0);
                } else {
                    trainState.setChainTrainNum(trainState.getChainTrainNum() + 1);
                }
                if(trainState.getTimeFrame() == trainState.getMode().timeFrameList.get(0)){
                    beforeTrainState = trainState.modifiableCopy();
                }
                trainState.saveLocation(LocationCategory.turnUpDate, LocationCategory.FINISH);
                return new TrainState[]{trainState, beforeTrainState};

            default:
                System.out.println("error turnUpDate");
                trainState.saveLocation(LocationCategory.turnUpDate, LocationCategory.FINISH);
                return new TrainState[]{trainState, beforeTrainState};

        }
    }

    public static void makeChoice(TrainState trainState, boolean text, Random rand) {
        trainState.setHands(makeTrainMenu(trainState, text, rand));
    }

    public static void choiceUpdate(TrainState trainState, boolean text, Random rand) {
        trainChoiceUpdate(trainState, text, rand);
        battleChoiceUpdate(trainState, rand);
        Print.println("行動が再抽選された", Print.highSpeed, text);
    }

    public static void battleChoiceUpdate(TrainState trainState, Random rand) {
        if(trainState.getTurn() > trainState.getTurnLimit()){
            return;
        }
        // trainState.refreshBattleMenus(makeBattleMenu(trainState, rand), trainState.getTurn());
    }

    public static void trainChoiceUpdate(TrainState trainState, boolean text, Random rand) {
        if(trainState.getTurn() > trainState.getTurnLimit()){
            return;
        }
        trainState.setHands(makeTrainMenu(trainState, text, rand));
    }

    // デッキからカードを引く
    private static List<CardWithParams> makeTrainMenu(TrainState trainState, boolean text, Random rand) {
        Print.slowStart(true, text);
        if(trainState.getHands().size() == 0 && trainState.deck.size() == 0){
            Print.println("手札もデッキも 0枚になってしまった。手札とデッキをリセットします" + Print.sleep(10), true, Print.highSpeed, text);
            
            trainState.deck = Card.startDeck(rand);
            Print.slowEnd(true, text);
            return new ArrayList<>(CardWithParams.startHand);
        }
        int addNum = addMenusNum(trainState);// 追加数
        if(trainState.getInnRedraw()){
            Print.println("宿屋の効果で現在の手札を捨てた" + Print.sleep(10), true, Print.highSpeed, text);
            
        }
        if(addNum >= 4){
            Print.print(Color.whiteOrange.toColor("[やる気]") + " 満々に ", true, Print.highSpeed, text);
            Print.println(addNum + "枚カードをデッキから引いた" + Print.sleep(10), true, Print.highSpeed, text);
            
        }else if(addNum >= 2){
            Print.print(Color.whiteOrange.toColor("[やる気]") + " 十分に ", true, Print.highSpeed, text);
            Print.println(addNum + "枚カードをデッキから引いた" + Print.sleep(10), true, Print.highSpeed, text);
            
        }else if(addNum >= 1){
            Print.print(Color.whiteOrange.toColor("[やる気]") + " が出ず ", true, Print.highSpeed, text);
            Print.println(addNum + "枚しかカードをデッキから引けなかった" + Print.sleep(10), true, Print.highSpeed, text);
        }else{
            Print.print(Color.whiteOrange.toColor("[やる気]") + " が全く出ず", true, Print.highSpeed, text);
            Print.println("デッキからカードを引けなかった" + Print.sleep(10), true, Print.highSpeed, text);
        }
        // 選択肢を使い果たしていたら追加数を1つ増やす
        if(trainState.getHands().size() == 0){
            Print.println("手札 0枚ボーナスで、追加で 1枚引いた" + Print.sleep(10), true, Print.highSpeed, text);
            
            addNum++;
        }
        if(trainState.getInnRedraw()){
            trainState.useInnRedraw();
            Print.println("宿屋の効果で捨てた枚数分さらにカードを引いた" + Print.sleep(10), true, Print.highSpeed, text);
            
            addNum += CardWithParams.cardsSize(trainState.getHands());
            trainState.setHands(new ArrayList<>());
        }
        for(int i = 0; i < trainState.getHands().size(); i++){
            trainState.getHands().get(i).isNew = false;
        }
        trainState.setHands(CardWithParams.notNew(trainState.getHands()));
        List<CardWithParams> result = CardWithParams.drawCard(trainState, addNum, text, rand);
        Print.slowEnd(true, text);
        return result;
    }

    // 追加される選択肢の数
    public static int addMenusNum(TrainState trainState) {
        Player self = trainState.getSelf();
        int num = (int) (self.getTrainStatus().get(TrainStatus.motivation) / 20);
        return num;
    }

    public static int makeAiAction(TrainState trainState, TrainState beforeTrainState, Scanner scanner, Random rand) {
        switch (trainState.getAuto()) {
            case random:
                return trainState.legalActions()[rand.nextInt(trainState.legalActions().length)];
            case playout:
                return trainState.aiLegalActions()[rand.nextInt(trainState.aiLegalActions().length)];
            case mctsS:
                return TrainMontecarlo.mctsAct(trainState, beforeTrainState, 300, false, false, scanner, rand);
            default:
        }
        return trainState.legalActions()[rand.nextInt(trainState.legalActions().length)];
    }

    public static int makeAction(TrainState trainState, TrainState beforeTrainState, int defaultNum, Scanner scanner, boolean text, Random rand) {
        int act;
        if (trainState.getUseSpendAction() && trainState.getSpendAction().size() != 0) {
            act = trainState.takeSpendAction();
            if (trainState.getSpendAction().size() == 0) {
                trainState.setUseSpendAction(false);
            }
        } else if (trainState.getAuto() == Auto.select) {
            // act = Print.input(defaultNum, scanner, text);
            act = trainState.takeNextAction();
        } else {
            if (trainState.legalActions().length == 1) {
                act = trainState.legalActions()[0];
                trainState.addChargeAction(act);
                return act;
            }
            act = makeAiAction(trainState, beforeTrainState, scanner, rand);
        }
        trainState.addChargeAction(act);
        return act;
    }

    public static int makeAction(TrainState trainState, TrainState beforeTrainState, Scanner scanner, boolean text, Random rand) {
        return makeAction(trainState, beforeTrainState, 0, scanner, text, rand);
    }

}
