package train;

import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.nio.charset.Charset;
import java.util.Scanner;

import battle.State;
import character.Player;
import character.Skill;
import character.Character.Attribute;
import data.action.Spell;
import data.item.BattleItem;
import game.GameState;
import game.LocationCategory;
import game.SwingTest;
import text.Print;
import text.Print.Color;
import train.TrainState.Mode;

public class SandBox {
    public static void main(String[] args) {
        // SwingTest.addTextS = new StringBuilder();
        // String target = "↓";
        // int byteLength = Print.getByteLength(target, Charset.forName("UTF-8"));
        // int fullWidthNum = (byteLength - target.length()) / 2;
        // int textLength = 0 - target.length() - fullWidthNum;
        // System.out.println("byteLength " + byteLength);
        // System.out.println("textLength " + textLength);
        // System.out.println("target " + target);
        // double a = 0.55;
        // System.out.println((int)a == a);
        // System.out.println(a + "" + a);
        // GameState s = GameState.load(4, false);
        // s.saveLocation(LocationCategory.stageClear, LocationCategory.NO_CHOICE);
        // s.trainState.saveLocation(LocationCategory.delimiterSave, LocationCategory.NO_CHOICE);
        // s.save(4, false);
        for(Spell spell : Spell.values()){
            spell.explain(new State(new Player("魔王", Attribute.A, Skill.NULL, Mode.normal), new Player("魔王", Attribute.A, Skill.NULL, Mode.normal), null, null), true, true, new Scanner(System.in));
        }
    }
}
