package train;

import java.util.EnumMap;
import java.util.Random;
import java.util.Scanner;

import battle.InputAction.Auto;
import character.Player;
import character.Character.Attribute;
import character.Skill;
import data.action.Spell;
import data.item.StartItemSet;
import train.TrainState.Mode;

public final class Test {
    public static void main(String[] args) {
        String name = "勇者";
        Scanner sc = new Scanner(System.in);
        Random rand =  new Random();
        // Train.train(new TrainState(new Player(name, Attribute.A, Skill.guts, Mode.normal), Mode.normal, Auto.select, Auto.select), StartItemSet.Invincible1, true, sc, rand)/*.endState.save(98, true)*/;
        //Train.train(new TrainState(new Player(name, Attribute.A, Skill.monster, new int[] {1000, 1000, 100, 100, 100, 10, 100, 2, 100, 100, 100, 100, 0}, new EnumMap<Spell, Integer>(Spell.class)), Mode.easy, Auto.select, Auto.select), StartItemSet.Mezamasidokei1, true, sc, rand)/*.endState.save(98, true)*/;
        //Train.train(TrainState.load(Integer.MIN_VALUE, true, true), StartItemSet.Karuisi1, true, sc, rand)/*.endState.save(98, true)*/;
        //TrainState state = TrainState.load(98, true);
        sc.close();
    }
}
