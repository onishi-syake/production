package train;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import battle.CalculateDamage;
import battle.State;
import battle.InputAction.Auto;
import character.Enemy;
import character.Player;
import character.Character.Attribute;
import character.Player.TrainStatus;
import data.card.Card;
import data.card.CardWithParams;
import data.card.Guild;
import data.card.TrainMenu;
import data.card.TrainMenuCategory;
import data.card.TrainMenu.TrainResult;
import data.item.BattleItem;
import data.item.DisposableItem;
import data.item.ImmediateItem;
import data.item.Item;
import data.item.StartItemSet;
import data.stage.Stage;
import game.LocationCategory;
import limitation.TrainLimitation;
import limitation.TrainLimitation.TrainLimitationCounter;
import log.unmodifiable.UnmodifiableTrainState;
import text.Print;

public class TrainState implements Serializable {
    private Player self;
    private Map<TrainLimitation, Map<TrainLimitationCounter, Integer>> trainLimitations;
    private Stage stage;
    private Mode mode;
    private int turnLimit;
    private int turn;
    private TimeFrame timeFrame;
    private int step;//AI用

    //TODO コピーコンストラクタに入れ忘れるとここの値を参照することになるので、final以外はコンストラクタで初期化した方がいいのでは？
    private boolean useItem = false;
    private boolean resuscitated = false;
    public boolean isUsedShopFirstFree;
    private int bossRewardShopFree;
    private boolean save = false;

    private TrainStatus beforeTrainMenu = null;
    private List<Integer> beforeUnlimitActions;
    private int chainTrainNum;
    private int chainSameTrainNum;
    private int missedEventChainNum;
    private int battleNum;

    private Enemy boss;
    public static final int startTrainMenuNum = 5;
    // public static final int maxBattleMenuNum = Monster.NUM;
    //public static final int easyMaxBattleMenuNum = Monster.easyNUM();
    private final int baseBattleMenuNum = 4;
    public List<Card> deck;
    private List<CardWithParams> hands;
    public Map<TrainMenuCategory, Integer> trainCategoryLevel;
    private List<Card> addCard;
    private shuffleModeWithAddCard shuffleMode;
    private List<TrainLimitation> tempUnlimits;
    // private List<List<Integer>> battleMenus = new ArrayList<List<Integer>>();

    private boolean useSpendAction;
    private List<Integer> chargeAction;
    private List<Integer> spendAction;
    private int nowChoice;

    private Map<Item, Boolean> buyAble;

    private Auto auto;
    private Auto battleAuto;

    // for state
    private int nextAction;
    private Map<LocationCategory, Integer> savedAction;// 現在位置の保存
    private int labFromTurn;// ラボでどのターンから来たか
    public Enemy tempEnemy;// 敵の一時保存用変数
    public State battleState;// 戦闘のstate
    public List<CardWithParams> trainings;// これから使うカード
    private List<Card> todaysFinishTrain;// 今日既に使ったカード
    public TimeFrame provisionalTimeFrame;// 仮の時間帯（手札選択時に使う）
    private TrainResult trainResult;// 本日の訓練結果
    private List<TrainMenu> definitedGreatSuccessTrainMenu;// その日確定大成功を発動した訓練のリスト
    private List<TrainMenu> gutsTrainMenu;// その日崖っぷち訓練を発動した訓練のリスト
    private Map<TrainStatus, Integer> beforeTrainStatus;// 前回の訓練内容と連続回数
    private boolean isInnRedraw;// 宿屋効果で引き直し待ちかどうか
    private List<Guild> UnbeatenBerserker;// まだ倒してないバーサーカーのリスト
    private List<Guild> UnbeatenAdventurer;// まだ倒してない冒険者のリスト


    public enum Mode{
        easy("イージー", Auto.random, new ArrayList<TimeFrame>(){{
            add(TimeFrame.afternoon);
        }}, 0.5),
        normal("ノーマル", Auto.playout, new ArrayList<TimeFrame>(){{
            add(TimeFrame.afternoon);
            add(TimeFrame.night);
        }}, 1),
        hard("ハード", Auto.mctsS, new ArrayList<TimeFrame>(){{
            add(TimeFrame.morning);
            add(TimeFrame.afternoon);
            add(TimeFrame.night);
        }}, 4),
        debug("デバッグ", Auto.mctsS, new ArrayList<TimeFrame>(){{
            add(TimeFrame.afternoon);
            add(TimeFrame.night);
        }}, -1),
        ;
        public final String jName;
        public final Auto bossAuto;
        public final List<TimeFrame> timeFrameList;
        public final double scale;
        Mode(String jName, Auto bossAuto, List<TimeFrame> timeFrameList, double scale){
            this.jName = jName;
            this.bossAuto = bossAuto;
            this.timeFrameList = timeFrameList;
            this.scale = scale;
        }
    }
    public enum TimeFrame{
        morning("朝"),
        afternoon("昼"),
        night("夜"),
        nextTurn("次の日に移行");
        ;
        public final String jName;
        TimeFrame(String jName){
            this.jName = jName;
        }
        ;
        public static TimeFrame returnNextTimeFrame(TimeFrame nowTimeFrame, Mode mode, int spendActionNum){
            // TODO これでは次のターンに移行するかどうか判定が出来ない（次のターンに移行する時間帯を作るべきか）
            if(nowTimeFrame == nextTurn){
                return null;
            }else if(spendActionNum == mode.timeFrameList.size() - mode.timeFrameList.indexOf(nowTimeFrame)){
                return nextTurn;
            }else if(spendActionNum < mode.timeFrameList.size() - mode.timeFrameList.indexOf(nowTimeFrame)){
                return mode.timeFrameList.get(mode.timeFrameList.indexOf(nowTimeFrame) + spendActionNum);
            }else{
                return null;
            }
        }
        public static boolean checkLegal(TimeFrame nowTimeFrame, Mode mode, int spendActionNum){
            return returnNextTimeFrame(nowTimeFrame, mode, spendActionNum) != null;
        }
        public static TimeFrame returnBackTimeFrame(TimeFrame nowTimeFrame, Mode mode, int spendActionNum){
            if(nowTimeFrame == nextTurn){
                if(spendActionNum == 0){
                    return nextTurn;
                }
                if(0 <= mode.timeFrameList.size() - spendActionNum){
                    return mode.timeFrameList.get(mode.timeFrameList.size() - spendActionNum);
                }else{
                    return null;
                }
            }
            if(0 <= mode.timeFrameList.indexOf(nowTimeFrame) - spendActionNum){
                return mode.timeFrameList.get(mode.timeFrameList.indexOf(nowTimeFrame) - spendActionNum);
            }else{
                return null;
            }
        }
    }
    //TODO 勇者ターンどこで決めるん？
    private List<Integer> bossTurn = new ArrayList<>(){{  //Modeに持たせるべきじゃね
        add(4);
        add(8);
        add(12);
        add(16);
        add(20);
        add(24);
    }};

    // private TrainState(Player self, Map<TrainLimitation, Map<TrainLimitationCounter, Integer>> trainLimitations, Stage stage, Mode mode, int turnLimit, int turn, TimeFrame timeFrame, int step, boolean useItem, boolean resuscitated, boolean useShopFirstFree, boolean save, TrainStatus beforeTrainMenu, List<Card> beforeTurnAction, List<Integer> beforeUnlimitAction, int chainTrainNum, int chainSameTrainNum, int missedEventChainNum, int battleNum, int spendTurn, Enemy[] bosses, int battleMenuNum, List<Card> deck, List<Card> trainMenus, Map<TrainMenu, Integer> trainMenuLevel, List<List<Integer>> battleMenus, boolean useSpendAction, List<Integer> chargeAction, List<Integer> spendAction, int nowChoice, Map<Item, Boolean> buyAble, Auto auto, Auto battleAuto){
    //     this.self = self;
    //     this.trainLimitations = trainLimitations;
    //     this.stage = stage;
    //     this.mode = mode;
    //     this.turnLimit = turnLimit;
    //     this.turn = turn;
    //     this.timeFrame = timeFrame;
    //     this.step = step;
    //     this.useItem = useItem;
    //     this.resuscitated = resuscitated;
    //     this.useShopFirstFree = 
    //     this.save = save;
    //     this.beforeTrainMenu = beforeTrainMenu;
    //     this.beforeTurnActions = beforeTurnAction;
    //     this.beforeUnlimitActions = beforeUnlimitAction;
    //     this.chainTrainNum = chainTrainNum;
    //     this.chainSameTrainNum = chainSameTrainNum;
    //     this.missedEventChainNum = missedEventChainNum;
    //     this.battleNum = battleNum;
    //     this.bosses = bosses;
    //     //this.battleMenuNum = battleMenuNum;
    //     this.deck = deck;
    //     this.trainMenus = trainMenus;
    //     this.trainMenuLevel = trainMenuLevel;
    //     this.battleMenus = battleMenus;
    //     this.useSpendAction = useSpendAction;
    //     this.chargeAction = chargeAction;
    //     this.spendAction = spendAction;
    //     this.nowChoice = nowChoice;
    //     this.buyAble = buyAble;
    //     this.auto = auto;
    //     this.battleAuto = battleAuto;
    // }
    // 初期生成
    public TrainState(Player self, Stage stage, Mode mode, Auto auto, Auto battleAuto, Random rand){
        this.self = self;
        this.trainLimitations = new HashMap<TrainLimitation, Map<TrainLimitationCounter, Integer>>(){{
            for(TrainLimitation key : TrainLimitation.values()){
                Map<TrainLimitationCounter, Integer> counter = new HashMap<TrainLimitationCounter, Integer>(){{
                    put(TrainLimitationCounter.flag, key.useAble(mode) ? 1 : 0);
                    put(TrainLimitationCounter.count, 0);
                }};
                put(key, counter);
            }
        }};
        this.stage = stage;
        this.mode = mode;
        // this.turnLimit = (this.getTrainLimitations().get(TrainLimitation.turn30) ? (this.getTrainLimitations().get(TrainLimitation.randomBoss) ? 33 : 31) : (this.getTrainLimitations().get(TrainLimitation.turn20) ? 21 : 11)) + (self.getSkill() == Skill.longevity && self.getSkill().useAble(self) ? 10 : 0);
        this.turnLimit = 24;
        this.turn = 0;
        this.timeFrame = mode.timeFrameList.get(0);
        this.isUsedShopFirstFree = false;
        this.bossRewardShopFree = 0;
        this.beforeUnlimitActions = new ArrayList<>();
        this.chainTrainNum = 0;
        this.chainSameTrainNum = 0;
        this.missedEventChainNum = 0;
        this.battleNum = 0;
        this.boss = stage.getBosses(mode.bossAuto, rand, BattleItem.Zoukyouzai).get(0);
        this.deck = Card.startDeck(rand);
        this.hands = new ArrayList<>(CardWithParams.startHand);
        this.trainCategoryLevel = new HashMap<TrainMenuCategory, Integer>(){{
            for(TrainMenuCategory category : TrainMenuCategory.values()){
                put(category, 1);
            }
        }};
        this.addCard = new ArrayList<>();
        this.shuffleMode = shuffleModeWithAddCard.BeforeLast;
        this.tempUnlimits = new ArrayList<>();
        this.auto = auto;
        this.battleAuto = battleAuto;
        this.chargeAction = new ArrayList<>();
        this.spendAction = new ArrayList<>();
        this.buyAble = new HashMap<>(){{
            for(DisposableItem key : DisposableItem.values()){
                this.put(key, true);
            }
            for(ImmediateItem key : ImmediateItem.values()){
                this.put(key, true);
            }
            for(BattleItem key : BattleItem.values()){
                this.put(key, true);
            }
        }};
        this.nextAction = LocationCategory.NO_CHOICE;
        this.savedAction = new HashMap<>(){{
            for(LocationCategory act : LocationCategory.values()){
                put(act, LocationCategory.NO_CHOICE);
            }
        }};
        this.labFromTurn = 0;
        this.trainings = new ArrayList<>();
        this.todaysFinishTrain = new ArrayList<>();
        this.trainResult = TrainResult.fault;
        this.definitedGreatSuccessTrainMenu = new ArrayList<>();
        this.gutsTrainMenu = new ArrayList<>();
        this.beforeTrainStatus = new HashMap<>(self.getTrainStatus());
        this.isInnRedraw = false;
        this.UnbeatenBerserker = new ArrayList<>(Guild.berserkerCards);
        this.UnbeatenAdventurer = new ArrayList<>(Guild.adventurerCards);
    }
    protected TrainState(TrainState trainState){
        this.self = trainState.self.modifiableCopy();
        this.trainLimitations = trainState.trainLimitations;
        this.stage = trainState.stage;
        this.mode = trainState.mode;
        this.turnLimit = trainState.turnLimit;
        this.turn = trainState.turn;
        this.timeFrame = trainState.timeFrame;
        this.step = trainState.step;
        this.useItem = trainState.useItem;
        this.resuscitated = trainState.resuscitated;
        this.isUsedShopFirstFree = trainState.isUsedShopFirstFree;
        this.bossRewardShopFree = trainState.bossRewardShopFree;
        this.save = trainState.save;
        this.beforeTrainMenu = trainState.beforeTrainMenu;
        this.beforeUnlimitActions = new ArrayList<>(trainState.beforeUnlimitActions);
        this.chainTrainNum = trainState.chainTrainNum;
        this.chainSameTrainNum = trainState.chainSameTrainNum;
        this.missedEventChainNum = trainState.missedEventChainNum;
        this.battleNum = trainState.battleNum;
        this.boss = trainState.boss.modifiableCopy();
        this.deck = new ArrayList<Card>(trainState.deck);
        this.hands = new ArrayList<CardWithParams>(trainState.hands);
        this.trainCategoryLevel = new HashMap<>(trainState.trainCategoryLevel);
        // this.battleMenus = new ArrayList<List<Integer>>() {{
        //     for(List<Integer> battleMenu : trainState.battleMenus){
        //         add(new ArrayList<>(battleMenu));
        //     }
        // }};
        //this.battleMenuNum = trainState.battleMenuNum;
        this.addCard = new ArrayList<>(trainState.addCard);
        this.shuffleMode = trainState.shuffleMode;
        this.tempUnlimits = new ArrayList<>(trainState.tempUnlimits);
        this.useSpendAction = trainState.useSpendAction;
        this.chargeAction = new ArrayList<>(trainState.chargeAction);
        this.spendAction = new ArrayList<>(trainState.spendAction);
        this.nowChoice = trainState.nowChoice;
        this.buyAble = new HashMap<>(trainState.buyAble);
        this.auto = trainState.auto;
        this.battleAuto = trainState.battleAuto;
        this.nextAction = trainState.nextAction;
        this.savedAction = new HashMap<>(trainState.savedAction);
        this.labFromTurn = trainState.labFromTurn;
        this.trainings = new ArrayList<>(trainState.trainings);
        this.todaysFinishTrain = new ArrayList<>(trainState.todaysFinishTrain);
        this.provisionalTimeFrame = trainState.provisionalTimeFrame;
        this.trainResult = trainState.trainResult;
        this.definitedGreatSuccessTrainMenu = new ArrayList<>(trainState.definitedGreatSuccessTrainMenu);
        this.gutsTrainMenu = new ArrayList<>(trainState.gutsTrainMenu);
        this.beforeTrainStatus = new HashMap<>(trainState.beforeTrainStatus);
        this.isInnRedraw = trainState.isInnRedraw;
        this.UnbeatenBerserker = new ArrayList<>(trainState.UnbeatenBerserker);
        this.UnbeatenAdventurer = new ArrayList<>(trainState.UnbeatenAdventurer);
    }
    public TrainState modifiableCopy(){
        return new TrainState(this);
    }
    public UnmodifiableTrainState unmodifiableCopy(){
        return new UnmodifiableTrainState(this);
    }
    public Player getSelf(){
        return this.self;
    }
    public void setSelf(Player self){
        this.self = self;
    }
    public Map<TrainLimitation, Map<TrainLimitationCounter, Integer>> getTrainLimitations(){
        return this.trainLimitations;
    }
    public void setTrainLimitations(Map<TrainLimitation, Map<TrainLimitationCounter, Integer>> trainLimitations){
        this.trainLimitations = trainLimitations;
    }
    public Mode getMode(){
        return this.mode;
    }
    public void setMode(Mode mode){
        this.mode = mode;
    }
    public Stage getStage(){
        return this.stage;
    }
    public void setStage(Stage stage){
        this.stage = stage;
    }
    public List<Integer> getBossTurn(){
        return this.bossTurn;
    }
    public void setBossTurn(List<Integer> bossTurn){
        this.bossTurn = bossTurn;
    }
    public boolean isEnd(){
        return this.self.getTrainStatus().get(TrainStatus.hp) <= 0;
    }
    public int getTurnLimit(){
        return this.turnLimit;
    }
    public void setTurnLimit(int turnLimit){
        this.turnLimit = turnLimit;
    }
    public int getTurn(){
        return this.turn;
    }
    public void setTurn(int turn){
        this.turn = turn;
    }
    public TimeFrame getTimeFrame(){
        return this.timeFrame;
    }
    public void setTimeFrame(TimeFrame timeFrame){
        this.timeFrame = timeFrame;
    }
    public int getStep(){
        return this.step;
    }
    public void setStep(int step){
        this.step = step;
    }
    public boolean getUseItem(){
        return this.useItem;
    }
    public void setUseItem(Boolean useItem){
        this.useItem = useItem;
    }
    public boolean getResuscitated(){
        return this.resuscitated;
    }
    public void resetResuscitated(){
        this.resuscitated = false;
    }
    public int getBossRewardShopFree(){
        return this.bossRewardShopFree;
    }
    public boolean isBossRewardShopFree(){
        return this.bossRewardShopFree > 0;
    }
    public void winBossRewardShopFree(){
        this.bossRewardShopFree++;
    }
    public void useBossRewardShopFree(){
        this.bossRewardShopFree--;
    }
    public boolean getSave(){
        return this.save;
    }
    public void setSave(Boolean save){
        this.save = save;
    }
    public TrainStatus getBeforeTrainMenu(){
        return this.beforeTrainMenu;
    }
    public void setBeforeTrainMenu(TrainStatus beforeTrainMenu){
        this.beforeTrainMenu = beforeTrainMenu;
    }
    public void resetBeforeTrainMenu(){
        this.beforeTrainMenu = null;
    }
    public List<Integer> getBeforeUnlimitActions(){
        return this.beforeUnlimitActions;
    }
    public void setBeforeUnlimitActions(List<Integer> beforeUnlimitActions){
        this.beforeUnlimitActions = beforeUnlimitActions;
    }
    public void addBeforeUnlimitAction(Integer beforeUnlimitAction){
        this.beforeUnlimitActions.add(beforeUnlimitAction);
    }
    public int getChainTrainNum(){
        return this.chainTrainNum;
    }
    public void setChainTrainNum(int chainTrainNum){
        this.chainTrainNum = chainTrainNum;
    }
    public int getChainSameTrainNum(){
        return this.chainSameTrainNum;
    }
    public void setChainSameTrainNum(int chainSameTrainNum){
        this.chainSameTrainNum = chainSameTrainNum;
    }
    public int getMissedEventChainNum(){
        return this.missedEventChainNum;
    }
    public void setMissedEventChainNum(int missedEventChainNum){
        this.missedEventChainNum = missedEventChainNum;
    }
    public int getBattleNum(){
        return this.battleNum;
    }
    public int getBattleRewardLevel(){
        return this.battleNum;
    }
    public int getBattlePowerLevel(){
        return this.battleNum;
    }
    public void addBattleNum(){
        this.battleNum++;
    }
    public Enemy getBoss(){
        return this.boss;
    }
    public void setBoss(Enemy boss){
        this.boss = boss;
    }
    public List<CardWithParams> getHands(){
        return this.hands;
    }
    public void setHands(List<CardWithParams> hands){
        this.hands = hands;
    }
    // 手札を捨てる為のメソッド
    // LocationCategory.dropTrainMenuNumに捨てる枚数を保存してから呼び出す
    public void dropTrainMenu(boolean text){
        final int EXPLAIN = 1;
        final int DROP_CARD = 2;
        final int slide_idx = 1;
        switch(this.getSavedLocation(LocationCategory.dropTrainMenu)){
            case LocationCategory.NO_CHOICE:
                this.saveLocation(LocationCategory.dropTrainMenu, EXPLAIN);
                dropTrainMenu(text);
                return;

            case EXPLAIN:
                if(this.hands.size() == 0){
                    Print.println("", true, Print.highSpeed, text);
                    Print.println("手札をすべて捨てた", true, Print.highSpeed, text);
                    Print.clearStaticText(text);
                    Print.changeWaitTextToLT(text);
                    this.saveLocation(LocationCategory.dropTrainMenu, DROP_CARD);
                    return;
                }
                Print.startFrame(false, text);
                Print.println("捨てるカードを選んでください", Print.highSpeed, text);
                Print.println("残り" + this.getSavedLocation(LocationCategory.dropTrainMenuNum) + "枚", Print.highSpeed, text);
                Print.println("", Print.highSpeed, text);
                for(int i = 0; i < this.hands.size(); i++){
                    Card card = this.hands.get(i).card;
                    Print.println((i + slide_idx) + ":" + card.jName(), EXPLAIN, text);
                }
                Print.endFrame(false, text);
                this.saveLocation(LocationCategory.dropTrainMenu, DROP_CARD);
                return;

            case DROP_CARD:
                if(this.hands.size() == 0){
                    this.saveLocation(LocationCategory.dropTrainMenuNum, 0);
                    this.saveLocation(LocationCategory.dropTrainMenu, LocationCategory.FINISH);
                    return;
                }
                int idx = takeNextAction() - slide_idx;
                try {
                    this.saveLocation(LocationCategory.dropTrainMenuNum, this.getSavedLocation(LocationCategory.dropTrainMenuNum) - this.hands.get(idx).card.getCardSize());
                    this.hands.remove(idx);
                } catch (Exception e) {
                    System.out.println("正しく入力してください");
                    this.saveLocation(LocationCategory.dropTrainMenu, EXPLAIN);
                    dropTrainMenu(text);
                    return;
                }
                if(this.getSavedLocation(LocationCategory.dropTrainMenuNum) <= 0){
                    this.saveLocation(LocationCategory.dropTrainMenu, LocationCategory.FINISH);
                    return;
                }else{
                    this.saveLocation(LocationCategory.dropTrainMenu, EXPLAIN);
                    dropTrainMenu(text);
                    return;
                }

            default:
                System.out.println("exception drop trainMenu");
                this.saveLocation(LocationCategory.dropTrainMenuNum, 0);
                this.saveLocation(LocationCategory.dropTrainMenu, LocationCategory.FINISH);
                return;

        }
    }
    // public List<List<Integer>> getBattleMenus(){
    //     return this.battleMenus;
    // }
    // public List<List<Integer>> getBattleMenus(TimeFrame timeFrame){
    //     return timeFrame != TimeFrame.night ? getWeakBattleMenus() : this.battleMenus;
    // }
    // public List<List<Integer>> getWeakBattleMenus(){
    //     List<List<Integer>> normalBattleMenus = new ArrayList<>(this.battleMenus);
    //     return new ArrayList<List<Integer>>(){{
    //         for(List<Integer> battleMenu : normalBattleMenus){
    //             add(new ArrayList<Integer>(){{
    //                 for(int battleEnemy : battleMenu){
    //                     Monster monster = Monster.values()[battleEnemy];
    //                     Monster weakMonster = monster.rankDownMonster != null ? monster.rankDownMonster : monster;
    //                     add(weakMonster.ordinal());
    //                 }
    //             }});
    //         }
    //     }};
    // }
    // public void addBattleMenus(List<Integer> battleMenu){
    //     this.battleMenus.add(battleMenu);
    // }
    // public void refreshBattleMenus(List<Integer> battleMenu, int turn){
    //     this.battleMenus.remove(turn - 1);
    //     this.battleMenus.add(turn - 1, battleMenu);
    // }
    // public void setBattleMenus(List<List<Integer>> battleMenus){
    //     this.battleMenus = battleMenus;
    // }
    public int getBattleMenuNum(){
        // return this.baseBattleMenuNum + this.battleNum;
        return this.baseBattleMenuNum;
    }
    /*public void setBattleMenuNum(int num){
        this.battleMenuNum = num;
    }*/
    public enum shuffleModeWithAddCard{
        BeforeLast, 
        Last, 
    };
    // デッキに追加するカードを保存する
    public void saveAddCard(List<Card> addCard, shuffleModeWithAddCard shuffleMode){
        this.addCard.addAll(addCard);
        this.shuffleMode = shuffleMode;
    }
    // 保存したカードをデッキに追加する
    public void addCardToDeck(boolean afterBoss, boolean text){
        Card card;
        for(int i = 0; i < this.addCard.size(); i++){
            card = addCard.get(i);
            this.deck.add(card);
            Print.println(card.jName() + "が" + (afterBoss ? "デッキに" : "デッキの一番上に") + "追加された" + Print.sleep(afterBoss ? 2 : 10), true, Print.highSpeed, text);
            
            if(shuffleMode == shuffleModeWithAddCard.BeforeLast && i == addCard.size() - 1){
                //シャッフルしない
            }else{
                shuffleDeck(text && !afterBoss);
            }
        }
        this.addCard.clear();
    }
    // デッキをシャッフル
    public void shuffleDeck(boolean text){
        Collections.shuffle(this.deck);
        Print.println("デッキがシャッフルされた" + Print.sleep(10), true, Print.highSpeed, text);
        
    }
    // 解放する要素を保存する
    public void saveUnlimits(List<TrainLimitation> unlimits){
        this.tempUnlimits.addAll(unlimits);
    }
    // 保存した解放する要素を解放する
    public void unlimitSaveUnlimits(boolean text, Scanner scanner){
        for(TrainLimitation limit : this.tempUnlimits){
            TrainLimitation.unlimit(this, limit, limit.unlimitCount, text, scanner);
        }
        this.tempUnlimits = new ArrayList<TrainLimitation>();
    }
    public boolean getUseSpendAction(){
        return this.useSpendAction;
    }
    public void setUseSpendAction(Boolean useSpendAction){
        this.useSpendAction = useSpendAction;
    }
    public List<Integer> getChargeAction(){
        return this.chargeAction;
    }
    public void setChargeAction(List<Integer> chargeAction){
        this.chargeAction = chargeAction;
    }
    public void addChargeAction(int act){
        this.chargeAction.add(act);
    }
    public List<Integer> getSpendAction(){
        return this.spendAction;
    }
    public void setSpendAction(List<Integer> spendAction){
        this.spendAction = spendAction;
    }
    public int takeSpendAction(){
        int act = spendAction.get(0);
        spendAction.remove(0);
        return act;
    }
    public int getNowChoice(){
        return this.nowChoice;
    }
    public void setNowChoice(int nowChoice){
        this.nowChoice = nowChoice;
    }
    public Map<Item, Boolean> getBuyAble(){
        return this.buyAble;
    }
    public void setBuyAble(Map<Item, Boolean> buyAble){
        this.buyAble = buyAble;
    }
    public Auto getAuto(){
        return this.auto;
    }
    public void setAuto(Auto auto){
        this.auto = auto;
    }
    public Auto getBattleAuto(){
        return this.battleAuto;
    }
    public void setBattleAuto(Auto battleAuto){
        this.battleAuto = battleAuto;
    }
    public void getNextAction(int action){
        this.nextAction = action;
    }
    public int takeNextAction(){
        int temp = this.nextAction;
        this.nextAction = LocationCategory.NO_CHOICE;
        return temp;
    }
    public void sendNextActionToBattleState(){
        this.battleState.getNextAction(this.nextAction);
        this.nextAction = LocationCategory.NO_CHOICE;
    }
    public void sendNextActionToSelf(){
        this.self.getNextAction(this.nextAction);
        this.nextAction = LocationCategory.NO_CHOICE;
    }
    public void saveLocation(LocationCategory category, Integer location){
        this.savedAction.replace(category, location);
    }
    public int getSavedLocation(LocationCategory category){
        return this.savedAction.get(category);
    }
    public void labPastJump(boolean text){
        if(this.labFromTurn < this.turn){
            this.labFromTurn = this.turn;
        }
        this.turn -= 2;
        Print.println("日付が巻き戻った", true, Print.highSpeed, text);
    }
    public int getLabFromTurn(){
        return this.labFromTurn;
    }
    public TrainStatus getProvisionalBeforeTrainMenu(){
        return getProvisionalBeforeTrainMenu(this.trainings.size());
    }
    public TrainStatus getProvisionalBeforeTrainMenu(int choiceTime){
        CardWithParams lastTrain = CardWithParams.lastCardWithSpendAction(this.trainings.subList(0, choiceTime));
        if(lastTrain == null){
            return this.beforeTrainMenu;
        }else{
            TrainStatus beforeTrainMenu = null;
            if(lastTrain.card instanceof TrainMenu){
                TrainMenu menu = (TrainMenu)lastTrain.card;
                beforeTrainMenu = (TrainStatus)menu.trainCategory.keySet().toArray()[0];
            }
            return beforeTrainMenu;
        }
    }
    // 今日の終了した訓練を取り出して削除
    public List<Card> pullTodaysFinishTrain(){
        List<Card> result = this.todaysFinishTrain;
        this.todaysFinishTrain = new ArrayList<>();
        return result;
    }
    // 今日の終了した訓練を追加
    public void addTodaysFinishTrain(Card finishCard){
        this.todaysFinishTrain.add(finishCard);
    }
    public TrainResult getTrainResult(){
        return this.trainResult;
    }
    public void setTrainResult(TrainResult trainResult){
        this.trainResult = trainResult;
    }
    public void drawTrainResult(Random rand){
        this.trainResult = TrainMenu.drawResult(self, rand);
    }
    public List<TrainMenu> getDefinitedGreatSuccessTrainMenu(){
        return this.definitedGreatSuccessTrainMenu;
    }
    public void addDefinitedGreatSuccessTrainMenu(TrainMenu menu){
        this.definitedGreatSuccessTrainMenu.add(menu);
    }
    public void resetDefinitedGreatSuccessTrainMenu(){
        this.definitedGreatSuccessTrainMenu = new ArrayList<>();
    }
    public List<TrainMenu> getGutsTrainMenu(){
        return this.gutsTrainMenu;
    }
    public void addGutsTrainMenu(TrainMenu menu){
        this.gutsTrainMenu.add(menu);
    }
    public void resetGutsTrainMenu(){
        this.gutsTrainMenu = new ArrayList<>();
    }
    public Map<TrainStatus, Integer> getChangedMountTrainStatus(){
        Map<TrainStatus, Integer> changeMount = new HashMap<>();
        Map<TrainStatus, Integer> afterTrainStatus = new HashMap<>(self.getTrainStatus());
        for(TrainStatus key : TrainStatus.values()){
            if(beforeTrainStatus.get(key).intValue() != afterTrainStatus.get(key).intValue()){
                changeMount.put(key, afterTrainStatus.get(key).intValue() - beforeTrainStatus.get(key).intValue());
            }
        }
        return changeMount;
    }
    public void setBeforeTrainStatus(){
        this.beforeTrainStatus = new HashMap<>(self.getTrainStatus());
    }
    public Map<TrainStatus, Integer> getBeforeTrainStatus(){
        return this.beforeTrainStatus;
    }
    public void setInnRedraw(){
        this.isInnRedraw = true;
    }
    public void useInnRedraw(){
        this.isInnRedraw = false;
    }
    public boolean getInnRedraw(){
        return this.isInnRedraw;
    }
    public void updateGuild(){
        for(CardWithParams card : this.hands){
            if(card.card instanceof Guild){
                card.card = _nextGuild((Guild)card.card);
            }
        }
    }
    private Guild _nextGuild(Guild oldGuild){
        Guild nextGuild;
        boolean fromNaked = Guild.nakedCards.contains(oldGuild);
        boolean fromJewelry = Guild.jewelryCards.contains(oldGuild);
        oldGuild = oldGuild.toNormal();
        if(Guild.berserkerCards.contains(oldGuild)){
            nextGuild = this.UnbeatenBerserker.get((this.UnbeatenBerserker.indexOf(oldGuild) + 1) % this.UnbeatenBerserker.size());
            if(fromNaked){
                nextGuild = nextGuild.toNaked();
            }
            if(fromJewelry){
                nextGuild = nextGuild.toJewelry();
            }
            return nextGuild;
        }
        if(Guild.adventurerCards.contains(oldGuild)){
            nextGuild = this.UnbeatenAdventurer.get((this.UnbeatenAdventurer.indexOf(oldGuild) + 1) % this.UnbeatenAdventurer.size());
            if(fromNaked){
                nextGuild = nextGuild.toNaked();
            }
            if(fromJewelry){
                nextGuild = nextGuild.toJewelry();
            }
            return nextGuild;
        }
        if(fromNaked){
            oldGuild = oldGuild.toNaked();
        }
        if(fromJewelry){
            oldGuild = oldGuild.toJewelry();
        }
        return oldGuild;
    }
    public void resetJewelryAndNaked(){
        for(CardWithParams card : this.hands){
            if(card.card instanceof Guild){
                card.card = ((Guild)card.card).toNormal();
            }
        }
    }
    public void resetUnbeatenGuild(){
        resetUnbeatenBerserker();
        resetUnbeatenAdventurer();
    }
    private void resetUnbeatenBerserker(){
        this.UnbeatenBerserker = new ArrayList<>(Guild.berserkerCards);
    }
    private void resetUnbeatenAdventurer(){
        this.UnbeatenAdventurer = new ArrayList<>(Guild.adventurerCards);
    }
    public void removeUnbeatenGuild(Guild removeGuild){
        removeGuild = removeGuild.toNormal();
        if(Guild.berserkerCards.contains(removeGuild)){
            _removeUnbeatenBerserker(removeGuild);
        }
        if(Guild.adventurerCards.contains(removeGuild)){
            _removeUnbeatenAdventurer(removeGuild);
        }
    }
    private void _removeUnbeatenBerserker(Guild removeGuild){
        this.UnbeatenBerserker.remove(removeGuild);
        if(this.UnbeatenBerserker.size() == 0){
            resetUnbeatenBerserker();
        }
    }
    private void _removeUnbeatenAdventurer(Guild removeGuild){
        this.UnbeatenAdventurer.remove(removeGuild);
        if(this.UnbeatenAdventurer.size() == 0){
            resetUnbeatenAdventurer();
        }
    }
    public void resuscitate(boolean heal, boolean text){
        this.resuscitated = true;
        if(heal){
            CalculateDamage.trainDamage(this.self, TrainStatus.maxHp, -100, text);
        }
    }
    public void noResuscitate(){
        this.resuscitated = true;
    }
    public void openStartItemSet(StartItemSet itemSet, boolean text, Scanner scanner, Random rand){
        Map<DisposableItem, Integer> disposableItems = self.getDisposableItemList();
        Map<BattleItem, Integer> battleItems = self.getItemList();
        for(Item key: itemSet.items.keySet()){
            if(key instanceof DisposableItem){
                DisposableItem dKey = (DisposableItem)key;
                disposableItems.replace(dKey, disposableItems.get(dKey) + itemSet.items.get(dKey));
            }else if(key instanceof BattleItem){
                BattleItem bKey = (BattleItem)key;
                battleItems.replace(bKey, battleItems.get(bKey) + itemSet.items.get(bKey));
            }
        }
        self.setDisposableItemList(disposableItems);
        self.setItemList(battleItems);
        BattleItem.dromItem(self, auto, rand, scanner, text);
    }
    public int[] legalActions(){
        return new int[0];
        // if(chargeAction.size() == 0){//初期行動
        //     if(auto == Auto.select){
        //         return new int[]{1, 2, 3};
        //     }else{
        //         List<Integer> legalActions = new ArrayList<Integer>();
        //         step %= 4;
        //         switch(step){//後で作る
        //             case 0:
        //             case 1:
        //                 legalActions.add(0);
        //                 Map<TrainStatus, Integer> trainStatus = this.self.getTrainStatus();
        //                 double inflation = Item.inflationCoef(this.getTurn());
        //                 for(int i = 0; i < Item.shopNUM(this, Shop.Normal, mode); i++){
        //                     Item item = Item.shopItemList(this, Shop.Normal).get(i);
        //                     if(!this.buyAble.get(item) || (item instanceof ImmediateItem && !((ImmediateItem)item).useAble(this))){
        //                         continue;
        //                     }else{
        //                         if(Math.round(item.getCost(this.self) * inflation) <= trainStatus.get(TrainStatus.money)){
        //                             legalActions.add(i+1);
        //                         }
        //                     }
        //                 }
        //                 break;
        //             case 2://(通し番号)
        //                 legalActions.add(DisposableItem.NUM);
        //                 for(int i = 0; i < DisposableItem.NUM; i++){
        //                     if(self.getDisposableItemList().get(DisposableItem.values()[i]) != 0){
        //                         if(DisposableItem.values()[i].useAble(this)){
        //                             legalActions.add(i);
        //                         }
        //                     }
        //                 }
        //                 break;
        //             case 3://(通し番号)
        //                 /* if(bossTurn.contains(turn)){
        //                     legalActions.add(1 + (TrainMenu.NUM + RestMenu.NUM + TrainEvent.NUM));
        //                     break;
        //                 }else */{
        //                     for(int i = 0; i < this.hands.size(); i++){
        //                         if(hands.get(i).card.getLegal(this, timeFrame, mode)){
        //                             legalActions.add(hands.get(i).card.getOrdinalNumber());
        //                         }
        //                     }
        //                     if(mode != Mode.easy || turn > 10){
        //                         // for(int i = 0; i < this.baseBattleMenuNum; i++){
        //                         //     legalActions.add(battleMenus.get(this.turn-1).get(i) + (TrainMenu.NUM + RestMenu.NUM + TrainEvent.NUM));
        //                         // }
        //                         // if(legalActions.size() == 0){
        //                         //     legalActions.add(battleMenus.get(this.turn-1).get(0) + (TrainMenu.NUM + RestMenu.NUM + TrainEvent.NUM));
        //                         // }
        //                     }else if(legalActions.size() == 0){
        //                         legalActions.add(-1);// error
        //                     }
        //                     break;
        //                 }
        //         }
        //         return legalActions.stream().mapToInt(i->i).toArray();
        //     }
        // }else if(chargeAction.get(0) == 1){//鍛錬
        //     if(chargeAction.size() == 1){
        //         return hands.stream().mapToInt(i->i.card.getOrdinalNumber()).toArray();
        //     }else if(chargeAction.get(1) == TrainMenu.NUM + RestMenu.NUM){//光商人
        //         if(chargeAction.size() % 3 == 2){
        //             Player self = this.getSelf();
        //             List<Integer> legalActionsList = new ArrayList<Integer>();
        //             double inflation = Item.inflationCoef(this.getTurn());
        //             List<Item> itemList = new ArrayList<>(Item.shopItemList(this, Shop.Shine));
        //             for(int i = 0; i < chargeAction.size(); i++){
        //                 if(i != 2 && i % 3 == 2){
        //                     itemList.remove(Item.shopItemList(this, Shop.Shine).get(chargeAction.get(i)-1));
        //                 }
        //             }
        //             for(int i = 0; i < Item.shopNUM(this, Shop.Shine, mode); i++){
        //                 Item shineItem = Item.shopItemList(this, Shop.Shine).get(i);
        //                 if(!(!this.getBuyAble().get(shineItem) || (shineItem instanceof ImmediateItem && !((ImmediateItem)shineItem).useAble(this)) || (!itemList.contains(shineItem) && !shineItem.getSomeBuyAble()))){
        //                     if((int)(Item.shopItemList(this, Shop.Shine).get(i).getCost(this.self) * inflation / 2) <= self.getTrainStatus().get(TrainStatus.money)){
        //                         legalActionsList.add(i+1);
        //                     }
        //                 }
        //             }
        //             legalActionsList.add(Item.shopNUM(this, Shop.Shine, mode) + 1);//無購入
        //             return legalActionsList.stream().mapToInt(i->i).toArray();
        //         }else if(chargeAction.size() % 3 == 0){//光商人個数選択
        //             return new int[]{1};
        //         }else if(chargeAction.size() % 3 == 1){//再購入
        //             return new int[]{0};//{1};
        //         }else{//
        //             return new int[]{-1};//{1};
        //         }
        //     }else{//光商人以外に特殊な選択が必要な物はない
        //         System.out.println("不正な入力です1");
        //         return new int[0];
        //     }
        // }else if(chargeAction.get(0) == 2){//戦闘
        //     /* if(bossTurn.contains(turn)){//勇者戦
        //         return new int[]{1};
        //     }else  */if(chargeAction.size() == 1){//戦闘前(通し番号)
        //         // return battleMenus.get(this.turn-1).stream().mapToInt(i->i).toArray();
        //     }else{//戦闘後宿屋選択
        //         return new int[]{1, 2};
        //     }
        // }else if(chargeAction.get(0) == 3){//アイテム
        //     if(chargeAction.size() == 1){
        //         return new int[]{1, 2};
        //     }else if(chargeAction.get(1) == 1){//購入(0で無購入)
        //         if(chargeAction.size() == 2){
        //             double inflation = Item.inflationCoef(this.getTurn());
        //             List<Integer> legalActionsList = new ArrayList<Integer>();
        //             for(int i = 0; i < Item.shopNUM(this, Shop.Normal, mode); i++){
        //                 Item item = Item.shopItemList(this, Shop.Normal).get(i);
        //                 if(!this.buyAble.get(item) || (item instanceof ImmediateItem && !((ImmediateItem)item).useAble(this))){
        //                 }else{
        //                     if(Math.round(item.getCost(this.self) * inflation) <= self.getTrainStatus().get(TrainStatus.money)){
        //                         legalActionsList.add(i+1);
        //                     }
        //                 }
        //             }
        //             legalActionsList.add(0);
        //             return legalActionsList.stream().mapToInt(i->i).toArray();
        //         }else{//個数選択
        //             return new int[]{1};
        //         }
        //     }else if(chargeAction.get(1) == 2){//使用(DisposableItem.NUMで無使用)(通し番号)
        //         List<Integer> legalActionsList = new ArrayList<Integer>();
        //         if(this.getUseItem()){
        //             return new int[]{DisposableItem.NUM};
        //         }
        //         for(DisposableItem key: DisposableItem.values()){
        //             if(self.getDisposableItemList().get(key) != 0){
        //                 if(key.useAble(this)){
        //                     legalActionsList.add(key.ordinal());
        //                 }
        //             }
        //         }
        //         legalActionsList.add(DisposableItem.NUM);
        //         return legalActionsList.stream().mapToInt(i->i).toArray();
        //     }else{//アイテムに3番以降は無い
        //         System.out.println("不正な入力です2");
        //         return new int[0];
        //     }
        // }else if(chargeAction.get(0) == 5){//イベント
        //     if(chargeAction.size() == 1){//イベントだけ選ばれることはない
        //         System.out.println("不正な入力です3");
        //         return new int[0];
        //     }else if(chargeAction.get(1) >= Event.NUM){//イベント数より多くなることは無い
        //         System.out.println("不正な入力です4");
        //         return new int[0];
        //     }else{//(通し番号)
        //         if(chargeAction.size() == 2){
        //             return Event.values()[chargeAction.get(1)].legalActions(this);
        //         }else if(chargeAction.get(1) == Event.DarkShop.ordinal()){//闇商人購入数
        //             return new int[]{1};
        //         }else{
        //             System.out.println("不正な入力です5");
        //             return new int[0];
        //         }
        //     }
        // }else if(chargeAction.get(0) == 6){//戦後宿屋
        //     return new int[]{1, 2};
        // }else{
        //     System.out.println("不正な入力です6");
        //     return new int[0];
        // }
    }

    public static String actionName(TrainState trainState, List<Integer> action, Mode mode){
        return "";
        // //TODO ワンプレイの外側にあるメソッドで行動の種類判定のためにtrainStateを使うべきではない（通し番号にすべき）
        // if(action.size() == 0){//初期行動
        //     return "行動してない";
        // }else if(action.get(0) == 1){//鍛錬
        //     if(action.size() == 1){
        //         return "強化までしか選んでないのはおかしい";
        //     }else if(action.get(1) == TrainMenu.NUM + RestMenu.NUM){//光商人
        //         return "光商人";
        //         /*if(chargeAction.size() % 3 == 2){
        //             Player self = this.getSelf();
        //             List<Integer> legalActionsList = new ArrayList<Integer>();
        //             double inflation = Math.pow(Item.inflationCoefinflationCoef, this.getTurn() - 1);
        //             List<Item> itemList = new ArrayList<>(Item.itemList(Shop.Shine, trainState.getMode()));
        //             for(int i = 0; i < chargeAction.size(); i++){
        //                 if(i != 2 && i % 3 == 2){
        //                     itemList.remove(Item.itemList(Shop.Shine, trainState.getMode()).get(chargeAction.get(i)-1));
        //                 }
        //             }
        //             for(int i = 0; i < Item.NUM(Shop.Shine, trainState.getMode()); i++){
        //                 Item shineItem = Item.itemList(Shop.Shine, trainState.getMode()).get(i);
        //                 if(!(!this.getBuyAble().get(shineItem) || (shineItem instanceof ImmediateItem && !((ImmediateItem)shineItem).useAble(this)) || (!itemList.contains(shineItem) && !shineItem.getSomeBuyAble()))){
        //                     if((int)(Item.itemList(Shop.Shine, trainState.getMode()).get(i).getCost() * inflation / 2) <= self.getTrainStatus().get(TrainStatus.money)){
        //                         legalActionsList.add(i+1);
        //                     }
        //                 }
        //             }
        //             legalActionsList.add(Item.NUM(Shop.Shine, trainState.getMode()) + 1);//無購入
        //             return legalActionsList.stream().mapToInt(i->i).toArray();
        //         }else if(chargeAction.size() % 3 == 0){//光商人個数選択
        //             return new int[]{1};
        //         }else if(chargeAction.size() % 3 == 1){//再購入
        //             return new int[]{0};//{1};
        //         }else{//
        //             return new int[]{-1};//{1};
        //         }*/
        //     }else if(action.get(1) < TrainMenu.NUM){
        //         return TrainMenu.values()[action.get(1)].jName;
        //     }else if(action.get(1) < TrainMenu.NUM + RestMenu.NUM){
        //         return RestMenu.values()[action.get(1)-TrainMenu.NUM].jName;
        //     }else if(action.get(1) < TrainMenu.NUM + RestMenu.NUM + TrainEvent.NUM){
        //         return TrainEvent.values()[action.get(1)-TrainMenu.NUM-RestMenu.NUM].jName;
        //     }else{
        //         return "良く分からん";
        //     }
        // }else if(action.get(0) == 2){//戦闘
        //     if(action.size() == 1){
        //         return "ギルドしか選んでないのはおかしい";
        //     }else if(action.size() == 2){
        //         if(action.get(1) >= Monster.NUM){
        //             return "ギルド：" + Boss.values()[action.get(1) - Monster.NUM].jName;
        //         }
        //         //return "ギルド：" + (mode == Mode.easy ? Monster.easyValues() : Monster.values())[action.get(1)].jName;
        //         return "ギルド：" + Monster.values()[action.get(1)].jName;
        //     }else{
        //         return "良く分からん";
        //     }
        // }else if(action.get(0) == 3){//アイテム
        //     if(action.size() == 1){
        //         return "アイテムまでしか選んでないのはおかしい";
        //     }else if(action.get(1) == 1){//購入(0で無購入)
        //         if(action.size() == 2){
        //             return "アイテムの購入までしか選んでないのはおかしい";
        //         }else if(action.size() == 3){
        //             if(action.get(2) == 0){
        //                 return "アイテム購入：無購入";
        //             }
        //             return "購入アイテムまでしか選んでないのはおかしい";
        //         }else if(action.size() == 4){
        //             return "アイテム購入：" + Item.shopItemList(trainState, Shop.Normal).get(action.get(2)-1).getJName() + action.get(3) + "個";
        //         }else{//個数選択
        //             return "良く分からん";
        //         }
        //     }else if(action.get(1) == 2){//使用(DisposableItem.NUMで無使用)(通し番号)
        //         if(action.size() == 2){
        //             return "アイテム使用までしか選んでないのはおかしい";
        //         }else if(action.size() == 3){
        //             if(action.get(2) == DisposableItem.NUM){
        //                 return "アイテム使用：無使用";
        //             }
        //             return "アイテム使用：" + DisposableItem.values()[action.get(2)].getJName();
        //         }else{
        //             return "良く分からん";
        //         }
        //     }else{//アイテムに3番以降は無い
        //         return "良く分からん";
        //     }
        // }else if(action.get(0) == 5){//イベント
        //     if(action.size() == 1){//イベントだけ選ばれることはない
        //         return "イベントだけ選ばれるのはおかしい";
        //     }else if(action.get(1) >= Event.NUM){//イベント数より多くなることは無い
        //         return "イベント数より多くなることは無い";
        //     }else{//(通し番号)
        //         if(action.size() == 2){
        //             if(action.get(1) == Event.battle.ordinal()){
        //                 return "イベント：強制戦闘";
        //             }
        //             return "イベントだけ選ばれることはない";
        //         }else if(action.size() == 3){
        //             return "イベント：" + Event.values()[action.get(1)].jName + "　選択肢" + action.get(2);
        //         }else if(action.get(1) == Event.DarkShop.ordinal()){//闇商人購入数
        //             if(action.get(2) == Item.shopNUM(trainState, Shop.Dark, mode)){
        //                 return "イベント：" + Event.values()[action.get(1)].jName + "　購入アイテム：なし";
        //             }
        //             return "イベント：" + Event.values()[action.get(1)].jName + "　購入アイテム：" + Item.shopItemList(trainState, Shop.Dark).get(action.get(2)) + action.get(3) + "個";
        //         }else{
        //             return "良く分からん";
        //         }
        //     }
        // }else if(action.get(0) == 6){//戦後宿屋
        //     return "戦闘後宿屋：" + (action.get(2) == 1 ? "行った" : "行ってない");
        // }else{
        //     return "良く分からん";
        // }
    }

    public int[] aiLegalActions(){
        return new int[0];
        // if(chargeAction.size() == 0){//初期行動
        //     if(auto != Auto.select){
        //         List<Integer> legalActions = new ArrayList<Integer>();
        //         step %= 4;
        //         switch(step){//後で作る
        //             case 0:
        //             case 1:
        //                 legalActions.add(0);
        //                 double inflation = Item.inflationCoef(this.getTurn());
        //                 for(int i = 0; i < Item.shopNUM(this, Shop.Normal, mode); i++){
        //                     Item item = Item.shopItemList(this, Shop.Normal).get(i);
        //                     if(!this.buyAble.get(item) || (item instanceof ImmediateItem && !((ImmediateItem)item).useAble(this))){
        //                         continue;
        //                     }else{
        //                         if(Math.round(item.getCost(this.self) * inflation) <= self.getTrainStatus().get(TrainStatus.money)){
        //                             legalActions.add(i+1);
        //                         }
        //                     }
        //                 }
        //                 break;
        //             case 2:
        //                 legalActions.add(DisposableItem.NUM);
        //                 for(int i = 0; i < DisposableItem.NUM; i++){
        //                     if(self.getDisposableItemList().get(DisposableItem.values()[i]) != 0){
        //                         if(DisposableItem.values()[i].useAble(this)){
        //                             if(DisposableItem.values()[i].aiUseAble(this)){
        //                                 legalActions.add(i);
        //                             }
        //                         }
        //                     }
        //                 }
        //                 break;
        //             case 3://(通し番号)
        //                 /* if(bossTurn.contains(turn)){
        //                     legalActions.add(1 + (TrainMenu.NUM + RestMenu.NUM + TrainEvent.NUM));
        //                     break;
        //                 }else */{
        //                     for(int i = 0; i < this.hands.size(); i++){
        //                         if(hands.get(i).card.getLegal(this, timeFrame, mode)){
        //                             if(hands.get(i).card instanceof RestMenu){
        //                                 RestMenu restMenu = (RestMenu)hands.get(i).card;
        //                                 if(restMenu.getAiLegal(this, timeFrame, mode)){
        //                                     legalActions.add(restMenu.getOrdinalNumber());
        //                                 }
        //                             }else{
        //                                 legalActions.add(hands.get(i).card.getOrdinalNumber());
        //                             }
        //                         }
        //                     }
        //                     self.trainToBattleStatus();
        //                     if(mode != Mode.easy || turn > 10){
        //                         for(int i = 0; i < this.baseBattleMenuNum; i++){//
        //                             /*if((this.getMode() == Mode.easy ? Monster.easyValues() : Monster.values())[battleMenus.get(this.turn-1).get(i)].generalPower() <= self.generalPower(false) * 4){
        //                                 legalActions.add(battleMenus.get(this.turn-1).get(i) + (TrainMenu.generalNUM() + RestMenu.generalNUM() + TrainEvent.generalNUM()));
        //                             }*/
        //                             if(Monster.values()[battleMenus.get(this.turn-1).get(i)].generalPower() <= self.generalPower(false) * 4){
        //                                 legalActions.add(battleMenus.get(this.turn-1).get(i) + (TrainMenu.NUM + RestMenu.NUM + TrainEvent.NUM));
        //                             }
        //                         }
        //                     }
        //                     if(legalActions.size() == 0){//legalActionなし保険
        //                         return legalActions();
        //                     }
        //                     break;
        //                 }
        //         }
        //         return legalActions.stream().mapToInt(i->i).toArray();
        //     }
        // }
        // return legalActions();
    }

    public void save(int num, boolean text) {
        try{
            Files.createDirectories(Paths.get("javaquest//saveDir"));
        }catch(FileAlreadyExistsException e){
            System.out.println("同じ名前のファイルが存在します");
        }catch(IOException e){
            System.out.println("入出力エラーもしくは親ディレクトリなし");
        }
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(new File("javaquest//saveDir//savedata_for_javaquest_" + num + ".txt"), false))) {
            Print.println("", Print.highSpeed, text);
            Print.println("セーブが完了しました", Print.highSpeed, text);
            oos.writeObject(this);
        } catch (IOException e) {
            Print.println("", Print.highSpeed, text);
            Print.println("正常に保存出来ませんでした", Print.highSpeed, text);
            e.printStackTrace();
        }
    }

    public static TrainState load(int num, boolean delete, boolean text) {
        TrainState state = null;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(new File("javaquest//saveDir//savedata_for_javaquest_" + num + ".txt")))) {
            state = (TrainState) ois.readObject();
            Print.println("", Print.highSpeed, text);
            Print.println("ロードが完了しました", Print.highSpeed, text);
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("正常に読み込めませんでした");
            e.printStackTrace();
        }
        if(delete){
            fileDelete(new File("javaquest//saveDir//savedata_for_javaquest_" + num + ".txt"), text);
        }
        return state;
    }

    public static List<Integer> saveDataNums(){
        File f = new File("javaquest//saveDir");
        File[] fs = f.listFiles();
        List<Integer> dataNums = new ArrayList<Integer>();
        if(fs != null){
            for(int i = 0; i < fs.length; i++){
               dataNums.add(Integer.parseInt(fs[i].getName().split("savedata_for_javaquest_")[1].split(".txt")[0]));
            }
        }
        return dataNums;
    }

    private static void fileDelete(File file, boolean text){
        if (file.isFile()) {
            if(file.delete()){
                Print.println("デリートされました", Print.highSpeed, text);
            };
        }else if(file.isDirectory()){
            File[] files = file.listFiles();
            for(int i=0; i<files.length; i++) {
                fileDelete(files[i], text);
            }
            if(file.delete()){
                Print.println("デリートされました", Print.highSpeed, text);
            };
        }
    }

}
