public class VersionCheck {
  public static void main(String[] args) {
    System.out.print("Javaバージョン(java.version):");
    System.out.println(System.getProperty("java.version"));
    
    System.out.print("オペレーティングシステム名(os.name):");
    System.out.println(System.getProperty("os.name"));
  }
}