import java.util.Random;
import java.util.Scanner;

import battle.Battle;
import battle.CalculateDamage;
import battle.InputAction.Auto;
import character.Player;
import character.Player.TrainStatus;
import train.TrainState;

public class JavaQuestBattle {
    public static void main(String[] args) {
        Random rand = new Random();
        Scanner scanner = new Scanner(System.in);
        System.out.println("プレーヤー1のロードするデータを選んでください");
        int data1 = scanner.nextInt();
        Player player1 = TrainState.load(data1 == 0 ? Integer.MIN_VALUE : data1, false, true).getSelf();
        System.out.println("プレーヤー2のロードするデータを選んでください");
        int data2 = scanner.nextInt();
        Player player2 = TrainState.load(data2 == 0 ? Integer.MIN_VALUE : data2, false, true).getSelf();
        for(Player player: new Player[]{player1, player2}){
            for(TrainStatus category: new TrainStatus[]{TrainStatus.maxHp, TrainStatus.maxMp}){
                CalculateDamage.trainDamage(player, category, -100, false);
            }
            player.trainToBattleStatus();
        }
        scanner.nextLine();
        Battle.startBattle(player1, player2, Auto.select, Auto.select, true, scanner, rand);
    }
}
