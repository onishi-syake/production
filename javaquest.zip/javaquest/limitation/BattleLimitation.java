package limitation;

import java.util.ArrayList;
import java.util.List;

import train.TrainState;
import train.TrainState.Mode;

//基本的にこのメソッド達はキャラ作成時にしか使わない
public enum BattleLimitation {
    //inputActionでselectを利用するPlayerのみを制限する
    useSpell("呪文解放",
    "呪文を利用可能になる", 
    new ArrayList<>(){{
        add(Mode.easy);
    }}){
        @Override
        public boolean useAble(Mode mode) {
            return true;
        }
        @Override
        public boolean useAble(){
            return false;
        }
    },
    useItem("アイテム解放",
    "アイテムを利用可能になる", 
    new ArrayList<>(){{

    }}){
        @Override
        public boolean useAble(Mode mode) {
            return false;
        }
        @Override
        public boolean useAble(){
            return false;
        }
    },
    useSpecial("必殺技解放",
    "必殺技を利用可能になる", 
    new ArrayList<>(){{
        add(Mode.easy);
    }}){
        @Override
        public boolean useAble(Mode mode) {
            return false;
        }
        @Override
        public boolean useAble(){
            return false;
        }
    },
    ;
    public final String jName;
    public final String explain;
    public final List<Mode> useAbleMode;
    private BattleLimitation(String jName, String explain, List<Mode> useAbleMode){
        this.jName = jName;
        this.explain = explain;
        this.useAbleMode = useAbleMode;
    }
    public abstract boolean useAble(Mode mode);
    public abstract boolean useAble();
}
