package limitation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import character.Player.TrainStatus;
import data.action.Spell;
import data.card.Card;
import data.card.Guild;
import data.card.ItemCard;
import data.card.RestMenu;
import data.card.TrainEvent;
import data.card.TrainMenu;
import data.event.Event;
import data.item.BattleItem;
import text.Print;
import train.Train;
import train.TrainState;
import train.TrainState.Mode;
import train.TrainState.shuffleModeWithAddCard;

//解放される要素のenum
//解放されているかどうかはtrainStateのフィールドにマップとして持たれる
//useAbleメソッドはゲーム開始時に解放されているかを判別する
public enum TrainLimitation {//属性・スキルまだ
    //基本システム
    tutorial("チュートリアル",//ok
    "チュートリアルを行う", 
    0,
    new ArrayList<>(){{
        add(Mode.easy);
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    // turn20("20ターン解放",//ok
    // "育成可能期間が20ターンに伸びる", 
    // new ArrayList<>(){{
    //     add(Mode.normal);
    //     add(Mode.hard);
    // }}){
    //     @Override
    //     public boolean useAble(){
    //         return false;
    //     }
    // },
    // turn30("30ターン解放",//ok
    // "育成可能期間が30ターンに伸びる", 
    // new ArrayList<>(){{
    //     add(Mode.hard);
    // }}){
    //     @Override
    //     public boolean useAble(){
    //         return false;
    //     }
    // },
    chainTrain("連続訓練",
    "訓練を連続でしたときに訓練効率が伸びる", 
    0,
    new ArrayList<>(){{
        add(Mode.normal);
        add(Mode.hard);
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    sameTrain("同行動訓練",
    "同じ訓練を連続でしたときに訓練効率が伸びる", 
    0,
    new ArrayList<>(){{
        add(Mode.easy);
        add(Mode.normal);
        add(Mode.hard);
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    randomBoss("ランダム勇者",//ok
    "勇者がランダムに作成される代わりに落とす金が増える", 
    0,
    new ArrayList<>(){{
        add(Mode.normal);
        add(Mode.hard);
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    attribute("属性",//ok 1回クリアで解放
    "育成開始時にランダムに属性が付与される", 
    0,
    new ArrayList<>(){{
        add(Mode.normal);
        add(Mode.hard);
    }}){
        @Override
        public boolean useAble(){
            return true;
        }
    },
    attributeS("呪文属性",//ok
    "呪文属性が解放される", 
    0,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    newAttribute("新属性仕様（ 1 ターン目の基本行動が属性の行動のみになる）",//ok
    "新属性仕様（ 1 ターン目の基本行動が属性の行動のみになる）が適用される", 
    0,
    new ArrayList<>(){{
        // add(Mode.easy);
        // add(Mode.normal);
        // add(Mode.hard);
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    randomEvent("ランダムイベント",//ok
    "ランダムにイベントが発生するようになる", 
    0,
    new ArrayList<>(){{
        add(Mode.easy);
        add(Mode.normal);
        add(Mode.hard);
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    fixedEvent("固定イベント",
    "固定の日に固定内容のイベントが発生する", 
    0,
    new ArrayList<>(){{
    }}){
        private Map<Integer, Event> events = new HashMap<Integer, Event>(){{
            put(3, Event.battle);
            put(7, Event.battle);
            put(13, Event.battle);
            put(17, Event.battle);
            put(23, Event.battle);
            put(27, Event.battle);
        }};
        @Override
        public boolean useAble(){
            return false;
        }
        @Override
        public Map<Integer, Event> fixedEvents(){
            return events;
        }
    },
    //スキル
    guts("根性",// 数回クリアで解放
    "スキル・根性が解放される。ライフが半分以下での訓練時に経験値が2倍になる", 
    0,
    new ArrayList<>(){{
        add(Mode.normal);
        add(Mode.hard);
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    // spellTaker("呪文テイカー",
    // "スキル・呪文テイカーが解放される。戦闘後、相手が最後に使った呪文を奪う", 
    // new ArrayList<>(){{
    //     add(Mode.normal);
    //     add(Mode.hard);
    // }}){
    //     @Override
    //     public boolean useAble(){
    //         return false;
    //     }
    // },
    trader("トレーダー",
    "スキル・トレーダーが解放される。商品の価格が安くなる", 
    0,
    new ArrayList<>(){{
        add(Mode.normal);
        add(Mode.hard);
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    prophet("予言者",
    "スキル・予言者が解放される。将来の行動を知ることが出来る", 
    0,
    new ArrayList<>(){{
        add(Mode.normal);
        add(Mode.hard);
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    longevity("長寿",
    "スキル・長寿が解放される。の終了日数が伸びる", 
    0,
    new ArrayList<>(){{
        add(Mode.normal);
        add(Mode.hard);
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    KJA("KJA",
    "スキル・KJAが解放される。最凶のギャンブル呪文「KJA」を習得した状態でゲームを開始する。また、毎日ギャンブルイベントが発生する", 
    0,
    new ArrayList<>(){{
        add(Mode.normal);
        add(Mode.hard);
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    //選択肢
    battle("ギルド",//ok
    "引ける札にギルドが追加される", 
    1,
    new ArrayList<>(){{
        add(Mode.easy);
        add(Mode.normal);
        add(Mode.hard);
    }}){
        @Override
        public boolean useAble(){
            return true;
        }
    },
    // trainingSize("小・大トレーニング解放",//ok
    // "トレーニングの選択肢に小トレーニングと大トレーニングが追加される", 
    // new ArrayList<>(){{
    //     add(Mode.normal);
    //     add(Mode.hard);
    // }}){
    //     @Override
    //     public boolean useAble(){
    //         return false;
    //     }
    // },
    //トレーニング解放系は最初から解放ではなく、下位のトレーニングで解放される
    bigA("攻撃力-B 訓練",//ok
    "引ける札に攻撃力-B 訓練が追加される", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return true;
        }
    },
    bigHp("HP-B 訓練",//ok
    "引ける札にHP-B 訓練が追加される", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return true;
        }
    },
    bigS("素早さ-B 訓練",//ok
    "引ける札に素早さB 訓練が追加される", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return true;
        }
    },
    gasolineMainte("ガソリンメンテ",//ok
    "引ける札にガソリンメンテが追加される", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return true;
        }
    },
    elecMainte("エレキメンテ",//ok
    "引ける札にエレキメンテが追加される", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    oilMainte("やる気メンテ",//ok
    "引ける札にオイルメンテが追加される", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    superA("攻撃力-C 訓練",//ok
    "引ける札に攻撃力-C 訓練が追加される", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return true;
        }
    },
    superHp("HP-C 訓練",//ok
    "引ける札にHP-C 訓練が追加される", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return true;
        }
    },
    superS("素早さC 訓練",//ok
    "引ける札に素早さ-C 訓練が追加される", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return true;
        }
    },
    mp("MP 訓練",//ok
    "引ける札にMP 訓練が追加される", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return true;
        }
    },
    // shineShop("呪文ショップ",
    // "ここでしか買えない呪文のオーブを販売する呪文ショップが選択肢の中に現れる", 
    // 1,
    // new ArrayList<>(){{
    // }}){
    //     @Override
    //     public boolean useAble(){
    //         return true;
    //     }
    // },
    labHP("肉体改造ラボ",
    "全ての訓練で HPの消費を 0 にする肉体改造ラボがショップに現れる", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    labCon("精神改造ラボ",
    "全ての訓練で 集中力の消費を 0 にする精神改造ラボがショップに現れる", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    labMoti("感情改造ラボ",
    "全ての訓練で やる気の消費を 0 にする感情改造ラボがショップに現れる", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    // 呪文解放
    fireSpell("ファイアのオーブ",//ok
    "「ファイアのオーブ」を購入できるようになる", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    stoneSpell("ストーンのオーブ",//ok
    "「ストーンのオーブ」を購入できるようになる", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    windSpell("ウィンドのオーブ",//ok
    "「ウィンドのオーブ」を購入できるようになる", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    healSpell("ヒールのオーブ",//ok
    "「ヒールのオーブ」を購入できるようになる", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    aUpSpell("アタックアップのオーブ",//ok
    "「アタックアップのオーブ」を購入できるようになる", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    sUpSpell("スピードアップのオーブ",//ok
    "「スピードアップのオーブ」を購入できるようになる", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    dUpSpell("ディフェンスアップのオーブ",//ok
    "「ディフェンスアップのオーブ」を購入できるようになる", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    NervousSpell("緊迫斬りのオーブ",
    "「緊迫斬りのオーブ」を購入できるようになる",
    1,
    new ArrayList<>(){{

    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    poisonSpell("毒斬りのオーブ",//ok
    "「毒斬りのオーブ」を購入できるようになる", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    stomatitisSpell("沈黙斬りのオーブ",//ok
    "「沈黙斬りのオーブ」を購入できるようになる", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    bondSpell("臆病斬りのオーブ",//ok
    "「臆病斬りのオーブ」を購入できるようになる", 
    1,
    new ArrayList<>(){{
        
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    lagSpell("回線斬りのオーブ",//ok
    "「回線斬りのオーブ」を購入できるようになる", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    TensionFieldSpell("テンションフィールドのオーブ",//ok
    "「テンションフィールドのオーブ」を購入できるようになる", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    SpecialFieldSpell("スペシャルフィールドのオーブ",//ok
    "「スペシャルフィールドのオーブ」を購入できるようになる", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    ReverseFieldSpell("リバースフィールドのオーブ",//ok
    "「リバースフィールドのオーブ」を購入できるようになる", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    RegenFieldSpell("リジェネフィールドのオーブ",//ok
    "「リジェネフィールドのオーブ」を購入できるようになる", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    On_StateChangeSpell("ONS-ステイトチェンジのオーブ",//ok
    "「ONS-ステイトチェンジのオーブ」を購入できるようになる", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    On_SpellReflectSpell("ONS-スペルリフレクトのオーブ",//ok
    "「ONS-スペルリフレクトのオーブ」を購入できるようになる", 
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    StrengthenFire("ファイアの強化石",
    "「ファイアの強化石」を購入できるようになる。ファイアを強化してフレイムを習得できる",
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    StrengthenFlame("フレイムの強化石",
    "「フレイムの強化石」を購入できるようになる。フレイムを強化してエプロンを習得できる",
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    StrengthenExplosion("エプロンの強化石",
    "「エプロンの強化石」を購入できるようになる。エプロンを強化してビッグバンを習得できる",
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    StrengthenWind("ウィンドの強化石",
    "「ウィンドの強化石」を購入できるようになる。ウィンドを強化してガストを習得できる",
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    StrengthenGust("ガストの強化石",
    "「ガストの強化石」を購入できるようになる。ガストを強化してトルネードを習得できる",
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    StrengthenTornado("トルネードの強化石",
    "「トルネードの強化石」を購入できるようになる。トルネードを強化してストームを習得できる",
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    StrengthenStone("ストーンの強化石",
    "「ストーンの強化石」を購入できるようになる。ストーンを強化してロックを習得できる",
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    StrengthenRock("ロックの強化石",
    "「ロックの強化石」を購入できるようになる。ロックを強化してラヴァを習得できる",
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    StrengthenLava("ラヴァの強化石",
    "「ラヴァの強化石」を購入できるようになる。ラヴァを強化してメテオを習得できる",
    1,
    new ArrayList<>(){{
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },

    // fieldSpell("フィールド呪文",//ok
    // "バザーでフィールド呪文を購入できるようになる", 
    // 2,
    // new ArrayList<>(){{
    // }}){
    //     @Override
    //     public boolean useAble(){
    //         return false;
    //     }
    // },
    // onSpell("ON呪文",//ok
    // "バザーでON系呪文を購入できるようになる", 
    // 2,
    // new ArrayList<>(){{
    // }}){
    //     @Override
    //     public boolean useAble(){
    //         return false;
    //     }
    // },
    // advanceAbnormalSpell("上級異常呪文",//ok
    // "バザーで上級異常呪文を購入できるようになる", 
    // 2,
    // new ArrayList<>(){{
    // }}){
    //     @Override
    //     public boolean useAble(){
    //         return false;
    //     }
    // },
    //通常ショップ
    Tairyokuzai("HP剤",//ok
    "HP剤をショップで購入できるようになる", 
    0,
    new ArrayList<>(){{
        add(Mode.normal);
        add(Mode.hard);
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    Maryokuzai("ガソリン/MP剤",//ok
    "ガソリン/MP剤をショップで購入できるようになる", 
    0,
    new ArrayList<>(){{
        add(Mode.normal);
        add(Mode.hard);
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    Bannnouyaku("オイル/万能薬",//ok
    "オイル/万能薬をショップで購入できるようになる", 
    0,
    new ArrayList<>(){{
        add(Mode.normal);
        add(Mode.hard);
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    Zoukyouzai("エレキ/強化剤",//ok
    "エレキ/強化剤をショップで購入できるようになる", 
    0,
    new ArrayList<>(){{
        add(Mode.normal);
        add(Mode.hard);
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    healItem("回復アイテム",//ok
    "回復アイテムをショップで購入できるようになる(エレキ・オイル・ガソリン)", 
    0,
    new ArrayList<>(){{
        add(Mode.normal);
        add(Mode.hard);
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    // wakeUp("目覚まし時計解放",//ok
    // "目覚まし時計をショップで購入できるようになる(精神力・行動力・健康値)", 
    // new ArrayList<>(){{
    //     add(Mode.easy);
    //     add(Mode.hard);
    // }}){
    //     @Override
    //     public boolean useAble(Mode mode) {
    //         return true;
    //     }
    //     @Override
    //     public boolean useAble(){
    //         return false;
    //     }
    // },
    // paralysisBook("パラライズ",//ok
    // "パラライズの書をショップで購入できるようになる", 
    // new ArrayList<>(){{
    //     add(Mode.normal);
    //     add(Mode.hard);
    // }}){
    //     @Override
    //     public boolean useAble(){
    //         return false;
    //     }
    // },
    // lagBook("ラグ",//ok
    // "ラグの書をショップで購入できるようになる", 
    // new ArrayList<>(){{
    //     add(Mode.normal);
    //     add(Mode.hard);
    // }}){
    //     @Override
    //     public boolean useAble(){
    //         return false;
    //     }
    // },
    // hesitanceBook("ヘジテンス",//ok
    // "ヘジテンスの書をショップで購入できるようになる", 
    // new ArrayList<>(){{
    //     add(Mode.normal);
    //     add(Mode.hard);
    // }}){
    //     @Override
    //     public boolean useAble(){
    //         return false;
    //     }
    // },
    // poisonBook("ポイズン",//ok
    // "ポイズンの書をショップで購入できるようになる", 
    // new ArrayList<>(){{
    //     add(Mode.normal);
    //     add(Mode.hard);
    // }}){
    //     @Override
    //     public boolean useAble(){
    //         return false;
    //     }
    // },
    // stomatitisBook("ストマティティス",//ok
    // "ストマティティスの書をショップで購入できるようになる", 
    // new ArrayList<>(){{
    //     add(Mode.normal);
    //     add(Mode.hard);
    // }}){
    //     @Override
    //     public boolean useAble(){
    //         return false;
    //     }
    // },
    //闇商人
    darkShop("闇商人",//item ok choice no
    "特殊なアイテムを販売してくれる闇商人がイベントで出現するようになる", 
    1,
    new ArrayList<>(){{
        add(Mode.hard);
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    // TraumaBook("トラウマ",//ok
    // "トラウマの書を闇商人から購入できるようになる", 
    // new ArrayList<>(){{
    //     add(Mode.hard);
    // }}){
    //     @Override
    //     public boolean useAble(){
    //         return false;
    //     }
    // },
    // ChaosBook("カオス",//ok
    // "カオスの書を闇商人から購入できるようになる", 
    // new ArrayList<>(){{
    //     add(Mode.hard);
    // }}){
    //     @Override
    //     public boolean useAble(){
    //         return false;
    //     }
    // },
    // On_StateChangeBook("顔本",//ok
    // "顔本を闇商人から購入できるようになる", 
    // new ArrayList<>(){{
    //     add(Mode.hard);
    // }}){
    //     @Override
    //     public boolean useAble(){
    //         return false;
    //     }
    // },
    // On_SpellReflectBook("歌本",//ok
    // "歌本を闇商人から購入できるようになる", 
    // new ArrayList<>(){{
    //     add(Mode.hard);
    // }}){
    //     @Override
    //     public boolean useAble(){
    //         return false;
    //     }
    // },
    // On_MoveCounterBook("踊本",//ok
    // "踊本を闇商人から購入できるようになる", 
    // new ArrayList<>(){{
    //     add(Mode.hard);
    // }}){
    //     @Override
    //     public boolean useAble(){
    //         return false;
    //     }
    // },
    Elixir("エリクサー",//ok
    "エリクサーを購入できるようになる", 
    1,
    new ArrayList<>(){{
        add(Mode.normal);
        add(Mode.hard);
    }}){
        @Override
        public boolean useAble(){
            return false;
        }
    },
    ;
    public final String jName;
    public final String explain;
    public final int unlimitCount;
    public final List<Mode> useAbleMode;
    private TrainLimitation(String jName, String explain, int unlimitCount, List<Mode> useAbleMode){
        this.jName = jName;
        this.explain = explain;
        this.unlimitCount = unlimitCount;
        this.useAbleMode = useAbleMode;
    }
    public abstract boolean useAble();
    public boolean useAble(Mode mode){
        if(mode == Mode.debug){
            return this.useAble();
        }
        return this.useAbleMode.contains(mode);
    };
    public Map<Integer, Event> fixedEvents(){
        return new HashMap<>();
    }
    public static void unlimit(TrainState trainState, TrainLimitation trainLimitation, int addCount, boolean text, Scanner scanner){
        if(trainLimitation == null)return;
        trainState.getTrainLimitations().get(trainLimitation).replace(TrainLimitationCounter.count, trainState.getTrainLimitations().get(trainLimitation).get(TrainLimitationCounter.count) + addCount);
        if(trainState.getTrainLimitations().get(trainLimitation).get(TrainLimitationCounter.flag) != 1 && trainState.getTrainLimitations().get(trainLimitation).get(TrainLimitationCounter.count) >= trainLimitation.unlimitCount){
            if(spellWithNormalSpellLimitation().keySet().contains(trainLimitation) || strengthenSpellLimitation(trainState).contains(trainLimitation) || labLimitation.contains(trainLimitation)){
                if(spellWithNormalSpellLimitation().keySet().contains(trainLimitation) && trainState.getSelf().getLearnedSpellLevel().containsKey(spellWithNormalSpellLimitation().get(trainLimitation))){
                    return;// 覚えている呪文は解放しない
                }
                Print.println(trainLimitation.jName + "がショップに売り出された" + Print.sleep(10), true, Print.highSpeed, text);
            }else{
                if(_strengthenSpellLimitation().values().contains(trainLimitation) && !trainState.getSelf().getLearnedSpellLevel().containsKey(_strengthenSpellLimitationReverse().get(trainLimitation))){
                    return;// 覚えている呪文は解放しない
                }
                Print.println(trainLimitation.jName + "が解放された" + Print.sleep(10), true, Print.highSpeed, text);
                
            }
            Print.nextLine(scanner, text);
            trainState.getTrainLimitations().get(trainLimitation).replace(TrainLimitationCounter.flag, 1);
            // for(TrainMenu trainMenu : TrainMenu.values()){
            //     if(trainMenu.name().equals(trainLimitation.name())){
            //         // Print.println(trainMenu.jName + "が次のターンに最優先で出現するようになりました。", Print.highSpeed, text);
            //         // Print.nextLine(scanner, text);
            //         trainState.addBeforeUnlimitAction(trainMenu.ordinal());
            //         for(int i = 0; i < trainMenu.unlimitAddToDeckNum(); i++){
            //             trainState.deck.add(trainMenu);
            //         }
            //     }
            // }
            // for(RestMenu restMenu : RestMenu.values()){
            //     if(restMenu.name().equals(trainLimitation.name())){
            //         // Print.println(restMenu.jName + "が次のターンに最優先で出現するようになりました。", Print.highSpeed, text);
            //         // Print.nextLine(scanner, text);
            //         trainState.addBeforeUnlimitAction(TrainMenu.NUM + restMenu.ordinal());
            //         for(int i = 0; i < restMenu.unlimitAddToDeckNum(); i++){
            //             trainState.deck.add(restMenu);
            //         }
            //     }
            // }
            // for(TrainEvent trainEvent : TrainEvent.values()){
            //     if(trainEvent.name().equals(trainLimitation.name())){
            //         // Print.println(trainEvent.jName + "が次のターンに最優先で出現するようになりました。", Print.highSpeed, text);
            //         // Print.nextLine(scanner, text);
            //         trainState.addBeforeUnlimitAction(TrainMenu.NUM + RestMenu.NUM + trainEvent.ordinal());
            //         for(int i = 0; i < trainEvent.unlimitAddToDeckNum(); i++){
            //             trainState.deck.add(trainEvent);
            //         }
            //     }
            // }
            for(Card card : Card.values()){
                if(card.name().equals(trainLimitation.name())){
                    // Print.println(trainEvent.jName + "が次のターンに最優先で出現するようになりました。", Print.highSpeed, text);
                    // Print.nextLine(scanner, text);
                    trainState.addBeforeUnlimitAction(card.getOrdinalNumber());
                    trainState.saveAddCard(new ArrayList<>(){{
                        for(int i = 0; i < card.unlimitAddToDeckNum(); i++){
                            add(card);
                        }
                    }}, shuffleModeWithAddCard.BeforeLast);
                }
            }
            // if("battle".equals(trainLimitation.name())){
            //     // Print.println("ギルドが次のターンに最優先で出現するようになりました。", Print.highSpeed, text);
            //     // Print.nextLine(scanner, text);
            //     trainState.addBeforeUnlimitAction(TrainMenu.NUM + RestMenu.NUM + TrainEvent.NUM);
            //     for(int i = 0; i < Battle.normalBattle.unlimitAddToDeckNum(); i++){
            //         trainState.deck.add(Battle.normalBattle);
            //     }
            // }
        }
    }

    // オーブ系リミット
    public static Map<TrainLimitation, Spell> spellWithNormalSpellLimitation(){
        return new HashMap<TrainLimitation, Spell>(){{
            put(fireSpell, Spell.Fire);
            put(windSpell, Spell.Wind);
            put(stoneSpell, Spell.Stone);
            put(healSpell, Spell.Heal);
            put(aUpSpell, Spell.AUp);
            put(sUpSpell, Spell.SUp);
            put(dUpSpell, Spell.DUp);
            put(NervousSpell, Spell.Nervous);
            put(lagSpell, Spell.Lag);
            put(bondSpell, Spell.Bond);
            put(poisonSpell, Spell.Poison);
            put(stomatitisSpell, Spell.Stomatitis);
            put(TensionFieldSpell, Spell.TensionField);
            put(SpecialFieldSpell, Spell.SpecialField);
            put(ReverseFieldSpell, Spell.ReverseField);
            put(RegenFieldSpell, Spell.RegenField);
            put(On_StateChangeSpell, Spell.On_StateChange);
            put(On_SpellReflectSpell, Spell.On_SpellReflect);
        }};
    }

    // 強化石系リミット
    public static Map<Spell, TrainLimitation> _strengthenSpellLimitation(){
        return new HashMap<Spell, TrainLimitation>(){{
            put(Spell.Fire, StrengthenFire);
            put(Spell.Flame, StrengthenFlame);
            put(Spell.Explosion, StrengthenExplosion);
            put(Spell.Wind, StrengthenWind);
            put(Spell.Gust, StrengthenGust);
            put(Spell.Tornado, StrengthenTornado);
            put(Spell.Stone, StrengthenStone);
            put(Spell.Rock, StrengthenRock);
            put(Spell.Lava, StrengthenLava);
        }};
    }

    // 強化石系リミット
    public static Map<TrainLimitation, Spell> _strengthenSpellLimitationReverse(){
        return new HashMap<TrainLimitation, Spell>(){{
            put(StrengthenFire, Spell.Fire);
            put(StrengthenFlame, Spell.Flame);
            put(StrengthenExplosion, Spell.Explosion);
            put(StrengthenWind, Spell.Wind);
            put(StrengthenGust, Spell.Gust);
            put(StrengthenTornado, Spell.Tornado);
            put(StrengthenStone, Spell.Stone);
            put(StrengthenRock, Spell.Rock);
            put(StrengthenLava, Spell.Lava);
        }};
    }

    // 前の呪文を覚えている強化石系リミット
    public static List<TrainLimitation> strengthenSpellLimitation(TrainState trainState){
        return new ArrayList<>(){{
            for(Spell spell : _strengthenSpellLimitation().keySet()){
                if(trainState.getSelf().getLearnedSpellLevel().containsKey(spell)){
                    add(_strengthenSpellLimitation().get(spell));
                }
            }
        }};
    }

    // ラボ系リミット
    public static final List<TrainLimitation> labLimitation = new ArrayList<>(){{
       add(TrainLimitation.labHP); 
       add(TrainLimitation.labCon); 
       add(TrainLimitation.labMoti); 
    }};

    // 与えられたリストから解放されていない制限を返す
    public static List<TrainLimitation> unlimitLimitations(TrainState state, List<TrainLimitation> checkList){
        Map<TrainLimitation, Map<TrainLimitationCounter, Integer>> stateLimitations = state.getTrainLimitations();
        List<TrainLimitation> releasedLimitations = new ArrayList<>();
        for(TrainLimitation limitation : checkList){
            if(stateLimitations.get(limitation).get(TrainLimitationCounter.flag) == 1){
                releasedLimitations.add(limitation);
            }
        }
        checkList.removeAll(releasedLimitations);
        return checkList;
    }

    // ラボの解放をリセットする関数
    public static void resetLabLimitation(TrainState trainState){
        for(TrainLimitation trainLimitation : labLimitation){
            trainState.getTrainLimitations().get(trainLimitation).replace(TrainLimitationCounter.count, 0);
            trainState.getTrainLimitations().get(trainLimitation).replace(TrainLimitationCounter.flag, 0);
        }
    }
    public static void resetSpellLimitation(TrainState trainState){
        for(TrainLimitation trainLimitation : spellWithNormalSpellLimitation().keySet()){
            trainState.getTrainLimitations().get(trainLimitation).replace(TrainLimitationCounter.count, 0);
            trainState.getTrainLimitations().get(trainLimitation).replace(TrainLimitationCounter.flag, 0);
        }
    }
    public static void resetStrengthenLimitation(TrainState trainState){
        for(TrainLimitation trainLimitation : _strengthenSpellLimitationReverse().keySet()){
            trainState.getTrainLimitations().get(trainLimitation).replace(TrainLimitationCounter.count, 0);
            trainState.getTrainLimitations().get(trainLimitation).replace(TrainLimitationCounter.flag, 0);
        }
    }

    public enum TrainLimitationCounter{
        flag,
        count,
    }
}