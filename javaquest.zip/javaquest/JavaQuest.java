import game.TestWindow;

public class JavaQuest {
    public static void main(String[] args) {
		TestWindow gw = new TestWindow("余命 16 日 魔王",1280,720);
		gw.setVisible(true);
	}
}
