package log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import battle.InputAction;
import battle.State;
import data.action.Spell;
import data.item.BattleItem;
import log.OneTurnBattleLog.Success;
import log.unmodifiable.UnmodifiableState;

public final class BattleLog {
    public final List<OneTurnBattleLog> battleLog;
    public final UnmodifiableState endState;
    public final int result;
    public final int lastTurn;
    public final List<StatusLog> p1ActionLog;
    public final List<StatusLog> p2ActionLog;
    public final List<StatusLog> p1ItemLog;
    public final List<StatusLog> p2ItemLog;
    public final int p1SAttack;
    public final int p2SAttack;
    public final int p1SDef;
    public final int p2SDef;
    public final int p1SCha;
    public final int p2SCha;
    public final Map<Success, Integer> p1Success;
    public final Map<Success, Integer> p2Success;
    public final Map<Spell, Integer> p1AdoptionSpell;
    public final Map<Spell, Integer> p2AdoptionSpell;
    public BattleLog(List<OneTurnBattleLog> battleLog, State state){
        int size = battleLog.size();
        OneTurnBattleLog last = battleLog.get(size - 1);
        this.battleLog = Collections.unmodifiableList(new ArrayList<>(){{for(OneTurnBattleLog log : battleLog){add(log);}}});
        this.endState =state.unmodifiableCopy();
        this.result = state.isWin(true);
        this.lastTurn = last.turn;
        List<List<OneTurnBattleLog>> p1Alog = new ArrayList<>();
        List<List<OneTurnBattleLog>> p2Alog = new ArrayList<>();
        List<List<OneTurnBattleLog>> p1Ilog = new ArrayList<>();
        List<List<OneTurnBattleLog>> p2Ilog = new ArrayList<>();
        if(battleLog.get(0).beforeState.getTurn() != 0){
            for(int i = 0; i <= InputAction.ACTION_NUM; i++){
                p1Alog.add(new ArrayList<>());
                p2Alog.add(new ArrayList<>());
            }
            for(int i = 0; i <= BattleItem.NUM; i++){
                p1Ilog.add(new ArrayList<>());
                p2Ilog.add(new ArrayList<>());
            }
            for(OneTurnBattleLog log : battleLog){
                if(log.p1Act != -1 && log.p2Act != -1 && log.p1Act != 0 && log.p2Act != 0){
                    p1Alog.get((log.p1Act - 1) % InputAction.ACTION_NUM + 1).add(log);
                    p2Alog.get((log.p2Act - 1) % InputAction.ACTION_NUM + 1).add(log);
                    p1Ilog.get((log.p1Act - 1) / InputAction.ACTION_NUM).add(log);
                    p2Ilog.get((log.p2Act - 1) / InputAction.ACTION_NUM).add(log);
                }
            }
        }
        this.p1ActionLog = Collections.unmodifiableList(new ArrayList<>(){{for(int i = 0; i <= InputAction.ACTION_NUM ; i++){
            if(p1Alog.get(i).size() != 0){
                this.add(new StatusLog(p1Alog.get(i), true, size));
            }else{
                this.add(null);
            }
        }}});
        this.p2ActionLog = Collections.unmodifiableList(new ArrayList<>(){{for(int i = 0; i <= InputAction.ACTION_NUM; i++){
            if(p2Alog.get(i).size() != 0){
                this.add(new StatusLog(p2Alog.get(i), false, size));
            }else{
                this.add(null);
            }
        }}});
        this.p1ItemLog = Collections.unmodifiableList(new ArrayList<>(){{for(int i = 0; i <= BattleItem.NUM ; i++){
            if(p1Ilog.get(i).size() != 0){
                this.add(new StatusLog(p1Ilog.get(i), true, size));
            }else{
                this.add(null);
            }
        }}});
        this.p2ItemLog = Collections.unmodifiableList(new ArrayList<>(){{for(int i = 0; i <= BattleItem.NUM; i++){
            if(p2Ilog.get(i).size() != 0){
                this.add(new StatusLog(p2Ilog.get(i), false, size));
            }else{
                this.add(null);
            }
        }}});
        this.p1SAttack = (int)battleLog.stream().filter(l -> l.p1Act == (4 + Spell.NUM + 1)).count();
        this.p2SAttack = (int)battleLog.stream().filter(l -> l.p2Act == (4 + Spell.NUM + 1)).count();
        this.p1SDef = (int)battleLog.stream().filter(l -> l.p1Act == (4 + Spell.NUM + 2)).count();
        this.p2SDef = (int)battleLog.stream().filter(l -> l.p2Act == (4 + Spell.NUM + 2)).count();
        this.p1SCha = (int)battleLog.stream().filter(l -> l.p1Act == (4 + Spell.NUM + 3)).count();
        this.p2SCha = (int)battleLog.stream().filter(l -> l.p2Act == (4 + Spell.NUM + 3)).count();
        this.p1Success = Collections.unmodifiableMap(new EnumMap<>(Success.class){{for(Success key : Success.values()){
            this.put(key, (int)battleLog.stream().filter(l -> l.p1Success.get(key)).count());
        }}});
        this.p2Success = Collections.unmodifiableMap(new EnumMap<>(Success.class){{for(Success key : Success.values()){
            this.put(key, (int)battleLog.stream().filter(l -> l.p2Success.get(key)).count());
        }}});
        this.p1AdoptionSpell = Collections.unmodifiableMap(new EnumMap<>(Spell.class){{for(Spell key : battleLog.get(0).beforeState.getPlayer1().getSpellArray()){
            this.put(key, last.afterState.getPlayer1().getSpellSlot().contains(key) ? 1 : 0);
        }}});
        this.p2AdoptionSpell = Collections.unmodifiableMap(new EnumMap<>(Spell.class){{for(Spell key : battleLog.get(0).beforeState.getPlayer2().getSpellArray()){
            this.put(key, last.afterState.getPlayer2().getSpellSlot().contains(key) ? 1 : 0);
        }}});
    }
    public OneTurnBattleLog getLog(int turn){
        return this.battleLog.get(turn - 1);
    }
    public int getResult(boolean player1){
        return this.result * (player1 ? 1 : -1);
    }
}
