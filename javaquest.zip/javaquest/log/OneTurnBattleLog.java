package log;

import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;

import battle.State;
import battle.InputAction.Action;
import data.action.Special;
import data.action.Spell;
import log.unmodifiable.UnmodifiableState;

public final class OneTurnBattleLog {
    public final UnmodifiableState beforeState;
    public final UnmodifiableState afterState;
    public final int turn;
    public final int p1Act;
    public final int p2Act;
    public final boolean p1_is_firstPalyer;
    public final int p1Hit;
    public final int p2Hit;
    public enum Success{
        sucSAttack(Special.SpecialAttack.jName + "成功"),
        sucDef(Action.defense.jName + "成功"),
        sucSDef(Special.SpecialDefense.jName + "成功"),
        sucCha(Action.tension.jName + "成功"),
        sucSCha(Special.SpecialTension.jName + "成功"),
        chargeRecovery(Action.tension.jName + "による全快"),
        ;
        public final String jName;
        private Success(String jname){
            this.jName = jname + "回数";
        }
        public static final int NUM = values().length;
    }
    public final Map<Success, Boolean> p1Success;
    public final Map<Success, Boolean> p2Success;

    public OneTurnBattleLog(State beforeState, State afterState, int p1Act, int p2Act, BattleTemporaryLog hitLog){
        this.beforeState = beforeState.unmodifiableCopy();
        this.afterState = afterState.unmodifiableCopy();
        this.turn = beforeState.getTurn();
        this.p1Act = p1Act;
        this.p2Act = p2Act;
        this.p1_is_firstPalyer = hitLog.getFirstPlayer();
        this.p1Hit = hitLog.getp1Hit();
        this.p2Hit = hitLog.getp2Hit();
        this.p1Success = Collections.unmodifiableMap(new EnumMap<>(Success.class){{for(Success key : Success.values()){
            this.put(key, hitLog.getp1Success().get(key));
        }}});
        this.p2Success = Collections.unmodifiableMap(new EnumMap<>(Success.class){{for(Success key : Success.values()){
            this.put(key, hitLog.getp2Success().get(key));
        }}});
    }
}
