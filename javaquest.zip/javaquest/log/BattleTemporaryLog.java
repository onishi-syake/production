package log;

import java.util.EnumMap;
import java.util.Map;

import log.OneTurnBattleLog.Success;

public final class BattleTemporaryLog {
    private boolean p1_is_firstPalyer;
    private int p1Hit = 0;
    private int p2Hit = 0;
    private Map<Success, Boolean> p1Success = new EnumMap<>(Success.class);
    private Map<Success, Boolean> p2Success = new EnumMap<>(Success.class);
    {
        for(Success key : Success.values()){
            p1Success.put(key, false);
            p2Success.put(key, false);
        }
    }

    boolean getFirstPlayer(){
        return this.p1_is_firstPalyer;
    }
    public void setFirstPlayer(boolean p1_is_firstPalyer){
        this.p1_is_firstPalyer = p1_is_firstPalyer;
    }
    int getp1Hit(){
        return this.p1Hit;
    }
    int getp2Hit(){
        return this.p2Hit;
    }
    public void setHit(boolean player1, int hit){
        if(player1){
            this.p1Hit = hit;
        }else{
            this.p2Hit = hit;
        }
    }
    public Map<Success, Boolean> getp1Success(){
        return this.p1Success;
    }
    public Map<Success, Boolean> getp2Success(){
        return this.p2Success;
    }
    public void setSuccess(boolean player1, boolean success, Success key){
        if(player1){
            this.p1Success.replace(key, success);
        }else{
            this.p2Success.replace(key, success);
        }
    }
}
