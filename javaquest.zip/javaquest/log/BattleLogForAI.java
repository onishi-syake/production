package log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import battle.InputAction;
import data.item.BattleItem;

public final class BattleLogForAI {
    public final List<StatusLog> p1ActionLog;
    public final List<StatusLog> p2ActionLog;
    public final List<StatusLog> p1ItemLog;
    public final List<StatusLog> p2ItemLog;
    public final double result;
    public final double p1Win;
    public final double p2Win;
    public final double lastTurn;
    public BattleLogForAI(List<BattleLog> battleLog){
        List<List<StatusLog>> p1Alog = new ArrayList<>();
        List<List<StatusLog>> p2Alog = new ArrayList<>();
        List<List<StatusLog>> p1Ilog = new ArrayList<>();
        List<List<StatusLog>> p2Ilog = new ArrayList<>();
        for(int i = 0; i <= InputAction.ACTION_NUM; i++){
            p1Alog.add(new ArrayList<>());
            p2Alog.add(new ArrayList<>());
        }
        for(int i = 0; i <= BattleItem.NUM; i++){
            p1Ilog.add(new ArrayList<>());
            p2Ilog.add(new ArrayList<>());
        }
        for(BattleLog log : battleLog){
            for(int i = 0; i <= InputAction.ACTION_NUM ; i++){
                if(log.p1ActionLog.get(i) != null){
                    p1Alog.get(i).add(log.p1ActionLog.get(i));
                }
                if(log.p2ActionLog.get(i) != null){
                    p2Alog.get(i).add(log.p2ActionLog.get(i));
                }
            }
            for(int i = 0; i <= BattleItem.NUM ; i++){
                if(log.p1ItemLog.get(i) != null){
                    p1Ilog.get(i).add(log.p1ItemLog.get(i));
                }
                if(log.p2ItemLog.get(i) != null){
                    p2Ilog.get(i).add(log.p2ItemLog.get(i));
                }
            }
        }
        this.p1ActionLog = Collections.unmodifiableList(new ArrayList<>(){{for(int i = 0; i <= InputAction.ACTION_NUM ; i++){
            if(p1Alog.get(i).size() != 0){
                this.add(new StatusLog(p1Alog.get(i)));
            }else{
                this.add(null);
            }
        }}});
        this.p2ActionLog = Collections.unmodifiableList(new ArrayList<>(){{for(int i = 0; i <= InputAction.ACTION_NUM ; i++){
            if(p2Alog.get(i).size() != 0){
                this.add(new StatusLog(p2Alog.get(i)));
            }else{
                this.add(null);
            }
        }}});
        this.p1ItemLog = Collections.unmodifiableList(new ArrayList<>(){{for(int i = 0; i <= BattleItem.NUM ; i++){
            if(p1Ilog.get(i).size() != 0){
                this.add(new StatusLog(p1Ilog.get(i)));
            }else{
                this.add(null);
            }
        }}});
        this.p2ItemLog = Collections.unmodifiableList(new ArrayList<>(){{for(int i = 0; i <= BattleItem.NUM ; i++){
            if(p2Ilog.get(i).size() != 0){
                this.add(new StatusLog(p2Ilog.get(i)));
            }else{
                this.add(null);
            }
        }}});
        this.result = battleLog.stream().mapToDouble(e -> (double)e.result)
                                        .average().orElse(0);
        this.p1Win = (double)battleLog.stream().filter(l -> l.result == 1).count() / battleLog.size();
        this.p2Win = (double)battleLog.stream().filter(l -> l.result == -1).count() / battleLog.size();
        this.lastTurn = battleLog.stream()  .mapToDouble(e -> (double)e.lastTurn)
                                            .average().orElse(0);
    }
}
