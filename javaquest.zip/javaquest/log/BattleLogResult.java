package log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import battle.InputAction;
import character.Character.MainStatus;
import data.action.Spell;
import data.item.BattleItem;
import log.OneTurnBattleLog.Success;

public final class BattleLogResult {
    public final List<StatusLog> winnerActionLog;
    public final List<StatusLog> drawActionLog;
    public final List<StatusLog> loserActionLog;
    public final List<StatusLog> winnerItemLog;
    public final List<StatusLog> drawItemLog;
    public final List<StatusLog> loserItemLog;
    public final Map<BattleItem, Integer> winnerSkillLog;
    public final Map<BattleItem, Integer> drawSkillLog;
    public final Map<BattleItem, Integer> loserSkillLog;
    public final Map<Spell, Double> winnerAdoptionSpell;
    public final Map<Spell, Double> drawAdoptionSpell;
    public final Map<Spell, Double> loserAdoptionSpell;
    public final double winnerSpellSelect; 
    public final double drawSpellSelect;   
    public final double loserSpellSelect;
    public final Map<Success, Integer> winnerSuccess;
    public final Map<Success, Integer> drawSuccess;
    public final Map<Success, Integer> loserSuccess;
    public final Map<MainStatus, Double> winnerStatus;
    public final Map<MainStatus, Double> drawStatus;
    public final Map<MainStatus, Double> loserStatus;
    public final double lastTurn;
    public BattleLogResult(List<BattleLog> battleLog){
        List<List<StatusLog>> winAlog = new ArrayList<>();
        List<List<StatusLog>> drawAlog = new ArrayList<>();
        List<List<StatusLog>> loseAlog = new ArrayList<>();
        List<List<StatusLog>> winIlog = new ArrayList<>();
        List<List<StatusLog>> drawIlog = new ArrayList<>();
        List<List<StatusLog>> loseIlog = new ArrayList<>();
        for(int i = 0; i <= InputAction.ACTION_NUM; i++){
            winAlog.add(new ArrayList<>());
            drawAlog.add(new ArrayList<>());
            loseAlog.add(new ArrayList<>());
        }
        for(int i = 0; i <= BattleItem.NUM; i++){
            winIlog.add(new ArrayList<>());
            drawIlog.add(new ArrayList<>());
            loseIlog.add(new ArrayList<>());
        }
        for(BattleLog log : battleLog){
            for(int i = 0; i <= InputAction.ACTION_NUM ; i++){
                if(log.p1ActionLog.get(i) != null){
                    switch(log.result){
                        case  1 :
                            winAlog.get(i).add(log.p1ActionLog.get(i));
                            break;
                        case  0 :
                            drawAlog.get(i).add(log.p1ActionLog.get(i));
                            break;
                        case -1:
                            loseAlog.get(i).add(log.p1ActionLog.get(i));
                            break;
                    }
                }
                if(log.p2ActionLog.get(i) != null){
                    switch(log.result){
                        case  1 :
                            loseAlog.get(i).add(log.p2ActionLog.get(i));
                            break;
                        case  0 :
                            drawAlog.get(i).add(log.p2ActionLog.get(i));
                            break;
                        case -1 :
                            winAlog.get(i).add(log.p2ActionLog.get(i));
                            break;
                    }
                }
            }
            for(int i = 0; i <= BattleItem.NUM ; i++){
                if(log.p1ItemLog.get(i) != null){
                    switch(log.result){
                        case 1:
                            winIlog.get(i).add(log.p1ItemLog.get(i));
                            break;
                        case 0:
                            drawIlog.get(i).add(log.p1ItemLog.get(i));
                            break;
                        case -1:
                            loseIlog.get(i).add(log.p1ItemLog.get(i));
                            break;
                    }
                }
                if(log.p2ItemLog.get(i) != null){
                    switch(log.result){
                        case  1 :
                            loseIlog.get(i).add(log.p2ItemLog.get(i));
                            break;
                        case  0 :
                            drawIlog.get(i).add(log.p2ItemLog.get(i));
                            break;
                        case -1 :
                            winIlog.get(i).add(log.p2ItemLog.get(i));
                            break;
                    }
                }
            }
        }
        this.winnerActionLog = Collections.unmodifiableList(new ArrayList<>(){{for(int i = 0; i <= InputAction.ACTION_NUM ; i++){
            if(winAlog.get(i).size() != 0){
                this.add(new StatusLog(winAlog.get(i)));
            }else{
                this.add(null);
            }
        }}});
        this.drawActionLog = Collections.unmodifiableList(new ArrayList<>(){{for(int i = 0; i <= InputAction.ACTION_NUM ; i++){
            if(drawAlog.get(i).size() != 0){
                this.add(new StatusLog(drawAlog.get(i)));
            }else{
                this.add(null);
            }
        }}});
        this.loserActionLog = Collections.unmodifiableList(new ArrayList<>(){{for(int i = 0; i <= InputAction.ACTION_NUM ; i++){
            if(loseAlog.get(i).size() != 0){
                this.add(new StatusLog(loseAlog.get(i)));
            }else{
                this.add(null);
            }
        }}});
        this.winnerItemLog = Collections.unmodifiableList(new ArrayList<>(){{for(int i = 0; i <= BattleItem.NUM ; i++){
            if(winIlog.get(i).size() != 0){
                this.add(new StatusLog(winIlog.get(i)));
            }else{
                this.add(null);
            }
        }}});
        this.drawItemLog = Collections.unmodifiableList(new ArrayList<>(){{for(int i = 0; i <= BattleItem.NUM ; i++){
            if(drawIlog.get(i).size() != 0){
                this.add(new StatusLog(drawIlog.get(i)));
            }else{
                this.add(null);
            }
        }}});
        this.loserItemLog = Collections.unmodifiableList(new ArrayList<>(){{for(int i = 0; i <= BattleItem.NUM ; i++){
            if(loseIlog.get(i).size() != 0){
                this.add(new StatusLog(loseIlog.get(i)));
            }else{
                this.add(null);
            }
        }}});
        this.winnerSkillLog = new HashMap<>(){{
            for(BattleItem key : BattleItem.values()){
                this.put(key, (int)(battleLog.stream().filter(l -> l.result == 1)
                                                .filter(l -> l.endState.getPlayer1().passiveItem == key)
                                                .count() + 
                              battleLog.stream().filter(l -> l.result == -1)
                                                .filter(l -> l.endState.getPlayer2().passiveItem == key)
                                                .count()));
            }
        }};
        this.drawSkillLog = new HashMap<>(){{
            for(BattleItem key : BattleItem.values()){
                this.put(key, (int)(battleLog.stream().filter(l -> l.result == 0)
                                                .filter(l -> l.endState.getPlayer1().passiveItem == key)
                                                .count() + 
                              battleLog.stream().filter(l -> l.result == 0)
                                                .filter(l -> l.endState.getPlayer2().passiveItem == key)
                                                .count()));
            }
        }};
        this.loserSkillLog = new HashMap<>(){{
            for(BattleItem key : BattleItem.values()){
                this.put(key, (int)(battleLog.stream().filter(l -> l.result == -1)
                                                .filter(l -> l.endState.getPlayer1().passiveItem == key)
                                                .count() + 
                              battleLog.stream().filter(l -> l.result == 1)
                                                .filter(l -> l.endState.getPlayer2().passiveItem == key)
                                                .count()));
            }
        }};
        this.winnerAdoptionSpell = Collections.unmodifiableMap(new EnumMap<>(Spell.class){{for(Spell key : Spell.values()){
            this.put(key, (battleLog.stream().filter(l -> l.result == 1)
                                            .map(l-> l.p1AdoptionSpell)
                                            .filter(a -> a.containsKey(key))
                                            .mapToDouble(a -> (double)a.get(key))
                                            .average().orElse(0)
                        + battleLog.stream().filter(l -> l.result == -1)
                                            .map(l-> l.p2AdoptionSpell)
                                            .filter(a -> a.containsKey(key))
                                            .mapToDouble(a -> (double)a.get(key))
                                            .average().orElse(0))
                         / 2
                                            );
        }}});
        this.drawAdoptionSpell = Collections.unmodifiableMap(new EnumMap<>(Spell.class){{for(Spell key : Spell.values()){
            this.put(key, (battleLog.stream().filter(l -> l.result == 0)
                                            .map(l-> l.p1AdoptionSpell)
                                            .filter(a -> a.containsKey(key))
                                            .mapToDouble(a -> (double)a.get(key))
                                            .average().orElse(0)
                        + battleLog.stream().filter(l -> l.result == 0)
                                            .map(l-> l.p2AdoptionSpell)
                                            .filter(a -> a.containsKey(key))
                                            .mapToDouble(a -> (double)a.get(key))
                                            .average().orElse(0))
                         / 2
                                            );
        }}});
        this.loserAdoptionSpell = Collections.unmodifiableMap(new EnumMap<>(Spell.class){{for(Spell key : Spell.values()){
            this.put(key, (battleLog.stream().filter(l -> l.result == -1)
                                            .map(l-> l.p1AdoptionSpell)
                                            .filter(a -> a.containsKey(key))
                                            .mapToDouble(a -> (double)a.get(key))
                                            .average().orElse(0)
                        + battleLog.stream().filter(l -> l.result == 1)
                                            .map(l-> l.p2AdoptionSpell)
                                            .filter(a -> a.containsKey(key))
                                            .mapToDouble(a -> (double)a.get(key))
                                            .average().orElse(0))
                         / 2
                                            );
        }}});
        this.winnerSpellSelect = this.winnerActionLog.stream()  .skip(4).limit(Spell.NUM)
                                                                .filter(l -> l != null)
                                                                .mapToDouble(l -> l.actionRate)
                                                                .sum();

        this.drawSpellSelect = this.drawActionLog.stream()      .skip(4).limit(Spell.NUM)
                                                                .filter(l -> l != null)
                                                                .mapToDouble(l -> l.actionRate)
                                                                .sum();

        this.loserSpellSelect = this.loserActionLog.stream()    .skip(4).limit(Spell.NUM)
                                                                .filter(l -> l != null)
                                                                .mapToDouble(l -> l.actionRate)
                                                                .sum();
        this.winnerSuccess = Collections.unmodifiableMap(new EnumMap<>(Success.class){{for(Success key : Success.values()){
            this.put(key, battleLog.stream().filter(l -> l.result ==  1).mapToInt(l -> l.p1Success.get(key)).sum()
                        + battleLog.stream().filter(l -> l.result == -1).mapToInt(l -> l.p2Success.get(key)).sum());
        }}});
        this.drawSuccess = Collections.unmodifiableMap(new EnumMap<>(Success.class){{for(Success key : Success.values()){
            this.put(key, battleLog.stream().filter(l -> l.result ==  0).mapToInt(l -> l.p1Success.get(key)).sum()
                        + battleLog.stream().filter(l -> l.result ==  0).mapToInt(l -> l.p2Success.get(key)).sum());
        }}});
        this.loserSuccess = Collections.unmodifiableMap(new EnumMap<>(Success.class){{for(Success key : Success.values()){
            this.put(key, battleLog.stream().filter(l -> l.result == -1).mapToInt(l -> l.p1Success.get(key)).sum()
                        + battleLog.stream().filter(l -> l.result ==  1).mapToInt(l -> l.p2Success.get(key)).sum());
        }}});
        this.winnerStatus = Collections.unmodifiableMap(new EnumMap<>(MainStatus.class){{for(MainStatus key : MainStatus.values()){
            this.put(key, (battleLog.stream().filter(l -> l.result ==  1).mapToInt(l -> l.endState.getPlayer1().getMainStatus().get(key)).average().orElseThrow()
                         + battleLog.stream().filter(l -> l.result == -1).mapToInt(l -> l.endState.getPlayer2().getMainStatus().get(key)).average().orElseThrow()) / 2);
        }}});
        this.drawStatus = Collections.unmodifiableMap(new EnumMap<>(MainStatus.class){{for(MainStatus key : MainStatus.values()){
            this.put(key, (battleLog.stream().filter(l -> l.result ==  0).mapToInt(l -> l.endState.getPlayer1().getMainStatus().get(key)).average().orElse(0)
                         + battleLog.stream().filter(l -> l.result ==  0).mapToInt(l -> l.endState.getPlayer2().getMainStatus().get(key)).average().orElse(0)) / 2);
        }}});
        this.loserStatus = Collections.unmodifiableMap(new EnumMap<>(MainStatus.class){{for(MainStatus key : MainStatus.values()){
            this.put(key, (battleLog.stream().filter(l -> l.result == -1).mapToInt(l -> l.endState.getPlayer1().getMainStatus().get(key)).average().orElseThrow()
                         + battleLog.stream().filter(l -> l.result ==  1).mapToInt(l -> l.endState.getPlayer2().getMainStatus().get(key)).average().orElseThrow()) / 2);
        }}});
        this.lastTurn = battleLog.stream()  .mapToDouble(e -> (double)e.lastTurn)
                                            .average().orElse(0);
    }
}
