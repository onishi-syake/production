package log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import battle.InputAction;
import battle.state_change.ChangeBattleStatus;
import battle.state_change.ChangeAbnormalState.AbnormalState;
import battle.state_change.ChangeAbnormalState.AbnormalStateCounter;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import battle.state_change.ChangeBattleStatus.StateChangeStatus;
import battle.state_change.ChangeBattleStatus.StatusCounter;
import battle.state_change.ChangeField.Field;
import battle.state_change.ChangeField.FieldCounter;
import character.Character.BattleStatus;
import character.Character.MainStatus;
import data.action.Spell;
import data.item.BattleItem;

public final class StatusLog{
    public final int actionCount;
    public final double actionRate;
    public final Map<Spell, Double> spellLevel;
    public final Map<MainStatus, Double> beforeMainStatus;
    public final Map<BattleStatus, Double> beforeBattleStatus;
    public final Map<StateChangeStatus, Double> beforeStateChangeStatus;
    public final Map<AbnormalState, Map<AbnormalStateCounter, Double>> beforeStateAbnormal;
    public final Map<ActionState, Map<ActionStateCounter, Double>> beforeStateAction;
    public final Map<Spell, Double> beforeSpellSlot;
    public final Map<BattleItem, Double> beforeItemList;
    public final Map<Field,Map<FieldCounter, Double>> beforeField;
    public final Map<MainStatus, Double> afterMainStatus;
    public final Map<BattleStatus, Double> afterBattleStatus;
    public final Map<StateChangeStatus, Double> afterStateChangeStatus;
    public final Map<AbnormalState, Map<AbnormalStateCounter, Double>> afterStateAbnormal;
    public final Map<ActionState, Map<ActionStateCounter, Double>> afterStateAction;
    public final Map<Spell, Double> afterSpellSlot;
    public final Map<BattleItem, Double> afterItemList;
    public final Map<Field,Map<FieldCounter, Double>> afterField;
    public final List<Double> lastAction;

    StatusLog(List<OneTurnBattleLog> log, boolean player1, int size){
        this.actionCount = log.size();
        this.actionRate = this.actionCount / size;
        this.spellLevel = Collections.unmodifiableMap(new EnumMap<>(Spell.class){{for(Spell key : Spell.values()){
            this.put(key, log.stream().map(s -> s.beforeState.getPlayer(player1).getSpellLevel())
                                        .filter(s -> s.containsKey(key))
                                        .mapToDouble(s -> s.get(key))
                                        .average().orElse(0));
        }}});
        this.beforeMainStatus = Collections.unmodifiableMap(new EnumMap<>(MainStatus.class){{for(MainStatus key : MainStatus.values()){
            this.put(key, log.stream().mapToDouble(s -> s.beforeState.getPlayer(player1).getMainStatus().get(key))
                                        .average().orElseThrow());
        }}});
        this.beforeBattleStatus = Collections.unmodifiableMap(new EnumMap<>(BattleStatus.class){{for(BattleStatus key : BattleStatus.values()){
            this.put(key, log.stream().mapToDouble(s -> s.beforeState.getPlayer(player1).getBattleStatus().get(key))
                                        .average().orElseThrow());
        }}});
        // this.beforeStateChangeStatus = Collections.unmodifiableMap(new EnumMap<>(StateChangeStatus.class){{for(StateChangeStatus key : StateChangeStatus.values()){
        //     this.put(key, Collections.unmodifiableMap(new EnumMap<>(StatusCounter.class){{for(StatusCounter category : StatusCounter.values()){
        //         this.put(category, log.stream().mapToDouble(s -> s.beforeState.getPlayer(player1).getStateChangeStatus().get(key).get(category))
        //                                         .average().orElseThrow());
        //     }}}));
        // }}});
        this.beforeStateChangeStatus = Collections.unmodifiableMap(new EnumMap<>(StateChangeStatus.class){{
            for(StateChangeStatus category : StateChangeStatus.values()){
                put(category, log.stream().mapToDouble(s -> ChangeBattleStatus.calculateBuffRate(s.beforeState.getPlayer(player1).getStateChangeStatus(), category))
                .average().orElseThrow());
            }
        }});
        this.beforeStateAbnormal = Collections.unmodifiableMap(new EnumMap<>(AbnormalState.class){{for(AbnormalState key : AbnormalState.values()){
            this.put(key, Collections.unmodifiableMap(new EnumMap<>(AbnormalStateCounter.class){{for(AbnormalStateCounter category : AbnormalStateCounter.values()){
                this.put(category, log.stream().mapToDouble(s -> s.beforeState.getPlayer(player1).getStateAbnormal().get(key).get(category))
                                                .average().orElseThrow());
            }}}));
        }}});
        this.beforeStateAction = Collections.unmodifiableMap(new EnumMap<>(ActionState.class){{for(ActionState key : ActionState.values()){
            this.put(key, Collections.unmodifiableMap(new EnumMap<>(ActionStateCounter.class){{for(ActionStateCounter category : ActionStateCounter.values()){
                this.put(category, log.stream().mapToDouble(s -> s.beforeState.getPlayer(player1).getStateAction().get(key).get(category))
                                                .average().orElseThrow());
            }}}));
        }}});
        this.beforeSpellSlot = Collections.unmodifiableMap(new EnumMap<>(Spell.class){{for(Spell key : Spell.values()){
            if(key != Spell.NULL){
                this.put(key, log.stream().mapToDouble(s -> s.beforeState.getPlayer(player1).getSpellSlot().contains(key) ? 1.0 : 0.0)
                                            .average().orElseThrow());
            }
        }}});
        this.beforeItemList = Collections.unmodifiableMap(new EnumMap<>(BattleItem.class){{for(BattleItem key : BattleItem.values()){
            this.put(key, log.stream().mapToDouble(s -> s.beforeState.getPlayer(player1).getItemList().get(key))
                                        .average().orElseThrow());
        }}});
        this.beforeField = Collections.unmodifiableMap(new EnumMap<>(Field.class){{for(Field key : Field.values()){
            this.put(key, Collections.unmodifiableMap(new EnumMap<>(FieldCounter.class){{for(FieldCounter category : FieldCounter.values()){
                this.put(category, log.stream().mapToDouble(s -> s.beforeState.getField().get(key).get(category))
                                                .average().orElseThrow());
            }}}));
        }}});
        this.afterMainStatus = Collections.unmodifiableMap(new EnumMap<>(MainStatus.class){{for(MainStatus key : MainStatus.values()){
            this.put(key, log.stream().mapToDouble(s -> s.afterState.getPlayer(player1).getMainStatus().get(key))
                                        .average().orElseThrow());
        }}});
        this.afterBattleStatus = Collections.unmodifiableMap(new EnumMap<>(BattleStatus.class){{for(BattleStatus key : BattleStatus.values()){
            this.put(key, log.stream().mapToDouble(s -> s.afterState.getPlayer(player1).getBattleStatus().get(key))
                                        .average().orElseThrow());
        }}});
        // this.afterStateChangeStatus = Collections.unmodifiableMap(new EnumMap<>(StateChangeStatus.class){{for(StateChangeStatus key : StateChangeStatus.values()){
        //     this.put(key, Collections.unmodifiableMap(new EnumMap<>(StatusCounter.class){{for(StatusCounter category : StatusCounter.values()){
        //         this.put(category, log.stream().mapToDouble(s -> s.afterState.getPlayer(player1).getStateChangeStatus().get(key).get(category))
        //                                         .average().orElseThrow());
        //     }}}));
        // }}});
        this.afterStateChangeStatus = Collections.unmodifiableMap(new EnumMap<>(StateChangeStatus.class){{
            for(StateChangeStatus category : StateChangeStatus.values()){
                put(category, log.stream().mapToDouble(s -> ChangeBattleStatus.calculateBuffRate(s.afterState.getPlayer(player1).getStateChangeStatus(), category))
                .average().orElseThrow());
            }
        }});
        this.afterStateAbnormal = Collections.unmodifiableMap(new EnumMap<>(AbnormalState.class){{for(AbnormalState key : AbnormalState.values()){
            this.put(key, Collections.unmodifiableMap(new EnumMap<>(AbnormalStateCounter.class){{for(AbnormalStateCounter category : AbnormalStateCounter.values()){
                this.put(category, log.stream().mapToDouble(s -> s.afterState.getPlayer(player1).getStateAbnormal().get(key).get(category))
                                                .average().orElseThrow());
            }}}));
        }}});
        this.afterStateAction = Collections.unmodifiableMap(new EnumMap<>(ActionState.class){{for(ActionState key : ActionState.values()){
            this.put(key, Collections.unmodifiableMap(new EnumMap<>(ActionStateCounter.class){{for(ActionStateCounter category : ActionStateCounter.values()){
                this.put(category, log.stream().mapToDouble(s -> s.afterState.getPlayer(player1).getStateAction().get(key).get(category))
                                                .average().orElseThrow());
            }}}));
        }}});
        this.afterSpellSlot = Collections.unmodifiableMap(new EnumMap<>(Spell.class){{for(Spell key : Spell.values()){
            if(key != Spell.NULL){
                this.put(key, log.stream().mapToDouble(s -> s.afterState.getPlayer(player1).getSpellSlot().contains(key) ? 1.0 : 0.0)
                                            .average().orElseThrow());
            }
        }}});
        this.afterItemList = Collections.unmodifiableMap(new EnumMap<>(BattleItem.class){{for(BattleItem key : BattleItem.values()){
            this.put(key, log.stream().mapToDouble(s -> s.afterState.getPlayer(player1).getItemList().get(key))
                                        .average().orElseThrow());
        }}});
        this.afterField = Collections.unmodifiableMap(new EnumMap<>(Field.class){{for(Field key : Field.values()){
            this.put(key, Collections.unmodifiableMap(new EnumMap<>(FieldCounter.class){{for(FieldCounter category : FieldCounter.values()){
                this.put(category, log.stream().mapToDouble(s -> s.afterState.getField().get(key).get(category))
                                                .average().orElseThrow());
            }}}));
        }}});
        this.lastAction = Collections.unmodifiableList(new ArrayList<>(){{IntStream.rangeClosed(0, InputAction.ACTION_NUM).forEachOrdered(i -> this.add(log.stream().mapToDouble(s -> ((s.beforeState.getPlayer(player1).getLastAction() - 1) % InputAction.ACTION_NUM + 1) == i ? 1.0 : 0.0).average().orElseThrow()));}});
    }
    StatusLog(List<StatusLog> log){
        this.actionCount = log.stream().mapToInt(l -> l.actionCount).sum();
        this.actionRate = log.stream().mapToDouble(l -> l.actionRate).average().orElseThrow();
        this.spellLevel = Collections.unmodifiableMap(new EnumMap<>(Spell.class){{for(Spell key : Spell.values()){
            this.put(key, log.stream().mapToDouble(s -> s.spellLevel.get(key))
                                        .average().orElseThrow());
        }}});
        this.beforeMainStatus = Collections.unmodifiableMap(new EnumMap<>(MainStatus.class){{for(MainStatus key : MainStatus.values()){
            this.put(key, log.stream().mapToDouble(s -> s.beforeMainStatus.get(key))
                                        .average().orElseThrow());
        }}});
        this.beforeBattleStatus = Collections.unmodifiableMap(new EnumMap<>(BattleStatus.class){{for(BattleStatus key : BattleStatus.values()){
            this.put(key, log.stream().mapToDouble(s -> s.beforeBattleStatus.get(key))
                                        .average().orElseThrow());
        }}});
        // this.beforeStateChangeStatus = Collections.unmodifiableMap(new EnumMap<>(StateChangeStatus.class){{for(StateChangeStatus key : StateChangeStatus.values()){
        //     this.put(key, Collections.unmodifiableMap(new EnumMap<>(StatusCounter.class){{for(StatusCounter category : StatusCounter.values()){
        //         this.put(category, log.stream().mapToDouble(s -> s.beforeStateChangeStatus.get(key).get(category))
        //                                         .average().orElseThrow());
        //     }}}));
        // }}});
        this.beforeStateChangeStatus = Collections.unmodifiableMap(new EnumMap<>(StateChangeStatus.class){{
            for(StateChangeStatus category : StateChangeStatus.values()){
                put(category, log.stream().mapToDouble(s -> s.beforeStateChangeStatus.get(category))
                .average().orElseThrow());
            }
        }});
        this.beforeStateAbnormal = Collections.unmodifiableMap(new EnumMap<>(AbnormalState.class){{for(AbnormalState key : AbnormalState.values()){
            this.put(key, Collections.unmodifiableMap(new EnumMap<>(AbnormalStateCounter.class){{for(AbnormalStateCounter category : AbnormalStateCounter.values()){
                this.put(category, log.stream().mapToDouble(s -> s.beforeStateAbnormal.get(key).get(category))
                                                .average().orElseThrow());
            }}}));
        }}});
        this.beforeStateAction = Collections.unmodifiableMap(new EnumMap<>(ActionState.class){{for(ActionState key : ActionState.values()){
            this.put(key, Collections.unmodifiableMap(new EnumMap<>(ActionStateCounter.class){{for(ActionStateCounter category : ActionStateCounter.values()){
                this.put(category, log.stream().mapToDouble(s -> s.beforeStateAction.get(key).get(category))
                                                .average().orElseThrow());
            }}}));
        }}});
        this.beforeSpellSlot = Collections.unmodifiableMap(new EnumMap<>(Spell.class){{for(Spell key : Spell.values()){
            if(key != Spell.NULL){
                this.put(key, log.stream().mapToDouble(s -> s.beforeSpellSlot.get(key))
                                            .average().orElseThrow());
            }
        }}});
        this.beforeItemList = Collections.unmodifiableMap(new EnumMap<>(BattleItem.class){{for(BattleItem key : BattleItem.values()){
            this.put(key, log.stream().mapToDouble(s -> s.beforeItemList.get(key))
                                        .average().orElseThrow());
        }}});
        this.beforeField = Collections.unmodifiableMap(new EnumMap<>(Field.class){{for(Field key : Field.values()){
            this.put(key, Collections.unmodifiableMap(new EnumMap<>(FieldCounter.class){{for(FieldCounter category : FieldCounter.values()){
                this.put(category, log.stream().mapToDouble(s -> s.beforeField.get(key).get(category))
                                                .average().orElseThrow());
            }}}));
        }}});
        this.afterMainStatus = Collections.unmodifiableMap(new EnumMap<>(MainStatus.class){{for(MainStatus key : MainStatus.values()){
            this.put(key, log.stream().mapToDouble(s -> s.afterMainStatus.get(key))
                                        .average().orElseThrow());
        }}});
        this.afterBattleStatus = Collections.unmodifiableMap(new EnumMap<>(BattleStatus.class){{for(BattleStatus key : BattleStatus.values()){
            this.put(key, log.stream().mapToDouble(s -> s.afterBattleStatus.get(key))
                                        .average().orElseThrow());
        }}});
        // this.afterStateChangeStatus = Collections.unmodifiableMap(new EnumMap<>(StateChangeStatus.class){{for(StateChangeStatus key : StateChangeStatus.values()){
        //     this.put(key, Collections.unmodifiableMap(new EnumMap<>(StatusCounter.class){{for(StatusCounter category : StatusCounter.values()){
        //         this.put(category, log.stream().mapToDouble(s -> s.afterStateChangeStatus.get(key).get(category))
        //                                         .average().orElseThrow());
        //     }}}));
        // }}});
        this.afterStateChangeStatus = Collections.unmodifiableMap(new EnumMap<>(StateChangeStatus.class){{
            for(StateChangeStatus category : StateChangeStatus.values()){
                put(category, log.stream().mapToDouble(s -> s.afterStateChangeStatus.get(category))
                .average().orElseThrow());
            }
        }});
        this.afterStateAbnormal = Collections.unmodifiableMap(new EnumMap<>(AbnormalState.class){{for(AbnormalState key : AbnormalState.values()){
            this.put(key, Collections.unmodifiableMap(new EnumMap<>(AbnormalStateCounter.class){{for(AbnormalStateCounter category : AbnormalStateCounter.values()){
                this.put(category, log.stream().mapToDouble(s -> s.afterStateAbnormal.get(key).get(category))
                                                .average().orElseThrow());
            }}}));
        }}});
        this.afterStateAction = Collections.unmodifiableMap(new EnumMap<>(ActionState.class){{for(ActionState key : ActionState.values()){
            this.put(key, Collections.unmodifiableMap(new EnumMap<>(ActionStateCounter.class){{for(ActionStateCounter category : ActionStateCounter.values()){
                this.put(category, log.stream().mapToDouble(s -> s.afterStateAction.get(key).get(category))
                                                .average().orElseThrow());
            }}}));
        }}});
        this.afterSpellSlot = Collections.unmodifiableMap(new EnumMap<>(Spell.class){{for(Spell key : Spell.values()){
            if(key != Spell.NULL){
                this.put(key, log.stream().mapToDouble(s -> s.afterSpellSlot.get(key))
                                            .average().orElseThrow());
            }
        }}});
        this.afterItemList = Collections.unmodifiableMap(new EnumMap<>(BattleItem.class){{for(BattleItem key : BattleItem.values()){
            this.put(key, log.stream().mapToDouble(s -> s.afterItemList.get(key))
                                        .average().orElseThrow());
        }}});
        this.afterField = Collections.unmodifiableMap(new EnumMap<>(Field.class){{for(Field key : Field.values()){
            this.put(key, Collections.unmodifiableMap(new EnumMap<>(FieldCounter.class){{for(FieldCounter category : FieldCounter.values()){
                this.put(category, log.stream().mapToDouble(s -> s.afterField.get(key).get(category))
                                                .average().orElseThrow());
            }}}));
        }}});
        this.lastAction = Collections.unmodifiableList(new ArrayList<>(){{IntStream.rangeClosed(0, InputAction.ACTION_NUM).forEachOrdered(i -> this.add(log.stream().mapToDouble(s -> s.lastAction.get(i)).average().orElseThrow()));}});
    }
}
