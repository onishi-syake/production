package log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import character.Player;
import data.item.BattleItem;
import data.item.DisposableItem;
import data.item.ImmediateItem;
import log.unmodifiable.UnmodifiableTrainState;

public final class GameLog {
    public final List<TrainLog> trainLog;
    public final UnmodifiableTrainState endState;
    public final int turn;
    public final int generalPower;
    public final int battleNum;
    public final Map<List<Integer>, Integer> actions;
    public final Map<DisposableItem, Integer> buyDisposableItem;
    public final Map<ImmediateItem, Integer> buyImmediateItem;
    public final Map<BattleItem, Integer> buyBattleItem;
    public GameLog(List<TrainLog> trailnLog){
        this.trainLog = Collections.unmodifiableList(new ArrayList<>(trailnLog));
        this.endState = trailnLog.get(trailnLog.size() - 1).afterState;
        Player self = this.endState.getSelf().modifiableCopy();
        this.turn = trailnLog.get(trailnLog.size() - 1).turn;
        self.trainToBattleStatus();
        this.generalPower = self.generalPower(true);
        this.battleNum = (int)trailnLog.stream().filter(log -> log.battleLog != null).count();
        this.actions = new HashMap<List<Integer>, Integer>();
        for(TrainLog log: trainLog){
            if(this.actions.containsKey(log.afterState.getChargeAction())){
                this.actions.replace(log.afterState.getChargeAction(), this.actions.get(log.afterState.getChargeAction())+1);
            }else{
                this.actions.put(log.afterState.getChargeAction(), 1);
            }
        }
        this.buyDisposableItem = Collections.unmodifiableMap(new EnumMap<>(DisposableItem.class){{for(DisposableItem key : DisposableItem.values()){
            this.put(key, trailnLog.stream().map(log -> log.buyDisposableItem).filter(d -> d.containsKey(key)).mapToInt(d -> d.get(key)).sum());
        }}});
        this.buyImmediateItem = Collections.unmodifiableMap(new EnumMap<>(ImmediateItem.class){{for(ImmediateItem key : ImmediateItem.values()){
            this.put(key, trailnLog.stream().map(log -> log.buyImmediateItem).filter(d -> d.containsKey(key)).mapToInt(d -> d.get(key)).sum());
        }}});
        this.buyBattleItem = Collections.unmodifiableMap(new EnumMap<>(BattleItem.class){{for(BattleItem key : BattleItem.values()){
            this.put(key, trailnLog.stream().map(log -> log.buyBattleItem).filter(d -> d.containsKey(key)).mapToInt(d -> d.get(key)).sum());
        }}});
    }
}
