package log.unmodifiable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

import train.TrainState;

public final class UnmodifiableTrainState extends TrainState{
    public UnmodifiableTrainState(TrainState trainState){
        super(trainState);
        super.setSelf(trainState.getSelf().unmodifiableCopy());

        super.setChargeAction(Collections.unmodifiableList(new ArrayList<>(trainState.getChargeAction())));
        super.setSpendAction(Collections.unmodifiableList(new ArrayList<>(trainState.getSpendAction())));
        super.setBuyAble(Collections.unmodifiableMap(new HashMap<>(trainState.getBuyAble())));
    }
}
