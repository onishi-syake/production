package log.unmodifiable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import battle.state_change.ChangeBattleStatus;
import battle.state_change.ChangeAbnormalState.AbnormalState;
import battle.state_change.ChangeAbnormalState.AbnormalStateCounter;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import battle.state_change.ChangeBattleStatus.StateChangeStatus;
import battle.state_change.ChangeBattleStatus.StatusCounter;
import character.Player;
import data.action.Spell;
import data.item.BattleItem;
import data.item.DisposableItem;
//attributeはついては適応されていない
public final class UnmodifiablePlayer extends Player{
    public UnmodifiablePlayer(Player player){
        super(player);

        super.setMainStatus(Collections.unmodifiableMap(new EnumMap<>(player.getMainStatus())));
        super.setBattleStatus(Collections.unmodifiableMap(new EnumMap<>(player.getBattleStatus())));
        super.setStateChangeStatus(Collections.unmodifiableList(ChangeBattleStatus.deepCopyStateChangeStatus(player.getStateChangeStatus())));
        super.setStateAbnormal(Collections.unmodifiableMap(new EnumMap<>(AbnormalState.class){{for(AbnormalState key : AbnormalState.values()){
            this.put(key, Collections.unmodifiableMap(new EnumMap<>(player.getStateAbnormal().get(key))));
        }}}));
        super.setStateAction(Collections.unmodifiableMap(new EnumMap<>(ActionState.class){{for(ActionState key : ActionState.values()){
            this.put(key, Collections.unmodifiableMap(new EnumMap<>(player.getStateAction().get(key))));
        }}}));
        super.setSpellLevel(Collections.unmodifiableMap(new EnumMap<>(player.getSpellLevel())));
        super.setSpellSlot(Collections.unmodifiableList(new ArrayList<>(player.getSpellSlot())));
        super.setItemList(Collections.unmodifiableMap(new EnumMap<>(player.getItemList())));

        super.setTrainStatus(Collections.unmodifiableMap(new EnumMap<>(player.getTrainStatus())));
        super.setDisposableItemList(Collections.unmodifiableMap(new EnumMap<>(player.getDisposableItemList())));
        super.setSpellBookLevel(Collections.unmodifiableMap(new EnumMap<>(player.getSpellBookLevel())));
    }
    @Override
    public void readyBattleState(){
        throw new UnsupportedOperationException();
    }
    @Override
    public void endBattle(){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setSpellSlotNum(int spellSlotNum){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setMainStatus(Map<MainStatus, Integer> mainStatus){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setBattleStatus(Map<BattleStatus, Integer> battleStatus){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setStateChangeStatus(List<Map<StateChangeStatus, Map<StatusCounter, Double>>> stateChangeStatus){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setStateAbnormal(Map<AbnormalState, Map<AbnormalStateCounter, Integer>> stateAbnormal){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setStateAction(Map<ActionState, Map<ActionStateCounter, Integer>> stateAction){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setSpellLevel(Map<Spell, Integer> spellLevel){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setSpellSlot(List<Spell> spellSlot){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setItemList(Map<BattleItem, Integer> itemList){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setLastAction(int lastAction){
        throw new UnsupportedOperationException();
    }
    @Override
    public void trainToBattleStatus(){
        throw new UnsupportedOperationException();
    }
    @Override
    public void battleToTrainStatus(){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setTrainStatus(Map<TrainStatus, Integer> trainStatus){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setDisposableItemList(Map<DisposableItem, Integer> trainItemList){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setSpellBookLevel(Map<SpellBookLevel, Integer> spellBookLevel){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setInnNum(int innNum){
        throw new UnsupportedOperationException();
    }
}
