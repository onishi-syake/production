package log.unmodifiable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import battle.state_change.ChangeBattleStatus;
import battle.state_change.ChangeAbnormalState.AbnormalState;
import battle.state_change.ChangeAbnormalState.AbnormalStateCounter;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import battle.state_change.ChangeBattleStatus.StateChangeStatus;
import battle.state_change.ChangeBattleStatus.StatusCounter;
import character.Enemy;
import data.action.Spell;
import data.item.BattleItem;

public final class UnmodifiableEnemy extends Enemy{
    public UnmodifiableEnemy(Enemy enemy){
        super(enemy);

        super.setMainStatus(Collections.unmodifiableMap(new EnumMap<>(enemy.getMainStatus())));
        super.setBattleStatus(Collections.unmodifiableMap(new EnumMap<>(enemy.getBattleStatus())));
        super.setStateChangeStatus(Collections.unmodifiableList(ChangeBattleStatus.deepCopyStateChangeStatus(enemy.getStateChangeStatus())));
        super.setStateAbnormal(Collections.unmodifiableMap(new EnumMap<>(AbnormalState.class){{for(AbnormalState key : AbnormalState.values()){
            this.put(key, Collections.unmodifiableMap(new EnumMap<>(enemy.getStateAbnormal().get(key))));
        }}}));
        super.setStateAction(Collections.unmodifiableMap(new EnumMap<>(ActionState.class){{for(ActionState key : ActionState.values()){
            this.put(key, Collections.unmodifiableMap(new EnumMap<>(enemy.getStateAction().get(key))));
        }}}));
        super.setSpellLevel(Collections.unmodifiableMap(new EnumMap<>(enemy.getSpellLevel())));
        super.setSpellSlot(Collections.unmodifiableList(new ArrayList<>(enemy.getSpellSlot())));
        super.setItemList(Collections.unmodifiableMap(new EnumMap<>(enemy.getItemList())));
    }
    @Override
    public void readyBattleState(){
        throw new UnsupportedOperationException();
    }
    @Override
    public void endBattle(){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setSpellSlotNum(int spellSlotNum){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setMainStatus(Map<MainStatus, Integer> mainStatus){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setBattleStatus(Map<BattleStatus, Integer> battleStatus){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setStateChangeStatus(List<Map<StateChangeStatus, Map<StatusCounter, Double>>> stateChangeStatus){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setStateAbnormal(Map<AbnormalState, Map<AbnormalStateCounter, Integer>> stateAbnormal){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setStateAction(Map<ActionState, Map<ActionStateCounter, Integer>> stateAction){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setSpellLevel(Map<Spell, Integer> spellLevel){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setSpellSlot(List<Spell> spellSlot){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setItemList(Map<BattleItem, Integer> itemList){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setLastAction(int lastAction){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setLastSpell(Spell lastSpell){
        throw new UnsupportedOperationException();
    }
}
