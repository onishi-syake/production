package log.unmodifiable;

import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;

import battle.State;
import battle.InputAction.Auto;
import battle.state_change.ChangeField.Field;
import battle.state_change.ChangeField.FieldCounter;
import character.Character;

public final class UnmodifiableState extends State{
    public UnmodifiableState(State state){
        super(state);

        super.setPlayer1(state.getPlayer1().unmodifiableCopy());
        super.setPlayer2(state.getPlayer2().unmodifiableCopy());
        super.setField(Collections.unmodifiableMap(new EnumMap<>(Field.class){{for(Field key : Field.values()){
            this.put(key, Collections.unmodifiableMap(new EnumMap<>(state.getField().get(key))));
        }}}));
    }
    @Override
    public void setPlayer1(Character player){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setPlayer2(Character player){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setPlayer(Character player, boolean player1){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setPlayer(Character player1, Character player2){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setAuto(Auto auto){
        throw new UnsupportedOperationException();
    }
    @Override
    public void setField(Map<Field,Map<FieldCounter, Integer>> field){
        throw new UnsupportedOperationException();
    }
    @Override
    public void countTurn(){
        throw new UnsupportedOperationException();
    }
    @Override
    public void endBattle(){
        throw new UnsupportedOperationException();
    }
}
