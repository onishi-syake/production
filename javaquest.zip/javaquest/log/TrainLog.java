package log;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import data.item.BattleItem;
import data.item.DisposableItem;
import data.item.ImmediateItem;
import log.unmodifiable.UnmodifiableTrainState;
import train.TrainState;

public final class TrainLog implements Serializable {
    public final UnmodifiableTrainState beforeState;
    public final UnmodifiableTrainState afterState;
    public final int turn;
    public final Map<DisposableItem, Integer> buyDisposableItem;
    public final Map<ImmediateItem, Integer> buyImmediateItem;
    public final Map<BattleItem, Integer> buyBattleItem;
    public final List<Integer> action;
    public final BattleLog battleLog;
    public final BattleLog eventBattleLog;
    public TrainLog(TrainState beforeState, TrainState afterState, TrainTemporaryLog buyLog){
        this.beforeState = beforeState.unmodifiableCopy();
        this.afterState = afterState.unmodifiableCopy();
        this.turn = beforeState.getTurn();
        this.buyDisposableItem = Collections.unmodifiableMap(new EnumMap<>(buyLog.getBuyD()));
        this.buyImmediateItem = Collections.unmodifiableMap(new EnumMap<>(buyLog.getBuyI()));
        this.buyBattleItem = Collections.unmodifiableMap(new EnumMap<>(buyLog.getBuyB()));
        this.action = Collections.unmodifiableList(new ArrayList<>(buyLog.getAction()));
        this.battleLog = buyLog.getBattleLog();
        this.eventBattleLog = buyLog.getEventBattleLog();
    }
    public OneTurnBattleLog getBattleLog(int turn){
        if(this.battleLog == null){
            throw new NullPointerException("この日戦闘を行っておりません");
        }
        return this.battleLog.battleLog.get(turn - 1);
    }
}
