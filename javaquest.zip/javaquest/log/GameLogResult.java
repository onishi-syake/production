package log;

import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import data.item.BattleItem;
import data.item.DisposableItem;
import data.item.ImmediateItem;

public final class GameLogResult {
    public final double turn;
    public final double generalPower;
    public final double battleNum;
    public final Map<List<Integer>, Integer> actions;
    public final Map<DisposableItem, Double> buyDisposableItem;
    public final Map<ImmediateItem, Double> buyImmediateItem;
    public final Map<BattleItem, Double> buyBattleItem;
    public GameLogResult(List<GameLog> gameLog){
        double size = gameLog.size();
        this.turn = gameLog.stream().mapToInt(log -> log.turn).average().orElseThrow();
        this.generalPower = gameLog.stream().mapToInt(log -> log.generalPower).average().orElseThrow();
        this.battleNum = gameLog.stream().mapToInt(log -> log.battleNum).average().orElseThrow();
        this.actions = new HashMap<List<Integer>, Integer>();
        for(GameLog log: gameLog){
            for(List<Integer> key: log.actions.keySet()){
                if(this.actions.containsKey(key) && this.actions.get(key) != null){
                    this.actions.replace(key, actions.get(key) + log.actions.get(key));
                }else{
                    this.actions.put(key, log.actions.get(key));
                }
            }
        }
        this.buyDisposableItem = Collections.unmodifiableMap(new EnumMap<>(DisposableItem.class){{for(DisposableItem key : DisposableItem.values()){
            this.put(key, gameLog.stream().map(log -> log.buyDisposableItem).filter(d -> d.containsKey(key)).mapToInt(d -> d.get(key)).sum() / size);
        }}});
        this.buyImmediateItem = Collections.unmodifiableMap(new EnumMap<>(ImmediateItem.class){{for(ImmediateItem key : ImmediateItem.values()){
            this.put(key, gameLog.stream().map(log -> log.buyImmediateItem).filter(d -> d.containsKey(key)).mapToInt(d -> d.get(key)).sum() / size);
        }}});
        this.buyBattleItem = Collections.unmodifiableMap(new EnumMap<>(BattleItem.class){{for(BattleItem key : BattleItem.values()){
            this.put(key, gameLog.stream().map(log -> log.buyBattleItem).filter(d -> d.containsKey(key)).mapToInt(d -> d.get(key)).sum() / size);
        }}});
    }
}
