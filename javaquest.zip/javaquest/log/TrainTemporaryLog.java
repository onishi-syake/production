package log;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;

import data.item.BattleItem;
import data.item.DisposableItem;
import data.item.ImmediateItem;

public final class TrainTemporaryLog implements Serializable {
    private EnumMap<DisposableItem, Integer> buyDisposableItem = new EnumMap<>(DisposableItem.class);
    private EnumMap<ImmediateItem, Integer> buyImmediateItem = new EnumMap<>(ImmediateItem.class);
    private EnumMap<BattleItem, Integer> buyBattleItem = new EnumMap<>(BattleItem.class);
    private List<Integer> action = new ArrayList<>();
    private BattleLog battleLog;
    private BattleLog eventBattleLog;

    public EnumMap<DisposableItem, Integer> getBuyD(){
        return this.buyDisposableItem;
    }
    public EnumMap<ImmediateItem, Integer> getBuyI(){
        return this.buyImmediateItem;
    }
    public EnumMap<BattleItem, Integer> getBuyB(){
        return this.buyBattleItem;
    }
    public List<Integer> getAction(){
        return this.action;
    }
    public BattleLog getBattleLog(){
        return this.battleLog;
    }
    public void setBattleLog(BattleLog log){
        this.battleLog = log;
    }
    public BattleLog getEventBattleLog(){
        return this.eventBattleLog;
    }
    public void setEventBattleLog(BattleLog log){
        this.eventBattleLog = log;
    }
}
