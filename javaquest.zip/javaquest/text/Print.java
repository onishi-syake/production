package text;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import game.SwingTest;
import battle.InputAction;
import battle.State;
import battle.InputAction.Action;
import battle.state_change.ChangeAbnormalState.AbnormalStateCounter;
import battle.state_change.ChangeAbnormalState;
import battle.state_change.ChangeBattleStatus;
import battle.state_change.ChangeField;
import battle.state_change.ChangeWeather;
import battle.state_change.ChangeAbnormalState.AbnormalState;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import battle.state_change.ChangeBattleStatus.StateChangeStatus;
import battle.state_change.ChangeField.Field;
import battle.state_change.ChangeField.FieldCounter;
import battle.state_change.ChangeWeather.Weather;
import battle.state_change.ChangeWeather.WeatherCounter;
import character.Character;
import character.Enemy;
import character.Player;
import character.Character.Attribute;
import character.Character.BattleStatus;
import character.Character.MainStatus;
import character.Player.TrainStatus;
import data.action.Special;
import data.action.Spell;
import data.card.Card;
import data.card.CardWithParams;
import data.card.TrainMenu;
import data.card.TrainMenu.TrainResult;
import data.item.BattleItem;
import game.GameState;
import game.LocationCategory;
import train.Train;
import train.TrainState;

//ゲーム内のテキスト入出力。flagをfalseにすれば全て消せる。
public final class Print {

    public static final boolean color = true;

    // ここの文字は2バイト以下の文字を使うこと
    public static final String title = "<div style=\"padding: 5px; border: 1px solid #FFFFFF; display: inline-block; width:605px; height:490px;\">" + "<br>".repeat(20) + Print.space(46, true) + "<font size=\"6\">余命</font> <font size=\"7\">16</font> <font size=\"6\">日</font> <font size=\"7\">魔王</font>" + "<br>".repeat(5) + Print.space(50, true) + "<font size=\"4\">Enterを押してください</font></div>";
    public static final String gameFrame = "<div style=\"padding: 5px; border: 1px solid #FFFFFF; display: inline-block; width:605px; height:490px;\">";
    public static final String sleepText = "$";// この文字1文字ごとに出力をsleepTime秒止める
    public static final double sleepTime = 0.05;
    public static final String skipStartText = "Ā";// この文字から
    public static final String skipEndText = "ā";// この文字までは瞬時に出力する
    public static final String slowStartText = "Ć";// この文字から
    public static final String slowEndText = "ć";// この文字まではゆっくり出力する
    public static final String verySlowStartText = "Ď";// この文字から
    public static final String verySlowEndText = "ď";// この文字までは超ゆっくり出力する
    public static final String tempSlowLiftStartText = "Ē";// この文字から
    public static final String tempSlowLiftEndText = "ē";// この文字まではゆっくり出力を解除する
    public static final String slowDeleteText = "Ĝ";// この文字が含まれているとゆっくり削除する
    public static final String changeWaitTextToLT = "ĝ";// この文字が含まれていると入力待ち文字が>>>から<<<に変わる

    public static final int highSpeed = 1;
    public static final int middleSpeed = 15;
    public static final int lowSpeed = 50;

    // 改行付きprint関数
    public static void println(String text, boolean isDynamic, int sleep, boolean flag){
        println(text, isDynamic, true, sleep, flag);
    }
    
    public static void println(String text, int sleep, boolean flag){
        println(text, false, true, sleep, flag);
    }

    // 改行付きprint関数
    public static void println(String text, boolean isDynamic, boolean isLineSpace, int sleep, boolean flag){
        if(flag){
            print(text, isDynamic, sleep, flag);
            if(SwingTest.addTextS != null){
                if(isDynamic && !text.equals("") && sleep != 0){
                    SwingTest.addText(sleep(5), isDynamic);
                }
                SwingTest.addText("<br>", isDynamic);
                if(isLineSpace) lineSpace(isDynamic, flag);
            }else{
                System.out.println();
            }
        }
    }

    // 引数で表示速度・表示の可否を指定可能なprint関数
    public static void print(String text, boolean isDynamic, int sleep, boolean flag){
        if(flag){
            if(SwingTest.addTextS != null){
                SwingTest.addText(text, isDynamic);
            }else{
                for(int i = 0; i < text.length(); i++){
                    System.out.print(text.charAt(i));
                    try {
                        Thread.sleep(sleep);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    public static void print(String text, int sleep, boolean flag){
        print(text, false, sleep, flag);
    }

    // 文字の長さをlengthに合わせる（足りない部分を空白で埋める）関数
    public static String format(String target, int length){
        int byteLength = getByteLength(target, Charset.forName("UTF-8"));
        int fullWidthNum = (byteLength - target.length()) / 2;
        int spaceNum = length - target.length() - fullWidthNum;
        spaceNum = spaceNum < 0 ? 0 : spaceNum;
        return target + space(spaceNum, true);
    }

    // 色付け時にズレる長さを調整出来るformat関数
    public static String format(String target, int length, int colorNum){
        
        if(SwingTest.addTextS != null){
            length += 29 * colorNum;
        }else{
            length += 8 * colorNum;
        }
        return format(target, length);
    }

    // 文字の長さを計測する関数(半角は1，全角は3)
    public static int getByteLength(String string, Charset charset) {
        return string.getBytes(charset).length;
    }

    // 整数値の入力を受け付ける。（正しくない入力の場合は0を返す）
    public static int input(Scanner sc, boolean flag){
        return input(0, sc, flag);
    }

    // 整数値の入力を受け付ける。（正しくない入力の場合は引数のdefaultNumを返す）
    public static int input(int defaultNum, Scanner sc, boolean flag){
        if(!flag) return -1;
        try{
            int x = Integer.parseInt(sc.nextLine());
            Print.println("", 0, flag);
            return x;
        }catch(Exception e){
            return defaultNum;
        }
    }

    //クリック待ち。
    public static void nextLine(Scanner sc, boolean flag){
        flag = false;
        if (flag) sc.nextLine();
    }

    //名前付きでゲージの表示を行う。
    public static void displayParameter(Character self, String name, MainStatus maxKey, MainStatus key, String mark, String emptyMark, Color frameColor, int n, boolean isRedOneThird, boolean cutNonActive, boolean text){
        // Print.println(name + ":" + self.getMainStatus().get(key) + " / " + self.getMainStatus().get(maxKey), Print.highSpeed, text);
        // generalDisplayParameter(mark, frameColor, self.getMainStatus().get(key), self.getMainStatus().get(maxKey), n, text);
        int redNum = 0;
        int scarletNum = 0;
        int activeMarkNum = (self.getMainStatus().get(maxKey).intValue() == 0 ? 0 : self.getMainStatus().get(key) * n / self.getMainStatus().get(maxKey));
        int nonActiveMarkNum = n - activeMarkNum;
        if(cutNonActive){
            nonActiveMarkNum = nonActiveMarkNum * 4 / 5;
        }
        if(isRedOneThird){
            if(activeMarkNum >= n / 3){
                scarletNum = n / 5;
                redNum = n / 3 - scarletNum;
                activeMarkNum -= scarletNum + redNum;
            }else{
                if(activeMarkNum >= n / 5){
                    scarletNum = n / 5;
                    redNum = activeMarkNum - scarletNum;
                    activeMarkNum = 0;
                }else{
                    scarletNum = activeMarkNum;
                    redNum = 0;
                    activeMarkNum = 0;
                }
            }
        }
        String gauge = Color.scarlet.toColor(mark.repeat(scarletNum)) +  Color.darkOrange.toColor(mark.repeat(redNum)) + mark.repeat(activeMarkNum) + emptyMark.repeat(nonActiveMarkNum);
        displayParameter(gauge, name + " |", "|", false, text);
    }

    // ゲージの表示
    public static void generalDisplayParameter(String mark, String nonMark, String frame, Color frameColor, int nowNum, int faultNum, int successNum, int greatSuccessNum, int maxNum, int n, boolean isShowChange, boolean isRedOneThird, boolean isDouble, boolean text){
        if(maxNum == 0){
            Print.print(frame, Print.highSpeed, text);
            Print.print(nonMark.repeat(n * 4 / 5), Print.highSpeed, text);
            Print.print(frame, Print.highSpeed, text);
            return;
        }
        String gauge;
        if(isShowChange){
            int dangerousNum = isRedOneThird ? n / 3 : 0; 
            int darkOrangeNum = 0;
            int grayGreenNum = 0;// 危険と成功減少の重なり
            int grayPurpleNum = 0;// 危険と大成功減少の重なり
            int activeMarkNum;
            int whiteMarkNum;// 通常色
            int yellowMarkNum;// 回復色
            int lightGreenMarkNum;// 成功時消費色
            int whiteBlueMarkNum;// 大成功時消費色
            // HP訓練＋回復で現在の最大値を超えたり、失敗時の値を超えるとバグるため。
            if(faultNum > maxNum){
                faultNum = maxNum;
            }
            if(successNum > faultNum){
                successNum = faultNum;
            }
            if(greatSuccessNum > faultNum){
                greatSuccessNum = faultNum;
            }
            if(successNum > greatSuccessNum){
                successNum = greatSuccessNum;
            }
    
            if(nowNum < faultNum){
                activeMarkNum = n * faultNum / maxNum;
            }else{
                activeMarkNum = n * nowNum / maxNum;
            }
            if(nowNum < successNum){
                whiteMarkNum = n * nowNum / maxNum;// 元の量
                yellowMarkNum = n * successNum / maxNum - whiteMarkNum;// 成功時の残り
            }else{
                whiteMarkNum = n * successNum / maxNum;// 成功時の残り
                yellowMarkNum = 0;
            }
            // lightGreenMarkNum = n * greatSuccessNum / maxNum - whiteMarkNum - yellowMarkNum;
            // whiteBlueMarkNum = activeMarkNum - whiteMarkNum - yellowMarkNum - lightGreenMarkNum;
            
            if(greatSuccessNum == successNum){
                lightGreenMarkNum = activeMarkNum - whiteMarkNum - yellowMarkNum;
                whiteBlueMarkNum = 0;
            }else{
                lightGreenMarkNum = n * (greatSuccessNum - successNum) / maxNum;// 大成功時と成功時の差
                whiteBlueMarkNum = activeMarkNum - whiteMarkNum - yellowMarkNum - lightGreenMarkNum;// 残り
            }
    
            // 警告色の作成
            if(activeMarkNum < dangerousNum){
                dangerousNum = activeMarkNum;
            }
            if(whiteMarkNum >= dangerousNum){
                darkOrangeNum += dangerousNum;
                whiteMarkNum -= dangerousNum;
                dangerousNum = 0;
            }else{
                darkOrangeNum = whiteMarkNum;
                dangerousNum -= whiteMarkNum;
                whiteMarkNum = 0;
                if(yellowMarkNum >= dangerousNum){
                    darkOrangeNum += dangerousNum;
                    yellowMarkNum -= dangerousNum;
                    dangerousNum = 0;
                }else{
                    darkOrangeNum += yellowMarkNum;
                    dangerousNum -= yellowMarkNum;
                    yellowMarkNum = 0;
                    if(lightGreenMarkNum >= dangerousNum){
                        grayGreenNum = dangerousNum;
                        lightGreenMarkNum -= dangerousNum;
                        dangerousNum = 0;
                    }else{
                        grayGreenNum = lightGreenMarkNum;
                        dangerousNum -= lightGreenMarkNum;
                        lightGreenMarkNum = 0;
                        
                        grayPurpleNum = dangerousNum;
                        whiteBlueMarkNum -= dangerousNum;
                        dangerousNum = 0;
                    }
                }
            }
    
            Map<Color, Integer> colorNum = new HashMap<Color, Integer>();
            colorNum.put(Color.darkOrange, darkOrangeNum);
            colorNum.put(Color.grayGreen, grayGreenNum);
            colorNum.put(Color.grayPurple, grayPurpleNum);
            colorNum.put(Color.white, whiteMarkNum);
            colorNum.put(Color.yellow, yellowMarkNum);
            colorNum.put(Color.lightGreen, lightGreenMarkNum);
            colorNum.put(Color.whiteBlue, whiteBlueMarkNum);
            colorNum.put(Color.gray, n - activeMarkNum);
            int repeatNum;
            gauge = "";
            String tempMark;
            for(Color color : new Color[]{Color.darkOrange, Color.grayGreen, Color.grayPurple, Color.white, Color.yellow, Color.lightGreen, Color.whiteBlue, Color.gray}){
                repeatNum = colorNum.get(color);
                if(color == Color.gray){
                    color = Color.white;
                    tempMark = nonMark;
                    if(tempMark.equals("-")){
                        repeatNum = repeatNum * 4 / 5;
                    }
                }else{
                    tempMark = mark;
                }
                if(repeatNum < 0){
                    System.out.println("error gauge minus");
                    continue;
                }
                gauge += color.toColor(tempMark.repeat(repeatNum));
            }
        }else{
            int activeMarkNum = n * nowNum / maxNum;
            int nonActiveMarkNum = (n - activeMarkNum) * 4 / 5;
            gauge = mark.repeat(activeMarkNum) + nonMark.repeat(nonActiveMarkNum);
        }
        displayParameter(gauge, frame, frame, false, text);
        // Print.print(frame, Print.highSpeed, text);
        // Print.print(gauge, Print.highSpeed, text);
        // Print.print(frame, Print.highSpeed, text);
    }

    public static void generalDisplayParameter(String mark, Color gaugeColor, Color frameColor, int n, int growNum, int maxNum, boolean isShowChange, boolean text){
        if(n > growNum){
            growNum = n;
        }
        String marks = mark.repeat(n);
        if(isShowChange){
            marks += Color.lightGreen.toColor(mark.repeat((maxNum > growNum ? growNum : maxNum) - n));
        }
        displayParameter(gaugeColor.toColor(marks), frameColor.toColor("["), frameColor.toColor("]"), false, text);
    }

    // 完成されたゲージとフレームのみを貰い、フォントを変更して表示
    public static void displayParameter(String gauge, String startFrame, String endFrame, boolean isDynamic, boolean text){
        print(startFrame, isDynamic, highSpeed, text);
        startArial(isDynamic, text);
        print(gauge, isDynamic, highSpeed, text);
        endArial(isDynamic, text);
        println(endFrame, isDynamic, highSpeed, text);
    }

    // 戦闘時の詳細情報
    private static void displayBattleStatus(Character self, boolean showItem, boolean text){
        println(self.getJName(), Print.highSpeed, text);
        println("", highSpeed, text);
        println(MainStatus.hp.jName + ": " + self.getMainStatus().get(MainStatus.hp) + " / " + self.getMainStatus().get(MainStatus.maxHp), Print.highSpeed, text);
        println(MainStatus.mp.jName + ": " + self.getMainStatus().get(MainStatus.mp) + " / " + self.getMainStatus().get(MainStatus.maxMp), Print.highSpeed, text);
        for(BattleStatus state : BattleStatus.values()){
            int beforeState = self.getMainStatus().get(MainStatus.valueOf(state.name()));
            int afterState = self.getBattleStatus().get(state);
            if(state == BattleStatus.d){
                println(state.status.jName + ": " + String.format("%.2f", beforeState / 100.0) + " → " + String.format("%.2f", afterState / 100.0), Print.highSpeed, text);
                continue;
            }
            println(state.status.jName + ": " + beforeState + " → " + afterState, Print.highSpeed, text);
        }
        println("テンション x" + self.getStateAction().get(ActionState.Tension).get(ActionStateCounter.count).toString(), Print.highSpeed, text);
        println("", highSpeed, text);
        String beforeAction = actionNumToName(self.getLastAction());
        if(4 + Spell.NUM + Special.NUM < self.getLastAction() && self.getLastAction() < 1 + InputAction.ACTION_NUM){
            beforeAction = "呪文追加";
        }
        println("前回行動:" + beforeAction , Print.highSpeed, text);
        println("必殺技:" + self.getAttribute().jName, Print.highSpeed, text);
        print("状態異常:", Print.highSpeed, text);
        for(AbnormalState aCategory : AbnormalState.values()){
            if(self.getStateAbnormal().get(aCategory).get(AbnormalStateCounter.flag) == 1){
                print(Print.space(1, text) + aCategory.jName + " ( " + self.getStateAbnormal().get(aCategory).get(AbnormalStateCounter.count) + " ターン)", Print.highSpeed, text);
            }
        }
        println("", highSpeed, text);
        println("溜めるレベル: " + self.getStateAction().get(ActionState.sucTen).get(ActionStateCounter.count) + " レベル", highSpeed, text);
        print("能力変化:", Print.highSpeed, text);
        for(StateChangeStatus state : StateChangeStatus.values()){
            int buffRate = (int)Math.round(ChangeBattleStatus.calculateBuffRate(self.getStateChangeStatus(), state));
            String udText = buffRate > 0 ? buffRate + "%増加" : -buffRate + "%減少";
            if(buffRate != 0){
                print(" " + state.status.status.jName + " " + udText, Print.highSpeed, text);
            }
        }
        println("", highSpeed, text);
        print("所持オーブ: ", Print.highSpeed, text);
        for(Spell spell : self.getLearnedSpellLevel().keySet()){
            if(spell != Spell.NULL){
                println(spell.jName, Print.highSpeed, text);
            }
            print(space(12, text), 0, text);
        }
        println("", highSpeed, text);
        if(showItem){
            println("戦闘スキル:" + self.passiveItem.jName, highSpeed, text);
        }
        Print.print(space(46, text), Print.highSpeed, text);
    }

    // ボス戦前のステータス表示
    public static void displayBattleStatusBeforeBattle(Character self, Character enemy, boolean isBoss, boolean text){
        startFrame(false, text);
        startTable(text);
        startRow(text);

        // int maxN = 50;
        // int selfHpN = self.getMainStatus().get(MainStatus.maxHp) / 40;
        // int enemyHpN = enemy.getMainStatus().get(MainStatus.maxHp) / 40;
        // while(Math.max(selfHpN, enemyHpN) > maxN){
        //     selfHpN /= 2;
        //     enemyHpN /= 2;
        // }
        int selfMpN = self.getMainStatus().get(MainStatus.maxMp);
        int enemyMpN = enemy.getMainStatus().get(MainStatus.maxMp);
        // int selfAN = self.getMainStatus().get(MainStatus.a) / 4;
        // int enemyAN = enemy.getMainStatus().get(MainStatus.a) / 4;
        // while(Math.max(selfAN, enemyAN) > maxN){
        //     selfAN /= 2;
        //     enemyAN /= 2;
        // }
        // int selfSN = self.getMainStatus().get(MainStatus.s) / 4;
        // int enemySN = enemy.getMainStatus().get(MainStatus.s) / 4;
        // while(Math.max(selfSN, enemySN) > maxN){
        //     selfSN /= 2;
        //     enemySN /= 2;
        // }
        
        int defaultLength = 20;
        int lineWrapCoef = 2;
        int maxGaugeLength = defaultLength * lineWrapCoef;
        int maxHpGaugeLengthS = defaultLength * self.getMainStatus().get(MainStatus.maxHp) / TrainStatus.maxHp.defaultNum;
        int aGaugeLengthS = defaultLength * self.getMainStatus().get(MainStatus.a) / TrainStatus.a.defaultNum;
        int sGaugeLengthS = defaultLength * self.getMainStatus().get(MainStatus.s) / TrainStatus.s.defaultNum;
        int maxHpGaugeLengthE = defaultLength * enemy.getMainStatus().get(MainStatus.maxHp) / TrainStatus.maxHp.defaultNum;
        int aGaugeLengthE = defaultLength * enemy.getMainStatus().get(MainStatus.a) / TrainStatus.a.defaultNum;
        int sGaugeLengthE = defaultLength * enemy.getMainStatus().get(MainStatus.s) / TrainStatus.s.defaultNum;

        for(int i = 0; i < 100; i++){
            if(maxHpGaugeLengthS > maxGaugeLength || 
            aGaugeLengthS > maxGaugeLength || 
            sGaugeLengthS > maxGaugeLength || 
            maxHpGaugeLengthE > maxGaugeLength || 
            aGaugeLengthE > maxGaugeLength || 
            sGaugeLengthE > maxGaugeLength){
                maxHpGaugeLengthS /= lineWrapCoef;
                aGaugeLengthS /= lineWrapCoef;
                sGaugeLengthS /= lineWrapCoef;
                maxHpGaugeLengthE /= lineWrapCoef;
                aGaugeLengthE /= lineWrapCoef;
                sGaugeLengthE /= lineWrapCoef;
            }else{
                break;
            }
        }

        //self
        println(self.getJName(), highSpeed, text);
        println("", highSpeed, text);
        Print.displayParameter(self, Print.format(MainStatus.hp.jName + "( " + self.getMainStatus().get(MainStatus.hp) + " )", 20), MainStatus.maxHp, MainStatus.hp, "/", "-", Color.white, maxHpGaugeLengthS, false, true, text);
        Print.displayParameter(self, Print.format(MainStatus.mp.jName + "( " + self.getMainStatus().get(MainStatus.mp) + " )", 20), MainStatus.maxMp, MainStatus.mp, "〇", "-", Color.white, selfMpN, false, true, text);
        Print.displayParameter(self, Print.format(MainStatus.a.jName + "( " + self.getMainStatus().get(MainStatus.a) + " )", 20), MainStatus.a, MainStatus.a, "/", "＿", Color.white, aGaugeLengthS, false, true, text);
        Print.displayParameter(self, Print.format(MainStatus.s.jName + "( " + self.getMainStatus().get(MainStatus.s) + " )", 20), MainStatus.s, MainStatus.s, "/", "-", Color.white, sGaugeLengthS, false, true, text);
        println("", highSpeed, text);
        println("必殺技:" + self.getAttribute().jName, Print.highSpeed, text);
        print("所持オーブ:", Print.highSpeed, text);
        int count = 0;
        for(Spell spell : self.getLearnedSpellLevel().keySet()){
            if(spell != Spell.NULL){
                count++;
                print(spell.jName, Print.highSpeed, text);
                if(count % 2 == 0){
                    println("", Print.highSpeed, text);
                    print(space(11, text), Print.highSpeed, text);
                }else{
                    print(space(1, text), Print.highSpeed, text);
                }
            }
        }
        println("", highSpeed, text);
        println("戦闘スキル:" + self.passiveItem.jName, highSpeed, text);
        Print.print(space(47, text), highSpeed, text);

        //仕切り
        separateRow(text);

        for(int i = 0; i < 20; i++){
            println(space(2, text) + "|" + space(2, text), false, false, 0, text);
        }
        
        separateRow(text);

        //enemy
        println(enemy.getJName(), highSpeed, text);
        println("", highSpeed, text);
        Print.displayParameter(enemy, Print.format(MainStatus.hp.jName + "( " + enemy.getMainStatus().get(MainStatus.hp) + " )", 20), MainStatus.maxHp, MainStatus.hp, "/", "-", Color.white, maxHpGaugeLengthE, false, true, text);
        Print.displayParameter(enemy, Print.format(MainStatus.mp.jName + "( " + enemy.getMainStatus().get(MainStatus.mp) + " )", 20), MainStatus.maxMp, MainStatus.mp, "〇", "＿", Color.white, enemyMpN, false, true, text);
        Print.displayParameter(enemy, Print.format(MainStatus.a.jName + "( " + enemy.getMainStatus().get(MainStatus.a) + " )", 20), MainStatus.a, MainStatus.a, "/", "-", Color.white, aGaugeLengthE, false, true, text);
        Print.displayParameter(enemy, Print.format(MainStatus.s.jName + "( " + enemy.getMainStatus().get(MainStatus.s) + " )", 20), MainStatus.s, MainStatus.s, "/", "-", Color.white, sGaugeLengthE, false, true, text);
        println("", highSpeed, text);
        println("必殺技:" + enemy.getAttribute().jName, Print.highSpeed, text);
        print("所持オーブ:", Print.highSpeed, text);
        count = 0;
        for(Spell spell : enemy.getLearnedSpellLevel().keySet()){
            if(spell != Spell.NULL){
                count++;
                print(spell.jName, Print.highSpeed, text);
                if(count % 2 == 0){
                    println("", Print.highSpeed, text);
                    print(space(11, text), Print.highSpeed, text);
                }else{
                    print(space(1, text), Print.highSpeed, text);
                }
            }
        }
        println("", highSpeed, text);
        println("戦闘スキル:" + enemy.passiveItem.jName, highSpeed, text);
        println("", highSpeed, text);
        if(isBoss){
            Print.println(Color.scarlet.toColor("※ 勇者の行動選択知能は非常に高いです"), false, Print.highSpeed, text);
        }


        endRow(text);
        endTable(text);
        endFrame(false, text);
    }

    // 戦闘ホーム
    public static void displayBattleMenu(State state, boolean self_is_player1, boolean text){
        Character self = state.getPlayer(self_is_player1);
        Character enemy = state.getPlayer(!self_is_player1);
        Map<Field,Map<FieldCounter, Integer>> field = state.getField();
                
        int selfBuffNum = ChangeBattleStatus.checkBuffNum(self);
        int enemyBuffNum = ChangeBattleStatus.checkBuffNum(enemy);
        int selfBuffLineAdjustmentNum = enemyBuffNum - selfBuffNum;
        int enemyBuffLineAdjustmentNum = selfBuffNum - enemyBuffNum;
        if(selfBuffLineAdjustmentNum < 0){
            selfBuffLineAdjustmentNum = 0;
        }
        if(enemyBuffLineAdjustmentNum < 0){
            enemyBuffLineAdjustmentNum = 0;
        }

        //関数化すべきでは？
        Print.println(state.getTurn() + " ターン目", false, false, Print.highSpeed, text);
        Print.setFrameStart(text);
        Print.startTable(text);
        Print.startRow(text);

        int n;

        Print.println(self.getJName(), Print.highSpeed, text);
        Print.println("", Print.highSpeed, text);
        n = 60;
        Print.displayParameter(self, Print.format(MainStatus.hp.jName + "( " + self.getMainStatus().get(MainStatus.hp) + " )", 13), MainStatus.maxHp, MainStatus.hp, "/", "-", Color.blue, n, true, true, text);
        
        

        n = self.getMainStatus().get(MainStatus.maxMp);
        Print.displayParameter(self, Print.format(MainStatus.mp.jName + "( " + self.getMainStatus().get(MainStatus.mp) + " )", 13), MainStatus.maxMp, MainStatus.mp, "〇", "＿", Color.blue, n, false, false, text);
        
        Print.println("", Print.highSpeed, text);
        
        if(self.getMainStatus().get(MainStatus.a).intValue() != self.getBattleStatus().get(BattleStatus.a).intValue()){
            Print.println(MainStatus.a.jName + "( " + self.getMainStatus().get(MainStatus.a) + " → " + self.getBattleStatus().get(BattleStatus.a) + " ) ", Print.highSpeed, text);
        }else{
            Print.println(MainStatus.a.jName + "( " + self.getBattleStatus().get(BattleStatus.a) + " ) ", Print.highSpeed, text);
        }
        
        if(self.getMainStatus().get(MainStatus.s).intValue() != self.getBattleStatus().get(BattleStatus.s).intValue()){
            Print.println(MainStatus.s.jName + "( " + self.getMainStatus().get(MainStatus.s) + " → " + self.getBattleStatus().get(BattleStatus.s) + " )", Print.highSpeed, text);
        }else{
            Print.println(MainStatus.s.jName + "( " + self.getBattleStatus().get(BattleStatus.s) + " )", Print.highSpeed, text);
        }
        
        if(self.getMainStatus().get(MainStatus.d).intValue() != 100 || self.getMainStatus().get(MainStatus.d).intValue() != self.getBattleStatus().get(BattleStatus.d).intValue()){
            if(self.getMainStatus().get(MainStatus.d).intValue() != self.getBattleStatus().get(BattleStatus.d).intValue()){
                Print.println(MainStatus.d.jName + "( " + String.format("%.2f", self.getMainStatus().get(MainStatus.d) / 100.0) + " → " + String.format("%.2f", self.getBattleStatus().get(BattleStatus.d) / 100.0) + " )", Print.highSpeed, text);
            }else{
                Print.println(MainStatus.d.jName + "( " + String.format("%.2f", self.getBattleStatus().get(BattleStatus.d) / 100.0) + " )", Print.highSpeed, text);
            }
        }else{
            Print.println("", Print.highSpeed, text);
        }
        Print.println("", Print.highSpeed, text);
        List<Integer> notLegalAct = new ArrayList<>();
        boolean isLegalSpell = true;
        if(ChangeAbnormalState.checkAbnormal(self, false).contains(AbnormalState.SuperStomatitis)){
            isLegalSpell = false;
        }
        for(Integer act : new int[]{4, self.getLastAction(), self.getSecondLastAction()}){
            if(ChangeAbnormalState.execute(self, field, AbnormalState.Nervous, act, 0, false) || 
            ChangeAbnormalState.execute(self, field, AbnormalState.SuperNervous, act, 0, false)){
                if(4 <= act && act < 4 + Spell.NUM){// 呪文
                    isLegalSpell = false;
                    continue;
                }
                notLegalAct.add(act);
            }
            if(self.getLastAction() == self.getSecondLastAction()){
                break;
            }
        }
        Print.print(format("選択不可", 10) + ": ", Print.highSpeed, text);
        if(self.getStateAction().get(ActionState.Swoon).get(ActionStateCounter.flag) == 1){
            Print.print("全て", Print.highSpeed, text);
        }else if(notLegalAct.size() == 0 && isLegalSpell){
            Print.print("なし", Print.highSpeed, text);
        }else{
            for(int act : notLegalAct){
                Print.print(Print.actionNumToName(act) + Print.space(2, text), Print.highSpeed, text);
            }
            if(!isLegalSpell){
                Print.print("呪文" + Print.space(2, text), Print.highSpeed, text);
            }
        }
        Print.println("", Print.highSpeed, text);
        
        if(self.getStateAction().get(ActionState.Tension).get(ActionStateCounter.count) != 0){
            Print.print(format("テンション", 12) + "x" + self.getStateAction().get(ActionState.Tension).get(ActionStateCounter.count), Print.highSpeed, text);
        }
        Print.println("", Print.highSpeed, text);
        
        if(self.getAttribute() != Attribute.Null){
            Print.print(format("必殺技", 10) + ": " + self.getAttribute().jName, Print.highSpeed, text);
            if(self.getStateAction().get(ActionState.newChargeSpecial).get(ActionStateCounter.flag) == 1){
                Print.print(" 〇", Print.highSpeed, text);
            }else{
                Print.print(" [" + self.getStateAction().get(ActionState.newChargeSpecial).get(ActionStateCounter.count) + "]", Print.highSpeed, text);
            }
        }
        Print.println("", Print.highSpeed, text);
        
        if(ChangeAbnormalState.checkAnyAbnormal(self, true)){
            Print.print(format("状態異常", 10) + ":", Print.highSpeed, text);
            for(AbnormalState aCategory : ChangeAbnormalState.checkAbnormal(self, true)){
                Print.print(Print.space(1, text) + aCategory.jName + " ( " + self.getStateAbnormal().get(aCategory).get(AbnormalStateCounter.count) + " ターン)", Print.highSpeed, text);
            }
        }
        Print.println("", Print.highSpeed, text);
        
        if(ChangeBattleStatus.checkAnyBuff(self)){
            Print.print(format("能力変化", 10) + ":", Print.highSpeed, text);
            for(StateChangeStatus buff : StateChangeStatus.values()){
                int buffRate = (int)Math.round(ChangeBattleStatus.calculateBuffRate(self.getStateChangeStatus(), buff));
                String udText = buffRate > 0 ? buffRate + "%増加" : -buffRate + "%減少";
                if(buffRate != 0){
                    Print.print(Print.space(1, text) + buff.status.status.jName + " " + udText, Print.highSpeed, text);
                    if(ChangeBattleStatus.getBuffTurn(self.getStateChangeStatus(), buff) != -1){
                        Print.print(Print.space(1, text) + "( " + ChangeBattleStatus.getBuffTurn(self.getStateChangeStatus(), buff) + " ターン)", Print.highSpeed, text);
                    }
                    Print.println("", Print.highSpeed, text);
                    
                    Print.print(Print.space(11, text), Print.highSpeed, text);
                }
            }
        }
        for(int i = 0; i < selfBuffLineAdjustmentNum + 1; i++){
            Print.println("", Print.highSpeed, text);
        }
        
        if(self.passiveItem != BattleItem.None){
            Print.print(format("戦闘スキル", 10) + ": " + self.passiveItem.jName, Print.highSpeed, text);
        }
        Print.println("", Print.highSpeed, text);
        
        if(ChangeField.getActiveFieldNum(state.getField()) != 0){
            print(format("フィールド", 10) + ": ", Print.highSpeed, text);
            for(Field fieldCategory : ChangeField.getActiveField(state.getField()).keySet()){
                Print.print(fieldCategory.jName + "( " + (state.getField().get(fieldCategory).get(FieldCounter.count) + 1) + " ターン)", Print.highSpeed, text);
            }
        }
        Print.println("", Print.highSpeed, text);
        


        Print.separateRow(text);
        for(int i = 0; i < 30; i++){
            Print.println(Print.space(2, text) + "|" + Print.space(2, text), false, false, 0, text);
        }
        Print.separateRow(text);


        Print.println(enemy.getJName(), Print.highSpeed, text);
        Print.println("", Print.highSpeed, text);

        n = 60;
        Print.displayParameter(enemy, Print.format(MainStatus.hp.jName + "( " + enemy.getMainStatus().get(MainStatus.hp) + " )", 13), MainStatus.maxHp, MainStatus.hp, "/", "-", Color.red, n, true, true, text);

        
        
        n = enemy.getMainStatus().get(MainStatus.maxMp);
        Print.displayParameter(enemy, Print.format(MainStatus.mp.jName + "( " + enemy.getMainStatus().get(MainStatus.mp) + " )", 13), MainStatus.maxMp, MainStatus.mp, "〇", "＿", Color.red, n, false, false, text);
        
        Print.println("", Print.highSpeed, text);

        if(enemy.getMainStatus().get(MainStatus.a).intValue() != enemy.getBattleStatus().get(BattleStatus.a).intValue()){
            Print.println(MainStatus.a.jName + "( " + enemy.getMainStatus().get(MainStatus.a) + " → " + enemy.getBattleStatus().get(BattleStatus.a) + " ) ", Print.highSpeed, text);
        }else{
            Print.println(MainStatus.a.jName + "( " + enemy.getBattleStatus().get(BattleStatus.a) + " ) ", Print.highSpeed, text);
        }
        
        if(enemy.getMainStatus().get(MainStatus.s).intValue() != enemy.getBattleStatus().get(BattleStatus.s).intValue()){
            Print.println(MainStatus.s.jName + "( " + enemy.getMainStatus().get(MainStatus.s) + " → " + enemy.getBattleStatus().get(BattleStatus.s) + " )", Print.highSpeed, text);
        }else{
            Print.println(MainStatus.s.jName + "( " + enemy.getBattleStatus().get(BattleStatus.s) + " )", Print.highSpeed, text);
        }
        
        if(enemy.getMainStatus().get(MainStatus.d).intValue() != 100 || enemy.getMainStatus().get(MainStatus.d).intValue() != enemy.getBattleStatus().get(BattleStatus.d).intValue()){
            if(enemy.getMainStatus().get(MainStatus.d).intValue() != enemy.getBattleStatus().get(BattleStatus.d).intValue()){
                Print.println(MainStatus.d.jName + "( " + String.format("%.2f", enemy.getMainStatus().get(MainStatus.d) / 100.0) + " → " + String.format("%.2f", enemy.getBattleStatus().get(BattleStatus.d) / 100.0) + " )", Print.highSpeed, text);
            }else{
                Print.println(MainStatus.d.jName + "( " + String.format("%.2f", enemy.getBattleStatus().get(BattleStatus.d) / 100.0) + " )", Print.highSpeed, text);
            }
        }else{
            Print.println("", Print.highSpeed, text);
        }
        Print.println("", Print.highSpeed, text);
        notLegalAct = new ArrayList<>();
        isLegalSpell = true;
        if(ChangeAbnormalState.checkAbnormal(enemy, false).contains(AbnormalState.SuperStomatitis)){
            isLegalSpell = false;
        }
        for(Integer act : new int[]{4, enemy.getLastAction(), enemy.getSecondLastAction()}){
            if(ChangeAbnormalState.execute(enemy, field, AbnormalState.Nervous, act, 0, false) || 
            ChangeAbnormalState.execute(enemy, field, AbnormalState.SuperNervous, act, 0, false)){
                if(4 <= act && act < 4 + Spell.NUM){// 呪文
                    isLegalSpell = false;
                    continue;
                }
                notLegalAct.add(act);
            }
            if(enemy.getLastAction() == enemy.getSecondLastAction()){
                break;
            }
        }
        Print.print(format("選択不可", 10) + ": ", Print.highSpeed, text);
        if(enemy.getStateAction().get(ActionState.Swoon).get(ActionStateCounter.flag) == 1){
            Print.print("全て", Print.highSpeed, text);
        }else if(notLegalAct.size() == 0 && isLegalSpell){
            Print.print("なし", Print.highSpeed, text);
        }else{
            for(int act : notLegalAct){
                if(4 + Spell.NUM + Special.NUM < act && act < 1 + InputAction.ACTION_NUM){
                    Print.print("？？？追加" + Print.space(2, text), Print.highSpeed, text);
                    continue;
                }
                Print.print(Print.actionNumToName(act) + Print.space(2, text), Print.highSpeed, text);
            }
            if(!isLegalSpell){
                Print.print("呪文" + Print.space(2, text), Print.highSpeed, text);
            }
        }
        Print.println("", Print.highSpeed, text);
        
        // Print.print("前回行動：" + Print.actionNumToName(enemy.getLastAction()) + "    属性：" + enemy.getAttribute().jName, Print.highSpeed, text);
        if(enemy.getStateAction().get(ActionState.Tension).get(ActionStateCounter.count) != 0){
            Print.print(format("テンション", 12) + "x" + enemy.getStateAction().get(ActionState.Tension).get(ActionStateCounter.count), Print.highSpeed, text);
        }
        Print.println("", Print.highSpeed, text);
        
        if(enemy.getAttribute() != Attribute.Null){
            // Print.print("必殺技:" + enemy.getAttribute().jName, Print.highSpeed, text);
            // if(enemy.getStateAction().get(ActionState.newChargeSpecial).get(ActionStateCounter.count) == 0){
            //     Print.print(" 〇", Print.highSpeed, text);
            // }else if(enemy.getStateAction().get(ActionState.newChargeSpecial).get(ActionStateCounter.count) == 1){
            //     Print.print(" ◎", Print.highSpeed, text);
            // }else if(enemy.getStateAction().get(ActionState.newChargeSpecial).get(ActionStateCounter.flag) == 1){
            //     Print.print(" ok!", Print.highSpeed, text);
            // }
            Print.print(format("必殺技", 10) + ": " + enemy.getAttribute().jName, Print.highSpeed, text);
            if(enemy.getStateAction().get(ActionState.newChargeSpecial).get(ActionStateCounter.flag) == 1){
                Print.print(" 〇", Print.highSpeed, text);
            }else{
                Print.print(" [" + enemy.getStateAction().get(ActionState.newChargeSpecial).get(ActionStateCounter.count) + "]", Print.highSpeed, text);
            }
        }
        Print.println("", Print.highSpeed, text);
        
        if(ChangeAbnormalState.checkAnyAbnormal(enemy, true)){
            Print.print(format("状態異常", 10) + ":", Print.highSpeed, text);
            for(AbnormalState aCategory : ChangeAbnormalState.checkAbnormal(enemy, true)){
                Print.print(Print.space(1, text) + aCategory.jName + " ( " + enemy.getStateAbnormal().get(aCategory).get(AbnormalStateCounter.count) + " ターン)", Print.highSpeed, text);
            }
        }
        Print.println("", Print.highSpeed, text);
        
        if(ChangeBattleStatus.checkAnyBuff(enemy)){
            Print.print(format("能力変化", 10) + ":", Print.highSpeed, text);
            for(StateChangeStatus buff : StateChangeStatus.values()){
                int buffRate = (int)Math.round(ChangeBattleStatus.calculateBuffRate(enemy.getStateChangeStatus(), buff));
                String udText = buffRate > 0 ? buffRate + "%増加" : -buffRate + "%減少";
                if(buffRate != 0){
                    Print.print(Print.space(1, text) + buff.status.status.jName + " " + udText, Print.highSpeed, text);
                    if(ChangeBattleStatus.getBuffTurn(enemy.getStateChangeStatus(), buff) != -1){
                        Print.print(Print.space(1, text) + "( " + ChangeBattleStatus.getBuffTurn(enemy.getStateChangeStatus(), buff) + " ターン)", Print.highSpeed, text);
                    }
                    Print.println("", Print.highSpeed, text);
                    
                    Print.print(Print.space(11, text), Print.highSpeed, text);
                }
            }
        }
        for(int i = 0; i < enemyBuffLineAdjustmentNum + 1; i++){
            Print.println("", Print.highSpeed, text);
            
        }
        
        if(enemy.passiveItem != BattleItem.None && !(enemy instanceof Player)){
            Print.print(format("戦闘スキル", 10) + ": " + enemy.passiveItem.jName, Print.highSpeed, text);
        }
        Print.println("", Print.highSpeed, text);
        
        if(ChangeField.getActiveFieldNum(state.getField()) != 0){
            print(format("フィールド", 10) + ": ", Print.highSpeed, text);
            for(Field fieldCategory : ChangeField.getActiveField(state.getField()).keySet()){
                Print.print(fieldCategory.jName + "( " + (state.getField().get(fieldCategory).get(FieldCounter.count) + 1) + " ターン)", Print.highSpeed, text);
            }
        }
        Print.println("", Print.highSpeed, text);
        


        Print.endRow(text);
        Print.endTable(text);
        Print.setFrameEnd(text);
    }

    public static void displayBattleField(State state, boolean self_is_player1, boolean text, Scanner scanner){
        Character self = state.getPlayer(self_is_player1);
        Character enemy = state.getPlayer(!self_is_player1);
        int choice;
        Spell spell;
        AbnormalState aState;
        int input;
        Map<Field,Map<FieldCounter, Integer>> field = state.getField();
        Map<Weather, Map<WeatherCounter, Integer>> weather = state.getWeather();
        final int EXPLAIN = 1;
        final int SELECT = 2;
        final int ENEMY_SPELL_EXPLAIN = 3;
        final int ENEMY_SPELL_SELECT = 4;
        final int ABNORMAL_EXPLAIN = 5;
        final int ABNORMAL_SELECT = 6;
        final int WAIT_ENTER = 7;
        List<AbnormalState> abnormalList = new ArrayList<>(){{
            for(AbnormalState state : AbnormalState.values()){
                if(ChangeAbnormalState.checkAbnormal(self, false).contains(state) || 
                ChangeAbnormalState.checkAbnormal(enemy, false).contains(state)){
                    add(state);
                }
            }
        }};
        switch(state.getSavedLocation(LocationCategory.displayBattleField)){
            case LocationCategory.NO_CHOICE:
                state.saveLocation(LocationCategory.displayBattleField, EXPLAIN);
                displayBattleField(state, self_is_player1, text, scanner);
                return;

            case EXPLAIN:
                boolean isDynamic = false;
                startFrame(isDynamic, text);
                startTable(isDynamic, text);
                startRow(isDynamic, text);
                displayBattleStatus(self, true, text);
                separateRow(isDynamic, text);
                for(int i = 0; i < 40; i++){
                    Print.println(Print.space(2, text) + "|" + Print.space(2, text), false, false, 0, text);
                }
                Print.separateRow(text);
                displayBattleStatus(enemy,  !(enemy instanceof Player), text);
                endRow(isDynamic, text);
                endTable(isDynamic, text);
                println("", highSpeed, text);
                print("フィールド:", Print.highSpeed, text);
                for(Field category : Field.values()){
                    if(field.get(category).get(FieldCounter.flag) == 1){
                        print(category.jName + " ", Print.highSpeed, text);
                    }
                }
                println("", highSpeed, text);
                println("", highSpeed, text);
                // print("天候:", Print.highSpeed, text);
                // Weather nowWeather = ChangeWeather.nowWeather(state);
                // if(nowWeather != Weather.NULL){
                //     println(nowWeather.jName + "(残り " + weather.get(nowWeather).get(WeatherCounter.count) + " ターン)", Print.highSpeed, text);
                //     print(ChangeWeather.makeAllRelationString(nowWeather), highSpeed, text);
                // }
                // println("", Print.highSpeed, text);
                // println("", highSpeed, text);
                println("詳細情報", highSpeed, text);
                println("1:敵呪文詳細", highSpeed, text);
                println("2:状態異常詳細", highSpeed, text);
                println("3:戦闘スキル説明", highSpeed, text);
                println("4:必殺技説明", highSpeed, text);
                endFrame(isDynamic, text);
                state.saveLocation(LocationCategory.displayBattleField, SELECT);
                return;

            case SELECT:
                input = state.takeNextAction();
                if(input == 1){
                    state.saveLocation(LocationCategory.displayBattleField, ENEMY_SPELL_EXPLAIN);
                    displayBattleField(state, self_is_player1, text, scanner);
                    return;
                }else if(input == 2){
                    state.saveLocation(LocationCategory.displayBattleField, ABNORMAL_EXPLAIN);
                    displayBattleField(state, self_is_player1, text, scanner);
                    return;
                }else if(input == 3){
                    BattleItem item = self.passiveItem;
                    BattleItem enemyItem = enemy.passiveItem;
                    startFrame(false, text);
                    println("戦闘スキル", highSpeed, text);
                    println("", highSpeed, text);
                    if(item == BattleItem.None){
                        println(self.getJName(), highSpeed, text);
                        println("戦闘スキルを所持していません", highSpeed, text);
                    }else{
                        println(self.getJName() + space(2, text) + item.jName, highSpeed, text);
                        println(item.battleExplain, highSpeed, text);
                    }
                    if(!(enemy instanceof Player)){
                        println("", highSpeed, text);
                        if(enemyItem == BattleItem.None){
                            println(enemy.getJName(), highSpeed, text);
                            println("戦闘スキルを所持していません", highSpeed, text);
                        }else{
                            println(enemy.getJName() + space(2, text) + enemyItem.jName, highSpeed, text);
                            println(enemyItem.battleExplain, highSpeed, text);
                        }
                    }
                    endFrame(false, text);
                    Print.changeWaitTextToLT(text);
                    state.saveLocation(LocationCategory.displayBattleField, WAIT_ENTER);
                    return;
                }else if(input == 4){
                    List<Character> showSpecialCharacters = new ArrayList<>(){{add(self);}};
                    Special special;
                    if(!(enemy instanceof Player)){
                        showSpecialCharacters.add(enemy);
                    }
                    startFrame(false, text);
                    println("必殺技", Print.highSpeed, text);
                    for(Character chara : showSpecialCharacters){
                        println("", Print.highSpeed, text);
                        if(chara.getAttribute() == Attribute.Null || chara.getAttribute() == null){
                            println(chara.getJName(), Print.highSpeed, text);
                            println(Attribute.Null.jName, Print.highSpeed, text);
                            continue;
                        }
                        if(chara.getAttribute() == Attribute.A){
                            special = Special.SpecialAttack;
                        }else if(chara.getAttribute() == Attribute.D){
                            special = Special.SpecialDefense;
                        }else{// Attribute.C
                            special = Special.SpecialTension;
                        }
                        println(chara.getJName() + space(2, text) + special.jName, Print.highSpeed, text);
                        println(special.explain, Print.highSpeed, text);
                    }
                    endFrame(false, text);
                    Print.changeWaitTextToLT(text);
                    state.saveLocation(LocationCategory.displayBattleField, WAIT_ENTER);
                    return;
                }else{
                    state.saveLocation(LocationCategory.displayBattleField, LocationCategory.FINISH);
                    return;
                }

                case ENEMY_SPELL_EXPLAIN:
                    startFrame(false, text);
                    println("どの呪文を調べますか", highSpeed, text);
                    for(int i = 0; i < enemy.getSpellArray().length; i++){
                        spell = enemy.getSpellArray()[i];
                        if(spell != Spell.NULL){
                            print((i + 1) + ": " + spell.jName + " ", Print.highSpeed, text);
                        }
                        if((i + 1) % 5 == 0){
                            println("", highSpeed, text);
                        }
                    }
                    // println("", highSpeed, text);
                    // print("Enter: 終了 ", highSpeed, text);
                    endFrame(false, text);
                    state.saveLocation(LocationCategory.displayBattleField, ENEMY_SPELL_SELECT);
                    return;
    
                case ENEMY_SPELL_SELECT:
                    choice = state.takeNextAction();
                    if(0 < choice && choice <= enemy.getSpellArray().length){
                        spell = enemy.getSpellArray()[choice - 1];
                        Print.println("", Print.highSpeed, text);
                        spell.explain(state, !self_is_player1, text, scanner);
                        nextLine(scanner, text);
                        state.saveLocation(LocationCategory.displayBattleField, ENEMY_SPELL_EXPLAIN);
                        return;
                    }else{
                        state.saveLocation(LocationCategory.displayBattleField, LocationCategory.FINISH);
                        return;
                    }

            case ABNORMAL_EXPLAIN:
                startFrame(false, text);
                println("どの状態異常を調べますか", highSpeed, text);
                for(int i = 0; i < abnormalList.size(); i++){
                    aState = abnormalList.get(i);
                    print((i + 1) + ": " + aState.jName + " ", Print.highSpeed, text);
                    if((i + 1) % 5 == 0){
                        println("", highSpeed, text);
                    }
                }
                // println("", highSpeed, text);
                // print("Enter: 終了 ", highSpeed, text);
                endFrame(false, text);
                state.saveLocation(LocationCategory.displayBattleField, ABNORMAL_SELECT);
                return;

            case ABNORMAL_SELECT:
                choice = state.takeNextAction();
                if(0 < choice && choice <= abnormalList.size()){
                    aState = abnormalList.get(choice - 1);
                    Print.startFrame(false, text);
                    Print.println(aState.jName, Print.highSpeed, text);
                    Print.print(aState.explain, Print.highSpeed, text);
                    Print.endFrame(false, text);
                    nextLine(scanner, text);
                    state.saveLocation(LocationCategory.displayBattleField, ABNORMAL_EXPLAIN);
                    return;
                }else{
                    state.saveLocation(LocationCategory.displayBattleField, LocationCategory.FINISH);
                    return;
                }

            case WAIT_ENTER:
                state.saveLocation(LocationCategory.displayBattleField, LocationCategory.FINISH);
                return;
        }
    };

    // 訓練選択画面におけるパラメータ表示
    public static void displayTrainStatusCustom(TrainState trainState, boolean isShowChange, boolean text){
        Player self = trainState.getSelf();
        Color nameColor;

        // println("", highSpeed, text);
        setFrameStart(text);
        String endTurnText = "";
        if(trainState.getTurn() <= 16){
            endTurnText = " / " + ((((trainState.getTurn() - 1) / 8) + 1) * 8);
        }
        Print.print(self.getJName() + space(4, text) + trainState.getTurn() + endTurnText + " 日目", Print.highSpeed, text);
        if(trainState.getTurn() <= trainState.getTurnLimit()){
            Print.println("  (次の勇者まで " + ((((trainState.getTurn() - 1) / 4) + 1) * 4 - trainState.getTurn() + 1) + " 日)", Print.highSpeed, text);
        }else{
            Print.println("", Print.highSpeed, text);
        }

        startTable(text);

        // startRow(text);
        
        // endRow(text);

        startRow(text);
        // 消費パラメータテーブル
        startTable(text);

        Map<TrainStatus, Map<TrainResult, Integer>> afterParam = CardWithParams.getChangeParameterFromChoice(trainState, trainState, null, null);

        // hpRow
        startRow(text);
        if(trainState.getSelf().getNoCostStatus().contains(TrainStatus.hp)){
            nameColor = Color.whiteGreen;
        }else{
            nameColor = Color.whiteOrange;
        }
        Print.print(nameColor.toColor(TrainStatus.hp.jName), highSpeed, text);
        separateRow(text);
        print("( " + String.valueOf(self.getTrainStatus().get(TrainStatus.hp)) + " )", Print.highSpeed, text);
        separateRow(text);
        Print.generalDisplayParameter("/", "-", "|", Color.white, self.getTrainStatus().get(TrainStatus.hp), afterParam.get(TrainStatus.hp).get(TrainResult.fault), afterParam.get(TrainStatus.hp).get(TrainResult.success), afterParam.get(TrainStatus.hp).get(TrainResult.greatSuccess),
         self.getTrainStatus().get(TrainStatus.maxHp), 60, isShowChange, true, true, text);
        // Print.generalDisplayParameter("/", Color.normal, self.getTrainStatus().get(TrainStatus.hp), self.getTrainStatus().get(TrainStatus.maxHp),
        //  20, text);
        endRow(text);
                
        // concentrationRow
        startRow(text);
        if(trainState.getSelf().getNoCostStatus().contains(TrainStatus.concentration)){
            nameColor = Color.whiteGreen;
        }else{
            nameColor = Color.whiteOrange;
        }
        Print.print(nameColor.toColor(TrainStatus.concentration.jName), highSpeed, text);
        separateRow(text);
        print("( " + String.valueOf(self.getTrainStatus().get(TrainStatus.concentration)) + " ) ", Print.highSpeed, text);
        separateRow(text);
        Print.generalDisplayParameter("/", "-", "|", Color.white, self.getTrainStatus().get(TrainStatus.concentration), afterParam.get(TrainStatus.concentration).get(TrainResult.fault), afterParam.get(TrainStatus.concentration).get(TrainResult.success), afterParam.get(TrainStatus.concentration).get(TrainResult.greatSuccess),
         self.getTrainStatus().get(TrainStatus.maxConcentration), 60, isShowChange, false, true, text);
        // Print.generalDisplayParameter("/", Color.normal, self.getTrainStatus().get(TrainStatus.concentration), self.getTrainStatus().get(TrainStatus.maxConcentration),
        //  20, text);
        endRow(text);
        
        // motivationRow
        startRow(text);
        if(trainState.getSelf().getNoCostStatus().contains(TrainStatus.motivation)){
            nameColor = Color.whiteGreen;
        }else{
            nameColor = Color.whiteOrange;
        }
        Print.print(nameColor.toColor(TrainStatus.motivation.jName), highSpeed, text);
        separateRow(text);
        print("( " + String.valueOf(self.getTrainStatus().get(TrainStatus.motivation)) + " )", Print.highSpeed, text);
        separateRow(text);
        Print.generalDisplayParameter("〇", "＿", "", Color.white, Train.addMenusNum(trainState), (int) (afterParam.get(TrainStatus.motivation).get(TrainResult.fault) / 20), (int) (afterParam.get(TrainStatus.motivation).get(TrainResult.success) / 20), (int) (afterParam.get(TrainStatus.motivation).get(TrainResult.greatSuccess) / 20),
        (int) (self.getTrainStatus().get(TrainStatus.maxMotivation) / 20), (int) (self.getTrainStatus().get(TrainStatus.maxMotivation) / 20), isShowChange, false, false, text);
        // Print.generalDisplayParameter("〇", "", Color.normal, Train.addMenusNum(trainState), (int) (self.getTrainStatus().get(TrainStatus.maxMotivation) / 20),
        // (int) (self.getTrainStatus().get(TrainStatus.maxMotivation) / 20), text);
        endRow(text);
                
        // // gasoline
        // Print.print("<br><br>" + Print.format(TrainStatus.gasoline.jName + "(" + TrainStatus.gasoline.color.toColor(String.valueOf(self.getTrainStatus().get(TrainStatus.gasoline))) + ")", 15, TrainStatus.gasoline.color != Color.normal ? 1 : 0), Print.highSpeed, text);
        // Print.generalDisplayParameter("/", Color.normal, self.getTrainStatus().get(TrainStatus.gasoline), self.getTrainStatus().get(TrainStatus.maxGasoline),
        //  (int)((Math.log(self.getTrainStatus().get(TrainStatus.maxGasoline) / 100) / Math.log(2) + 1) * 10), text);
        
        endTable(text);
        
        

        separateRow(text);

        startTable(text);
        startRow(text);
        println("|", 0, text);
        endRow(text);
        startRow(text);
        println("|", 0, text);
        endRow(text);
        startRow(text);
        println("|", 0, text);
        endRow(text);
        endTable(text);
        
        separateRow(text);


        int defaultLength = 15;
        int lineWrapCoef = 4;
        // int gaugeLength;
        int maxHpGaugeLength = defaultLength * self.getTrainStatus().get(TrainStatus.maxHp) / TrainStatus.maxHp.defaultNum;
        int aGaugeLength = defaultLength * self.getTrainStatus().get(TrainStatus.a) / TrainStatus.a.defaultNum;
        int sGaugeLength = defaultLength * self.getTrainStatus().get(TrainStatus.s) / TrainStatus.s.defaultNum;
        int growGaugeLength;
        int maxGaugeLength = defaultLength * lineWrapCoef;
        Color gaugeColor = Color.white;
        Color[] colors = new Color[]{Color.white, Color.purple, Color.blue, Color.red, Color.yellow};
        
        for(Color color : colors){
            if(maxHpGaugeLength > maxGaugeLength || 
            aGaugeLength > maxGaugeLength || 
            sGaugeLength > maxGaugeLength){
                maxHpGaugeLength /= lineWrapCoef;
                aGaugeLength /= lineWrapCoef;
                sGaugeLength /= lineWrapCoef;
            }else{
                gaugeColor = color;
                break;
            }
        }

        // maxHp
        startTable(text);
        startRow(text);
        Print.print(TrainStatus.maxHp.jName, highSpeed, text);
        separateRow(text);
        Print.print("( " + self.getTrainStatus().get(TrainStatus.maxHp) + " )", Print.highSpeed, text);
        separateRow(text);
        // gaugeLength = defaultLength * self.getTrainStatus().get(TrainStatus.maxHp) / TrainStatus.maxHp.defaultNum;
        // for(Color color : colors){
        //     if(gaugeLength > defaultLength * lineWrapCoef){
        //         gaugeLength /= lineWrapCoef;
        //     }else{
        //         gaugeColor = color;
        //         break;
        //     }
        // }
        growGaugeLength = maxHpGaugeLength * afterParam.get(TrainStatus.maxHp).get(TrainResult.success) / self.getTrainStatus().get(TrainStatus.maxHp);
        Print.generalDisplayParameter("|", gaugeColor, Color.yellow, maxHpGaugeLength, growGaugeLength, maxGaugeLength, isShowChange, text);
        endRow(text);
        // a
        startRow(text);
        Print.print(TrainStatus.a.jName, highSpeed, text);
        separateRow(text);
        Print.print("( " + self.getTrainStatus().get(TrainStatus.a) + " )", Print.highSpeed, text);
        separateRow(text);
        // gaugeLength = defaultLength * self.getTrainStatus().get(TrainStatus.a) / TrainStatus.a.defaultNum;
        // for(Color color : colors){
        //     if(gaugeLength > defaultLength * lineWrapCoef){
        //         gaugeLength /= lineWrapCoef;
        //     }else{
        //         gaugeColor = color;
        //         break;
        //     }
        // }
        growGaugeLength = aGaugeLength * afterParam.get(TrainStatus.a).get(TrainResult.success) / self.getTrainStatus().get(TrainStatus.a);
        Print.generalDisplayParameter("|", gaugeColor, Color.purple, aGaugeLength, growGaugeLength, maxGaugeLength, isShowChange, text);
        endRow(text);

        // s
        startRow(text);
        Print.print(TrainStatus.s.jName, highSpeed, text);
        separateRow(text);
        Print.print("( " + self.getTrainStatus().get(TrainStatus.s) + " )", Print.highSpeed, text);
        separateRow(text);
        // gaugeLength = defaultLength * self.getTrainStatus().get(TrainStatus.s) / TrainStatus.s.defaultNum;
        // for(Color color : colors){
        //     if(gaugeLength > defaultLength * lineWrapCoef){
        //         gaugeLength /= lineWrapCoef;
        //     }else{
        //         gaugeColor = color;
        //         break;
        //     }
        // }
        growGaugeLength = sGaugeLength * afterParam.get(TrainStatus.s).get(TrainResult.success) / self.getTrainStatus().get(TrainStatus.s);
        Print.generalDisplayParameter("|", gaugeColor, Color.green, sGaugeLength, growGaugeLength, maxGaugeLength, isShowChange, text);
        endRow(text);
        endTable(text);

        endRow(text);
        endTable(text);
        int con = self.getTrainStatus().get(TrainStatus.concentration);
        if(con <= 100){
            Print.print("大成功: 0%" + Print.space(4, text) + "成功: " + con + "%" + Print.space(4, text) + "失敗: " + (100 - con) + "%", Print.highSpeed, text);
        }else if(self.getTrainStatus().get(TrainStatus.concentration).intValue() <= 200){
            Print.print("大成功: " + (con - 100) + "%" + Print.space(4, text) + "成功: " + (200 - con) + "%" + Print.space(4, text) + "失敗: 0%", Print.highSpeed, text);
        }else{
            Print.print("大成功: 100%" + Print.space(4, text) + "成功: 0%" + Print.space(4, text) + "失敗: 0%", Print.highSpeed, text);
        }
        if(trainState.getSelf().getElixirTurn() != 0){
            Print.println("", Print.highSpeed, text);
            Print.println(BattleItem.Elixir.jName + "発動中!", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
        }
        // if(TrainMenu.guts(trainState.getSelf())){
        //     Print.println("", Print.highSpeed, text);
        //     Print.println(Color.blue.toColor("根性発動中!"), Print.highSpeed, text);
        //     Print.println("", Print.highSpeed, text);
        // }
        setFrameEnd(text);
    }

    // デッキの内容を表示
    public static void displayDeck(TrainState trainState, boolean text){
        List<Card> deck = new ArrayList<>(trainState.deck);
        // Card deckTop = deck.get(deck.size() - 1);
        Card.sortCards(deck);
        Card beforeCard = null;
        int count = 1;
        startFrame(false, text);
        println("デッキ情報", highSpeed, text);
        
        Print.startTable(text);
        if(deck.size() != 0){
            Print.startRow(text);
            for(Card card : deck){
                if(beforeCard == null){
                    print(card.properName(), highSpeed, text);
                    separateRow(text);
                    print(card.categoryName(), highSpeed, text);
                }else if(card != beforeCard){
                    separateRow(text);
                    println(count + "枚", highSpeed, text);
                    endRow(text);
                    startRow(text);
                    print(card.properName(), highSpeed, text);
                    separateRow(text);
                    print(card.categoryName(), highSpeed, text);
                    count = 1;
                }else{
                    count++;
                }
                beforeCard = card;
            }
            separateRow(text);
            println(count + "枚", highSpeed, text);
            endRow(text);
        }else{
            println("デッキが空っぽです", highSpeed, text);
        }
        endTable(false, text);
        endFrame(false, text);
        // Print.println("デッキトップ:" + deckTop.jName(), highSpeed, text);
    }

    // 2者ステータス比較（ギルド、訓練）
    public static void displayDoubleCharacterStatus(TrainState trainState, Enemy enemy, boolean isTrainStatus, boolean isDynamic, boolean isFreeWidthFrame, boolean text, Scanner scanner){
        if(isFreeWidthFrame){
            startFreeWidthFrame(isDynamic, text);
        }else{
            startFrame(isDynamic, text);
        }
        Print.startTable(isDynamic, text);
        Print.startRow(isDynamic, text);
        if(isTrainStatus){
            Print.displayDetailStatus(trainState, false, isDynamic, text, scanner);
        }else{
            trainState.getSelf().trainToBattleStatus();
            boolean isBattleStatus = false;
            Print.displayCharacterStatus(trainState.getSelf(), isBattleStatus, isDynamic, text);
        }
        Print.print(space(47, text), highSpeed, text);
        Print.separateRow(isDynamic, text);

        if(isTrainStatus){
            for(int i = 0; i < 5; i++){
                println("", 0, text);
            }
        }

        for(int i = 0; i < 25; i++){
            println(space(2, text) + "|" + space(2, text), false, false, 0, text);
        }
        
        Print.separateRow(isDynamic, text);
        if(isTrainStatus){
            Print.skipStart(true, text);
            Print.println("", isDynamic, Print.highSpeed, text);
            Print.println("", isDynamic, Print.highSpeed, text);
            println("", isDynamic, 0, text);
            println("", isDynamic, 0, text);
            println("", isDynamic, 0, text);
            Print.skipEnd(true, text);
            
            
        }
        Print.displayEnemyStatus(enemy, isDynamic, text);
        Print.endRow(isDynamic, text);
        Print.endTable(isDynamic, text);
        endFrame(isDynamic, text);
    }

    // 訓練時の詳細情報
    public static void displayDetailStatus(TrainState trainState, boolean isSaveData, boolean isDynamic, boolean text, Scanner scanner){
        //TODO mp入れる
        Player self = trainState.getSelf();
        self.trainToBattleStatus();
        String endTurnText = "";
        if(trainState.getTurn() <= 16 && !isSaveData){
            endTurnText = " / " + ((((trainState.getTurn() - 1) / 8) + 1) * 8);
        }
        Print.print(trainState.getTurn() + endTurnText + " 日目", isDynamic, Print.highSpeed, text);
        if(trainState.getTurn() <= trainState.getTurnLimit() && !isSaveData){
            Print.println("  (次の勇者まで " + ((((trainState.getTurn() - 1) / 4) + 1) * 4 - trainState.getTurn() + 1) + " 日)", isDynamic, Print.highSpeed, text);
        }else{
            Print.println("", Print.highSpeed, text);
        }
        Print.println("", isDynamic, Print.highSpeed, text);
        if(!isSaveData){
            Print.print(TrainStatus.concentration.jName + ": " + self.getTrainStatus().get(TrainStatus.concentration) + " / " + self.getTrainStatus().get(TrainStatus.maxConcentration) + "    ", isDynamic, Print.highSpeed, text);
            Print.print(TrainStatus.motivation.jName + ": " + self.getTrainStatus().get(TrainStatus.motivation) + " / " + self.getTrainStatus().get(TrainStatus.maxMotivation) + "    ", isDynamic, Print.highSpeed, text);
            Print.println(TrainStatus.money.jName + ": " + self.getTrainStatus().get(TrainStatus.money) + " 円", isDynamic, Print.highSpeed, text);
            // Print.print("育成スキル: " + self.getSkill().jName, isDynamic, Print.highSpeed, text);
            Print.print("前回" + Train.TrainTurnAction.train.jName + ": " + (trainState.getBeforeTrainMenu() == null ? "なし" : trainState.getBeforeTrainMenu().jName), isDynamic, Print.highSpeed, text);
            Print.println(space(4, text) + "復活のお守り: " + (trainState.getResuscitated() ? "使用済み" : "未使用"), isDynamic, Print.highSpeed, text);
            Print.println("", isDynamic, Print.highSpeed, text);
            Print.println(self.getJName(), isDynamic, highSpeed, text);
        }
        
        
        
        // Print.println(" 総合力 : " + self.generalPower(true), isDynamic, Print.highSpeed, text);
        if(!isSaveData){
            Print.println(TrainStatus.hp.jName + ": " + self.getTrainStatus().get(TrainStatus.hp) + " / " + self.getTrainStatus().get(TrainStatus.maxHp), isDynamic, Print.highSpeed, text);
        }else{
            Print.println(TrainStatus.maxHp.jName + ": " + self.getTrainStatus().get(TrainStatus.maxHp), isDynamic, Print.highSpeed, text);
        }
        
        Print.println(TrainStatus.mp.jName + ": " + self.getTrainStatus().get(TrainStatus.mp) + " / " + self.getTrainStatus().get(TrainStatus.maxMp), isDynamic, Print.highSpeed, text);
        
        Print.println(TrainStatus.a.jName + ": " + self.getTrainStatus().get(TrainStatus.a), isDynamic, Print.highSpeed, text);
        
        // Print.print("    " + TrainStatus.e.jName + " : " + self.getTrainStatus().get(TrainStatus.e), Print.highSpeed, text);
        Print.println(TrainStatus.s.jName + ": " + self.getTrainStatus().get(TrainStatus.s), isDynamic, Print.highSpeed, text);
        
        Print.println(TrainStatus.d.jName + ": " + String.format("%.2f", self.getTrainStatus().get(TrainStatus.d) / 100.0), isDynamic, Print.highSpeed, text);
        // Print.print("" + TrainStatus.gasoline.jName + " : " + self.getTrainStatus().get(TrainStatus.gasoline) + " / " + self.getTrainStatus().get(TrainStatus.maxGasoline) + "    ", Print.highSpeed, text);
        Print.println("", isDynamic, Print.highSpeed, text);
        // displayUnlimition(trainState, text);
        //Print.print("連続鍛錬回数 : " + trainState.getChainTrainNum() + " 回    ", Print.highSpeed, text);
        // Print.print("連続同行動回数 : " + trainState.getChainSameTrainNum() + " 回    ", Print.highSpeed, text);
        
        println("必殺技: " + self.getAttribute().jName, isDynamic, highSpeed, text);
        
        Print.println("戦闘スキル: " + self.passiveItem.jName, isDynamic, Print.highSpeed, text);
        
        Print.print("所持オーブ: ", isDynamic, Print.highSpeed, text);
        // for(Spell spell: self.getLearnedSpellLevel().keySet()){
        //     if(spell != Spell.NULL){
        //         Print.print(" " + spell.getLevelName(self), isDynamic, Print.highSpeed, text);
        //     }
        // }
        int count = 0;
        for(Spell spell : self.getLearnedSpellLevel().keySet()){
            if(spell != Spell.NULL){
                count++;
                print(spell.jName, Print.highSpeed, text);
                if(count % 2 == 0){
                    println("", Print.highSpeed, text);
                    print(space(12, text), Print.highSpeed, text);
                }else{
                    print(space(1, text), Print.highSpeed, text);
                }
            }
        }
        println("", isDynamic, highSpeed, text);
        
        println("呪文スロット数: " + self.getSpellSlotNum(), isDynamic, highSpeed, text);
        
        // Print.println("<br>育成アイテム", Print.highSpeed, text);
        // int count = 0;
        // for(DisposableItem key: DisposableItem.values()){
        //     if(self.getDisposableItemList().get(key) != 0){
        //         if(count == 4){
        //             Print.println("", Print.highSpeed, text);
        //             count = 0;
        //         }
        //         count++;
        //         Print.println(" " + key.jName + " x " + self.getDisposableItemList().get(key), Print.highSpeed, text);
        //     }
        // }
        // Print.println("<br>戦闘薬", Print.highSpeed, text);
        // count = 0;
        // for(BattleItem key: BattleItem.values()){
        //     for(int i = 0; i < self.getItemList().get(key); i++){
        //         Print.print(key.jName + " ", Print.highSpeed, text);
        //     }
        //     /*if(self.getItemList().get(key) != 0){
        //         if(count == 4){
        //             Print.println("", Print.highSpeed, text);
        //             count = 0;
        //         }
        //         count++;
        //         Print.println(" " + key.jName + " x " + self.getItemList().get(key), Print.highSpeed, text);
        //     }*/
        // }
    }

    public static void displaySimpleStatus(TrainState trainState, boolean isFinish, boolean isDynamic, boolean text, Scanner scanner){
        //TODO mp入れる
        Player self = trainState.getSelf();
        self.trainToBattleStatus();
        Print.println(trainState.getTurn() + " 日目", isDynamic, Print.highSpeed, text);
        
        Print.println(TrainStatus.hp.jName + ": " + self.getTrainStatus().get(TrainStatus.maxHp), isDynamic, Print.highSpeed, text);
        
        Print.println(TrainStatus.a.jName + ": " + self.getTrainStatus().get(TrainStatus.a), isDynamic, Print.highSpeed, text);
        
        Print.println(TrainStatus.s.jName + ": " + self.getTrainStatus().get(TrainStatus.s), isDynamic, Print.highSpeed, text);
    }

    public static void displayTrainCostStatus(TrainState trainState, boolean text){
        Player self = trainState.getSelf();
        self.trainToBattleStatus();
        Print.println("", Print.highSpeed, text);
        Print.print(TrainStatus.hp.jName + " : " + self.getTrainStatus().get(TrainStatus.hp) + " / " + self.getTrainStatus().get(TrainStatus.maxHp) + "    ", Print.highSpeed, text);
        // Print.print(TrainStatus.gasoline.jName + " : " + self.getTrainStatus().get(TrainStatus.gasoline) + " / " + self.getTrainStatus().get(TrainStatus.maxGasoline) + "    ", Print.highSpeed, text);
        Print.print(TrainStatus.concentration.jName + " : " + self.getTrainStatus().get(TrainStatus.concentration) + " / " + self.getTrainStatus().get(TrainStatus.maxConcentration) + "    ", Print.highSpeed, text);
        Print.print(TrainStatus.motivation.jName + " : " + self.getTrainStatus().get(TrainStatus.motivation) + " / " + self.getTrainStatus().get(TrainStatus.maxMotivation) + "    ", Print.highSpeed, text);
        Print.println("", Print.highSpeed, text);
        Print.println("", Print.highSpeed, text);
    }

    public static void displayCharacterStatus(Character self, boolean isBattleStatus, boolean isDynamic, boolean text){
        println(self.getJName(), isDynamic, Print.highSpeed, text);
        
        // println(self.getJName() + "    総合力 : " + self.generalPower(true), isDynamic, Print.highSpeed, text);
        //前回行動を入れる
        println(MainStatus.hp.jName + ": " + self.getMainStatus().get(MainStatus.hp) + " / " + self.getMainStatus().get(MainStatus.maxHp), isDynamic, Print.highSpeed, text);
        
        println(MainStatus.mp.jName + ": " + self.getMainStatus().get(MainStatus.mp) + " / " + self.getMainStatus().get(MainStatus.maxMp), isDynamic, Print.highSpeed, text);
        
        for(BattleStatus state : BattleStatus.values()){
            int status;
            if(isBattleStatus){
                status = self.getBattleStatus().get(state);
            }else{
                status = self.getMainStatus().get(MainStatus.valueOf(state.name()));
            }
            if(state == BattleStatus.d){
                println(state.status.jName + ": " + (String.format("%.2f", status / 100.0)), isDynamic, highSpeed, text);
                
                continue;
            }
            println(state.status.jName + ": " + status, isDynamic, Print.highSpeed, text);
            
        }
        Print.println("", isDynamic, Print.highSpeed, text);
        println("必殺技:　" + self.getAttribute().jName, isDynamic, Print.highSpeed, text);
        
        println("戦闘スキル: " + self.passiveItem.jName, isDynamic, highSpeed, text);
        
        print("所持オーブ:", isDynamic, Print.highSpeed, text);
        // for(Spell spell : self.getLearnedSpellLevel().keySet()){
        //     if(spell != Spell.NULL){
        //         print(" " + spell.jName, isDynamic, Print.highSpeed, text);
        //     }
        // }
        int count = 0;
        for(Spell spell : self.getLearnedSpellLevel().keySet()){
            if(spell != Spell.NULL){
                count++;
                print(spell.jName, Print.highSpeed, text);
                if(count % 2 == 0){
                    println("", Print.highSpeed, text);
                    print(space(12, text), Print.highSpeed, text);
                }else{
                    print(space(1, text), Print.highSpeed, text);
                }
            }
        }
        Print.println("", isDynamic, Print.highSpeed, text);
        
        println("呪文スロット数: " + self.getSpellSlotNum(), isDynamic, highSpeed, text);
        
    }

    public static void displayEnemyStatus(Enemy self, boolean isDynamic, boolean text){
        displayCharacterStatus(self, true, isDynamic, text);
        // if(self.getFirstAction() != -1){
        //     Print.println("初回行動：" + actionNumToName(self.getFirstAction()), isDynamic, Print.highSpeed, text);
        // }
        String intelligence = "さァ";
        switch(self.auto){
            case select :
                intelligence = "選択";
                break;
            case random:
            case aiRandom:
            case biasedRandom:
                intelligence= "低い";
                break;
            case playout:
            case cycle:
                intelligence= "中";
                break;
            case mcs:
            case enemyMCTS:
            case mctsS:
            case mctsL:
                intelligence= "高い";
                break;
        }
        
        println("行動選択知能: " + intelligence, isDynamic, highSpeed, text);
        
        if(self.money != 0){
            println("報酬: " + self.money, isDynamic, highSpeed, text);
        }
    }
    public static void displayBattleItem(Character self, boolean text){
        Map<BattleItem, Integer> battleItem = self.getItemList();
        int num = 1;
        BattleItem[] item_keys = battleItem.keySet().toArray(new BattleItem[battleItem.size()]);
        BattleItem key;
        for(int i = 0; i < item_keys.length; i++){
            key = item_keys[i];
            for(int j = 0; j < battleItem.get(key); j++){
                Print.print(num + ":" + key.jName + "  ", Print.middleSpeed, text);
                num++;
            }
        }
        Print.println("", Print.highSpeed, text);
    }

    public static void displaySpellSlot(Character self, boolean isDynamic, boolean text){
        if(Spell.removeNULLFromList(self.getSpellSlot()).size() == 0){
            Print.println("スロットが空です", isDynamic, Print.highSpeed, text);
            Print.changeWaitTextToLT(text);
            return;
        }
        for(int i = 0; i < Spell.removeNULLFromList(self.getSpellSlot()).size(); i++){
            Print.print((i + 1) + ":" + Spell.removeNULLFromList(self.getSpellSlot()).get(i).getLevelName(self) + "(" + Spell.removeNULLFromList(self.getSpellSlot()).get(i).getCost(self) + ") ", isDynamic, Print.highSpeed, text);
        }
        Print.println("", isDynamic, Print.highSpeed, text);
    }

    public static void displaySaveDatas(GameState gameState){
        for(int idx = 1; idx <= GameState.saveDataNum; idx++){
            if(GameState.saveDataNums().contains(idx)){
                GameState state = GameState.load(idx, false);
                Print.print(idx + ":", Print.highSpeed, true);
                long playHour = state.getPlaySeconds() / (60 * 60);
                long playMinute = (state.getPlaySeconds() % (60 * 60)) / 60;
                long playSeconds = state.getPlaySeconds() % 60;
                String playTime = "プレイ時間: " + playHour + "時間 " + playMinute + "分 " + playSeconds + "秒";
                boolean isFinish = false;
                if(state.getSavedLocation(LocationCategory.train) == LocationCategory.FINISH){
                    Print.println(Print.space(2, gameState.text) + "育成完了" + space(8, gameState.text) + playTime, Print.highSpeed, gameState.text);
                    isFinish = true;
                }else{
                    Print.println(Print.space(2, gameState.text) + "育成中" + space(8, gameState.text) + playTime, Print.highSpeed, gameState.text);
                }
                Print.startFrame(false, true);
                Print.displaySimpleStatus(state.trainState, isFinish, false, true, gameState.scanner);
                Print.endFrame(false, true);
                Print.println("", Print.highSpeed, true);
            }else{
                Print.println(idx + ":", Print.highSpeed, true);
                Print.startFrame(false, true);
                Print.endFrame(false, true);
                Print.println("", Print.highSpeed, true);
            }
        }
    }

    // public static void displayDetailSaveDatas(GameState gameState){
    //     long playHour = gameState.getPlaySeconds() / (60 * 60);
    //     long playMinute = (gameState.getPlaySeconds() % (60 * 60)) / 60;
    //     long playSeconds = gameState.getPlaySeconds() % 60;
    //     String playTime = "プレイ時間: " + playHour + "時間 " + playMinute + "分 " + playSeconds + "秒";
    //     Print.println(playTime, Print.highSpeed, gameState.text);
    //     Print.startFrame(false, true);
    //     Print.displayDetailStatus(gameState.trainState, false, true, gameState.scanner);
    //     Print.endFrame(false, true);
    //     Print.println("", Print.highSpeed, true);
    // }
    
    public static String actionNumToName(int action){
        if(action == -1){
            return "なし";
        }
        if(action == 1){
            return Action.attack.jName;
        }
        if(action == 2){
            return Action.defense.jName;
        }
        if(action == 3){
            return Action.tension.jName;
        }
        if(4 <= action && action < 4 + Spell.NUM){
            return Spell.values()[action-4].jName;
        }
        if(action == 4 + Spell.NUM){
            return "チャージスペシャル";
        }
        if(4 + Spell.NUM < action && action <= 4 + Spell.NUM + Special.NUM){
            return Special.values()[action-(4 + Spell.NUM + 1)].jName;
        }
        if(4 + Spell.NUM + Special.NUM < action && action < 1 + InputAction.ACTION_NUM){
            return Spell.values()[action-(4 + Spell.NUM + 1 + Special.NUM)].jName + "追加";
        }
        if(1+ InputAction.ACTION_NUM <= action && action < 1 + InputAction.ACTION_NUM + BattleItem.NUM){
            return BattleItem.values()[(action - 1) / InputAction.ACTION_NUM].jName;
        }
        return "正しく入力されていません";
    }

    // 小数で整数と同じ値の場合に整数の様に表示する
    public static String removeZero(double num){
        if(num == (int)num){
            return String.valueOf((int)num);
        }
        return String.valueOf(num);
    }

    public static List<Tips> tipsList(){
        return new ArrayList<Tips>(){{
            add(new Tips("能力減少中のキャラクターに能力上昇効果を与えると、能力減少効果を解除します。また、能力上昇中のキャラクターには能力減少効果が効きません！", " 戦闘"));
            add(new Tips("テンションが上がると攻撃力と素早さが上がりますが、それぞれ上がり方が違います。素早さは指数関数的に上昇することに注意してください！", " 戦闘"));
            add(new Tips("状態異常にかかっているキャラクターにさらに同じ状態異常をかけると、上位の状態異常にかかります。効果は超強力です！", " 戦闘"));
            add(new Tips("闘技場で戦う相手には、最初の行動に特徴があるようです。", " 戦闘"));
            add(new Tips("戦闘中に相手が落としたオーブは、次に相手が行動するまでに相手を倒すことで、そのオーブを手に入れることができます。", " 戦闘"));
            add(new Tips("冒険者から手に入れたオーブを既に持っていた場合、元のオーブがさらに強化されます。", " 戦闘"));
            add(new Tips("HPが1/3を下回ると、崖っぷち訓練が発動し訓練効果が倍になります！", " 育成"));
            add(new Tips("Aの訓練カードを消費すると、ショップにオーブが売り出されます。", " 育成"));
            add(new Tips("やる気と集中力は現在の値が少ない時には訓練での消費も減ります。", " 育成"));
            add(new Tips("最大HPが非常に高いと、訓練が確定大成功になります。", " 育成"));
            add(new Tips("育成中に1回だけ、死んでしまっても復活することができます。戦闘時では戦闘開始時からやり直しですが、育成時では訓練結果を保持してHPを全回復します。つまり、、", ""));
        }};
    }

    public enum Color{
        white("d4d4d4", "31m"),// 基本色
        scarlet("D21D18", "31m"),// 警告色/瀕死ゲージ（1/5）
        darkScarlet("cd9178", "31m"),// 
        red("f14d4c", "31m"),// デメリット・敵名
        brown("CD9178", "31m"),// 冒険者・バサカカード

        yellowLighted("FFEB80", "31m"),// HP/super
        yellow("FFD704", "31m"),// HP/選択中・指示色
        yellowDarked("806C01", "31m"),// HP/normal

        darkOrange("E88D8B", "31m"),// 瀕死ゲージ（1/3）
        beige("e2b59b", "31m"),// 
        darkYellow("f4b246", "31m"),// 
        whiteOrange("DCDCAA", "31m"),// シナリオ色

        orange("FFA500", "31m"),// 

        purpleLighted("E2C3DF", "31m"),// super/a
        purple("C586BF", "31m"),// 集中
        purpleDarked("634360", "31m"),// normal/a
        grayPurple("C2b4c5", "31m"),// 瀕死ゲージと大成功の重なり

        greenLighted("B4CCAA", "32m"),// super/s
        green("699956", "32m"),// やる気
        greenDarked("354D2B", "32m"),// normal/s

        whiteGreen("B5CEA7", "32m"),// ラボ
        grayGreen("9aab9e", "32m"),// 瀕死ゲージと成功の重なり
        lightGreen("4dc8b0", "32m"),// 訓練成功時減少ゲージ色
        blue("16A0FF", "36m"),// メリット・自名
        miyamotoBlue("4CC8B0", "36m"),// アイテムカード
        darkBlue("254F78", "36m"),// 宿カード
        lightBlue("579BD7", "36m"),// 今は無し
        whiteBlue("9CDCFD", "36m"),// 訓練大成功時減少ゲージ色
        gray("999999", "90m"),// 選択不可
        black("1e1e1e", "90m"),// 背景色
        ;
        final String colorCodeRGB;
        final String colorCodeInline;
        private Color(String colorCodeRGB, String colorCodeInline){
            this.colorCodeRGB = colorCodeRGB;
            this.colorCodeInline = colorCodeInline;
        }
        public String toColor(String text){
            if(color){
                if (SwingTest.addTextS != null) {
                    return "<font color=\"#" + this.colorCodeRGB + "\">" + text + "</font>";
                }else{
                    return "\033[" + this.colorCodeInline + text + "\033[m";
                }
            }else{
                return text;
            }
        };
        public void startColor(boolean isDynamic, boolean text){
            print("<font color=\"#" + this.colorCodeRGB + "\">", isDynamic, 0, text);
        }
        public void endColor(boolean isDynamic, boolean text){
            print("</font>", isDynamic, 0, text);
        }
    }

    public static void printTitle(boolean text){
        print(title, 0, text);
        skipStart(true, text);
        for(int i = 0; i < 100; i++){
            Print.println("", true, Print.highSpeed, text);
        }
        skipEnd(true, text);
        changeWaitTextToLT(text);
    }

    public static void printTips(Random rand, boolean text){
        tipsList().get(rand.nextInt(tipsList().size())).printTips(text);
    }

    public static void printHorizontalLine(boolean isDynamic, boolean text){
        printHorizontalLine(false, isDynamic, text);
    }

    public static void printHorizontalLine(boolean isSlow, boolean isDynamic, boolean text){
        if(!isSlow && isDynamic)skipStart(isDynamic, text);
        println("_".repeat(isDynamic ? 55 : 100), isDynamic, highSpeed, text);
        if(!isSlow && isDynamic)skipEnd(isDynamic, text);
    }

    public static void printHorizontalLine(Color color, boolean isDynamic, boolean text){
        color.startColor(isDynamic, text);
        skipStart(isDynamic, text);
        println("_".repeat(isDynamic ? 55 : 100), isDynamic, highSpeed, text);
        skipEnd(isDynamic, text);
        color.endColor(isDynamic, text);
        println("", isDynamic, 0, text);
    }

    public static void printBigSeparater(boolean isDynamic, boolean text){
        println("", isDynamic, highSpeed, text);
        println("", isDynamic, highSpeed, text);
        printHorizontalLine(true, isDynamic, text);
        // println(sleep(10), isDynamic, 0, text);
        println("", isDynamic, highSpeed, text);
        println("", isDynamic, highSpeed, text);
    }

    // public static String addUnderSpace(String content){
    //     return "<span style=\"line-height:200%;\">" + content + "</span>";
    // }

    // public static void printHalfSpace(boolean isDynamic, boolean text){
    //     // print("<hr style=\"background-color: #123456;\">", isDynamic, highSpeed, text);
    //     print("<br><span style=\"line-height: 0.5;\">&nbsp;</span>", isDynamic, highSpeed, text);
    // }

    public static void clearStaticText(boolean text){
        println("", 0, text);
    }

    public static void changeFontSizeStart(int size, boolean text){
        changeFontSizeStart(size, false, text);
    }

    public static void changeFontSizeEnd(boolean text){
        changeFontSizeEnd(false, text);
    }

    public static void lineSpace(boolean isDynamic, boolean text){
        changeFontSizeStart(1, isDynamic, text);
        print("　<br>", isDynamic, 0, text);
        changeFontSizeEnd(isDynamic, text);
    }

    public static void startArial(boolean isDynamic, boolean text){
        print("<font style=\"font-family: Arial;\">", isDynamic, 0, text);
    }

    public static void endArial(boolean isDynamic, boolean text){
        print("</font>", isDynamic, 0, text);
    }

    public static void changeFontSizeStart(int size, boolean isDynamic, boolean text){
        print("<font size=\"" + size + "\">", isDynamic, 0, text);
    }

    public static void changeFontSizeEnd(boolean isDynamic, boolean text){
        print("</font>", isDynamic, 0, text);
    }

    public static void setFrameStart(boolean text){
        startFrame(false, text);
    }

    public static void setFrameEnd(boolean text){
        endFrame(false, text);
    }

    public static void startFrame(boolean isDynamic, boolean text){
        int width = isDynamic ? 300 : 550;
        print("<div style=\"padding: 5px; border: 1px solid #FFFFFF; display: inline-block; width:" + width + "px;\">", isDynamic, 0, text);
        // print("<div style=\"padding: 10px; margin-bottom: 10px; border: 1px dashed #FFFFFF; display: inline-block;\">", isDynamic, 0, text);
    }

    public static void startGameFrame(boolean isDynamic, boolean text){
        print(gameFrame, isDynamic, 0, text);
        // print("<div style=\"padding: 10px; margin-bottom: 10px; border: 1px dashed #FFFFFF; display: inline-block;\">", isDynamic, 0, text);
    }

    public static void startFreeWidthFrame(boolean isDynamic, boolean text){
        print("<div style=\"padding: 5px; border: 1px solid #FFFFFF; display: inline-block;\">", isDynamic, 0, text);
        // print("<div style=\"padding: 10px; margin-bottom: 10px; border: 1px dashed #FFFFFF; display: inline-block;\">", isDynamic, 0, text);
    }

    public static void startCardFlame(Color color, boolean isDynamic, boolean text){
        print("<div style=\"padding: 5px; border: 1px solid #" + color.colorCodeRGB + "; display: inline-block; width:250px; height:40px;\">", isDynamic, 0, text);
    }

    public static void startCardDoubleFlame(Color color, boolean isDynamic, boolean text){
        print("<div style=\"padding: 5px; border: 1px solid #" + color.colorCodeRGB + "; display: inline-block; width:250px; height:96px;\">", isDynamic, 0, text);
    }

    public static void endFrame(boolean isDynamic, boolean text){
        print("</div>", isDynamic, 0, text);
    }

    public static void startTable(String menu, boolean isDynamic, boolean text){
        print("<table" + menu + ">", isDynamic, 0, text);
    }

    public static void startTable(boolean text){
        startTable("", false, text);
    }

    public static void startTable(boolean isDynamic, boolean text){
        startTable("", isDynamic, text);
    }

    public static void endTable(boolean text){
        endTable(false, text);
    }

    public static void endTable(boolean isDynamic, boolean text){
        print("</table>", isDynamic, 0, text);
    }

    public static void startRow(boolean text){
        startRow(false, text);
    }

    public static void startRow(boolean isDynamic, boolean text){
        _startTableRow(isDynamic, text);
        _startTableData(isDynamic, text);
    }

    public static void startRowDoubleVertical(boolean isDynamic, boolean text){
        _startTableRow(isDynamic, text);
        _startTableDataDoubleVertical(isDynamic, text);
    }

    public static void startRowDoubleHorizontal(boolean isDynamic, boolean text){
        _startTableRow(isDynamic, text);
        _startTableDataDoubleHorizontal(isDynamic, text);
    }

    public static void startRowMergeVertical(int mergeNum, boolean isDynamic, boolean text){
        _startTableRow(isDynamic, text);
        _startTableDataMergeVertical(mergeNum, isDynamic, text);
    }

    public static void startRowMergeHorizontal(int mergeNum, boolean isDynamic, boolean text){
        _startTableRow(isDynamic, text);
        _startTableDataMergeHorizontal(mergeNum, isDynamic, text);
    }

    public static void separateRow(boolean text){
        separateRow(false, text);    
    }

    public static void separateRowDoubleVertical(boolean isDynamic, boolean text){
        _endTableData(isDynamic, text);
        _startTableDataDoubleVertical(isDynamic, text);
    }

    public static void separateRow(boolean isDynamic, boolean text){
        _endTableData(isDynamic, text);
        _startTableData(isDynamic, text);
    }

    public static void endRow(boolean text){
        endRow(false, text);
    }

    public static void endRow(boolean isDynamic, boolean text){
        _endTableData(isDynamic ,text);
        _endTableRow(isDynamic, text);
    }

    public static void _startTableRow(boolean isDynamic, boolean text){
        print("<tr>", isDynamic, 0, text);
    }

    public static void _endTableRow(boolean text){
        _endTableRow(false, text);
    }

    public static void _endTableRow(boolean isDynamic, boolean text){
        print("</tr>", isDynamic, 0, text);
    }

    public static void _startTableData(boolean isDynamic, boolean text){
        print("<td valign=\"top\">", isDynamic, 0, text);
    }

    public static void _startTableDataDoubleVertical(boolean isDynamic, boolean text){
        print("<td valign=\"top\" rowspan=\"2\">", isDynamic, 0, text);
    }

    public static void _startTableDataDoubleHorizontal(boolean isDynamic, boolean text){
        print("<td valign=\"top\" colspan=\"2\">", isDynamic, 0, text);
    }

    public static void _startTableDataMergeVertical(int mergeNum, boolean isDynamic, boolean text){
        print("<td valign=\"top\" rowspan=\"" + mergeNum + "\">", isDynamic, 0, text);
    }

    public static void _startTableDataMergeHorizontal(int mergeNum, boolean isDynamic, boolean text){
        print("<td valign=\"top\" colspan=\"" + mergeNum + "\">", isDynamic, 0, text);
    }

    public static void _endTableData(boolean text){
        _endTableData(false, text);
    }

    public static void _endTableData(boolean isDynamic, boolean text){
        print("</td>", isDynamic, 0, text);
    }

    public static String space(int num, boolean text){
        if(!text){
            return "";
        }
        if(SwingTest.addTextS != null){
            return "&nbsp;".repeat(num);
        }else{
            return " ".repeat(num);
        }
    }

    public static String sleep(int sleepNum){
        return sleepText.repeat(sleepNum);
    }

    public static String sleepEachCharacter(String baseText, int sleepNum){
        String newText = "";
        for(String character : baseText.split("")){
            newText += sleepText.repeat(sleepNum) + character;
        }
        return newText;
    }

    public static void skipStart(boolean isDynamic, boolean text){
        Print.print(Print.skipStartText, isDynamic, 0, text);
    }

    public static void skipEnd(boolean isDynamic, boolean text){
        Print.print(Print.skipEndText, isDynamic, 0, text);
    }

    public static void slowStart(boolean isDynamic, boolean text){
        Print.print(Print.slowStartText, isDynamic, 0, text);
    }

    public static void slowEnd(boolean isDynamic, boolean text){
        Print.print(Print.slowEndText, isDynamic, 0, text);
    }

    public static void verySlowStart(boolean isDynamic, boolean text){
        Print.print(Print.verySlowStartText, isDynamic, 0, text);
    }

    public static void verySlowEnd(boolean isDynamic, boolean text){
        Print.print(Print.verySlowEndText, isDynamic, 0, text);
    }

    public static void tempSlowLiftStart(boolean isDynamic, boolean text){
        Print.print(Print.tempSlowLiftStartText, isDynamic, 0, text);
    }

    public static void tempSlowLiftEnd(boolean isDynamic, boolean text){
        Print.print(Print.tempSlowLiftEndText, isDynamic, 0, text);
    }

    public static void deleteSlow(boolean text){
        Print.print(Print.slowDeleteText, false, 0, text);
    }

    public static void changeWaitTextToLT(boolean text){
        Print.print(Print.changeWaitTextToLT, true, 0, text);
    }
}
