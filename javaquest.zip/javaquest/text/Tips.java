package text;

public class Tips {
    private String tips;
    private String mode;
    public Tips(String tips, String mode){
        this.tips = tips;
        this.mode = mode;
    }

    public void printTips(boolean text){
        Print.startFrame(false, text);
        Print.println("攻略のヒント" + this.mode, Print.highSpeed, text);
        Print.println(this.tips, Print.highSpeed, text);
        Print.endFrame(false, text);
        Print.skipStart(true, text);
        for(int i = 0; i < 100; i++){
            Print.println("", true, Print.highSpeed, text);
        }
        Print.skipEnd(true, text);
        Print.changeWaitTextToLT(text);
    }
}
