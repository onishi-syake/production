package game;

import java.awt.Choice;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

import battle.CalculateDamage;
import battle.State;
import battle.InputAction.Auto;
import battle.state_change.ChangeBattleStatus;
import battle.state_change.ChangeAbnormalState.AbnormalState;
import battle.state_change.ChangeAbnormalState.AbnormalStateCounter;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import battle.state_change.ChangeBattleStatus.StateChangeStatus;
import battle.state_change.ChangeBattleStatus.StatusCounter;
import battle.state_change.ChangeField.Field;
import battle.state_change.ChangeField.FieldCounter;
import character.Enemy;
import character.Player;
import character.Skill;
import character.Character.Attribute;
import character.Character.MainStatus;
import data.action.Spell;
import data.card.CardWithParams;
import data.card.Guild;
import data.card.ItemCard;
import data.card.RestMenu;
import data.card.TrainEvent;
import data.card.TrainMenu;
import data.enemy.BaseMonster;
import data.enemy.Boss;
import data.enemy.Monster;
import data.item.BattleItem;
import data.stage.Stage;
import game.LocationCategory;
import limitation.TrainLimitation;
import limitation.TrainLimitation.TrainLimitationCounter;
import log.TrainTemporaryLog;
import text.Print;
import text.Print.Color;
import train.TrainState;
import train.TrainState.Mode;

public class Setup {
    public static void setup(GameState gameState, int action){
        
        if(gameState.getSavedLocation(LocationCategory.setup) == LocationCategory.NO_CHOICE){
            Print.clearStaticText(gameState.text);
            Print.println("※ 入出力はこちらの画面で行います", true, Print.highSpeed, gameState.text);
            Print.println("", true, Print.highSpeed, gameState.text);
            Print.println("1:はじめから 2:つづきから 3:対戦", true, Print.highSpeed, gameState.text);
            gameState.saveLocation(LocationCategory.setup, 0);
            return;
        }
        if(gameState.getSavedLocation(LocationCategory.setup) == 0){
            // Print.println("名前を入力してください", Print.highSpeed, gameState.text);
            // gameState.saveLocation(LocationCategory.setup, 1);
            int mode = action;
            if(mode < 1 || 3 < mode){
                gameState.saveLocation(LocationCategory.setup, LocationCategory.NO_CHOICE);
                Print.println("1~3で入力してください", true, Print.highSpeed, gameState.text);
                Print.changeWaitTextToLT(gameState.text);
                return;
            }else{
                gameState.saveLocation(LocationCategory.setup, mode);
                setup(gameState, action);
                return;
            }
            // if(mode == 4){
            //     Print.println("敵を選択してください", true, Print.highSpeed, gameState.text);
            //     int idx = 0;
            //     for(BaseMonster monster : BaseMonster.values()){
            //         Print.println(idx++ + " " + monster.jName, Print.highSpeed, gameState.text);
            //     }
            //     Print.println(idx++ + " " + Boss.ApprenticeBrave.jName, Print.highSpeed, gameState.text);
            // }
            // gameState.saveLocation(LocationCategory.setup, mode);
            // if(mode != 4){
            //     setup(gameState, action);
            // }
            // return;
        }
        if(gameState.getSavedLocation(LocationCategory.setup) == 1){
            
            String name = String.valueOf(action);
            name = "魔王";
            Print.println("名前を" + name + "に設定しました", true, Print.highSpeed, gameState.text);
            Mode mode = Mode.normal;
            Stage stage = Stage.last;
            Attribute attribute;
            Skill skill = Skill.NULL;
            int hp = 1000;
            int mp = 5;
            int atk = 100;
            int def = 100;
            int spd = 100;
            int motivation = 100;
            int maxMotivation = 100;
            int concentration = 200;
            int maxConcentration = 200;
            int gasoline = 100;
            int money = 0;

            //属性選択
            // if(TrainLimitation.attribute.useAble(mode)){
            //     double randouble = gameState.rand.nextDouble();
            //     if(randouble < 1.0 / 3){
            //         attribute = Attribute.A;
            //     }else if(randouble < 2.0 / 3){
            //         attribute = Attribute.D;
            //     }else{
            //         attribute = Attribute.C;
            //     }
            //     /*if(TrainLimitation.attributeS.useAble() && rand.nextDouble() < 0.1){
            //         attribute = Attribute.S;
            //     }*/
            //     System.out.println("<br>あなたの属性は乱数で" + attribute.jName + "に決定しました。");
            //     // System.out.println(attribute.jName + "でプレイしますか（いいえを選ぶと無属性になります）<br>1:はい  2:いいえ");
            //     // if(sc.nextInt() == 2){
            //     //     attribute = Attribute.Null;
            //     // }
            //     gameState.scanner.nextLine();
            // }else{
                attribute = Attribute.Null;
            // }
            gameState.trainState = new TrainState(new Player(name, attribute, skill, new int[] {hp, hp, mp, mp, atk, def, 10, spd, 2, concentration, maxConcentration, motivation, maxMotivation, gasoline, gasoline, money}, new EnumMap<Spell, Integer>(Spell.class), mode), stage, mode, Auto.select, Auto.select, gameState.rand);
            gameState.saveLocation(LocationCategory.gameStep, 2);
            gameState.saveLocation(LocationCategory.setup, LocationCategory.FINISH);
            gameState.resetTimer();
            return;
        }
        if(gameState.getSavedLocation(LocationCategory.setup) == 4){
            Player self = new Player("魔王", Attribute.A, Skill.NULL, new int[] {1000, 1000, 10, 10, 100, 100, 10, 100, 1}, new EnumMap<>(Spell.class){{
                for(Spell key: Spell.values()){
                    if(key == Spell.NULL){
                        continue;
                    }
                    put(key, 1);
                }
                // put(Spell.Fire, 1);
                // put(Spell.TensionField, 1);
                // // put(Spell.Flare, 1);
                // put(Spell.Stone, 1);
                // // put(Spell.LargeHeal, 1);
                // put(Spell.Poison, 2);
                // // put(Spell.Update, 1);
                // put(Spell.AUp, 1);
                // put(Spell.SUp, 1);
                // put(Spell.ReverseField, 1);
            }}, Mode.hard);
            self.passiveItem = BattleItem.Bannnouyaku;
            self.setSpellSlotNum(2);
            Enemy enemy;
            if(action < BaseMonster.values().length){
                enemy = new Enemy(BaseMonster.values()[action], 0, 0);
            }else{
                enemy = new Enemy(Boss.normalBrave, Attribute.A, BattleItem.values()[gameState.rand.nextInt(BattleItem.NUM - 1)], gameState.rand, false);
                // enemy = new Enemy(Boss.ApprenticeBrave, Attribute.Null, BattleItem.Zoukyouzai, gameState.rand, false);
            }
            // self.passiveItem = BattleItem.Bannnouyaku;
            // enemy.passiveItem = BattleItem.Bannnouyaku;
            // self.getStateChangeStatus().add(new HashMap<>(){{put(StateChangeStatus.A, new HashMap<>(){{put(StatusCounter.buffRate, 1.0); put(StatusCounter.turnCount, 1.0);}});}});
            // self.getStateChangeStatus().add(new HashMap<>(){{put(StateChangeStatus.D, new HashMap<>(){{put(StatusCounter.buffRate, 1.0); put(StatusCounter.turnCount, 1.0);}});}});
            // self.getStateChangeStatus().add(new HashMap<>(){{put(StateChangeStatus.S, new HashMap<>(){{put(StatusCounter.buffRate, 1.0); put(StatusCounter.turnCount, 1.0);}});}});
            // enemy.getStateChangeStatus().add(new HashMap<>(){{put(StateChangeStatus.A, new HashMap<>(){{put(StatusCounter.buffRate, 1.0); put(StatusCounter.turnCount, 1.0);}});}});
            // enemy.getStateChangeStatus().add(new HashMap<>(){{put(StateChangeStatus.D, new HashMap<>(){{put(StatusCounter.buffRate, 1.0); put(StatusCounter.turnCount, 1.0);}});}});
            // enemy.getStateChangeStatus().add(new HashMap<>(){{put(StateChangeStatus.S, new HashMap<>(){{put(StatusCounter.buffRate, 1.0); put(StatusCounter.turnCount, 1.0);}});}});
            gameState.battleState = new State(self, enemy, Auto.select, enemy.auto);
            // gameState.battleState = new State(self, enemy, Auto.select, Auto.random);
            // gameState.battleState.getField().replace(Field.RegenField, new HashMap<>(){{put(FieldCounter.count, 2); put(FieldCounter.flag, 1);}});
            // enemy.setAttribute(Attribute.A);
            // self.getStateAction().replace(ActionState.Tension, new HashMap<>(){{put(ActionStateCounter.count, 2); put(ActionStateCounter.flag, 2);}});
            // enemy.getStateAction().replace(ActionState.Tension, new HashMap<>(){{put(ActionStateCounter.count, 2); put(ActionStateCounter.flag, 2);}});
            // self.getStateAbnormal().replace(AbnormalState.Poison, new HashMap<>(){{put(AbnormalStateCounter.count, 2); put(AbnormalStateCounter.flag, 1);}});
            // enemy.getStateAbnormal().replace(AbnormalState.Poison, new HashMap<>(){{put(AbnormalStateCounter.count, 2); put(AbnormalStateCounter.flag, 1);}});
            // self.getStateAbnormal().replace(AbnormalState.Bond, new HashMap<>(){{put(AbnormalStateCounter.count, 2); put(AbnormalStateCounter.flag, 1);}});
            // enemy.getStateAbnormal().replace(AbnormalState.Bond, new HashMap<>(){{put(AbnormalStateCounter.count, 2); put(AbnormalStateCounter.flag, 1);}});
            gameState.saveLocation(LocationCategory.gameStep, 3);
            gameState.saveLocation(LocationCategory.setup, LocationCategory.FINISH);
            return;
        }
        if(gameState.getSavedLocation(LocationCategory.setup) == 3){
            final int IS_BATTLE_AI_EXPLAIN = 1;
            final int IS_BATTLE_AI_SELECT = 2;
            final int SHOW_DATA1 = 3;
            final int SHOW_DATA2 = 4;
            final int CHOICE_P1 = 5;
            final int CHOICE_P2 = 6;
            final int BATTLE_START = 7;

            final int DOUBLE_PLAYER = 1;
            final int BATTLE_AI = 2;
            GameState state;
            switch (gameState.getSavedLocation(LocationCategory.loadBattle)) {
                case LocationCategory.NO_CHOICE:
                    if(GameState.saveDataNums().size() != 0){
                        gameState.saveLocation(LocationCategory.loadBattle, IS_BATTLE_AI_EXPLAIN);
                        setup(gameState, action);
                        return;
                    }else{
                        Print.println("セーブデータがありませんでした", true, Print.highSpeed, gameState.text);
                        gameState.saveLocation(LocationCategory.setup, LocationCategory.NO_CHOICE);
                        Print.changeWaitTextToLT(gameState.text);
                        return;
                    }

                case IS_BATTLE_AI_EXPLAIN:
                    Print.skipStart(true, gameState.text);
                    Print.println(Color.yellow.toColor("対戦モードを選択してください"), true, Print.highSpeed, true);
                    Print.skipEnd(true, gameState.text);
                    Print.startFrame(false, gameState.text);
                    Print.println("対戦モード", Print.highSpeed, gameState.text);
                    Print.println(DOUBLE_PLAYER + ": 2人対戦" + Print.space(4, gameState.text) + BATTLE_AI + ": 対AI", Print.highSpeed, gameState.text);
                    Print.endFrame(false, gameState.text);
                    gameState.saveLocation(LocationCategory.loadBattle, IS_BATTLE_AI_SELECT);
                    return;
                    
                case IS_BATTLE_AI_SELECT:
                    if(action == DOUBLE_PLAYER){
                        gameState.saveLocation(LocationCategory.battleMode, DOUBLE_PLAYER);
                        gameState.saveLocation(LocationCategory.loadBattle, SHOW_DATA1);
                        setup(gameState, LocationCategory.NO_CHOICE);
                    }else if(action == BATTLE_AI){
                        gameState.saveLocation(LocationCategory.battleMode, BATTLE_AI);
                        gameState.saveLocation(LocationCategory.loadBattle, SHOW_DATA1);
                        setup(gameState, LocationCategory.NO_CHOICE);
                    }else if(action == 0){
                        gameState.saveLocation(LocationCategory.setup, LocationCategory.NO_CHOICE);
                        gameState.saveLocation(LocationCategory.loadBattle, LocationCategory.NO_CHOICE);
                        setup(gameState, LocationCategory.NO_CHOICE);
                        return;
                    }else{
                        Print.println("正しく入力してください", true, Print.highSpeed, gameState.text);
                        Print.clearStaticText(gameState.text);
                        Print.changeWaitTextToLT(gameState.text);
                        gameState.saveLocation(LocationCategory.loadBattle, IS_BATTLE_AI_EXPLAIN);
                    }
                    return;
            
                case SHOW_DATA1:
                    Print.skipStart(true, gameState.text);
                    if(gameState.getSavedLocation(LocationCategory.battleMode) == BATTLE_AI){
                        Print.println(Color.yellow.toColor("プレイヤーのセーブデータを選択してください"), true, Print.highSpeed, true);
                    }else{
                        Print.println(Color.yellow.toColor("1人目のプレイヤーのセーブデータを選択してください"), true, Print.highSpeed, true);
                    }
                    Print.skipEnd(true, gameState.text);
                    Print.displaySaveDatas(gameState);
                    gameState.saveLocation(LocationCategory.loadBattle, CHOICE_P1);
                    return;

                case CHOICE_P1:
                    if(GameState.saveDataNums().contains(action)){
                        gameState.saveLocation(LocationCategory.loadBattleP1, action);
                        gameState.saveLocation(LocationCategory.loadBattle, SHOW_DATA2);
                        setup(gameState, LocationCategory.NO_CHOICE);
                    }else{
                        gameState.saveLocation(LocationCategory.loadBattle, SHOW_DATA1);
                        setup(gameState, LocationCategory.NO_CHOICE);
                    }
                    return;
            
                case SHOW_DATA2:
                    if(gameState.getSavedLocation(LocationCategory.battleMode) == BATTLE_AI){
                        Print.skipStart(true, gameState.text);
                        Print.println(Color.yellow.toColor("対戦相手を選択してください"), true, Print.highSpeed, true);
                        Print.skipEnd(true, gameState.text);
                        Print.startFrame(false, gameState.text);
                        int count = 0;
                        for(Boss boss : Boss.values()){
                            Print.println(++count + ": " + boss.jName, Print.highSpeed, gameState.text);
                        }
                        Print.endFrame(false, gameState.text);
                    }else{
                        Print.skipStart(true, gameState.text);
                        Print.println(Color.yellow.toColor("2人目のプレイヤーのセーブデータを選択してください"), true, Print.highSpeed, true);
                        Print.skipEnd(true, gameState.text);
                        Print.displaySaveDatas(gameState);
                    }
                    gameState.saveLocation(LocationCategory.loadBattle, CHOICE_P2);
                    return;

                case CHOICE_P2:
                    if(gameState.getSavedLocation(LocationCategory.battleMode) == BATTLE_AI){
                        if(0 < action && action <= Boss.values().length){
                            gameState.saveLocation(LocationCategory.loadBattleP2, action - 1);// Boss.values[]に突っ込んで良いように-1する
                            gameState.saveLocation(LocationCategory.loadBattle, BATTLE_START);
                            setup(gameState, LocationCategory.NO_CHOICE);
                        }else{
                            gameState.saveLocation(LocationCategory.loadBattle, SHOW_DATA2);
                            setup(gameState, LocationCategory.NO_CHOICE);
                        }
                    }else{
                        if(GameState.saveDataNums().contains(action)){
                            gameState.saveLocation(LocationCategory.loadBattleP2, action);
                            gameState.saveLocation(LocationCategory.loadBattle, BATTLE_START);
                            setup(gameState, LocationCategory.NO_CHOICE);
                        }else{
                            gameState.saveLocation(LocationCategory.loadBattle, SHOW_DATA2);
                            setup(gameState, LocationCategory.NO_CHOICE);
                        }
                    }
                    return;

                case BATTLE_START:
                    Player p1 = GameState.load(gameState.getSavedLocation(LocationCategory.loadBattleP1), gameState.text).trainState.getSelf();
                    if(gameState.getSavedLocation(LocationCategory.battleMode) == BATTLE_AI){
                        Boss boss = Boss.values()[gameState.getSavedLocation(LocationCategory.loadBattleP2)];
                        Attribute attribute;
                        boolean isRandomStatus = true;
                        BattleItem battleItem = BattleItem.values()[gameState.rand.nextInt(BattleItem.NUM - 1)];
                        if(boss == Boss.ApprenticeBrave){
                            attribute = Attribute.Null;
                        }else if(boss == Boss.normalBrave){
                            attribute = Attribute.A;
                        }else{
                            attribute = Attribute.values()[gameState.rand.nextInt(3)];
                        }
                        if(boss == Boss.ApprenticeBrave
                        || boss == Boss.LegendaryBrave
                        || boss == Boss.FastidiousHero){
                            isRandomStatus = false;
                        }
                        if(boss == Boss.ApprenticeBrave){
                            battleItem = BattleItem.Zoukyouzai;
                        }
                        Enemy enemy = new Enemy(boss, attribute, battleItem, gameState.rand, isRandomStatus);
                        p1.trainToBattleStatus();
                        CalculateDamage.changeParameter(p1, MainStatus.hp, -p1.getMainStatus().get(MainStatus.maxHp), false);
                        CalculateDamage.changeParameter(p1, MainStatus.mp, -p1.getMainStatus().get(MainStatus.maxMp), false);
                        gameState.battleState = new State(p1, enemy, Auto.select, Auto.enemyMCTS);
                    }else{
                        Player p2 = GameState.load(gameState.getSavedLocation(LocationCategory.loadBattleP2), gameState.text).trainState.getSelf();
                        p1.setJName("プレイヤー1");
                        p2.setJName("プレイヤー2");
                        p2.nameColor = Color.red;
                        p1.trainToBattleStatus();
                        p2.trainToBattleStatus();
                        CalculateDamage.changeParameter(p1, MainStatus.hp, -p1.getMainStatus().get(MainStatus.maxHp), false);
                        CalculateDamage.changeParameter(p2, MainStatus.hp, -p2.getMainStatus().get(MainStatus.maxHp), false);
                        CalculateDamage.changeParameter(p1, MainStatus.mp, -p1.getMainStatus().get(MainStatus.maxMp), false);
                        CalculateDamage.changeParameter(p2, MainStatus.mp, -p2.getMainStatus().get(MainStatus.maxMp), false);
                        gameState.battleState = new State(p1, p2, Auto.select, Auto.select);
                    }
                    Print.deleteSlow(gameState.text);
                    Print.slowStart(false, gameState.text);// gameStep == 3の中でslowEndしている
                    ChangeBattleStatus.reset(gameState.battleState);
                    gameState.saveLocation(LocationCategory.gameStep, 3);
                    gameState.saveLocation(LocationCategory.setup, LocationCategory.FINISH);
                    return;

                default:
                    break;
            }
        }
        if(gameState.getSavedLocation(LocationCategory.setup) == 2){
            final int SHOW_DATA = 1;
            final int CHOICE_DATA = 2;
            final int FINAL_CHECK = 3;
            switch (gameState.getSavedLocation(LocationCategory.load)) {
                case LocationCategory.NO_CHOICE:
                    if(GameState.saveDataNums().size() != 0){
                        gameState.saveLocation(LocationCategory.load, SHOW_DATA);
                        setup(gameState, action);
                        return;
                    }else{
                        Print.println("セーブデータがありませんでした", true, Print.highSpeed, gameState.text);
                        gameState.saveLocation(LocationCategory.setup, LocationCategory.NO_CHOICE);
                        Print.changeWaitTextToLT(gameState.text);
                        return;
                    }
            
                case SHOW_DATA:
                    Print.skipStart(true, gameState.text);
                    Print.println(Color.yellow.toColor("ロードするセーブデータを選択してください"), true, Print.highSpeed, true);
                    Print.skipEnd(true, gameState.text);
                    Print.displaySaveDatas(gameState);
                    gameState.saveLocation(LocationCategory.load, CHOICE_DATA);
                    return;

                case CHOICE_DATA:
                    if(GameState.saveDataNums().contains(action)){
                        if(GameState.load(action, gameState.text).getSavedLocation(LocationCategory.train) == LocationCategory.FINISH){
                            Print.println("育成完了済みのデータです", true, Print.highSpeed, gameState.text);
                            Print.clearStaticText(gameState.text);
                            Print.changeWaitTextToLT(gameState.text);
                        }else{
                            gameState.saveLocation(LocationCategory.load, FINAL_CHECK);
                            gameState.saveLocation(LocationCategory.tempLoadDataNum, action);
                            Print.startFrame(false, gameState.text);
                            Print.displayDetailStatus(GameState.load(action, gameState.text).trainState, true, false, gameState.text, gameState.scanner);
                            Print.endFrame(false, gameState.text);
                            Print.println("", Print.highSpeed, gameState.text);
                            Print.println("このデータでよろしいですか", Print.highSpeed, gameState.text);
                            Print.println("Enter:決定 1:キャンセル", Print.highSpeed, gameState.text);
                            Print.changeWaitTextToLT(gameState.text);
                        }
                    }else{
                        if(action == 0){
                            gameState.saveLocation(LocationCategory.load, LocationCategory.NO_CHOICE);
                            gameState.saveLocation(LocationCategory.setup, LocationCategory.NO_CHOICE);
                            setup(gameState, LocationCategory.NO_CHOICE);
                            return;
                        }
                        gameState.saveLocation(LocationCategory.load, SHOW_DATA);
                        setup(gameState, LocationCategory.NO_CHOICE);
                    }
                    return;

                case FINAL_CHECK:
                    if(action == 0){
                        Print.println("ロードしました", true, Print.highSpeed, gameState.text);
                        gameState.load(GameState.load(gameState.getSavedLocation(LocationCategory.tempLoadDataNum), gameState.text));
                        gameState.resetLastActionTime();
                        gameState.saveLocation(LocationCategory.setup, LocationCategory.FINISH);
                    // }else if(action == 1){
                    //     gameState.saveLocation(LocationCategory.load, LocationCategory.NO_CHOICE);
                    //     gameState.saveLocation(LocationCategory.setup, LocationCategory.NO_CHOICE);
                    //     setup(gameState, LocationCategory.NO_CHOICE);
                    //     return;
                    }else{
                        gameState.saveLocation(LocationCategory.load, SHOW_DATA);
                        setup(gameState, action);
                        return;
                    }

                default:
                    break;
            }
        }
        if(gameState.getSavedLocation(LocationCategory.setup) == 5){
            
            String name = String.valueOf(action);
            name = "魔王";
            Print.println("名前を" + name + "に設定しました", true, Print.highSpeed, gameState.text);
            Mode mode = Mode.normal;
            Stage stage = Stage.last;
            Attribute attribute;
            Skill skill = Skill.NULL;
            int maxHp = 1000;
            int hp = 1000;
            int mp = 5;
            int atk = 3000;
            int def = 100;
            int spd = 1;
            int electricity = 100;
            int maxElectricity = 100;
            int oil = 100;
            int maxOil = 200;
            int gasoline = 100;
            int money = 10000;
            int turn = 8;

            //属性選択
            // if(TrainLimitation.attribute.useAble(mode)){
            //     double randouble = gameState.rand.nextDouble();
            //     if(randouble < 1.0 / 3){
            //         attribute = Attribute.A;
            //     }else if(randouble < 2.0 / 3){
            //         attribute = Attribute.D;
            //     }else{
            //         attribute = Attribute.C;
            //     }
            //     /*if(TrainLimitation.attributeS.useAble() && rand.nextDouble() < 0.1){
            //         attribute = Attribute.S;
            //     }*/
            //     System.out.println("<br>あなたの属性は乱数で" + attribute.jName + "に決定しました。");
            //     // System.out.println(attribute.jName + "でプレイしますか（いいえを選ぶと無属性になります）<br>1:はい  2:いいえ");
            //     // if(sc.nextInt() == 2){
            //     //     attribute = Attribute.Null;
            //     // }
            //     gameState.scanner.nextLine();
            // }else{
                attribute = Attribute.Null;
            // }
            Map<Spell, Integer> spell = new EnumMap<Spell, Integer>(Spell.class){{
                // for(Spell sp : Spell.values()){
                //     put(sp, 1);
                // }
                put(Spell.BigBang, 1);
            }};
            gameState.trainState = new TrainState(new Player(name, attribute, skill, new int[] {hp, maxHp, mp, mp, atk, def, 10, spd, 2, oil, maxOil, electricity, maxElectricity, gasoline, gasoline, money}, spell, mode), stage, mode, Auto.select, Auto.select, gameState.rand);
            gameState.trainState.setTurn(turn);
            gameState.trainState.getTrainLimitations().get(TrainLimitation.labHP).replace(TrainLimitationCounter.flag, 1);
            gameState.trainState.getSelf().setSpellSlotNum(2);
            gameState.trainState.noResuscitate();
            gameState.beforeTrainState = gameState.trainState.modifiableCopy();
            gameState.log = new ArrayList<>();
            gameState.buyLog = new TrainTemporaryLog();
            gameState.trainState.setHands(new ArrayList<>());
            // gameState.trainState.getHands().add(new CardWithParams(-1, TrainMenu.normalHp, new ArrayList<>(){{

            // }}, true));
            gameState.trainState.getHands().add(new CardWithParams(-1, TrainMenu.bigA, new ArrayList<>(){{

            }}, true));
            // gameState.trainState.getHands().add(new CardWithParams(-1, TrainMenu.superA, new ArrayList<>(){{

            // }}, true));
            // gameState.trainState.getHands().add(new CardWithParams(-1, TrainMenu.normalS, new ArrayList<>(){{

            // }}, true));
            // gameState.trainState.getHands().add(new CardWithParams(-1, TrainMenu.normalS, new ArrayList<>(){{

            // }}, true));
            // gameState.trainState.getHands().add(new CardWithParams(-1, TrainMenu.normalS, new ArrayList<>(){{

            // }}, true));
            // gameState.trainState.getHands().add(new CardWithParams(-1, TrainMenu.normalS, new ArrayList<>(){{

            // }}, true));
            gameState.trainState.getHands().add(new CardWithParams(-1, TrainMenu.mp, new ArrayList<>(){{
                add(TrainLimitation.RegenFieldSpell);
            }}, true));
            // gameState.trainState.getHands().add(new CardWithParams(-1, TrainMenu.superA, new ArrayList<>(){{

            // }}, true));
            gameState.trainState.getHands().add(new CardWithParams(-1, RestMenu.maintenance, new ArrayList<>(){{

            }}, true));
            // gameState.trainState.getHands().add(new CardWithParams(-1, TrainMenu.normalA, new ArrayList<>(){{

            // }}, true));
            // gameState.trainState.getHands().add(new CardWithParams(-1, ItemCard.HPMedicine, new ArrayList<>(){{

            // }}, true));
            // gameState.trainState.getHands().add(new CardWithParams(-1, ItemCard.ConMedicine, new ArrayList<>(){{

            // }}, true));
            // gameState.trainState.getHands().add(new CardWithParams(-1, ItemCard.MotivMedicine, new ArrayList<>(){{

            // }}, true));
            // gameState.trainState.getHands().add(new CardWithParams(-1, TrainMenu.normalA, new ArrayList<>(){{

            // }}, true));
            // gameState.trainState.getHands().add(new CardWithParams(-1, ItemCard.MotivMedicine, new ArrayList<>(){{

            // }}, true));
            gameState.trainState.getHands().add(new CardWithParams(-1, Guild.berserkerA, new ArrayList<>(){{

            }}, true));
            // gameState.trainState.getHands().add(new CardWithParams(-1, Guild.berserkerA, new ArrayList<>(){{

            // }}, true));
            gameState.trainState.getHands().add(new CardWithParams(-1, Guild.red, new ArrayList<>(){{

            }}, true));
            gameState.trainState.getHands().add(new CardWithParams(-1, Guild.brown, new ArrayList<>(){{

            }}, true));
            // gameState.trainState.getHands().add(new CardWithParams(-1, Guild.jewelryRed, new ArrayList<>(){{
                
            // }}, true));
            gameState.trainState.getHands().add(new CardWithParams(-1, TrainEvent.labHP, new ArrayList<>(){{
                
            }}, true));
            // gameState.trainState.getHands().add(new CardWithParams(-1, TrainEvent.labCon, new ArrayList<>(){{
                
            // }}, true));
            // gameState.trainState.getHands().add(new CardWithParams(-1, TrainEvent.labMoti, new ArrayList<>(){{
                
            // }}, true));
            // gameState.trainState.getHands().add(new CardWithParams(-1, ItemCard.ConMedicine, new ArrayList<>(){{
                
            // }}, true));
            gameState.trainState.getHands().add(new CardWithParams(-1, RestMenu.maintenance, new ArrayList<>(){{
                
            }}, true));
            gameState.trainState.getHands().add(new CardWithParams(-1, RestMenu.maintenance, new ArrayList<>(){{
                
            }}, true));
            // gameState.trainState.getHands().add(new CardWithParams(-1, TrainMenu.superA, new ArrayList<>(){{
                
            // }}, true));
            gameState.trainState.deck = new ArrayList<>();
            gameState.trainState.deck.add(TrainMenu.bigA);
            gameState.trainState.deck.add(TrainMenu.bigA);
            gameState.trainState.deck.add(TrainMenu.bigA);
            gameState.trainState.deck.add(TrainMenu.bigA);
            gameState.trainState.deck.add(TrainMenu.bigS);
            gameState.trainState.deck.add(TrainMenu.bigS);
            gameState.trainState.deck.add(TrainMenu.normalA);
            gameState.trainState.deck.add(TrainMenu.normalA);
            gameState.trainState.deck.add(TrainMenu.normalA);
            gameState.trainState.deck.add(TrainMenu.normalA);
            gameState.trainState.deck.add(TrainMenu.normalS);
            gameState.trainState.deck.add(TrainMenu.normalS);
            gameState.trainState.isUsedShopFirstFree = true;
            gameState.saveLocation(LocationCategory.gameStep, 2);
            gameState.saveLocation(LocationCategory.setup, LocationCategory.FINISH);
            gameState.resetTimer();
            return;
        }
        if(gameState.getSavedLocation(LocationCategory.setup) == 24){
            
            
            String name = String.valueOf(action);
            name = "魔王";
            Print.println("名前を" + name + "に設定しました", true, Print.highSpeed, gameState.text);
            Mode mode = Mode.normal;
            Stage stage = Stage.last;
            Attribute attribute;
            Skill skill = Skill.NULL;
            int hp = 10000;
            int mp = 5;
            int atk = 1000;
            int def = 100;
            int spd = 1000;
            int motivation = 100;
            int maxMotivation = 100;
            int concentration = 200;
            int maxConcentration = 200;
            int gasoline = 100;
            int money = 0;

            //属性選択
            // if(TrainLimitation.attribute.useAble(mode)){
            //     double randouble = gameState.rand.nextDouble();
            //     if(randouble < 1.0 / 3){
            //         attribute = Attribute.A;
            //     }else if(randouble < 2.0 / 3){
            //         attribute = Attribute.D;
            //     }else{
            //         attribute = Attribute.C;
            //     }
            //     /*if(TrainLimitation.attributeS.useAble() && rand.nextDouble() < 0.1){
            //         attribute = Attribute.S;
            //     }*/
            //     System.out.println("<br>あなたの属性は乱数で" + attribute.jName + "に決定しました。");
            //     // System.out.println(attribute.jName + "でプレイしますか（いいえを選ぶと無属性になります）<br>1:はい  2:いいえ");
            //     // if(sc.nextInt() == 2){
            //     //     attribute = Attribute.Null;
            //     // }
            //     gameState.scanner.nextLine();
            // }else{
                attribute = Attribute.Null;
            // }
            gameState.trainState = new TrainState(new Player(name, attribute, skill, new int[] {hp, hp, mp, mp, atk, def, 10, spd, 2, concentration, maxConcentration, motivation, maxMotivation, gasoline, gasoline, money}, new EnumMap<Spell, Integer>(Spell.class), mode), stage, mode, Auto.select, Auto.select, gameState.rand);
            gameState.saveLocation(LocationCategory.gameStep, 2);
            gameState.saveLocation(LocationCategory.setup, LocationCategory.FINISH);
            gameState.resetTimer();
            return;
        }
    }
}
