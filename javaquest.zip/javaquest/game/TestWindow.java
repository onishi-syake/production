package game;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import battle.InputAction;
import battle.State;
import battle.InputAction.Auto;
import text.Print;

public class TestWindow extends JFrame implements KeyListener, ActionListener{
    GameState gameState;
    int act;
    JLabel labelDynamic;
    JLabel labelStatic;
    JLabel labelBottom;
    StringBuilder sbD;
    StringBuilder sbS;
    String tempStaticText;
    boolean resetStatic;
    JScrollPane scrollPanelDynamic;
    JScrollPane scrollPanelStatic;
    Container contentPane;
    Timer timer;
    boolean enterSpeedUp = false;
    boolean printSlowD = false;
    boolean printSlowS = false;
    boolean printVerySlowS = false;
    boolean tempSlowLift = false;
    boolean deleteSlow = false;
    boolean noSleepText = false;
    final String waitInputText = "&gt;&gt;&gt;";
    final String waitEnterText = "↵";
    public static final String prefixedFixedTextDynamic = "<html><head>" + 
     "<style type=\"text/css\"> div {padding: 10px;} .gauge {text-align: justify;}</style>"+ 
     "</head><body><div style=\"width:330px;\">";
     public static final String prefixedFixedTextStatic = "<html><head>" + 
      "<style type=\"text/css\"> div {padding: 10px;} .gauge {text-align: justify;}</style>"+ 
      "</head><body><div>";
    public static final String postfixedFixedText = "</div></body></html>";
	public TestWindow(String title, int width, int height) {
		super(title);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(width,height);
		setLocationRelativeTo(null);
		// setLayout(null);
		// setResizable(false);

        this.contentPane = this.getContentPane();

        this.labelDynamic = new JLabel("Press Enter");
        this.labelDynamic.setFont(new Font("ＭＳ ゴシック", Font.BOLD, 12));
        this.labelDynamic.setOpaque(true);
        this.labelDynamic.setVerticalAlignment(JLabel.TOP);
        this.labelDynamic.setForeground(new Color(212, 212, 212));
        this.labelDynamic.setBackground(new Color(30, 30, 30));

        this.labelStatic = new JLabel();
        this.labelStatic.setFont(new Font("ＭＳ ゴシック", Font.BOLD, 12));
        this.labelStatic.setOpaque(true);
        this.labelStatic.setVerticalAlignment(JLabel.TOP);
        this.labelStatic.setForeground(new Color(212, 212, 212));
        this.labelStatic.setBackground(new Color(30, 30, 30));

        this.labelBottom = new JLabel("  >>>が出ている時に数字で入力。Enterで決定。無入力enterで戻る");

        this.scrollPanelStatic = new JScrollPane();
        this.scrollPanelStatic.setViewportView(this.labelStatic);
        this.scrollPanelStatic.getVerticalScrollBar().setUnitIncrement(20);

        this.scrollPanelDynamic = new JScrollPane();
        this.scrollPanelDynamic.setViewportView(this.labelDynamic);
        this.scrollPanelDynamic.setPreferredSize(new Dimension(450, 0));
        this.scrollPanelDynamic.getVerticalScrollBar().setUnitIncrement(20);

        this.contentPane.add(this.scrollPanelStatic, BorderLayout.CENTER);
        this.contentPane.add(this.scrollPanelDynamic, BorderLayout.EAST);
        this.contentPane.add(this.labelBottom, BorderLayout.SOUTH);

        // global label
        SwingTest.addTextS = new StringBuilder();
        SwingTest.addTextD = new StringBuilder();
        this.sbS = new StringBuilder(TestWindow.prefixedFixedTextStatic + Print.title + TestWindow.postfixedFixedText);
        this.sbD = new StringBuilder(TestWindow.prefixedFixedTextDynamic + this.waitEnterText + TestWindow.postfixedFixedText);
        this.tempStaticText = "";
        this.resetStatic = true;
        this.labelStatic.setText(this.sbS.toString());
        this.labelDynamic.setText(this.sbD.toString());

 
		//キー入力の有効化
		addKeyListener(this);
        this.gameState = new GameState();
        act = 0;

        this.timer = new Timer(10, this);
        this.timer.setRepeats(true);
        this.timer.start();
	}
 
	@Override
	public void keyTyped(KeyEvent e) {
		//使用しないので空にしておきます。
	}
 
	@Override
	public void keyPressed(KeyEvent e) {
        if(SwingTest.addTextD.length() != 0 || SwingTest.addTextS.length() != 0){
            this.enterSpeedUp = true;
            return;
        }
        int num;
		switch ( e.getKeyCode() ) {
            case KeyEvent.VK_0:
            case KeyEvent.VK_1:
            case KeyEvent.VK_2:
            case KeyEvent.VK_3:
            case KeyEvent.VK_4:
            case KeyEvent.VK_5:
            case KeyEvent.VK_6:
            case KeyEvent.VK_7:
            case KeyEvent.VK_8:
            case KeyEvent.VK_9:
                num = e.getKeyCode() - KeyEvent.VK_0;
                this.act *= 10;
                this.act += num;
                if(this.act > 10000){
                    this.act = 9999;
                }
                this.sbD.replace((this.sbD.lastIndexOf(this.nowWaitMode())), this.sbD.length() - TestWindow.postfixedFixedText.length(), this.nowWaitMode() + (this.act != 0 ? String.valueOf(this.act) : ""));
                this.labelDynamic.setText(this.sbD.toString());
                break;

            case KeyEvent.VK_NUMPAD0:
            case KeyEvent.VK_NUMPAD1:
            case KeyEvent.VK_NUMPAD2:
            case KeyEvent.VK_NUMPAD3:
            case KeyEvent.VK_NUMPAD4:
            case KeyEvent.VK_NUMPAD5:
            case KeyEvent.VK_NUMPAD6:
            case KeyEvent.VK_NUMPAD7:
            case KeyEvent.VK_NUMPAD8:
            case KeyEvent.VK_NUMPAD9:
                num = e.getKeyCode() - KeyEvent.VK_NUMPAD0;
                this.act *= 10;
                this.act += num;
                if(this.act > 10000){
                    this.act = 9999;
                }
                this.sbD.replace((this.sbD.lastIndexOf(this.nowWaitMode())), this.sbD.length() - TestWindow.postfixedFixedText.length(), this.nowWaitMode() + (this.act != 0 ? String.valueOf(this.act) : ""));
                this.labelDynamic.setText(this.sbD.toString());
                break;
        
            case KeyEvent.VK_ENTER:
                this.gameState.addPlayTime();
                String actText = this.act == 0 ? "" : String.valueOf(this.act);
                if(this.sbD.lastIndexOf(this.nowWaitMode() + actText) == this.sbD.lastIndexOf(this.nowWaitMode() + actText + "_")){
                    this.sbD.replace(this.sbD.lastIndexOf(this.nowWaitMode() + actText), this.sbD.lastIndexOf(this.nowWaitMode() + actText) + (this.nowWaitMode() + actText + "_").length(), this.nowWaitMode() + actText);
                }
                //エンターキー
                SwingTest.firstDynamicOutPut = true;
                if(this.act != 0){
                    Print.println("", true, 0, this.gameState.text);
                }
                gameState.next(this.act);
                this.act = 0;
                Print.skipStart(true, this.gameState.text);
                
                if(SwingTest.addTextD.indexOf(Print.changeWaitTextToLT) != -1){
                    SwingTest.addTextD.replace(SwingTest.addTextD.indexOf(Print.changeWaitTextToLT), SwingTest.addTextD.indexOf(Print.changeWaitTextToLT) + Print.changeWaitTextToLT.length(), "");
                    SwingTest.addText(this.waitEnterText + (this.act != 0 ? String.valueOf(this.act) : "") + "\n", true);
                }else{
                    SwingTest.addText(this.waitInputText + (this.act != 0 ? String.valueOf(this.act) : "") + "\n", true);
                }
                Print.skipEnd(true, this.gameState.text);
                break;

            case KeyEvent.VK_BACK_SPACE:
                this.act /= 10;
                this.sbD.replace((this.sbD.lastIndexOf(this.nowWaitMode())), this.sbD.length() - TestWindow.postfixedFixedText.length(), this.nowWaitMode() + (this.act != 0 ? String.valueOf(this.act) : ""));
                this.labelDynamic.setText(this.sbD.toString());
                break;
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		//使用しないので空にしておきます。
	}

    @Override
    public void actionPerformed(ActionEvent e){
        if (e.getSource() == this.timer){
            int printNum;
            String printText;
            if(this.deleteSlow){
                int removeStartIdx = this.sbS.lastIndexOf(postfixedFixedText) - 10;
                if(removeStartIdx < prefixedFixedTextStatic.length()){
                    removeStartIdx = prefixedFixedTextStatic.length();
                }
                this.sbS.replace(removeStartIdx, this.sbS.lastIndexOf(postfixedFixedText), "");
                if(this.sbS.length() == (prefixedFixedTextStatic + postfixedFixedText).length()){
                    this.deleteSlow = false;
                }else if(this.sbS.length() < (prefixedFixedTextStatic + postfixedFixedText).length()){
                    this.deleteSlow = false;
                    System.out.println("error 消えすぎ");
                }
            }else if(SwingTest.addTextD.length() != 0){
                if(this.sbS.length() != 0){
                    if(SwingTest.addTextS.indexOf(Print.slowDeleteText) != -1){
                        this.deleteSlow = true;
                        SwingTest.addTextS.replace(SwingTest.addTextS.indexOf(Print.slowDeleteText), SwingTest.addTextS.indexOf(Print.slowDeleteText) + Print.slowDeleteText.length(), "");
                        this.tempStaticText = this.sbS.toString();
                        return;
                    }else{
                        this.tempStaticText = this.sbS.toString();
                        this.sbS.setLength(0);
                    }
                }
                printNum = 1;
                if(SwingTest.addTextD.substring(0, 1).equals("<")){
                    printNum = 0;
                    while(true){
                        if((printNum + "<font size=\"1\">　<br></font>".length() < SwingTest.addTextD.length()) && SwingTest.addTextD.substring(printNum, printNum + "<font size=\"1\">　<br></font>".length()).equals("<font size=\"1\">　<br></font>")){
                            printNum += "<font size=\"1\">　<br></font>".length();
                        }else if(SwingTest.addTextD.substring(printNum, printNum + 1).equals("<")){
                            printNum = SwingTest.addTextD.indexOf(">", printNum) + 1;
                        }else{
                            break;
                        }
                    }
                    this.noSleepText = true;
                }
                if(SwingTest.addTextD.substring(0, 1).equals(Print.skipStartText)){
                    printNum = SwingTest.addTextD.indexOf(Print.skipEndText) + 1;
                }
                if("&nbsp;".length() <= SwingTest.addTextD.length() && SwingTest.addTextD.substring(0, "&nbsp;".length()).equals("&nbsp;")){
                    printNum = "&nbsp;".length();
                }
                if(SwingTest.addTextD.substring(0, 1).equals(Print.slowStartText)){
                    this.printSlowD = true;
                }
                if(SwingTest.addTextD.substring(0, 1).equals(Print.slowEndText)){
                    this.printSlowD = false;
                }
                if(SwingTest.addTextD.substring(0, 1).equals(Print.tempSlowLiftStartText)){
                    this.tempSlowLift = true;
                }
                if(SwingTest.addTextD.substring(0, 1).equals(Print.tempSlowLiftEndText)){
                    this.tempSlowLift = false;
                }
                printText = SwingTest.addTextD.substring(0, printNum);
                if(printText.indexOf(Print.skipStartText) == 0){
                    printText = printText.substring(1, printText.length() - 1);
                }
                if(SwingTest.addTextD.substring(0, 1).equals(Print.slowStartText)){
                    printText = "";
                }
                if(SwingTest.addTextD.substring(0, 1).equals(Print.slowEndText)){
                    printText = "";
                }
                if(SwingTest.addTextD.substring(0, 1).equals(Print.tempSlowLiftStartText)){
                    printText = "";
                }
                if(SwingTest.addTextD.substring(0, 1).equals(Print.tempSlowLiftEndText)){
                    printText = "";
                }
                if(printText.equals(Print.sleepText)){
                    if(!this.enterSpeedUp && !this.noSleepText){
                        try {
                            Thread.sleep((long)(Print.sleepTime * 1000));
                        } catch (Exception ex) {
                            // TODO: handle exception
                            System.out.println(ex);
                            System.out.println("止まらなかった");
                        }
                    }
                }else{
                    for(String specialChar : new ArrayList<String>(){{
                        add(Print.sleepText);
                        add(Print.skipStartText);
                        add(Print.skipEndText);
                        add(Print.slowStartText);
                        add(Print.slowEndText);
                        add(Print.verySlowStartText);
                        add(Print.verySlowEndText);
                        add(Print.tempSlowLiftStartText);
                        add(Print.tempSlowLiftEndText);
                        add(Print.slowDeleteText);
                        add(Print.changeWaitTextToLT);
                    }}){
                        printText = printText.replace(specialChar, "");
                    }
                    this.sbD.insert(this.sbD.length()-TestWindow.postfixedFixedText.length(), printText);
                    if(this.printSlowD && !this.tempSlowLift && !this.enterSpeedUp && !this.noSleepText){
                        try {
                            Thread.sleep((long)(Print.sleepTime * 1000));
                        } catch (Exception ex) {
                            System.out.println(ex);
                            System.out.println("止まらなかった");
                        }
                    }
                }
                this.noSleepText = false;
                SwingTest.addTextD.delete(0, printNum);
                if(SwingTest.addTextD.length() == 0){
                    this.enterSpeedUp = false;
                    if(SwingTest.addTextS.length() == 0){
                        this.sbS.append(this.tempStaticText);
                    }
                    this.tempStaticText = "";
                }
            }else if(SwingTest.addTextS.length() != 0){
                if(this.resetStatic){
                    this.resetStatic = false;
                    this.sbS.setLength(0);
                    this.sbS.append(TestWindow.prefixedFixedTextStatic + TestWindow.postfixedFixedText);
                }
                printNum = 1000;
                if(printNum > SwingTest.addTextS.length()){
                    printNum = SwingTest.addTextS.length();
                }

                if(SwingTest.addTextS.substring(0, printNum).contains(Print.slowStartText)){
                    if(SwingTest.addTextS.substring(0, printNum).indexOf(Print.slowStartText) == 0){
                        this.printSlowS = true;
                        SwingTest.addTextS.replace(0, Print.slowStartText.length(), "");
                    }else{
                        printNum = SwingTest.addTextS.indexOf(Print.slowStartText);
                    }
                }

                if(printNum > SwingTest.addTextS.length()){
                    printNum = SwingTest.addTextS.length();
                }

                if(SwingTest.addTextS.substring(0, printNum).contains(Print.verySlowStartText)){
                    if(SwingTest.addTextS.substring(0, printNum).indexOf(Print.verySlowStartText) == 0){
                        this.printVerySlowS = true;
                        SwingTest.addTextS.replace(0, Print.verySlowStartText.length(), "");
                    }else{
                        printNum = SwingTest.addTextS.indexOf(Print.verySlowStartText);
                    }
                }

                if(this.printSlowS){
                    printNum = 10;
                }

                if(this.printVerySlowS){
                    printNum = 1;
                }

                if(printNum > SwingTest.addTextS.length()){
                    printNum = SwingTest.addTextS.length();
                }

                if(SwingTest.addTextS.substring(0, printNum).contains(Print.slowEndText)){
                    if(SwingTest.addTextS.substring(0, printNum).indexOf(Print.slowEndText) == 0){
                        this.printSlowS = false;
                        SwingTest.addTextS.replace(0, Print.slowEndText.length(), "");
                    }else{
                        printNum = SwingTest.addTextS.indexOf(Print.slowEndText);
                    }
                }

                if(printNum > SwingTest.addTextS.length()){
                    printNum = SwingTest.addTextS.length();
                }

                if(SwingTest.addTextS.substring(0, printNum).contains(Print.verySlowEndText)){
                    if(SwingTest.addTextS.substring(0, printNum).indexOf(Print.verySlowEndText) == 0){
                        this.printVerySlowS = false;
                        SwingTest.addTextS.replace(0, Print.verySlowEndText.length(), "");
                    }else{
                        printNum = SwingTest.addTextS.indexOf(Print.verySlowEndText);
                    }
                }

                if(printNum > SwingTest.addTextS.length()){
                    printNum = SwingTest.addTextS.length();
                }
                
                if(SwingTest.addTextS.length() != 0 && SwingTest.addTextS.substring(0, 1).equals("<")){
                    printNum = SwingTest.addTextS.indexOf(">") + 1;
                }
                this.sbS.insert(this.sbS.length()-TestWindow.postfixedFixedText.length(), SwingTest.addTextS.substring(0, printNum));
                SwingTest.addTextS.delete(0, printNum);
                if(this.printVerySlowS){
                    try {
                        Thread.sleep((long)(Print.sleepTime * 1 * 1000));
                    } catch (Exception ex) {
                        System.out.println(ex);
                        System.out.println("止まらなかった");
                    }
                }
                if(SwingTest.addTextS.length() == 0){
                    this.resetStatic = true;
                }
            }else{
                // 敵の並列読み
                if(this.gameState.trainState != null && this.gameState.trainState.battleState != null){ 
                    State state = gameState.trainState.battleState;
                    if((state.getAuto(true) == Auto.select) && (state.getAuto(false) != Auto.select)
                        && (state.getSavedLocation(LocationCategory.selectBattleAction) == 1)
                        && (state.getSavedLocation(LocationCategory.inputBattleAction) == 3)
                        && (!state.temp_p2_action_selected)){

                        state.temp_p2_action = InputAction.select(state.modifiableCopy(), false, false, this.gameState.scanner, this.gameState.rand);
                        state.temp_p2_action_selected = true;
                    }
                }
                // _の点滅表示
                if(this.nowWaitMode() == this.waitInputText){
                    String actText = this.act == 0 ? "" : String.valueOf(this.act);
                    if(this.sbD.lastIndexOf(this.waitInputText + actText) == this.sbD.lastIndexOf(this.waitInputText + actText + "_")){
                        this.sbD.replace(this.sbD.lastIndexOf(this.waitInputText + actText), this.sbD.lastIndexOf(this.waitInputText + actText) + (this.waitInputText + actText + "_").length(), this.waitInputText + actText);
                    }else{
                        this.sbD.replace(this.sbD.lastIndexOf(this.waitInputText + actText), this.sbD.lastIndexOf(this.waitInputText + actText) + (this.waitInputText + actText).length(), this.waitInputText + actText + "_");
                    }
                }
                try {
                    Thread.sleep((long)(150));
                } catch (Exception ex) {
                    System.out.println(ex);
                    System.out.println("止まらなかった");
                }
            }
            this.labelDynamic.setText(this.sbD.toString());
            this.labelStatic.setText(this.sbS.toString());
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    if(SwingTest.addTextD.length() != 0){
                        scrollPanelDynamic.getVerticalScrollBar().setValue(scrollPanelDynamic.getVerticalScrollBar().getMaximum());
                    }else if(SwingTest.addTextS.length() != 0){
                        scrollPanelStatic.getVerticalScrollBar().setValue(scrollPanelStatic.getVerticalScrollBar().getMaximum());
                    }
                }
            });
            int removeStartTextNum = 10000;
            int remainingTextNum = 5000;
            if(this.sbD.length() > removeStartTextNum){
                String allTagText = "<";
                String endTagText = "</";
                String removeText = this.sbD.substring(TestWindow.prefixedFixedTextDynamic.length(), this.sbD.indexOf(allTagText, remainingTextNum));
                removeText = removeText.replace("<br>", "");
                removeText = removeText.replace("<hr>", "");
                int tagAllCount = (removeText.length() - removeText.replace(allTagText, "").length()) / allTagText.length();
                int tagEndCount = (removeText.length() - removeText.replace(endTagText, "").length()) / endTagText.length();
                int tagStartCount = tagAllCount - tagEndCount;
                int tagDifference = tagStartCount - tagEndCount;
                this.sbD.replace(TestWindow.prefixedFixedTextDynamic.length(), this.sbD.indexOf(allTagText, remainingTextNum), "");
                for(int i = 0; i < tagDifference; i++){
                    removeText = this.sbD.substring(TestWindow.prefixedFixedTextDynamic.length(), this.sbD.indexOf(endTagText, TestWindow.prefixedFixedTextDynamic.length()));
                    removeText = removeText.replace("<br>", "");
                    removeText = removeText.replace("<hr>", "");
                    tagDifference += (removeText.length() - removeText.replace(allTagText, "").length()) / allTagText.length();
                    this.sbD.replace(TestWindow.prefixedFixedTextDynamic.length(), this.sbD.indexOf(endTagText, TestWindow.prefixedFixedTextDynamic.length()) + endTagText.length(), "");
                    this.sbD.replace(TestWindow.prefixedFixedTextDynamic.length(), this.sbD.indexOf(">", TestWindow.prefixedFixedTextDynamic.length()) + ">".length(), "");
                }
            }
        }else{
            System.out.println("error ");
        }
    }

    public String nowWaitMode(){
        int waitInputIdx = this.sbD.lastIndexOf(this.waitInputText);
        int waitEnterIdx = this.sbD.lastIndexOf(this.waitEnterText);
        if(waitInputIdx >= waitEnterIdx){
            return waitInputText;
        }else{
            return waitEnterText;
        }
    }
}
