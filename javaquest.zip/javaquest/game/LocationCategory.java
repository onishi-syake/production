package game;

public enum LocationCategory {
    train,
    saveLog,
    item,
    choiceTrainings,
    scenario,
    doTrainings,
    trainOneTurnRefreshed,
    trainCardChoiced,
    shopStep,
    useItemStep,
    buyingItem,
    gameStep,
    tipsAndTitle,
    setup,
    changeSpell,
    save,
    delimiterSave,
    load,
    tempLoadDataNum,
    loadBattle,
    battleMode,
    loadBattleP1,
    loadBattleP2,
    setPassiveItem,
    explainCardCategory,
    explainCard,
    executeCard,
    dropTrainMenu,
    dropTrainMenuNum,
    canResetEnemyMenu,
    battleInTrain,
    turnUpDate,
    battle,
    selectBattleAction,
    inputBattleAction,
    moveSpell,
    useBattleItem,
    chargeSpecial,
    displayBattleField,
    chantSpell,
    replaceOrb,
    changeSpellFromBattle,
    isUsingItem,
    gameOver,
    gameClear,
    stageClear,
    returnGameMenu,
    ;
    // 何も選ばれていないことを示す値
    public static final int NO_CHOICE = -123489;
    // そこでの処理を終了したことを示す値
    public static final int FINISH = -987321;
    // そこでの処理を終了したことを示す値(戻り値を使わない)
    public static final int NO_RETURN_FINISH = -555555;
    // ゲームを終了することを示す値
    public static final int EXIT = -24224;
    // 真を示す値
    public static final int TRUE = -64614;

}
