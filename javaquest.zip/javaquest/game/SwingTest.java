package game;

public class SwingTest {
    // global label
    public static StringBuilder addTextS;
    public static StringBuilder addTextD;
    public static boolean firstDynamicOutPut = true;
    public static void main(String[] args) {
		TestWindow gw = new TestWindow("テストウィンドウ",800,800);
		gw.setVisible(true);
	}

    public static void addText(String text, boolean isDynamic){
        if(isDynamic){
            if(firstDynamicOutPut){
                text = "<br><br>" + text;
                firstDynamicOutPut = false;
            }
            SwingTest.addTextD.insert(SwingTest.addTextD.length(), text);
        }else{
            SwingTest.addTextS.insert(SwingTest.addTextS.length(), text);
        }
    }

    public static void addText(String text){
        addText(text, false);
    }
}
