package game;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import battle.Battle;
import battle.State;
import data.enemy.Boss;
import data.item.StartItemSet;
import log.TrainLog;
import log.TrainTemporaryLog;
import text.Print;
import text.Print.Color;
import train.Train;
import train.TrainState;
import character.Character;
import character.Character.MainStatus;

public class GameState implements Serializable {
    private static final long serialVersionUID = 1420672609912364060L;
    public TrainState trainState;
    public TrainState beforeTrainState;
    public List<TrainLog> log;
    public TrainTemporaryLog buyLog = new TrainTemporaryLog();
    public State battleState;
    public int nextAction;
    private Map<LocationCategory, Integer> savedAction;

    private long playTime;
    private long lastActionTime;

    public boolean text;
    public transient Scanner scanner;
    public transient Random rand;
    public static final int saveDataNum = 4;
    public static final String saveDir = "saveDatas";
    public static final String saveFile = "saveData_";

    public GameState(){
        this.trainState = null;
        this.beforeTrainState = null;
        this.log = new ArrayList<>();
        this.battleState = null;
        this.savedAction = new HashMap<>(){{
            for(LocationCategory act : LocationCategory.values()){
                if(act == LocationCategory.gameStep){
                    put(act, 1);
                    continue;
                }
                put(act, LocationCategory.NO_CHOICE);
            }
        }};
        this.playTime = 0;
        this.lastActionTime = System.currentTimeMillis();
        this.text = true;
        this.scanner = new Scanner(System.in);
        this.rand = new Random();
    }

    // gameStateをリセットする（ゲームオーバーからの再プレイ時などに利用）
    public void reset(){
        this.trainState = null;
        this.beforeTrainState = null;
        this.log = new ArrayList<>();
        this.battleState = null;
        this.savedAction = new HashMap<>(){{
            for(LocationCategory act : LocationCategory.values()){
                if(act == LocationCategory.gameStep){
                    put(act, 1);
                    continue;
                }
                put(act, LocationCategory.NO_CHOICE);
            }
        }};
        this.playTime = 0;
        this.lastActionTime = System.currentTimeMillis();
        this.text = true;
    }

    // プレイ時間を取得する
    public long getPlaySeconds(){
        return this.playTime / 1000;
    }

    // プレイ時間をリセットする
    public void resetTimer(){
        this.playTime = 0;
        this.resetLastActionTime();
    }

    // 前回行動時を現在の時間にする
    public void resetLastActionTime(){
        this.lastActionTime = System.currentTimeMillis();
    }

    // 前回行動時から今回行動時のプレイ時間を保存する
    public void addPlayTime(){
        long nowTime = System.currentTimeMillis();
        long diffTime = nowTime - this.lastActionTime;
        if(diffTime > 5 * 60 * 1000){
            diffTime = 5 * 60 * 1000;
        }
        this.playTime += diffTime;
        this.lastActionTime = nowTime;
    }

    public void next(int action){
        
        if(this.savedAction.get(LocationCategory.gameStep).intValue() == 0){
            final int TITLE = 1;
            switch(this.getSavedLocation(LocationCategory.tipsAndTitle)){
                case LocationCategory.NO_CHOICE:
                    Print.printTips(this.rand, this.text);
                    this.saveLocation(LocationCategory.tipsAndTitle, TITLE);
                    return;
                
                case TITLE:
                    Print.printTitle(this.text);
                    this.saveLocation(LocationCategory.tipsAndTitle, LocationCategory.NO_CHOICE);
                    this.saveLocation(LocationCategory.gameStep, 1);
                    return;

                default:
                    this.saveLocation(LocationCategory.gameStep, 1);
                    return;

            }
        }else if(this.savedAction.get(LocationCategory.gameStep).intValue() == 1){
            Setup.setup(this, action);
            if(getSavedLocation(LocationCategory.setup) == LocationCategory.FINISH){
                saveLocation(LocationCategory.setup, LocationCategory.NO_CHOICE);
                next(action);
            }
        }else if(this.savedAction.get(LocationCategory.gameStep).intValue() == 2){
            this.nextAction = action;
            Train.train(this, StartItemSet.None);
            if(this.getSavedLocation(LocationCategory.train) == LocationCategory.FINISH){
                if(this.trainState.getSavedLocation(LocationCategory.returnGameMenu) == LocationCategory.TRUE){
                    this.reset();
                    next(LocationCategory.NO_CHOICE);
                    return;
                }
                if(this.getSavedLocation(LocationCategory.gameClear) != LocationCategory.TRUE){
                    System.out.println("game finish");
                    Print.slowStart(true, text);
                    Print.println("GAME OVER", true, Print.highSpeed, text);
                    Print.slowEnd(true, text);
                    Print.changeWaitTextToLT(text);
                    Print.clearStaticText(text);
                    this.saveLocation(LocationCategory.gameStep, 4);
                    // System.exit(0);
                }
            }
        }else if(this.savedAction.get(LocationCategory.gameStep).intValue() == 3){
            this.battleState.getNextAction(action);
            this.battleState = Battle.battle(this.battleState, text, scanner, rand, -123);// 〇〇は倒れたを入れる
            Print.slowEnd(false, text);// 対戦用
            if(this.battleState.getSavedLocation(LocationCategory.battle) == LocationCategory.FINISH){
                for(Character chara : new Character[]{battleState.getPlayer1(), battleState.getPlayer2()}){
                    if(chara.getMainStatus().get(MainStatus.hp) <= 0){
                        Print.println(chara.getJName() + "は倒れた！" + Print.sleep(15), true, Print.highSpeed, text);
                        Print.changeWaitTextToLT(this.text);
                    }
                }
                this.saveLocation(LocationCategory.gameStep, 5);
            }
        }else if(this.getSavedLocation(LocationCategory.gameStep) == 4){
            final int EXPLAIN = 1;
            final int CHOICE_SAVEDATA_NUM = 2;
            final int NO_SAVE_CHECK = 3;
            switch(this.getSavedLocation(LocationCategory.save)){
                case LocationCategory.NO_CHOICE:
                    // Print.startFrame(false, text);
                    // Print.print("今回のデータをセーブしますか?", Print.highSpeed, text);
                    // Print.println("", Print.highSpeed, text);
                    // Print.println("Enter: はい    1: いいえ", Print.highSpeed, text);
                    // Print.changeWaitTextToLT(text);
                    // Print.endFrame(false, text);
                    this.saveLocation(LocationCategory.save, EXPLAIN);
                    next(LocationCategory.NO_CHOICE);
                    return;
                case EXPLAIN:
                    // if(action == 0){
                        Print.skipStart(true, text);
                        Print.println(Color.yellow.toColor("セーブする番号を指定してください"), Print.highSpeed, text);
                        Print.skipEnd(true, text);
                        // Print.println("(注意!!既に存在する番号を指定するとデータが上書きされてしまいます!)", Print.highSpeed, text);
                        Print.displaySaveDatas(this);
                        this.saveLocation(LocationCategory.save, CHOICE_SAVEDATA_NUM);
                        return;
                    // }else if(action == 1){
                    //     this.saveLocation(LocationCategory.save, LocationCategory.NO_CHOICE);
                    //     this.reset();
                    //     this.saveLocation(LocationCategory.gameStep, 0);
                    //     // if(this.getSavedLocation(LocationCategory.train) == LocationCategory.FINISH){
                    //     //     this.saveLocation(LocationCategory.gameStep, 5);
                    //     // }else{
                    //     //     this.saveLocation(LocationCategory.gameStep, 2);
                    //     // }
                    //     next(LocationCategory.NO_CHOICE);
                    //     return;
                    // }else{
                    //     this.saveLocation(LocationCategory.save, LocationCategory.NO_CHOICE);
                    //     next(action);
                    //     return;
                    // }
                case CHOICE_SAVEDATA_NUM:
                    if(0 < action && action <= GameState.saveDataNum){
                        this.saveLocation(LocationCategory.save, LocationCategory.NO_CHOICE);
                        // 保存したデータがどこから始まるかを指定
                        if(this.getSavedLocation(LocationCategory.train) == LocationCategory.FINISH){
                            this.saveLocation(LocationCategory.gameStep, 5);
                        }else{
                            this.saveLocation(LocationCategory.gameStep, 2);
                        }
                        // this.trainState.getSelf().setJName("魔王" + action);
                        this.save(action, text);
                        this.reset();
                        this.saveLocation(LocationCategory.gameStep, 0);
                        Print.changeWaitTextToLT(text);
                        return;
                    }else if(action == 0){
                        Print.startFrame(false, text);
                        // Print.println("", Print.highSpeed, text);
                        Print.println("セーブしますか？", Print.highSpeed, text);
                        Print.println(Color.red.toColor("セーブしないと続きからでそれ以降のターンをプレイしたり、セーブしたデータで対戦することが出来ません"), Print.highSpeed, text);
                        Print.println("", Print.highSpeed, text);
                        Print.println("Enter: はい    1: いいえ", Print.highSpeed, text);
                        Print.changeWaitTextToLT(text);
                        Print.endFrame(false, text);
                        this.saveLocation(LocationCategory.save, NO_SAVE_CHECK);
                        // next(LocationCategory.NO_CHOICE);
                        return;
                    }else{
                        Print.println("セーブする番号は1~" + GameState.saveDataNum + "で指定してください", true, Print.highSpeed, text);
                        Print.clearStaticText(text);
                        Print.changeWaitTextToLT(text);
                        this.saveLocation(LocationCategory.save, LocationCategory.NO_CHOICE);
                        return;
                    }

                case NO_SAVE_CHECK:
                    if(action == 1){
                        this.saveLocation(LocationCategory.save, LocationCategory.NO_CHOICE);
                        this.reset();
                        this.saveLocation(LocationCategory.gameStep, 0);
                        next(LocationCategory.NO_CHOICE);
                        return;
                    }else{
                        this.saveLocation(LocationCategory.save, EXPLAIN);
                        next(LocationCategory.NO_CHOICE);
                        return;
                    }
            }
            return;
        }else if(this.getSavedLocation(LocationCategory.gameStep) == 5){
            final int IS_REPLAY = 1;
            switch(this.getSavedLocation(LocationCategory.gameOver)){
                case LocationCategory.NO_CHOICE:
                    this.reset();
                    this.saveLocation(LocationCategory.gameStep, 0);
                    next(LocationCategory.NO_CHOICE);
                    return;
                    // Print.startFrame(false, text);
                    // Print.println("もう一度プレイしますか?", Print.highSpeed, text);
                    // Print.println("Enter: はい 1: いいえ", Print.highSpeed, text);
                    // Print.changeWaitTextToLT(text);
                    // Print.endFrame(false, text);
                    // this.saveLocation(LocationCategory.gameOver, IS_REPLAY);
                    // return;

                case IS_REPLAY:
                    if(action == 0){
                        this.reset();
                        next(LocationCategory.NO_CHOICE);
                        return;
                    }else if(action == 1){
                        System.exit(0);
                        return;
                    }else{
                        this.saveLocation(LocationCategory.gameOver, LocationCategory.NO_CHOICE);
                        next(action);
                        return;
                    }
            }
            return;
        }
        if((this.trainState != null && this.trainState.getSavedLocation(LocationCategory.delimiterSave) == LocationCategory.TRUE) || 
        this.getSavedLocation(LocationCategory.gameStep) == 6){
            final int SHOW_CLEAR_BEFORE = 1;
            final int SHOW_CLEAR = 2;
            final int SCENARIO = 3;
            switch(this.getSavedLocation(LocationCategory.stageClear)){
                case LocationCategory.NO_CHOICE:
                    this.saveLocation(LocationCategory.gameStep, 6);
                    this.saveLocation(LocationCategory.stageClear, SHOW_CLEAR_BEFORE);
                    this.trainState.saveLocation(LocationCategory.delimiterSave, LocationCategory.NO_CHOICE);
                    if(trainState.getTurn() == 17 || trainState.getTurn() == 25){
                        next(LocationCategory.NO_CHOICE);
                    }else{
                        Print.changeWaitTextToLT(text);
                    }
                    return;

                case SHOW_CLEAR_BEFORE:
                    Print.slowStart(true, text);
                    // if(this.trainState.getTurn() == 9){
                    //     Print.println("魔王は" + Boss.ApprenticeBrave.jName + "と" + Boss.normalBrave.jName + "を倒し、", true, Print.highSpeed, text);
                    // }else if(this.trainState.getTurn() == 17){
                    //     Print.println("魔王は" + Boss.StrongestBrave.jName + "と" + Boss.LegendaryBrave.jName + "を倒し、", true, Print.highSpeed, text);
                    // }else if(this.trainState.getTurn() == 25){
                    //     Print.println("魔王は" + Boss.DemiseBrave.jName + "と" + Boss.FastidiousHero.jName + "を倒し、", true, Print.highSpeed, text);
                    // }
                    Print.println("魔王は" + (this.trainState.getTurn()-1) + "日生き延びることに成功した", true, Print.highSpeed, text);
                    Print.slowEnd(true, text);
                    this.saveLocation(LocationCategory.stageClear, SHOW_CLEAR);
                    Print.changeWaitTextToLT(text);
                    return;


                case SHOW_CLEAR:
                    // game clear
                    Print.startGameFrame(false, text);

                    for(int i = 0; i < 14; i++){
                        Print.println("", Print.lowSpeed, text);
                    }
                    Print.print(Print.space(42, true), Print.lowSpeed, text);
                    Color.yellow.startColor(false, text);
                    Print.changeFontSizeStart(7, text);
                    Print.verySlowStart(false, text);
                    if(this.trainState.getTurn() == 9){
                        Print.println("STAGE CLEAR!!", Print.lowSpeed, text);
                    }else if(this.trainState.getTurn() == 17){
                        Print.println("GAME CLEAR!!", Print.lowSpeed, text);
                    }else if(this.trainState.getTurn() == 25){
                        Print.println("GAME COMPLETE!!", Print.lowSpeed, text);
                    }
                    Print.verySlowEnd(false, text);
                    Print.changeFontSizeEnd(text);
                    Color.yellow.endColor(false, text);
                    Print.endFrame(false, text);
                    for(int i = 0; i < 35; i++){
                        Print.println(Print.sleep(1), true, 0, text);
                    }
                    if(trainState.getTurn() == 17 || trainState.getTurn() == 25){
                        this.saveLocation(LocationCategory.stageClear, SCENARIO);
                        // this.saveLocation(LocationCategory.gameStep, 4);
                        Print.changeWaitTextToLT(text);
                        return;
                    }else{
                        this.saveLocation(LocationCategory.stageClear, LocationCategory.NO_CHOICE);
                        this.saveLocation(LocationCategory.gameStep, 4);
                        Print.changeWaitTextToLT(text);
                        return;
                    }

                case SCENARIO:
                    Print.clearStaticText(text);
                    if(trainState.getTurn() % 8 == 1){
                        boolean isDynamic = true;
                        switch(trainState.getTurn() / 8){
                            case 2:
                                Print.printBigSeparater(isDynamic, text);
                                Print.changeFontSizeStart(4, isDynamic, text);
                                Color.whiteOrange.startColor(isDynamic, text);
                                
                                Print.println("お疲れ様です" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                Print.println("これにて「余命 16 日 魔王」はゲームクリアとなります" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                Print.println("おめでとうございます！" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                Print.println("エンドロールです！" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                Print.println("企画·システム設計·グラフィックデザイン" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                Print.println("宮本　雄大" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                Print.println("プログラム作成" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                Print.println("大西　耕介" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                Print.println("宮本　雄大" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                Print.println("ここまでプレイしていただき、ありがとうございました" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                Print.println("しかし、まだ少しばかり続きがあるようです" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                Print.println("余力がある方は挑戦してみてください" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                Print.println("尋常ではない難易度なので、" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                Print.println("もし挑戦する場合には心しておいてください" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                
                                Color.whiteOrange.endColor(isDynamic, text);
                                Print.changeFontSizeEnd(isDynamic, text);
                                Print.printBigSeparater(isDynamic, text);
                                this.saveLocation(LocationCategory.stageClear, LocationCategory.NO_CHOICE);
                                this.saveLocation(LocationCategory.gameStep, 4);
                                Print.changeWaitTextToLT(text);
                                return;
                            
                            case 3:
                                Print.printBigSeparater(isDynamic, text);
                                Print.changeFontSizeStart(4, isDynamic, text);
                                Color.whiteOrange.startColor(isDynamic, text);
                                
                                Print.println("クリアおめでとうございます！" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                Print.println("この文章が出ているということは、作者でもほとんどクリアできない狂気じみた難易度の勇者を攻略したということでしょう。" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                Print.println("素晴らしいです！" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                Print.println("そして、ここまで興味を持ってゲームをプレイしていただけたというのは我々開発陣にとっても本当に嬉しい限りです。" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                Print.println("これで本当のラストとなります" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                Print.println("ここまで到達するのはかなりの時間を要したと思います。お疲れ様でした！" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                Print.println("最後までプレイしていただき、本当にありがとうございました！" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                Print.println("感想や意見などあれば連絡いただけると幸いです" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                Print.println("「面白かった」など言っていただければ泣いて喜びます！" + Print.sleep(15), isDynamic, Print.highSpeed, text);
                                Print.println("", isDynamic, Print.highSpeed, text);
                                
                                
                                Color.whiteOrange.endColor(isDynamic, text);
                                Print.changeFontSizeEnd(isDynamic, text);
                                Print.printBigSeparater(isDynamic, text);
                                this.saveLocation(LocationCategory.stageClear, LocationCategory.NO_CHOICE);
                                this.saveLocation(LocationCategory.gameStep, 4);
                                Print.changeWaitTextToLT(text);
                                return;

                            default:
                                Print.printHorizontalLine(isDynamic, text);
                                this.saveLocation(LocationCategory.stageClear, LocationCategory.NO_CHOICE);
                                this.saveLocation(LocationCategory.gameStep, 4);
                                Print.changeWaitTextToLT(text);
                                return;
                        }
                    }else{
                        this.saveLocation(LocationCategory.stageClear, LocationCategory.NO_CHOICE);
                        this.saveLocation(LocationCategory.gameStep, 4);
                        Print.changeWaitTextToLT(text);
                        return;
                    }
            }
            // this.next(action);
        }
    }
    public void saveLocation(LocationCategory category, Integer location){
        this.savedAction.replace(category, location);
    }
    public int getSavedLocation(LocationCategory category){
        return this.savedAction.get(category);
    }
    public void sendNextAction(){
        this.trainState.getNextAction(this.nextAction);
        this.nextAction = LocationCategory.NO_CHOICE;
    }

    public void save(int num, boolean text) {
        try{
            Files.createDirectories(Paths.get(GameState.saveDir));
        }catch(FileAlreadyExistsException e){
            System.out.println("同じ名前のファイルが存在します");
        }catch(IOException e){
            System.out.println("入出力エラーもしくは親ディレクトリなし");
        }
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(new File(GameState.saveDir + "//" + GameState.saveFile + num + ".txt"), false))) {
            Print.println("", Print.highSpeed, text);
            Print.println("セーブが完了しました", Print.highSpeed, text);
            oos.writeObject(this);
        } catch (IOException e) {
            Print.println("", Print.highSpeed, text);
            Print.println("正常に保存出来ませんでした", Print.highSpeed, text);
            e.printStackTrace();
        }
    }

    public static GameState load(int num, boolean text){
        GameState state = null;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(new File(GameState.saveDir + "//" + GameState.saveFile + num + ".txt")))) {
            state = (GameState) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("正常に読み込めませんでした");
            e.printStackTrace();
        }
        return state;
    }

    public void load(GameState gameState){
        this.trainState = gameState.trainState != null ? gameState.trainState.modifiableCopy() : null;
        this.beforeTrainState = gameState.beforeTrainState != null ? gameState.beforeTrainState.modifiableCopy() : null;
        this.log = new ArrayList<>(gameState.log);
        this.battleState = gameState.battleState != null ? gameState.battleState.modifiableCopy() : null;
        this.savedAction = new HashMap<>(gameState.savedAction);
        this.playTime = gameState.playTime;
        this.resetLastActionTime();
        this.text = gameState.text;
    }

    public static List<Integer> saveDataNums(){
        File f = new File(GameState.saveDir);
        File[] fs = f.listFiles();
        List<Integer> dataNums = new ArrayList<Integer>();
        if(fs != null){
            for(int i = 0; i < fs.length; i++){
                if(fs[i].getName().contains(GameState.saveFile)){
                    dataNums.add(Integer.parseInt(fs[i].getName().split(GameState.saveFile)[1].split(".txt")[0]));
                }
            }
        }
        return dataNums;
    }
}
