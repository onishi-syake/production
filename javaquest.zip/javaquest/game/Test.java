package game;

import java.util.Scanner;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import action.ActionSelectMulti;
import battle.State;
import battle.InputAction.Auto;
import text.Print;

public class Test {
    public static void main(String[] args) {
        GameState gameState = new GameState();
        int act;
        while(true){
            if(gameState.trainState != null && gameState.trainState.battleState != null){
                State state = gameState.trainState.battleState;
                if((state.getAuto(true) == Auto.select) && (state.getAuto(false) != Auto.select)
                    && (state.getSavedLocation(LocationCategory.selectBattleAction) == 1)
                    && (state.getSavedLocation(LocationCategory.inputBattleAction) == 2)
                    && (!state.temp_p2_action_selected)){
                        

                    ExecutorService execService = null;
                    try{
                        execService = Executors.newSingleThreadExecutor();
                        ActionSelectMulti c = new ActionSelectMulti();
                        c.setField(state, false, false, gameState.scanner, gameState.rand);
                        Future<String> result = execService.submit( c );
                        act = Print.input(gameState.scanner, true);
    
                        try{
                            state.temp_p2_action = Integer.parseInt(result.get());
                            state.temp_p2_action_selected = true;
                            gameState.next(act);
                        } catch (InterruptedException | ExecutionException e) {
                            e.printStackTrace();
                        }
                    }finally{
                        // ExecutorServiceは明示的に終了する必要がある
                        execService.shutdown();
                    }
                }else{
                    act = Print.input(gameState.scanner, true);
                    gameState.next(act);
                }
            }else{
                act = Print.input(gameState.scanner, true);
                gameState.next(act);
            }
        }
    }
}
