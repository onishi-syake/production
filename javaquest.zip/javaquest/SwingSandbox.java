import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;

public class SwingSandbox extends JFrame{
    SwingSandbox(){
        super("テスト");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(200, 200);

        Container cont = getContentPane();
        JLabel label = new JLabel("hello");
        cont.add(label);
        Timer timer = new Timer(200, null);
        timer.addActionListener(new ActionListener() {
            int x = 0;
            @Override
            public void actionPerformed(ActionEvent e){
                label.setText(String.valueOf(this.x));
                this.x++;
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e1) {
                    e1.printStackTrace();
                }
                label.setText(label.getText() + "hello");
            }
        });
        timer.start();
    }

    public static void main(String[] args) {
        SwingSandbox sand = new SwingSandbox();
        sand.setVisible(true);
    }
}
