package battle;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.Random;

import battle.InputAction.Auto;
import character.Character;
import character.Enemy;
import character.Player;
import character.Character.Attribute;
import character.Skill;
import data.action.Spell;
import data.enemy.BaseMonster;
import data.enemy.Monster;
import data.item.BattleItem;
import train.TrainState.Mode;

public final class Test {
    /*public static void main(String[] args){
        Random rand = new Random();
        Scanner scanner = new Scanner(System.in);
        Character self = new CharacterTester("魔王", 2, true, new int[] {1000, 1000, 200, 200, 100, 10, 100, 2}, new EnumMap<>(Spell.class){{
            for(Spell key: Spell.values()){
                put(key, 2);
            }
        }});
        self.getItemList().put(BattleItem.Tairyokuzai, 1);
        self.getItemList().put(BattleItem.Maryokuzai, 1);
        self.getItemList().put(BattleItem.Zoukyouzai,1);
        self.getItemList().put(BattleItem.Bannnouyaku,1);
        self.setItemList(self.getItemList());
        Character target = new CharacterTester("ゴブリン", 2, true, new int[] {1000, 1000, 200, 200, 100, 10, 100, 2}, new EnumMap<>(Spell.class){{
            for(Spell key: Spell.values()){
                put(key, 1);
            }
        }});
        target.getItemList().put(BattleItem.Tairyokuzai, 1);
        target.getItemList().put(BattleItem.Maryokuzai, 0);
        target.setItemList(target.getItemList());
        //int x = 0;
        for(int i = 0; i < 1; i++){
            //if(Battle.battle(self, target, "mcts", "mcs", false, scanner, rand)[0] == 1.0)x++;
            Battle.startBattle(self, target, Auto.select, Auto.select, true, scanner, rand);
        }
        //System.out.println(x);
        scanner.close();
    }*/
    public static void main(String[] args){
        Random rand = new Random();
        Scanner scanner = new Scanner(System.in);
        Player self = new Player("魔王", Attribute.A, Skill.NULL, new int[] {1000, 1000, 5, 5, 100, 100, 10, 100, 2}, new EnumMap<>(Spell.class){{
            // for(Spell key: Spell.values()){
            //     put(key, 2);
            // }
            put(Spell.Fire, 2);
            // put(Spell.Flare, 1);
            put(Spell.Stone, 1);
            // put(Spell.LargeHeal, 1);
            put(Spell.Poison, 2);
            // put(Spell.Update, 1);
            put(Spell.SUp, 1);
        }}, Mode.hard);
        // self.setSpellSlot(Arrays.asList(self.getSpellArray()));
        // self.getItemList().put(BattleItem.Tairyokuzai, 1);
        self.getItemList().put(BattleItem.Maryokuzai, 1);
        // self.getItemList().put(BattleItem.Zoukyouzai,1);
        self.getItemList().put(BattleItem.Bannnouyaku,1);
        self.passiveItem = BattleItem.Tairyokuzai;
        // self.getItemList().put(BattleItem.Elixir,1);
        BattleItem.randomDropItem(self, rand);
        Character target;
        int monster = 1;
        if(monster == 1){
            target = (character.Character)(new Player("ゴブリン", Attribute.A, Skill.NULL, new int[] {1000, 1000, 5, 5, 100, 100, 10, 10, 2}, new EnumMap<>(Spell.class){{
                for(Spell key: Spell.values()){
                    put(key, 1);
                }
            }}, Mode.hard));
            target.setSpellSlot(Arrays.asList(target.getSpellArray()));
            target.getItemList().put(BattleItem.Tairyokuzai, 1);
            target.getItemList().put(BattleItem.Maryokuzai, 0);
            target.getItemList().put(BattleItem.Bannnouyaku, 1);
            BattleItem.randomDropItem(target, rand);
            target.passiveItem = BattleItem.Tairyokuzai;
        }else{
            target = new Enemy(BaseMonster.red, 5, 0);
        }
        //int x = 0;
        for(int i = 0; i < 1; i++){
            //if(Battle.battle(self, target, "mcts", "mcs", false, scanner, rand)[0] == 1.0)x++;
            Battle.startBattle(self, target, Auto.select, Auto.select, true, scanner, rand);
        }
        //System.out.println(x);
        scanner.close();
    }
}
