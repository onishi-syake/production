package battle;

import java.util.EnumMap;
import java.util.Random;
import java.util.Scanner;

import battle.InputAction.Auto;
import character.Character;
import character.CharacterTester;
import character.Enemy;
import character.Character.Attribute;
import data.action.Spell;
import data.enemy.BaseMonster;
import data.item.BattleItem;
import text.Print.Color;

public final class EnemyTester {
    public static void main(String[] args) {
        Random rand = new Random();
        Scanner scanner = new Scanner(System.in);
        Character self = new CharacterTester("魔王", Color.blue, Attribute.A, 2, false, new int[] {2800, 2800, 480, 480, 480, 100, 10, 240, 2}, new EnumMap<>(Spell.class), BattleItem.Zoukyouzai);
        self.getItemList().put(BattleItem.Tairyokuzai, 1);
        self.getItemList().put(BattleItem.Maryokuzai, 1);
        self.getItemList().put(BattleItem.Zoukyouzai,1);
        self.getItemList().put(BattleItem.Bannnouyaku,1);
        BattleItem.randomDropItem(self, rand);
        Enemy target = new Enemy(BaseMonster.red, 1, 0);
        Battle.startBattle(self, target, Auto.select, target.auto, true, scanner, rand);
        scanner.close();
    }
}
