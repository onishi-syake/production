package battle;

import java.util.Map;

import battle.InputAction.Auto;
import battle.state_change.ChangeField.Field;
import battle.state_change.ChangeField.FieldCounter;
import battle.state_change.ChangeWeather.Weather;
import battle.state_change.ChangeWeather.WeatherCounter;
import character.CharacterForAI;
import log.unmodifiable.UnmodifiableState;

public final class StateForAI extends State{
    public StateForAI(CharacterForAI player1, CharacterForAI player2, Auto p1Auto, Auto p2Auto, Map<Field,Map<FieldCounter, Integer>> field, Map<Weather,Map<WeatherCounter, Integer>> weather, boolean spellUsed, int turn, boolean p1Escape, boolean P2Escape){
        super(player1, player2, p1Auto, p2Auto, field, weather, spellUsed, turn, p1Escape, P2Escape);
    }
    private StateForAI(StateForAI state){
        super(state);
    }
    StateForAI(State state){
        super(state);
        this.setPlayer(state.getPlayer1().forAI(), state.getPlayer2().forAI());
    }
    @Override
    public StateForAI modifiableCopy(){
        return new StateForAI(this);
    }
    @Override
    public UnmodifiableState unmodifiableCopy(){
        throw new UnsupportedOperationException();
    }
    @Override
    public StateForAI forAI(){
        return new StateForAI(this);
    }
}
