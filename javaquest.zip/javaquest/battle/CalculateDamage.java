package battle;

import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import battle.state_change.ChangeActionState;
import battle.state_change.ChangeBattleStatus;
import battle.state_change.ChangeWeather;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import battle.state_change.ChangeWeather.Weather;
import battle.InputAction.Action;
import character.Character;
import character.Player;
import character.Character.BattleStatus;
import character.Character.MainStatus;
import character.Player.TrainStatus;
import data.enemy.Boss;
import log.BattleTemporaryLog;
import text.Print;
import text.Print.Color;

public final class CalculateDamage {
    
    public enum CostCategory{
        direct,// 実数値コスト
        ratioFromMax,// 最大値からの割合コスト
        ratioFromCurrentValue,// 現在値からの割合コスト
    }

    public static final double BASE_VARIANCE_RATE = 1.0/3.0;//通常攻撃などに使われる基本的な分散の値。

    //MainStatusの増減処理を行う
    public static void changeParameter(Character self, MainStatus category, int damage, boolean text){
        Map<MainStatus, Integer> mainStatus = self.getMainStatus();
        // int maxHp = mainStatus.get(MainStatus.maxHp);
        // int hp = mainStatus.get(MainStatus.hp);
        // int maxMp = mainStatus.get(MainStatus.maxMp);
        // int mp = mainStatus.get(MainStatus.mp);
        // if(category == MainStatus.hp){
        //     if(maxHp <= hp - damage){
        //         damage = hp - maxHp;
        //     }
        //     if(damage < 0){
        //         Print.println(self.jName + "は" + MainStatus.hp.jName + "を" + Color.blue.toColor(String.valueOf(-damage)) + "回復した", Print.middleSpeed, text);
        //     }
        //     else{
        //         Print.println(self.jName + "は" + Print.toRed(String.valueOf(damage)) + "のダメージを受けた", Print.middleSpeed, text);
        //     }
        //     hp -= damage;
        //     mainStatus.replace(MainStatus.hp, hp);
        //     if(hp == maxHp && damage != 0){
        //         Print.println(MainStatus.hp.jName + "が満タンになった", Print.middleSpeed, text);
        //     }
        // }
        // if(category == MainStatus.mp){
        //     if(mp < damage){
        //         damage = mp;
        //     }
        //     if(maxMp <= mp - damage){
        //         damage = mp - maxMp;
        //     } 
        //     mp -= damage;
        //     mainStatus.replace(MainStatus.mp, mp);
        //     if(damage < 0){
        //         Print.println(self.jName + "は" + MainStatus.mp.jName + "を" + Color.blue.toColor(String.valueOf(-damage)) + "回復した", Print.middleSpeed, text);
        //     }
        //     else{
        //         Print.println(self.jName + "は" + MainStatus.mp.jName + "を" + Print.toRed(String.valueOf(damage)) + "削られた", Print.middleSpeed, text);
        //     }
        //     if(mp == maxMp && damage != 0){
        //         Print.println(MainStatus.mp.jName + "が満タンになった", Print.middleSpeed, text);
        //     }
        // }
        int nowValue = mainStatus.get(category);
        int maxValue;
        if(category == MainStatus.hp){
            maxValue = mainStatus.get(MainStatus.maxHp);
        }else if(category == MainStatus.mp){
            maxValue = mainStatus.get(MainStatus.maxMp);
        }else{
            maxValue = Integer.MAX_VALUE;
        }
        if(maxValue <= nowValue - damage){
            damage = nowValue - maxValue;
        }
        if(damage < 0){
            Print.println(self.getJName() + "は" + category.jName + "を " + Color.blue.toColor(String.valueOf(-damage)) + " 回復した！" + Print.sleep(2), true, Print.middleSpeed, text);
            
        }else if(damage == 0){
            // Print.println(self.getJName() + "の" + category.jName + "は変わらなかった" + Print.sleep(2), true, Print.middleSpeed, text);
        }else{
            Print.println(self.getJName() + "は" + category.jName + "に " + Color.red.toColor(String.valueOf(damage)) + " のダメージを受けた！" + Print.sleep(2), true, Print.middleSpeed, text);
            
        }
        if(category == MainStatus.hp && damage > 0){
            self.damaged();
        }
        nowValue -= damage;
        mainStatus.replace(category, nowValue);
        // if(nowValue == maxValue && damage != 0){
        //     Print.println(category.jName + "が満タンになった！" + Print.sleep(2), true, Print.middleSpeed, text);
        //     
        // }
        self.setMainStatus(mainStatus);
    }
    //TrainStatusのダメージ・コスト処理を行う
    public static void trainDamage(Player self, TrainStatus category, int damage, boolean text){
        if(category.child == null){
            trainDamage(self, new CalculateDamage().new CostParameter(category, damage, CostCategory.direct), text);
        }else{
            trainDamage(self, new CalculateDamage().new CostParameter(category, damage, CostCategory.ratioFromMax), text);
        }
    }
    public static void trainDamage(Player self, CostParameter costParameter, boolean text){
        costParameter = changeToDirect(self, costParameter);
        TrainStatus category = costParameter.statusCategory;
        int damage = (int)costParameter.value;
        Map<TrainStatus, Integer> trainStatus = self.getTrainStatus();
        int status = trainStatus.get(category);
        boolean heal = damage < 0;
        TrainStatus parent = null;
        for(int i = 0; i < TrainStatus.values().length; i++){
            if(TrainStatus.values()[i].child == category){
                parent = TrainStatus.values()[i];
            }
        }
        
        if(trainStatus.get(parent) != null && trainStatus.get(parent) <= status - damage){
            damage = status - trainStatus.get(parent);
        }
        if(damage > status){
            damage = status;
        }
        if(self.getElixirTurn() != 0 && damage > 0 && category != TrainStatus.money){
            damage = 0;
        }
        if(self.getNoCostStatus().contains(category) && damage > 0){
            damage = 0;
        }
        //TODO 全回復・全消費入れる
        if (damage == 0) {
            // Print.println(self.getJName() + "の" + category.jName + "は変わらなかった", true, Print.middleSpeed, text);
        }else if(heal){
            if(trainStatus.get(parent) != null && trainStatus.get(parent) == status - damage){
                Print.println(self.getJName() + "は" + category.jName + "を全回復した！", true, Print.middleSpeed, text);
            }else{
                Print.println(self.getJName() + "は" + category.jName + "を " + Color.blue.toColor(String.valueOf(-damage)) + " 回復した！", true, Print.middleSpeed, text);
            }
        }else{
            if(status == damage){
                Print.println(self.getJName() + "は" + category.jName + "を全て失った！", true, Print.middleSpeed, text);
            }else{
                Print.println(self.getJName() + "は" + category.jName + "を " + Color.red.toColor(String.valueOf(damage)) + " 失った！", true, Print.middleSpeed, text);
            }
        }
        status -= damage;
        trainStatus.replace(category, status);
        self.setTrainStatus(trainStatus);
    }
    // 割合消費を実数値消費に直す
    public static CostParameter changeToDirect(Player self, CostParameter baseParameter){
        CostParameter copyParameter = new CalculateDamage().new CostParameter(baseParameter);
        if(copyParameter.costCategory == CostCategory.ratioFromMax){
            copyParameter.value = self.getTrainStatus().get(copyParameter.statusCategory) * copyParameter.value / 100;
            copyParameter.statusCategory = copyParameter.statusCategory.child;
        }
        if(copyParameter.costCategory == CostCategory.ratioFromCurrentValue){
            copyParameter.value = self.getTrainStatus().get(copyParameter.statusCategory) * copyParameter.value / 100;
        }
        copyParameter.costCategory = CostCategory.direct;
        return copyParameter;
    }
    // 消費ステータス1つに対する消費量を計算
    public static int getDirectCost(Player self, List<CostParameter> parameters, TrainStatus trainStatus){
        int cost = 0;
        List<CostParameter> directParameters = new ArrayList<>(){{
            for(CostParameter oldParameter : parameters){
                add(changeToDirect(self, oldParameter));
            }
        }};
        for(CostParameter directParameter : directParameters){
            if(directParameter.statusCategory == trainStatus){
                cost += directParameter.value;
            }
        }
        return cost;
    }
    //TrainStatusの成長処理を行う
    public static void trainProgress(Player self, TrainStatus category, boolean percent, int progress, boolean text){
        Map<TrainStatus, Integer> trainStatus = self.getTrainStatus();
        int status = trainStatus.get(category);
        
        if(percent){
            progress = status * progress / 100;
        }
        if(progress + status > category.maxNum){
            progress = category.maxNum - status;
        }

        if(progress > 0){
            Print.println(self.getJName() + "の" + category.jName + "が " + Color.blue.toColor(String.valueOf(progress)) + " 成長した！", true, Print.middleSpeed, text);
        }else if(progress == 0){
            Print.println(self.getJName() + "の" + category.jName + "は成長しなかった！", true, Print.middleSpeed, text);
        }else{
            Print.println(self.getJName() + "の" + category.jName + "が " + Color.red.toColor(String.valueOf(-progress)) + " 減った！", true, Print.middleSpeed, text);
        }
        status += progress;
        trainStatus.replace(category, status);
        self.setTrainStatus(trainStatus);
    }


    
    //攻撃などの乱数の処理。randomRateに下限倍率を入力する。
    public static int randomProcess(int damage, double varianceRate, Random rand){
        return (int)((double)damage * ((1.0 - varianceRate) + rand.nextDouble() * (varianceRate * 2.0)));
    }

    //回避処理。
    public static int avoidanceProcess(int aNum, int hitRate, boolean text, Random rand){
        int sucANum = 0;
        for(int i = 0; i < aNum; i++){
            if(rand.nextDouble() * 100 < hitRate){
                sucANum++;
            }
        }
        // TODO 回避なし（仮裁定）
        return 1;//return sucANum;
    }

    //通常攻撃や呪文などでダメージを与える全般の処理。テンションや乱数の処理が行われる。
    public static int attackProcess(int damage, int aNum, int hitRate, double randomRate, boolean resetTension, boolean useTension, boolean useAttackStatus,
     boolean canDefense, boolean doApplyDefenceStatus, boolean makeChargeMiss, State state, boolean actor_is_player1, boolean target_is_player1, boolean attack, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
        Character actor = state.getPlayer(actor_is_player1);
        Character target = state.getPlayer(target_is_player1);
        Map<ActionState, Map<ActionStateCounter, Integer>> actorStateAction = actor.getStateAction();

        //TODO 攻撃回数全員1回（仮裁定）
        aNum = 1;

        int sucANum;
        //useTension == false用変数
        int nowTension = -1;
        if(target.getStateAction().get(ActionState.Defense).get(ActionStateCounter.flag) == 1 ||
        target.getStateAction().get(ActionState.SpecialDefense).get(ActionStateCounter.flag) == 1){
            sucANum = aNum;
        }else{
            sucANum = avoidanceProcess(aNum, hitRate, text, rand);
        }
        //useTension == falseの時にまずTensionを0にする
        if(!useTension){
            nowTension = actorStateAction.get(ActionState.Tension).get(ActionStateCounter.count);
            actorStateAction.get(ActionState.Tension).replace(ActionStateCounter.count, 0);
            ChangeBattleStatus.reset(state);
        }
        if(resetTension){
            int actorTension = actorStateAction.get(ActionState.Tension).get(ActionStateCounter.count);
            if(actorTension > 0){
                /* Print.print("力の", Print.middleSpeed, text);
                for(int i = 1; i < actorTension; i++){
                    Print.print("とっても", Print.lowSpeed, text);
                }
                Print.println("こもった一撃", Print.middleSpeed, text); */
                if(sucANum != 0){
                    if(useAttackStatus){
                        for(int i = 0; i < actorTension - 1; i++){
                            Print.println("追撃" + "！".repeat(i + 1) + Print.sleep(5), true, Print.highSpeed, text);
                            
                        }
                        // Print.println("テンションを消費して" + MainStatus.a.jName + "が" + actorTension + "倍になった！" + Print.sleep(2), true, Print.middleSpeed, text);
                        
                        Print.nextLine(scanner, text);
                    }else{
                        Print.println("溜めたテンションが力に変わる！" + Print.sleep(2), true, Print.highSpeed, text);
                        
                    }
                }
                actorStateAction.get(ActionState.Tension).replace(ActionStateCounter.count, 0);
                actorStateAction.get(ActionState.Tension).replace(ActionStateCounter.flag, -1);
            }
        }
        if(sucANum == 0){
            Print.println("しかし、" + Action.attack.jName + "は外れた！" + Print.sleep(2), true, Print.middleSpeed, text);
            
            return sucANum;
        }
        /*if(sucANum >= 2){
            for(int i = 1; i < sucANum; i++){
                Print.println("追", Print.lowSpeed, text);
            }
            Print.println("撃!", Print.lowSpeed, text);
        }*/
        if(sucANum >= 2){
            Print.println(sucANum + " 回当たった！" + Print.sleep(2), true, Print.middleSpeed, text);
            
            Print.nextLine(scanner, text);
        }
        if (target.getStateAction().get(ActionState.Defense).get(ActionStateCounter.flag) == 1 && !canDefense){
            //TODO 呪文以外の防御出来ない攻撃にもこのテキストが出る
            Print.println("呪文は防御出来ない！" + Print.sleep(2), true, Print.middleSpeed, text);
            
            Print.nextLine(scanner, text);
        }
        //乱数ゼロ化
        randomRate = 0;
        damage = randomProcess(damage, randomRate, rand);
        damage *= sucANum;
        if(doApplyDefenceStatus){
            damage = (int)(damage / (target.getBattleStatus().get(BattleStatus.d) / 100.0));
            if(target.getJName().equals(Boss.normalBrave.jName)){
                Print.println(target.getJName() + "の重厚な鋼の鎧がダメージを和らげた！" + Print.sleep(2), true, Print.highSpeed, text);
                
            }
            if(target.getJName().equals(Boss.StrongestBrave.jName)){
                Print.println("ふんどし姿の" + target.getJName() + "にはダメージが倍増した！" + Print.sleep(2), true, Print.highSpeed, text);
                
            }
            if(target.getJName().equals(Boss.LegendaryBrave.jName)){
                Print.println(target.getJName() + "の黄金混じりの高級装備がダメージを吸収する！" + Print.sleep(2), true, Print.highSpeed, text);
                
            }
            if(target.getJName().equals(Boss.DemiseBrave.jName)){
                Print.println(target.getJName() + "は微動だにせず、攻撃を受け入れた！" + Print.sleep(2), true, Print.highSpeed, text);
                
            }
        }

        // if(ChangeWeather.nowWeather(state) == Weather.Cure){
        //     Print.println("癒天候によりダメージが半分になった", Print.middleSpeed, text);
        //     Print.nextLine(scanner, text);
        //     damage /= 2;
        // }

        //仮変更
        if ((target.getStateAction().get(ActionState.Defense).get(ActionStateCounter.flag) == 1 && canDefense) || target.getStateAction().get(ActionState.SpecialDefense).get(ActionStateCounter.flag) == 1){
            damage = 0;//ダメージ半減
            sucANum = 0;
            Print.println(target.getJName() + "は攻撃を抑えた！" + Print.sleep(2), true, Print.highSpeed, text);
        }

        ChangeActionState.onset(state, target_is_player1, actor_is_player1, ActionState.sucSDef, log, text, scanner, rand);
        CalculateDamage.changeParameter(target, MainStatus.hp, damage, text);
        if(attack && sucANum != 0){
            if(makeChargeMiss){
                ChangeActionState.onset(state, target_is_player1, actor_is_player1, ActionState.Attacked, log, text, scanner, rand);
            }
            if(target.getStateAction().get(ActionState.Tension).get(ActionStateCounter.flag) != 1 &&
             target.getStateAction().get(ActionState.SpecialTension).get(ActionStateCounter.flag) != 1 &&
             !(target.getStateAction().get(ActionState.Defense).get(ActionStateCounter.flag) == 1 && canDefense) && 
             target.getStateAction().get(ActionState.SpecialDefense).get(ActionStateCounter.flag) != 1 && 
             target.getStateAction().get(ActionState.Tension).get(ActionStateCounter.count) != 0){
                Print.print("攻撃されたことで" + target.getJName() + "のテンションは", true, Print.middleSpeed, text);
                /*for(int i = 1; i < sucANum; i++){
                    Print.print("とっても", Print.lowSpeed, text);
                }*/
                Print.println("消し飛んだ！" + Print.sleep(2), true, Print.middleSpeed, text);
                
                /*if(target.getStateAction().get(ActionState.Tension).get(ActionStateCounter.count) - sucANum < 0){*/
                    target.getStateAction().get(ActionState.Tension).replace(ActionStateCounter.count, 0);
                /*}else{
                    target.getStateAction().get(ActionState.Tension).replace(ActionStateCounter.count, target.getStateAction().get(ActionState.Tension).get(ActionStateCounter.count) - sucANum);
                }*/
                ChangeBattleStatus.reset(state);
            }
        }
        //useTension == falseの時に0にしたTensonを元に戻す
        if(!useTension){
            actorStateAction.get(ActionState.Tension).replace(ActionStateCounter.count, nowTension);
            ChangeBattleStatus.reset(state);
        }
        state.setPlayer(actor, actor_is_player1);
        state.setPlayer(target, target_is_player1);
        return sucANum;
    }

    // 2の4乗根のn乗を端数の出ない値に直す
    public static double clearFourthRootOfTwo(int n){
        double result = Math.pow(2, n / 4);
        if(n % 4 == 1){
            result *= 1.2;
        }
        if(n % 4 == 2){
            result *= 1.4;
        }
        if(n % 4 == 3){
            result *= 1.7;
        }
        return result;
    }

    // コストのパラメータを纏めるクラス
    public class CostParameter {
        public TrainStatus statusCategory;
        public double value;
        public CostCategory costCategory;
        public CostParameter(TrainStatus statusCategory, double value, CostCategory costCategory){
            this.statusCategory = statusCategory;
            this.value = value;
            this.costCategory = costCategory;
        }
        public CostParameter(CostParameter base){
            this.statusCategory = base.statusCategory;
            this.value = base.value;
            this.costCategory = base.costCategory;
        }
    }
}
