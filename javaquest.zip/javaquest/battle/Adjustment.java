package battle;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import battle.InputAction.Action;
import battle.InputAction.Auto;
import battle.state_change.ChangeAbnormalState.AbnormalState;
import battle.state_change.ChangeAbnormalState.AbnormalStateCounter;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import battle.state_change.ChangeBattleStatus.StateChangeStatus;
import battle.state_change.ChangeBattleStatus.StatusCounter;
import battle.state_change.ChangeField.Field;
import battle.state_change.ChangeField.FieldCounter;
import character.Character;
import character.CharacterTester;
import character.Character.Attribute;
import character.Character.BattleStatus;
import character.Character.MainStatus;
import data.action.Special;
import data.action.Spell;
import data.item.BattleItem;
import log.BattleLog;
import log.BattleLogForAI;
import log.BattleLogResult;
import log.StatusLog;
import log.OneTurnBattleLog.Success;
import text.Print;
import text.Print.Color;

public final class Adjustment {
    private static final int num = 2000;
    private static final int division = 200;
    private static final long sleep = 100;
    private static final boolean parallel = true;
    public static void main(String[] args) {
        Random rand = new Random();
        Scanner scanner = new Scanner(System.in);
        Character self;
        Character enemy;
        List<BattleLog> log = new ArrayList<>();
        List<List<Character>> se = new ArrayList<>();
        int[] mainStatus = new int[9];
        // ここからステータス変更可能

        // self
        // 知能
        Auto SELF_AUTO = Auto.enemyMCTS;
        // ステータス
        boolean isRandomSelfStatus = true;// これがtrueの場合、攻撃力と素早さが半分から2倍の中でランダムに決まる。HPはその逆数が掛けられる。
        int baseSelfHp = 1000;
        int baseSelfMp = 8;
        int baseSelfA = 100;
        int baseSelfD = 100;
        int baseSelfS = 100;
        // 必殺技
        boolean isRandomSelfAttribute = true;// 必殺技はランダムか否か
        Attribute selfAttribute = Attribute.A;// 必殺技（ランダムなら無視される）
        // 呪文
        int selfSpellSlotNum = 5;// 呪文のスロット数
        boolean isRandomSelfLearnSpell = true;// 覚えている呪文はランダムか否か
        int selfLearnSpellNum = 10;// 覚えている呪文の数（ランダムでないなら無視される）
        Map<Spell, Integer> selfLearnSpell = new EnumMap<>(Spell.class){{// 覚えている呪文（ランダムなら無視される）
            put(Spell.Fire, 1);
            put(Spell.Wind, 1);
        }};
        // スキル
        boolean isRandomSelfSkill = true;// スキルはランダムか否か
        BattleItem selfSkill = BattleItem.Zoukyouzai;// スキル（ランダムなら無視される）

        // enemy
        // 知能
        Auto ENEMY_AUTO = Auto.enemyMCTS;
        // ステータス
        boolean isRandomEnemyStatus = true;// これがtrueの場合、攻撃力と素早さが半分から2倍の中でランダムに決まる。HPはその逆数が掛けられる。
        int baseEnemyHp = 1000;
        int baseEnemyMp = 8;
        int baseEnemyA = 100;
        int baseEnemyD = 100;
        int baseEnemyS = 100;
        // 必殺技
        boolean isRandomEnemyAttribute = true;// 必殺技はランダムか否か
        Attribute enemyAttribute = Attribute.A;// 必殺技（ランダムなら無視される）
        // 呪文
        int enemySpellSlotNum = 5;// 呪文のスロット数
        boolean isRandomEnemyLearnSpell = true;// 覚えている呪文はランダムか否か
        int enemyLearnSpellNum = 10;// 覚えている呪文の数（ランダムでないなら無視される）
        Map<Spell, Integer> enemyLearnSpell = new EnumMap<>(Spell.class){{// 覚えている呪文（ランダムなら無視される）
            put(Spell.Fire, 1);
        }};
        // スキル
        boolean isRandomEnemySkill = true;// スキルはランダムか否か
        BattleItem enemySkill = BattleItem.Zoukyouzai;// スキル（ランダムなら無視される）
        
        // ここまでステータス変更可能
        for(int i = 0; i < num; i++){
            int e = 0;
            mainStatus[0] = baseSelfHp;
            mainStatus[1] = baseSelfHp;
            mainStatus[2] = baseSelfMp;
            mainStatus[3] = baseSelfMp;
            mainStatus[4] = baseSelfA;
            mainStatus[5] = baseSelfD;
            mainStatus[6] = e;
            mainStatus[7] = baseSelfS;
            mainStatus[8] = 1;
            if(isRandomSelfStatus){
                double aCoef = Math.pow(2, (rand.nextDouble() * 2) - 1);
                double sCoef = Math.pow(2, (rand.nextDouble() * 2) - 1);
                double hpCoef = 1 / aCoef / sCoef;
                mainStatus[0] *= hpCoef;
                mainStatus[1] *= hpCoef;
                mainStatus[4] *= aCoef;
                mainStatus[7] *= sCoef;
            }
            self = new CharacterTester("魔王", Color.blue, isRandomSelfAttribute ? Attribute.values()[rand.nextInt(3)] : selfAttribute, selfSpellSlotNum, false, mainStatus, isRandomSelfLearnSpell ? new EnumMap<>(Spell.class){{
                for(int i = 0; i < selfLearnSpellNum; i++){
                    Spell spell = Spell.values()[rand.nextInt(Spell.NUM)];
                    put(spell, 1);
                }
            }} : selfLearnSpell, isRandomSelfSkill ? BattleItem.values()[rand.nextInt(BattleItem.NUM - 1)] : selfSkill);
            for(BattleItem key : BattleItem.values()){
                self.getItemList().put(key, 1);
            }
            BattleItem.randomDropItem(self, rand);
            mainStatus[0] = baseEnemyHp;
            mainStatus[1] = baseEnemyHp;
            mainStatus[2] = baseEnemyMp;
            mainStatus[3] = baseEnemyMp;
            mainStatus[4] = baseEnemyA;
            mainStatus[5] = baseEnemyD;
            mainStatus[6] = e;
            mainStatus[7] = baseEnemyS;
            mainStatus[8] = 1;
            if(isRandomEnemyStatus){
                double aCoef = Math.pow(2, (rand.nextDouble() * 2) - 1);
                double sCoef = Math.pow(2, (rand.nextDouble() * 2) - 1);
                double hpCoef = 1 / aCoef / sCoef;
                mainStatus[0] *= hpCoef;
                mainStatus[1] *= hpCoef;
                mainStatus[4] *= aCoef;
                mainStatus[7] *= sCoef;
            }
            enemy = new CharacterTester("ゴブリン", Color.yellow, isRandomEnemyAttribute ? Attribute.values()[rand.nextInt(3)] : enemyAttribute, enemySpellSlotNum, false, mainStatus, isRandomEnemyLearnSpell ? new EnumMap<>(Spell.class){{
                for(int i = 0; i < enemyLearnSpellNum; i++){
                    Spell spell = Spell.values()[rand.nextInt(Spell.NUM)];
                    put(spell, 1);
                }
            }} : enemyLearnSpell, isRandomEnemySkill ? BattleItem.values()[rand.nextInt(BattleItem.NUM - 1)] : enemySkill);
            for(BattleItem key : BattleItem.values()){
                enemy.getItemList().put(key, 1);
            }
            BattleItem.randomDropItem(enemy, rand);
            if(parallel){
                se.add(Arrays.asList(new Character[]{self,enemy}));
            }else{
                log.add(Battle.startBattle(self, enemy, SELF_AUTO, ENEMY_AUTO, false, scanner, rand));
                System.out.println((i + 1));
            }
        }
        if(parallel){
            for(int i = 0; i < num; i += division){
                Collections.addAll(log, se.parallelStream().skip(i).limit(division).map(s -> Battle.startBattle(s.get(0), s.get(1), SELF_AUTO, ENEMY_AUTO, false, scanner, rand)).toArray(BattleLog[]::new));
                System.out.println((i + division));
            }
        }
        printTurnAndNum(log, scanner);
        scanner.close();
    }

    private static void printTurnAndNum(List<BattleLog> log, Scanner sc){
        BattleLogForAI logForAI = new BattleLogForAI(log);
        BattleLogResult logResult = new BattleLogResult(log);
        System.out.println();
        System.out.println("平均ターン" + logResult.lastTurn);
        System.out.println(" self勝率" + logForAI.p1Win);
        System.out.println("enemy勝率" + logForAI.p2Win);
        for(int i = 0; i <= InputAction.ACTION_NUM ; i++){
            if(i == 0){
                System.out.println(Color.blue.toColor("逃げる"));
            }
            if(i == 1){
                System.out.println(Color.blue.toColor(Action.attack.jName));
            }
            if(i ==2){
                System.out.println(Color.blue.toColor(Action.defense.jName));
            }
            if(i == 3){
                System.out.println(Color.blue.toColor(Action.tension.jName));
            }
            if(4 <= i && i < 4 + Spell.NUM){
                System.out.println(Color.blue.toColor(Spell.values()[i-4].jName));
            }
            if(i == 4 + Spell.NUM){
                System.out.println(Color.blue.toColor("必殺技"));
            }
            if(4 + Spell.NUM < i && i <= 4 + Spell.NUM + Special.NUM){
                System.out.println(Color.blue.toColor(Special.values()[i - 4 - Spell.NUM - 1].jName));
            }
            if(4 + Spell.NUM + Special.NUM < i && i < 1 + InputAction.ACTION_NUM){
                System.out.println(Color.blue.toColor(Spell.values()[i - (4 + Spell.NUM + 1 + Special.NUM)].jName + "追加"));
            }
            System.out.print(Color.yellow.toColor("勝者 : "));
            printNum(logResult.winnerActionLog.get(i));
            System.out.print("  " + Color.red.toColor("敗者 : "));
            printNum(logResult.loserActionLog.get(i));
            System.out.print("  " + Color.red.toColor("引き分け : "));
            printNum(logResult.drawActionLog.get(i));
            System.out.println();
            System.out.println();
            if(i % 10 == 0){
                Print.input(sc, true);
            }
        }
        for(int i = 0; i <= BattleItem.NUM ; i++){
            if(i == 0){
                System.out.println(Color.blue.toColor("アイテム未使用"));
            }else{
                System.out.println(Color.blue.toColor(BattleItem.values()[i - 1].jName));
            }
            System.out.print(Color.red.toColor("勝者 : "));
            printNum(logResult.winnerItemLog.get(i));
            System.out.print("  " + Color.red.toColor("敗者 : "));
            printNum(logResult.loserItemLog.get(i));
            System.out.print("  " + Color.red.toColor("引き分け : "));
            printNum(logResult.drawItemLog.get(i));
            System.out.println();
            System.out.println();
        }
        System.out.println(Color.blue.toColor(Action.spell.jName + "使用率"));
        System.out.print(Color.red.toColor("勝者 : "));
        System.out.print(logResult.winnerSpellSelect);
        System.out.print("  " + Color.red.toColor("敗者 : "));
        System.out.print(logResult.loserSpellSelect);
        System.out.print("  " + Color.red.toColor("引き分け : "));
        System.out.print(logResult.drawSpellSelect);
        System.out.println();
        System.out.println();
        for(int i = 0; i < Spell.NUM; i++){
            Spell key = Spell.values()[i];
            System.out.println(Color.blue.toColor(key.jName + "採用率"));
            System.out.print(Color.red.toColor("勝者 : "));
            System.out.print(logResult.winnerAdoptionSpell.get(key));
            System.out.print("  " + Color.red.toColor("敗者 : "));
            System.out.print(logResult.loserAdoptionSpell.get(key));
            System.out.print("  " + Color.red.toColor("引き分け : "));
            System.out.print(logResult.drawAdoptionSpell.get(key));
            System.out.println();
            System.out.println();
            if(i % 10 == 0){
                Print.input(sc, true);
            }
        }
        for(int i = 0; i < Success.NUM; i++){
            Success key = Success.values()[i];
            System.out.println(Color.blue.toColor(key.jName));
            System.out.print(Color.red.toColor("勝者 : "));
            System.out.print(logResult.winnerSuccess.get(key));
            System.out.print("  " + Color.red.toColor("敗者 : "));
            System.out.print(logResult.loserSuccess.get(key));
            System.out.print("  " + Color.red.toColor("引き分け : "));
            System.out.print(logResult.drawSuccess.get(key));
            System.out.println();
            System.out.println();
            if(i % 10 == 0){
                Print.input(sc, true);
            }
        }
        System.out.println(Color.blue.toColor("平均ステータス"));
        System.out.println(Color.red.toColor("勝者 : "));
        for(MainStatus key : MainStatus.values()){
            System.out.println("    " + key.jName + logResult.winnerStatus.get(key));
        }
        System.out.println(Color.red.toColor("敗者 : "));
        for(MainStatus key : MainStatus.values()){
            System.out.println("    " + key.jName + logResult.loserStatus.get(key));
        }
        System.out.print(Color.red.toColor("引き分け : "));
        for(MainStatus key : MainStatus.values()){
            System.out.println("    " + key.jName+ logResult.drawStatus.get(key));
        }
        System.out.println();
        System.out.println("スキル");
        for(BattleItem key : BattleItem.values()){
            System.out.println(Color.blue.toColor(key.jName));
            System.out.print(Color.red.toColor("勝者 : "));
            System.out.print(logResult.winnerSkillLog.get(key));
            System.out.print("  " + Color.red.toColor("敗者 : "));
            System.out.print(logResult.loserSkillLog.get(key));
            System.out.print("  " + Color.red.toColor("引き分け : "));
            System.out.print(logResult.drawSkillLog.get(key));
            System.out.println();
            System.out.println();
        }
        System.out.println();
        System.out.println();
    }

    private static void printAll(List<BattleLog> log, Scanner scanner){
                /*
        BattleLogForAI logForAI = new BattleLogForAI(log);
        for(int i = 0; i <= InputAction.ACTION_NUM ; i++){
            if(i == 0){
                System.out.println(Color.blue.toColor(Action.escape.jName));
            }
            if(i == 1){
                System.out.println(Color.blue.toColor(Action.attack.jName));
            }
            if(i ==2){
                System.out.println(Color.blue.toColor(Action.defense.jName));
            }
            if(i == 3){
                System.out.println(Color.blue.toColor(Action.charge.jName));
            }
            if(4 <= i && i < 4 + Spell.NUM){
                System.out.println(Color.blue.toColor(Spell.values()[i-4].jName));
            }
            if(i == 4 + Spell.NUM){
                System.out.println(Color.blue.toColor(Action.special.jName));
            }
            if(4 + Spell.NUM < i && i <= 4 + Spell.NUM + Special.NUM){
                System.out.println(Color.blue.toColor(Special.values()[i - 4 - Spell.NUM - 1].jName));
            }
            if(4 + Spell.NUM + Special.NUM < i && i < 1 + InputAction.ACTION_NUM){
                System.out.println(Color.blue.toColor(Spell.values()[i - (4 + Spell.NUM + 1 + Special.NUM)].jName + "追加"));
            }
            System.out.println("\n" + Print.toRed("self"));
            printStatus(logForAI.p1ActionLog.get(i));
            System.out.println("\n" + Print.toRed("enemy"));
            printStatus(logForAI.p2ActionLog.get(i));
        }
        for(int i = 0; i <= BattleItem.NUM ; i++){
            if(i == 0){
                System.out.println(Color.blue.toColor(Action.item.jName + "未使用"));
            }else{
                System.out.println(Color.blue.toColor(BattleItem.values()[i - 1].jName));
            }
            System.out.println("\n" + Print.toRed("self"));
            printStatus(logForAI.p1ItemLog.get(i));
            System.out.println("\n" + Print.toRed("enemy"));
            printStatus(logForAI.p2ItemLog.get(i));
        }
        */


        BattleLogResult logResult = new BattleLogResult(log);
        for(int i = 0; i <= InputAction.ACTION_NUM ; i++){
            if(i == 0){
                System.out.println(Color.blue.toColor("逃げる"));
            }
            if(i == 1){
                System.out.println(Color.blue.toColor(Action.attack.jName));
            }
            if(i ==2){
                System.out.println(Color.blue.toColor(Action.defense.jName));
            }
            if(i == 3){
                System.out.println(Color.blue.toColor(Action.tension.jName));
            }
            if(4 <= i && i < 4 + Spell.NUM){
                System.out.println(Color.blue.toColor(Spell.values()[i-4].jName));
            }
            if(i == 4 + Spell.NUM){
                System.out.println(Color.blue.toColor("必殺技"));
            }
            if(4 + Spell.NUM < i && i <= 4 + Spell.NUM + Special.NUM){
                System.out.println(Color.blue.toColor(Special.values()[i - 4 - Spell.NUM - 1].jName));
            }
            if(4 + Spell.NUM + Special.NUM < i && i < 1 + InputAction.ACTION_NUM){
                System.out.println(Color.blue.toColor(Spell.values()[i - (4 + Spell.NUM + 1 + Special.NUM)].jName + "追加"));
            }
            System.out.println("\n" + Color.red.toColor("勝者"));
            printStatus(logResult.winnerActionLog.get(i));
            System.out.println("\n" + Color.red.toColor("敗者"));
            printStatus(logResult.loserActionLog.get(i));
            System.out.println("\n" + Color.red.toColor("引き分け"));
            printStatus(logResult.drawActionLog.get(i));
        }
        for(int i = 0; i <= BattleItem.NUM ; i++){
            if(i == 0){
                System.out.println(Color.blue.toColor("アイテム未使用"));
            }else{
                System.out.println(Color.blue.toColor(BattleItem.values()[i - 1].jName));
            }
            System.out.println("\n" + Color.red.toColor("勝者"));
            printStatus(logResult.winnerItemLog.get(i));
            System.out.println("\n" + Color.red.toColor("敗者"));
            printStatus(logResult.loserItemLog.get(i));
            System.out.println("\n" + Color.red.toColor("引き分け"));
            printStatus(logResult.drawItemLog.get(i));
        }
    }

    private static void printNum(StatusLog log){
        if(log != null){
            System.out.print("使用回数 " + log.actionCount);
        }
    }
    private static void printStatus(StatusLog log){
        try{
            if(log != null){
                System.out.println("使用回数 : " + log.actionCount);
                System.out.println("\n使用率 : " + log.actionRate);
                Thread.sleep(sleep);
                System.out.println("\n" + Action.spell.jName + "レベル");
                for(Spell key : Spell.values()){
                    if(key != Spell.NULL){
                        System.out.print(" " + key.jName + " : " + log.spellLevel.get(key));
                    }
                }
                Thread.sleep(sleep);
                System.out.println("\n\nメインステータス");
                for(MainStatus key : MainStatus.values()){
                    System.out.print(" " + key.jName + " : " + log.beforeMainStatus.get(key) + "→" + log.afterMainStatus.get(key));
                }
                Thread.sleep(sleep);
                System.out.println("\n\nバトルステータス");
                for(BattleStatus key : BattleStatus.values()){
                    System.out.print(" " + key.status.jName + " : " + log.beforeBattleStatus.get(key) + "→" + log.afterBattleStatus.get(key));
                }
                Thread.sleep(sleep);
                System.out.println("\n\n能力変化");
                for(StateChangeStatus key : StateChangeStatus.values()){
                    System.out.println(" " + key.status.status.jName);
                    System.out.print(" ");
                    for(StatusCounter counter : StatusCounter.values()){
                        System.out.print(" " + counter.name() + " : " + log.beforeStateChangeStatus.get(key) + "→" + log.afterStateChangeStatus.get(key));
                    }
                    System.out.println();
                }
                Thread.sleep(sleep);
                System.out.println("\n\n状態異常");
                for(AbnormalState key : AbnormalState.values()){
                    System.out.println(" " + key.jName);
                    System.out.print(" ");
                    for(AbnormalStateCounter counter : AbnormalStateCounter.values()){
                        System.out.print(" " + counter.name() + " : " + log.beforeStateAbnormal.get(key).get(counter) + "→" + log.afterStateAbnormal.get(key).get(counter));
                    }
                    System.out.println();
                }
                Thread.sleep(sleep);
                System.out.println("\n\n一時変化");
                for(ActionState key : ActionState.values()){
                    System.out.println(" " + key.name());
                    System.out.print(" ");
                    for(ActionStateCounter counter : ActionStateCounter.values()){
                        System.out.print(" " + counter.name() + " : " + log.beforeStateAction.get(key).get(counter) + "→" + log.afterStateAction.get(key).get(counter));
                    }
                    System.out.println();
                }
                Thread.sleep(sleep);
                System.out.println("\n\nフィールド");
                for(Field key : Field.values()){
                    System.out.println(" " + key.jName);
                    System.out.print(" ");
                    for(FieldCounter counter : FieldCounter.values()){
                        System.out.print(" " + counter.name() + " : " + log.beforeField.get(key).get(counter) + "→" + log.afterField.get(key).get(counter));
                    }
                    System.out.println();
                }
                Thread.sleep(sleep);
                System.out.println("\n\n" + Action.spell.jName + "スロット");
                for(Spell key : Spell.values()){
                    if(key != Spell.NULL){
                        System.out.print(" " + key.jName + " : " + log.beforeSpellSlot.get(key) + "→" + log.afterSpellSlot.get(key));
                    }
                }
                Thread.sleep(sleep);
                System.out.println("\n\n所持アイテム");
                for(BattleItem key : BattleItem.values()){
                    System.out.print(" " + key.jName + " : " + log.beforeItemList.get(key) + "→" + log.afterItemList.get(key));
                }
            }else{
                System.out.println("行動なし");
            }
        }catch(InterruptedException e){

        }
        System.out.println();
    }
}
