package battle;

import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import battle.InputAction.Action;
import battle.state_change.*;
import battle.state_change.ChangeAbnormalState.AbnormalState;
import battle.state_change.ChangeAbnormalState.AbnormalStateCounter;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import battle.state_change.ChangeField.Field;
import battle.state_change.ChangeField.FieldCounter;
import battle.state_change.ChangeWeather.Weather;
import character.Character;
import character.Character.BattleStatus;
import character.Character.MainStatus;
import character.Character.Attribute;
import character.Enemy;
import character.Player;
import data.action.Special;
import data.action.Spell;
import data.item.BattleItem;
import log.BattleTemporaryLog;
import text.Print;

//actionをintで受け取り、実行するまで。
public final class ExecuteAction {
    //キャラクターのターンが回って来た時に受け付けた入力から行動を実行する。
    public static State act(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean bond, int action, int enemyAction, boolean spendCost, boolean text, Scanner scanner, Random rand){
        state = state.modifiableCopy();
        Character actor = state.getPlayer(actor_is_player1);
        if(actor instanceof Enemy){
            Enemy eActor = (Enemy)actor;
            if(eActor.getLastSpell() != Spell.NULL){
                // Print.println(eActor.getJName() + "は" + eActor.getLastSpell().jName + "のオーブを回収した", true, Print.highSpeed, text);
                eActor.setLastSpell(Spell.NULL);
            }
        }
        /* Map<Field,Map<FieldCounter, Integer>> field = state.getField();
        //ヘジテンス追加
        if(hesitance){
            ChangeAbnormalState.execute(actor, field, AbnormalState.Hesitance, action, enemyAction, text);
            if(actor.getStateAbnormal().get(AbnormalState.Hesitance).get(AbnormalStateCounter.noMove) == 1){
                actor.getStateAbnormal().get(AbnormalState.Hesitance).replace(AbnormalStateCounter.noMove, 0);
                state.setPlayer(actor, actor_is_player1);
                return state;
            }
        } */
        //行動不能
        if(action == -1){
            if(actor.getStateAction().get(ActionState.Swoon).get(ActionStateCounter.flag).intValue() == 1){
                Print.println(actor.getJName() + "は怯んで行動出来なかった" + Print.sleep(2), true, Print.middleSpeed, text);
                
            }else{
                Print.println(actor.getJName() + "は行動出来なかった" + Print.sleep(2), true, Print.middleSpeed, text);
                
            }
            return state;
        }
        if(action == 0){
            escape(actor, text);
        }
        if(action == 1){
            Print.println(actor.getJName() + "は" + Action.attack.jName + "した！" + Print.sleep(2), true, Print.middleSpeed, text);
            
            attack(state, actor_is_player1, target_is_player1, log, text, scanner, rand);
        }
        if(action == 2){
            if(actor.getStateAction().get(ActionState.Attacked).get(ActionStateCounter.flag) == 1){
                Print.println(actor.getJName() + "は防御したが、", true, Print.middleSpeed, text);
                Print.println("倍も高い" + MainStatus.s.jName + "に先手を取られてしまった！", true, Print.middleSpeed, text);
            }else{
                Print.println(actor.getJName() + "は" + Action.defense.jName + "した！" + Print.sleep(2), true, Print.middleSpeed, text);
            }
            
            guard(state, actor_is_player1, target_is_player1, log, text, scanner, rand);
            //ChangeActionState.onset(copyState, target_is_player1, actor_is_player1, ActionState.sucSDef, text, scanner, rand);
        }
        if(action == 3){
            Print.println(state.getPlayer(actor_is_player1).getJName() + "は溜めた！" + Print.sleep(2), true, Print.middleSpeed, text);
            
            concentrate(state, actor_is_player1, target_is_player1, log, text, scanner, rand);
        }
        if(4 <= action && action < 4 + Spell.NUM){
            if(spendCost){
                if(actor.getStateAction().get(ActionState.On_SpellReflect).get(ActionStateCounter.flag) == 1){
                    target_is_player1 = !target_is_player1;
                }
                chantSpell(Spell.values()[action-4], enemyAction, state, actor_is_player1, target_is_player1, log, text, scanner, rand);
            }else{
                Spell.values()[action-4].execute(state, actor_is_player1, target_is_player1, log, text, rand, scanner);
            }
        }
        if(action == 4 + Spell.NUM){
            ChangeActionState.onset(state, actor_is_player1, target_is_player1, ActionState.oldChargeSpecial, log, text, scanner, rand);
        }
        if(4 + Spell.NUM < action && action <= 4 + Spell.NUM + Special.NUM){
            moveSpecial(Special.values()[action - 4 - Spell.NUM - 1],state, actor_is_player1, target_is_player1, log, text, scanner, rand);
            if(action == 4 + Spell.NUM + 1){
                ChangeActionState.onset(state, target_is_player1, actor_is_player1, ActionState.sucDef, log, text, scanner, rand);
            }
        }
        if(4 + Spell.NUM + Special.NUM < action && action < 1 + InputAction.ACTION_NUM){
            changeSpell(actor, Spell.values()[action - (4 + Spell.NUM + 1 + Special.NUM)], text);
        }
        if(1 + InputAction.ACTION_NUM <= action){
            if(spendCost){
                useItem(BattleItem.values()[action - 1 - InputAction.ACTION_NUM], state, actor_is_player1, target_is_player1, log, rand, text, scanner);
            }else{
                BattleItem.values()[action - 1 - InputAction.ACTION_NUM].battleExecute(state, actor_is_player1, target_is_player1, log, rand, text, scanner);
            }
        }
        state.setPlayer(actor, actor_is_player1);
        return state;
    }

    //アイテムの合法判定
    public static boolean legalItem(BattleItem name, Character actor, boolean text){
        Map<BattleItem, Integer> itemList = actor.getItemList();
        if(itemList.get(name) == 0){
            Print.println(name.jName + "を所持していなかった", true, Print.middleSpeed, text);
            return false;
        }
        if(actor.getStateAction().get(ActionState.UseItem).get(ActionStateCounter.flag) == 1){
            Print.println("既にアイテムを使用していた", true, Print.middleSpeed, text);
            return false;
        }
        if(!name.battleUseAble(actor)){
            Print.println("使用条件を満たしていなかった", true, Print.middleSpeed, text);
            return false;
        }
        return true;
    }

    // 逃げる
    private static void escape(Character actor, boolean text){
        Print.println("", true, Print.highSpeed, text);
        Print.println(actor.getJName() + "は逃げ出した", true, Print.middleSpeed, text);
    }

    // 攻撃
    public static int attack(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Scanner scanner, Random rand){
        Character actor = state.getPlayer(actor_is_player1);
        Character target = state.getPlayer(target_is_player1);
        int aNum = actor.getMainStatus().get(MainStatus.aNum);
        if(state.getPlayer(actor_is_player1).getAttribute() == Attribute.A){
            ChangeActionState.onset(state, actor_is_player1, target_is_player1, ActionState.newChargeSpecial, log, text, scanner, rand);
        }
        // for(AbnormalState aState : new AbnormalState[]{AbnormalState.SaltWater, AbnormalState.SuperSaltWater}){
        //     if(actor.getStateAbnormal().get(aState).get(AbnormalStateCounter.flag) == 1){
        //         Print.println(actor.jName + aState.execute2, Print.middleSpeed, text);
        //         CalculateDamage.changeParameter(actor, MainStatus.mp, 
        //         actor.getMainStatus().get(MainStatus.maxMp) * ChangeAbnormalState.stomaMPRate * (aState == AbnormalState.SuperSaltWater ? 2 : 1) / 100, text);
        //     }
        // }
        //属性で攻撃回数2倍
        if(actor.getAttribute() == Attribute.A && false){// TODO 属性封印
            aNum *= 2;
            Print.println("", true, Print.highSpeed, text);
            Print.println("攻撃属性により攻撃回数が2倍になり、" + aNum + "回攻撃になった！", true, Print.middleSpeed, text);
            Print.nextLine(scanner, text);
        }
        int hit = CalculateDamage.attackProcess(actor.getBattleStatus().get(BattleStatus.a), aNum, 100 - target.getMainStatus().get(MainStatus.e), CalculateDamage.BASE_VARIANCE_RATE, true, true, true, true, true, true, state, actor_is_player1, target_is_player1, true, log, text, rand, scanner);
        log.setHit(actor_is_player1, hit);
        ChangeActionState.onset(state, target_is_player1, actor_is_player1, ActionState.sucDef, log, text, scanner, rand);
        return hit;
    }

    // 防御
    public static void guard(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Scanner scanner, Random rand){
        // for(AbnormalState aState : new AbnormalState[]{AbnormalState.SaltWater, AbnormalState.SuperSaltWater}){
        //     if(state.getPlayer(actor_is_player1).getStateAbnormal().get(aState).get(AbnormalStateCounter.flag) == 1){
        //         Print.println(state.getPlayer(actor_is_player1).jName + aState.execute2, Print.middleSpeed, text);
        //         CalculateDamage.changeParameter(state.getPlayer(actor_is_player1), MainStatus.mp, 
        //         state.getPlayer(actor_is_player1).getMainStatus().get(MainStatus.maxMp) * ChangeAbnormalState.stomaMPRate * (aState == AbnormalState.SuperSaltWater ? 2 : 1) / 100, text);
        //     }
        // }
        if(state.getPlayer(actor_is_player1).getAttribute() == Attribute.D){
            ChangeActionState.onset(state, actor_is_player1, target_is_player1, ActionState.newChargeSpecial, log, text, scanner, rand);
        }
        ChangeActionState.onset(state, actor_is_player1, target_is_player1, ActionState.Defense, log, text, scanner, rand);
    }

    // 溜める
    public static void concentrate(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Scanner scanner, Random rand){
        // Print.println("", true, Print.highSpeed, text);
        // Print.println(state.getPlayer(actor_is_player1).getJName() + "は溜めた", true, Print.middleSpeed, text);
        // for(AbnormalState aState : new AbnormalState[]{AbnormalState.SaltWater, AbnormalState.SuperSaltWater}){
        //     if(state.getPlayer(actor_is_player1).getStateAbnormal().get(aState).get(AbnormalStateCounter.flag) == 1){
        //         Print.println(state.getPlayer(actor_is_player1).jName + aState.execute2, Print.middleSpeed, text);
        //         CalculateDamage.changeParameter(state.getPlayer(actor_is_player1), MainStatus.mp, 
        //         state.getPlayer(actor_is_player1).getMainStatus().get(MainStatus.maxMp) * ChangeAbnormalState.stomaMPRate * (aState == AbnormalState.SuperSaltWater ? 2 : 1) / 100, text);
        //     }
        // }
        if(state.getPlayer(actor_is_player1).getAttribute() == Attribute.C){
            ChangeActionState.onset(state, actor_is_player1, target_is_player1, ActionState.newChargeSpecial, log, text, scanner, rand);
        }
        ChangeActionState.onset(state, actor_is_player1, target_is_player1, ActionState.Tension, log, text, scanner, rand);
    }

    // 呪文入れ替え
    public static void changeSpell(Character actor, Spell name, boolean text){
        Print.println(actor.getJName() + "はオーブを変更した！", true, Print.middleSpeed, text);
        // 
        // Print.println(actor.getJName() + "は" + name.jName + "のオーブをスロットに入れた！", true, Print.middleSpeed, text);
        if(actor.getSpellSlot().size() - 1 >= 0){
            actor.getSpellSlot().remove(actor.getSpellSlot().size() - 1);
        }
        actor.getSpellSlot().add(0, name);
        // CalculateDamage.changeParameter(actor, MainStatus.mp, -actor.getMainStatus().get(MainStatus.maxMp) * 30 / 100, text);
    }

    //呪文を唱える
    //呪文の合法判定をlegalSpellに移した
    private static void chantSpell(Spell spell, int enemyAction, State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Scanner scanner, Random rand){
        Character actor = state.getPlayer(actor_is_player1);
        // Print.println(actor.getJName() + "の" + spell.getLevelName(actor) + Print.sleep(2), true, Print.middleSpeed, text);
        // 
        Print.println(state.getPlayer(actor_is_player1).getJName() + "は" + spell.getLevelName(actor) + "のオーブを振りかざした！" + Print.sleep(2), true, Print.highSpeed, text);
        
        if(!spell.getLegal(state, ChangeWeather.nowWeather(state), actor, text, scanner))return;
        spell.executePrint(state, actor_is_player1, target_is_player1, text, rand);
        spell.spendCost(actor, text);
        if(spell != Spell.On_SpellReflect) state.useSpell();
        Map<ActionState, Map<ActionStateCounter, Integer>> stateAction = actor.getStateAction();
        Map<ActionStateCounter, Integer> tensionField = stateAction.get(ActionState.Tension);
        //呪文を打つときはコストとしてテンションを支払うという仕様のためのコード
        if(tensionField.get(ActionStateCounter.count) > 0){
            //tensionは減らない
            tensionField.replace(ActionStateCounter.count, tensionField.get(ActionStateCounter.count) - 0);
        }
        stateAction.replace(ActionState.Tension, tensionField);
        actor.setStateAction(stateAction);
        ChangeBattleStatus.reset(state);

        // for(AbnormalState aState : new AbnormalState[]{AbnormalState.SaltWater, AbnormalState.SuperSaltWater}){
        //     if(actor.getStateAbnormal().get(aState).get(AbnormalStateCounter.flag) == 1){
        //         Print.println(actor.jName + aState.execute1, Print.middleSpeed, text);
        //         CalculateDamage.changeParameter(actor, MainStatus.hp, 
        //         spell.getCost(actor) * ChangeAbnormalState.stomaHPRate * (aState == AbnormalState.SuperSaltWater ? 2 : 1), text);
        //     }
        // }
        // //同種の呪文だと打ち消される
        // if(4 <= enemyAction && enemyAction < 4 + Spell.NUM && spell.weather == Spell.values()[enemyAction-4].weather){
        //     Print.println(actor.jName + "の" + spell.jName + "は" + state.getPlayer(!actor_is_player1).jName + "の" + Spell.values()[enemyAction-4].jName + "によって打ち消された"
        //     , Print.middleSpeed, text);
        // }else{
            spell.execute(state, actor_is_player1, target_is_player1, log, text, rand, scanner);
        // }
        if(actor instanceof Enemy){
            ((Enemy)actor).setLastSpell(spell);
            Print.println(actor.getJName() + "は" + spell.jName + "のオーブを落とした" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
        state.setPlayer(actor, actor_is_player1);
    }


    //アイテムを使う
    //アイテムの合法判定をlegalItemに移した
    private static void useItem(BattleItem item, State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, Random rand, boolean text, Scanner scanner){
        Character actor = state.getPlayer(actor_is_player1);
        Map<BattleItem, Integer> itemList = actor.getItemList();
        if(!legalItem(item, actor, text)){
            return;
        }
        itemList.replace(item, itemList.get(item) - 1);
        actor.setItemList(itemList);
        Print.println("", true, Print.highSpeed, text);
        Print.println(actor.getJName() + "は" + item.jName + "を使った", true, Print.middleSpeed, text);
        if (actor.getItemList().get(item) == 0){
            Print.println(item.jName + "が無くなった", true, Print.middleSpeed, text); 
        }
        item.battleExecute(state, actor_is_player1, target_is_player1, log, rand, text, scanner);
        actor.getStateAction().get(ActionState.UseItem).replace(ActionStateCounter.flag, 1);
        state.setPlayer(actor, actor_is_player1);
    }

    // 必殺技使用
    private static void moveSpecial(Special special, State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Scanner scanner, Random rand){
        Character actor = state.getPlayer(actor_is_player1);
        if(actor.getStateAction().get(ActionState.oldChargeSpecial).get(ActionStateCounter.flag) == 1){
            actor.getStateAction().get(ActionState.UsedSpecial).replace(ActionStateCounter.flag, 1);
        }else{
            Print.println(actor.getJName() + Field.SpecialField.execute, true, Print.middleSpeed, text);
        }
        special.execute(state, actor_is_player1, target_is_player1, true, log, text, rand, scanner);
        state.setPlayer(actor, actor_is_player1);
    }

}