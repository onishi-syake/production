package battle;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import battle.InputAction.Action;
import battle.InputAction.Auto;
import battle.state_change.ChangeAbnormalState.AbnormalState;
import battle.state_change.ChangeAbnormalState.AbnormalStateCounter;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import battle.state_change.ChangeBattleStatus.StateChangeStatus;
import battle.state_change.ChangeBattleStatus.StatusCounter;
import battle.state_change.ChangeField.Field;
import battle.state_change.ChangeField.FieldCounter;
import character.Character;
import character.CharacterTester;
import character.Enemy;
import character.Character.Attribute;
import character.Character.BattleStatus;
import character.Character.MainStatus;
import data.action.Special;
import data.action.Spell;
import data.enemy.BaseMonster;
import data.item.BattleItem;
import log.BattleLog;
import log.BattleLogForAI;
import log.BattleLogResult;
import log.StatusLog;
import log.OneTurnBattleLog.Success;
import text.Print;
import text.Print.Color;

public final class AdjustmentForEnemy {
    private static final int num = 2000;
    private static final int division = 200;
    private static final long sleep = 100;
    private static final boolean parallel = true;
    private static final boolean combined = true;
    private static final int baseStatus = 100;
    private static final Auto SELF_AUTO = Auto.biasedRandom;
    private static final Auto ENEMY_AUTO = Auto.random;
    public static void main(String[] args) {
        Random rand = new Random();
        Scanner scanner = new Scanner(System.in);
        Character self;
        Character enemy;
        List<BattleLog> log = new ArrayList<>();
        List<List<Character>> se = new ArrayList<>();
        int[] mainStatus = new int[] {1000, 1000, 8, 8, 100, 100, 10, 100, 1};
        boolean isSelfPlayer = true;
        int selfLevel = 0;
        int enemyLevel = 3;
        for(int i = 0; i < num; i++){
            if(isSelfPlayer){
                if(combined){
                    int e = 0;
                    int status = baseStatus;
                    double aCoef = Math.pow(2, (rand.nextDouble() * 2) - 1);
                    int d = 100;
                    double sCoef = Math.pow(2, (rand.nextDouble() * 2) - 1);
                    double hpCoef = 1 / aCoef / sCoef;
                    mainStatus[0] = (int)(hpCoef * status * 10);
                    mainStatus[1] = (int)(hpCoef * status * 10);
                    mainStatus[4] = (int)(aCoef * status);
                    mainStatus[5] = d;
                    mainStatus[6] = e;
                    mainStatus[7] = (int)(sCoef * status);
                    mainStatus[8] = 1;
                }
                self = new CharacterTester("魔王", Color.blue, Attribute.values()[rand.nextInt(3)], 10, false, mainStatus, new EnumMap<>(Spell.class){{
                    for(int i = 0; i < 10; i++){
                        Spell spell = Spell.values()[rand.nextInt(Spell.NUM)];
                        put(spell, 1);
                    }
                }}, BattleItem.values()[rand.nextInt(BattleItem.NUM - 1)]);
            }else{
                self = new Enemy(BaseMonster.berserkerA, selfLevel, 0);
            }
            enemy = new Enemy(BaseMonster.red, enemyLevel, 0);
            if(parallel){
                se.add(Arrays.asList(new Character[]{self,enemy}));
            }else{
                log.add(Battle.startBattle(self, enemy, SELF_AUTO, ENEMY_AUTO, false, scanner, rand));
                System.out.println((i + 1));
            }
        }
        if(parallel){
            for(int i = 0; i < num; i += division){
                Collections.addAll(log, se.parallelStream().skip(i).limit(division).map(s -> Battle.startBattle(s.get(0), s.get(1), SELF_AUTO, ENEMY_AUTO, false, scanner, rand)).toArray(BattleLog[]::new));
                System.out.println((i + division));
            }
        }
        printTurnAndNum(log, scanner);
        scanner.close();
    }

    private static void printTurnAndNum(List<BattleLog> log, Scanner sc){
        BattleLogForAI logForAI = new BattleLogForAI(log);
        BattleLogResult logResult = new BattleLogResult(log);
        System.out.println();
        System.out.println("平均ターン" + logResult.lastTurn);
        System.out.println(" self勝率" + logForAI.p1Win);
        System.out.println("enemy勝率" + logForAI.p2Win);
        for(int i = 0; i <= InputAction.ACTION_NUM ; i++){
            if(i == 0){
                System.out.println(Color.blue.toColor("逃げる"));
            }
            if(i == 1){
                System.out.println(Color.blue.toColor(Action.attack.jName));
            }
            if(i ==2){
                System.out.println(Color.blue.toColor(Action.defense.jName));
            }
            if(i == 3){
                System.out.println(Color.blue.toColor(Action.tension.jName));
            }
            if(4 <= i && i < 4 + Spell.NUM){
                System.out.println(Color.blue.toColor(Spell.values()[i-4].jName));
            }
            if(i == 4 + Spell.NUM){
                System.out.println(Color.blue.toColor("必殺技"));
            }
            if(4 + Spell.NUM < i && i <= 4 + Spell.NUM + Special.NUM){
                System.out.println(Color.blue.toColor(Special.values()[i - 4 - Spell.NUM - 1].jName));
            }
            if(4 + Spell.NUM + Special.NUM < i && i < 1 + InputAction.ACTION_NUM){
                System.out.println(Color.blue.toColor(Spell.values()[i - (4 + Spell.NUM + 1 + Special.NUM)].jName + "追加"));
            }
            System.out.print(Color.yellow.toColor("勝者 : "));
            printNum(logResult.winnerActionLog.get(i));
            System.out.print("  " + Color.red.toColor("敗者 : "));
            printNum(logResult.loserActionLog.get(i));
            System.out.print("  " + Color.red.toColor("引き分け : "));
            printNum(logResult.drawActionLog.get(i));
            System.out.println();
            System.out.println();
            if(i % 10 == 0){
                Print.input(sc, true);
            }
        }
        for(int i = 0; i <= BattleItem.NUM ; i++){
            if(i == 0){
                System.out.println(Color.blue.toColor("アイテム未使用"));
            }else{
                System.out.println(Color.blue.toColor(BattleItem.values()[i - 1].jName));
            }
            System.out.print(Color.red.toColor("勝者 : "));
            printNum(logResult.winnerItemLog.get(i));
            System.out.print("  " + Color.red.toColor("敗者 : "));
            printNum(logResult.loserItemLog.get(i));
            System.out.print("  " + Color.red.toColor("引き分け : "));
            printNum(logResult.drawItemLog.get(i));
            System.out.println();
            System.out.println();
        }
        System.out.println(Color.blue.toColor(Action.spell.jName + "使用率"));
        System.out.print(Color.red.toColor("勝者 : "));
        System.out.print(logResult.winnerSpellSelect);
        System.out.print("  " + Color.red.toColor("敗者 : "));
        System.out.print(logResult.loserSpellSelect);
        System.out.print("  " + Color.red.toColor("引き分け : "));
        System.out.print(logResult.drawSpellSelect);
        System.out.println();
        System.out.println();
        for(int i = 0; i < Spell.NUM; i++){
            Spell key = Spell.values()[i];
            System.out.println(Color.blue.toColor(key.jName + "採用率"));
            System.out.print(Color.red.toColor("勝者 : "));
            System.out.print(logResult.winnerAdoptionSpell.get(key));
            System.out.print("  " + Color.red.toColor("敗者 : "));
            System.out.print(logResult.loserAdoptionSpell.get(key));
            System.out.print("  " + Color.red.toColor("引き分け : "));
            System.out.print(logResult.drawAdoptionSpell.get(key));
            System.out.println();
            System.out.println();
            if(i % 10 == 0){
                Print.input(sc, true);
            }
        }
        for(int i = 0; i < Success.NUM; i++){
            Success key = Success.values()[i];
            System.out.println(Color.blue.toColor(key.jName));
            System.out.print(Color.red.toColor("勝者 : "));
            System.out.print(logResult.winnerSuccess.get(key));
            System.out.print("  " + Color.red.toColor("敗者 : "));
            System.out.print(logResult.loserSuccess.get(key));
            System.out.print("  " + Color.red.toColor("引き分け : "));
            System.out.print(logResult.drawSuccess.get(key));
            System.out.println();
            System.out.println();
            if(i % 10 == 0){
                Print.input(sc, true);
            }
        }
        System.out.println(Color.blue.toColor("平均ステータス"));
        System.out.println(Color.red.toColor("勝者 : "));
        for(MainStatus key : MainStatus.values()){
            System.out.println("    " + key.jName + logResult.winnerStatus.get(key));
        }
        System.out.println(Color.red.toColor("敗者 : "));
        for(MainStatus key : MainStatus.values()){
            System.out.println("    " + key.jName + logResult.loserStatus.get(key));
        }
        System.out.print(Color.red.toColor("引き分け : "));
        for(MainStatus key : MainStatus.values()){
            System.out.println("    " + key.jName+ logResult.drawStatus.get(key));
        }
        System.out.println();
        System.out.println();
    }

    private static void printAll(List<BattleLog> log, Scanner scanner){
                /*
        BattleLogForAI logForAI = new BattleLogForAI(log);
        for(int i = 0; i <= InputAction.ACTION_NUM ; i++){
            if(i == 0){
                System.out.println(Color.blue.toColor(Action.escape.jName));
            }
            if(i == 1){
                System.out.println(Color.blue.toColor(Action.attack.jName));
            }
            if(i ==2){
                System.out.println(Color.blue.toColor(Action.defense.jName));
            }
            if(i == 3){
                System.out.println(Color.blue.toColor(Action.charge.jName));
            }
            if(4 <= i && i < 4 + Spell.NUM){
                System.out.println(Color.blue.toColor(Spell.values()[i-4].jName));
            }
            if(i == 4 + Spell.NUM){
                System.out.println(Color.blue.toColor(Action.special.jName));
            }
            if(4 + Spell.NUM < i && i <= 4 + Spell.NUM + Special.NUM){
                System.out.println(Color.blue.toColor(Special.values()[i - 4 - Spell.NUM - 1].jName));
            }
            if(4 + Spell.NUM + Special.NUM < i && i < 1 + InputAction.ACTION_NUM){
                System.out.println(Color.blue.toColor(Spell.values()[i - (4 + Spell.NUM + 1 + Special.NUM)].jName + "追加"));
            }
            System.out.println("\n" + Print.toRed("self"));
            printStatus(logForAI.p1ActionLog.get(i));
            System.out.println("\n" + Print.toRed("enemy"));
            printStatus(logForAI.p2ActionLog.get(i));
        }
        for(int i = 0; i <= BattleItem.NUM ; i++){
            if(i == 0){
                System.out.println(Color.blue.toColor(Action.item.jName + "未使用"));
            }else{
                System.out.println(Color.blue.toColor(BattleItem.values()[i - 1].jName));
            }
            System.out.println("\n" + Print.toRed("self"));
            printStatus(logForAI.p1ItemLog.get(i));
            System.out.println("\n" + Print.toRed("enemy"));
            printStatus(logForAI.p2ItemLog.get(i));
        }
        */


        BattleLogResult logResult = new BattleLogResult(log);
        for(int i = 0; i <= InputAction.ACTION_NUM ; i++){
            if(i == 0){
                System.out.println(Color.blue.toColor("逃げる"));
            }
            if(i == 1){
                System.out.println(Color.blue.toColor(Action.attack.jName));
            }
            if(i ==2){
                System.out.println(Color.blue.toColor(Action.defense.jName));
            }
            if(i == 3){
                System.out.println(Color.blue.toColor(Action.tension.jName));
            }
            if(4 <= i && i < 4 + Spell.NUM){
                System.out.println(Color.blue.toColor(Spell.values()[i-4].jName));
            }
            if(i == 4 + Spell.NUM){
                System.out.println(Color.blue.toColor("必殺技"));
            }
            if(4 + Spell.NUM < i && i <= 4 + Spell.NUM + Special.NUM){
                System.out.println(Color.blue.toColor(Special.values()[i - 4 - Spell.NUM - 1].jName));
            }
            if(4 + Spell.NUM + Special.NUM < i && i < 1 + InputAction.ACTION_NUM){
                System.out.println(Color.blue.toColor(Spell.values()[i - (4 + Spell.NUM + 1 + Special.NUM)].jName + "追加"));
            }
            System.out.println("\n" + Color.red.toColor("勝者"));
            printStatus(logResult.winnerActionLog.get(i));
            System.out.println("\n" + Color.red.toColor("敗者"));
            printStatus(logResult.loserActionLog.get(i));
            System.out.println("\n" + Color.red.toColor("引き分け"));
            printStatus(logResult.drawActionLog.get(i));
        }
        for(int i = 0; i <= BattleItem.NUM ; i++){
            if(i == 0){
                System.out.println(Color.blue.toColor("アイテム未使用"));
            }else{
                System.out.println(Color.blue.toColor(BattleItem.values()[i - 1].jName));
            }
            System.out.println("\n" + Color.red.toColor("勝者"));
            printStatus(logResult.winnerItemLog.get(i));
            System.out.println("\n" + Color.red.toColor("敗者"));
            printStatus(logResult.loserItemLog.get(i));
            System.out.println("\n" + Color.red.toColor("引き分け"));
            printStatus(logResult.drawItemLog.get(i));
        }
    }

    private static void printNum(StatusLog log){
        if(log != null){
            System.out.print("使用回数 " + log.actionCount);
        }
    }
    private static void printStatus(StatusLog log){
        try{
            if(log != null){
                System.out.println("使用回数 : " + log.actionCount);
                System.out.println("\n使用率 : " + log.actionRate);
                Thread.sleep(sleep);
                System.out.println("\n" + Action.spell.jName + "レベル");
                for(Spell key : Spell.values()){
                    if(key != Spell.NULL){
                        System.out.print(" " + key.jName + " : " + log.spellLevel.get(key));
                    }
                }
                Thread.sleep(sleep);
                System.out.println("\n\nメインステータス");
                for(MainStatus key : MainStatus.values()){
                    System.out.print(" " + key.jName + " : " + log.beforeMainStatus.get(key) + "→" + log.afterMainStatus.get(key));
                }
                Thread.sleep(sleep);
                System.out.println("\n\nバトルステータス");
                for(BattleStatus key : BattleStatus.values()){
                    System.out.print(" " + key.status.jName + " : " + log.beforeBattleStatus.get(key) + "→" + log.afterBattleStatus.get(key));
                }
                Thread.sleep(sleep);
                System.out.println("\n\n能力変化");
                for(StateChangeStatus key : StateChangeStatus.values()){
                    System.out.println(" " + key.status.status.jName);
                    System.out.print(" ");
                    for(StatusCounter counter : StatusCounter.values()){
                        System.out.print(" " + counter.name() + " : " + log.beforeStateChangeStatus.get(key) + "→" + log.afterStateChangeStatus.get(key));
                    }
                    System.out.println();
                }
                Thread.sleep(sleep);
                System.out.println("\n\n状態異常");
                for(AbnormalState key : AbnormalState.values()){
                    System.out.println(" " + key.jName);
                    System.out.print(" ");
                    for(AbnormalStateCounter counter : AbnormalStateCounter.values()){
                        System.out.print(" " + counter.name() + " : " + log.beforeStateAbnormal.get(key).get(counter) + "→" + log.afterStateAbnormal.get(key).get(counter));
                    }
                    System.out.println();
                }
                Thread.sleep(sleep);
                System.out.println("\n\n一時変化");
                for(ActionState key : ActionState.values()){
                    System.out.println(" " + key.name());
                    System.out.print(" ");
                    for(ActionStateCounter counter : ActionStateCounter.values()){
                        System.out.print(" " + counter.name() + " : " + log.beforeStateAction.get(key).get(counter) + "→" + log.afterStateAction.get(key).get(counter));
                    }
                    System.out.println();
                }
                Thread.sleep(sleep);
                System.out.println("\n\nフィールド");
                for(Field key : Field.values()){
                    System.out.println(" " + key.jName);
                    System.out.print(" ");
                    for(FieldCounter counter : FieldCounter.values()){
                        System.out.print(" " + counter.name() + " : " + log.beforeField.get(key).get(counter) + "→" + log.afterField.get(key).get(counter));
                    }
                    System.out.println();
                }
                Thread.sleep(sleep);
                System.out.println("\n\n" + Action.spell.jName + "スロット");
                for(Spell key : Spell.values()){
                    if(key != Spell.NULL){
                        System.out.print(" " + key.jName + " : " + log.beforeSpellSlot.get(key) + "→" + log.afterSpellSlot.get(key));
                    }
                }
                Thread.sleep(sleep);
                System.out.println("\n\n所持アイテム");
                for(BattleItem key : BattleItem.values()){
                    System.out.print(" " + key.jName + " : " + log.beforeItemList.get(key) + "→" + log.afterItemList.get(key));
                }
            }else{
                System.out.println("行動なし");
            }
        }catch(InterruptedException e){

        }
        System.out.println();
    }
}
