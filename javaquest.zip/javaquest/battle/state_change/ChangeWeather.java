package battle.state_change;

import battle.State;
import data.action.Spell;
import text.Print;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public final class ChangeWeather {
    public enum Weather{
        Fire("火", 0, 0),
        Wind("風", 0, 0),
        Stone("地", 0, 0),
        Cure("癒", 0, 0),
        Abnormal("異", 0, 0),
        NULL("無", 1, Integer.MAX_VALUE),
        ;
        public final String jName;// 名前
        public final Map<WeatherCounter,Integer> DEFAULT_NUM;// 初期値（フラグ・残りターン）
        private Weather(String jName, int flag, int count){
            this.jName = jName;
            this.DEFAULT_NUM = new HashMap<WeatherCounter, Integer>(){{
                put(WeatherCounter.flag, flag);
                put(WeatherCounter.count, count);
            }};
        }
    }
    // 呪文との関係を示す用(state, spell)
    public enum WeatherRelation{
        // 発動不可
        nonActivation(
            new Weather[][]{
                new Weather[]{Weather.Fire, Weather.Abnormal},
                new Weather[]{Weather.Wind, Weather.Abnormal},
                new Weather[]{Weather.Stone, Weather.Abnormal},
                new Weather[]{Weather.Cure, Weather.Abnormal},
            }, "発動できなかった", "x", 0
        ),
        // 2倍になった後無天候
        bombEffect(
            new Weather[][]{
                new Weather[]{Weather.Fire, Weather.Fire},
                new Weather[]{Weather.Wind, Weather.Wind},
                new Weather[]{Weather.Stone, Weather.Stone},
            }, "効果が倍増した", "↑'", 2
        ),
        // 半減
        littleEffect(
            new Weather[][]{
                new Weather[]{Weather.Fire, Weather.Stone},
                new Weather[]{Weather.Wind, Weather.Fire},
                new Weather[]{Weather.Stone, Weather.Wind},
            }, "効果が半減した", "↓", 0.5
        ),
        // 倍増
        largeEffect(
            new Weather[][]{
                new Weather[]{Weather.Fire, Weather.Wind},
                new Weather[]{Weather.Wind, Weather.Stone},
                new Weather[]{Weather.Stone, Weather.Fire},
                new Weather[]{Weather.Cure, Weather.Fire},
                new Weather[]{Weather.Cure, Weather.Wind},
                new Weather[]{Weather.Cure, Weather.Stone},
            }, "効果が倍増した", "↑", 2
        ),
        // 関係なし
        noRelation(new Weather[0][0], "", "", 1),
        ;
        public final Weather[][] weatherStateSpellPairs;// 天候の組み合わせ
        public final String explain;// 説明文
        public final String miniExplain;// 記号説明
        public final double coef;// 効果倍率係数
        WeatherRelation(Weather[][] weatherStateSpellPairs, String explain, String miniExplain, double coef){
            this.weatherStateSpellPairs = weatherStateSpellPairs;
            this.explain = explain;
            this.miniExplain = miniExplain;
            this.coef = coef;
        }
    }
    public enum WeatherCounter{
        flag,// その天候かどうか
        count// 残りターン
    }
    // 天候変化
    public static void onset(State state, Spell spell, int count, boolean text, Scanner scanner){
        Weather weather = spell.weather;
        if(weather == Weather.NULL){
            return;
        }
        if(makeRelation(ChangeWeather.nowWeather(state), spell.weather, false, scanner) == WeatherRelation.bombEffect){
            allZero(state);
            state.getWeather().replace(Weather.NULL, new HashMap<WeatherCounter, Integer>(){{
                put(WeatherCounter.flag, 1);
                put(WeatherCounter.count, Integer.MAX_VALUE);
            }});
            Print.println("天候と呪文が打ち消し合って" + Weather.NULL.jName + "天候になった", true, Print.highSpeed, text);
            return;
        }
        allZero(state);
        Map<WeatherCounter, Integer> counter = new HashMap<WeatherCounter, Integer>(){{
            put(WeatherCounter.flag, 1);
            put(WeatherCounter.count, count);
        }};
        state.getWeather().replace(weather, counter);
        Print.println(weather.jName + "天候になった", true, Print.highSpeed, text);
    }

    // 現在の天候を出力
    public static Weather nowWeather(State state){
        List<Weather> weatherList = new ArrayList<Weather>();
        for(Weather key : state.getWeather().keySet()){
            if(state.getWeather().get(key).get(WeatherCounter.flag) == 1){
                weatherList.add(key);
            }
        }
        if(weatherList.size() == 1){
            return weatherList.get(0);
        }else{
            System.out.println("発生している天候の数が不正です");
            return null;
        }
    }

    // 天候の関係を出力
    public static WeatherRelation makeRelation(Weather stateWeather, Weather spellWeather, boolean text, Scanner scanner){
        //weatherStateSpellPairsはstate, spellの順番
        for(WeatherRelation relation : WeatherRelation.values()){
            Weather[][] weatherStateSpellPairs = relation.weatherStateSpellPairs;
            for(Weather[] weatherStateSpellPair : weatherStateSpellPairs){
                if(stateWeather == weatherStateSpellPair[0] && spellWeather == weatherStateSpellPair[1]){
                    Print.println(stateWeather.jName + "天候により" + spellWeather.jName + "属性の呪文は" + relation.explain, true, Print.highSpeed, text);
                    Print.nextLine(scanner, text);
                    return relation;
                }
            }
        }
        return WeatherRelation.noRelation;
    }

    // 現在の天候に対して全天候の関係を出力
    public static Map<Weather, WeatherRelation> makeAllRelation(Weather stateWeather){
        Map<Weather, WeatherRelation> relations = new HashMap<>();
        for(Weather spellWeather : Weather.values()){
            relations.put(spellWeather, makeRelation(stateWeather, spellWeather, false, null));
        }
        return relations;
    }

    // 現在の天候に対して全天候の関係を記号表記で文字列出力
    public static String makeAllRelationString(Weather stateWeather){
        String txt = "";
        Map<Weather, WeatherRelation> relations = makeAllRelation(stateWeather);
        WeatherRelation relation;
        for(Weather spellWeather : Weather.values()){
            relation = relations.get(spellWeather);
            if(relation != WeatherRelation.noRelation){
                txt += spellWeather.jName + relation.miniExplain + " ";
            }
        }
        return txt;
    }

    // 天候を初期化
    public static void reset(State state){
        Map<Weather,Map<WeatherCounter, Integer>> resetWeather = new HashMap<>(){{
            for(Weather weather : Weather.values()){
                put(weather, new HashMap<>(){{
                    for(WeatherCounter weatherCounter : WeatherCounter.values()){
                        put(weatherCounter, weather.DEFAULT_NUM.get(weatherCounter));
                    }
                }});
            }
        }};
        state.setWeather(resetWeather);
    }

    // 天候を全て0にする（無天候ですらなくなるため、その後に天候を設定する必要がある）
    public static void allZero(State state){
        Map<Weather,Map<WeatherCounter, Integer>> zeroWeather = new HashMap<>(){{
            for(Weather weather : Weather.values()){
                put(weather, new HashMap<>(){{
                    for(WeatherCounter weatherCounter : WeatherCounter.values()){
                        put(weatherCounter, 0);
                    }
                }});
            }
        }};
        state.setWeather(zeroWeather);
    }

    // ターン終了処理
    public static void turnEndProcess(State state, boolean text, Scanner scanner){
        Map<WeatherCounter, Integer> counter = state.getWeather().get(nowWeather(state));
        counter.replace(WeatherCounter.count, counter.get(WeatherCounter.count) - 1);
        if(counter.get(WeatherCounter.count) <= 0){
            
            Print.println(nowWeather(state).jName + "天候が終了した", true, Print.highSpeed, text);
            Print.nextLine(scanner, text);
            reset(state);
            return;
        }
        state.getWeather().replace(nowWeather(state), counter);
    }
}
