package battle.state_change;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import battle.State;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeField.Field;
import battle.state_change.ChangeField.FieldCounter;
import character.Character;
import character.Character.BattleStatus;
import character.Character.MainStatus;
import character.Player.TrainStatus;
import text.Print;

//A,B,Sの能力変化の処理
public final class ChangeBattleStatus {
    public enum StateChangeStatus{
        A(BattleStatus.a),// 攻撃力
        D(BattleStatus.d),// 防御力
        S(BattleStatus.s),// 素早さ
        ;
        public final BattleStatus status;// 対応する能力増加効果等込みステータスのカテゴリ
        public final String jName;
        private StateChangeStatus(BattleStatus status){
            this.status = status;
            this.jName = status.jName;
        }
    }
    public enum StatusCounter{
        buffRate,// 能力増加効果量
        turnCount// 残りターン
    }

    // ディープコピー
    public static List<Map<StateChangeStatus, Map<StatusCounter, Double>>> deepCopyStateChangeStatus(List<Map<StateChangeStatus, Map<StatusCounter, Double>>> stateChangeStatus){
        return new ArrayList<>(){{
            for(Map<StateChangeStatus, Map<StatusCounter, Double>> buff : stateChangeStatus){
                add(new EnumMap<>(StateChangeStatus.class){{
                    for(StateChangeStatus key : buff.keySet()){{
                        put(key, new EnumMap<>(buff.get(key)));
                    }}
                }});
            }
        }};
    }

    // 特定のステータスの能力増加効果量を計算
    public static double calculateBuffRate(List<Map<StateChangeStatus, Map<StatusCounter, Double>>> stateChangeStatus, StateChangeStatus category){
        double buffRate = 0;
        List<Double> buffList = new ArrayList<>();
        List<Double> debuffList = new ArrayList<>();
        for(Map<StateChangeStatus, Map<StatusCounter, Double>> buff : stateChangeStatus){
            if(buff.keySet().contains(category)){
                if(buff.get(category).get(StatusCounter.buffRate) > 0){
                    buffList.add(buff.get(category).get(StatusCounter.buffRate));
                }else{
                    debuffList.add(buff.get(category).get(StatusCounter.buffRate));
                }
            }
        }
        if(buffList.size() != 0){
            for(double buff : buffList){
                buffRate += buff;
            }
        }else if(debuffList.size() != 0){
            double rate = 1;
            for(double debuff : debuffList){
                rate *= (100.0 + debuff) / 100.0;
            }
            buffRate = 100 * (rate - 1);
        }
        return buffRate;
    }

    // 特定のステータスの能力増加効果の残りターンを出力（そのステータスの能力変化が一つしかない前提）
    public static int getBuffTurn(List<Map<StateChangeStatus, Map<StatusCounter, Double>>> stateChangeStatus, StateChangeStatus category){
        for(Map<StateChangeStatus, Map<StatusCounter, Double>> buff : stateChangeStatus){
            if(buff.keySet().contains(category)){
                return (int)Math.round(buff.get(category).get(StatusCounter.turnCount));
            }
        }
        return -1;
    }

    // 特定のステータスの能力増加効果・能力減少効果を解除
    public static void releaseBuffAndDebuff(List<Map<StateChangeStatus, Map<StatusCounter, Double>>> stateChangeStatus, StateChangeStatus category, boolean text){
        List<Map<StateChangeStatus, Map<StatusCounter, Double>>> releaseBuffAndDebuffList = new ArrayList<Map<StateChangeStatus, Map<StatusCounter, Double>>>();
        for(Map<StateChangeStatus, Map<StatusCounter, Double>> buff : stateChangeStatus){
            if(buff.keySet().contains(category)){
                releaseBuffAndDebuffList.add(buff);
            }
        }
        for(Map<StateChangeStatus, Map<StatusCounter, Double>> buff : releaseBuffAndDebuffList){
            stateChangeStatus.remove(buff);
        }
        // if(releaseDebuffList.size() != 0){
        //     Print.println(category.jName + "の能力減少効果が全て解除された。", Print.highSpeed, text);
        // }
    }

    // 能力減少効果を全て解除
    public static void releaseAllDebuff(List<Map<StateChangeStatus, Map<StatusCounter, Double>>> stateChangeStatus, boolean text){
        for(Map<StateChangeStatus, Map<StatusCounter, Double>> buff : new ArrayList<>(stateChangeStatus)){
            if(buff.get(buff.keySet().toArray(new StateChangeStatus[0])[0]).get(StatusCounter.buffRate) < 0){
                stateChangeStatus.remove(buff);
            }
        }
    }

    // 能力増加効果・能力減少効果が掛かる
    public static void onset(State state, boolean self_is_player1, StateChangeStatus category, double buffRate, int turnCount, boolean text, Scanner scanner){
        Character self = state.getPlayer(self_is_player1);
        List<Map<StateChangeStatus, Map<StatusCounter, Double>>> stateChangeStatus = self.getStateChangeStatus();
        boolean up = buffRate > 0;
        String udText = up ? "増加した！" : "減少した！";
        if(up){
            releaseBuffAndDebuff(stateChangeStatus, category, text);
        }else{
            if(calculateBuffRate(stateChangeStatus, category) > 0){
                Print.println(self.getJName() + "の能力は減少しなかった" + Print.sleep(2), true, Print.highSpeed, text);
                
                return;
            }else if(calculateBuffRate(stateChangeStatus, category) < 0){
                Print.println(self.getJName() + "の能力は既に減少している" + Print.sleep(2), true, Print.highSpeed, text);
                
                return;
            }
        }
        stateChangeStatus.add(new EnumMap<>(StateChangeStatus.class){{
            put(category, new EnumMap<>(StatusCounter.class){{
                put(StatusCounter.buffRate, buffRate);
                put(StatusCounter.turnCount, (double)(turnCount + 1));// 入力ターンは発動したターンを含めずにターン数を入力
            }});
        }});
        Print.println(self.getJName() + "は" + category.status.status.jName + "が" + udText + Print.sleep(2), true, Print.middleSpeed, text);
        
        self.setStateChangeStatus(stateChangeStatus);
        state.setPlayer(self, self_is_player1);
        reset(state);
    }

    // 能力増加効果・能力減少効果からステータスを再計算
    public static void execute(Character self){
        Map<BattleStatus, Integer> battleStatus = self.getBattleStatus();
        for(StateChangeStatus category : StateChangeStatus.values()){
            battleStatus.replace(category.status, (int)Math.round(battleStatus.get(category.status) * (100 + calculateBuffRate(self.getStateChangeStatus(), category)) / 100));
        }
        self.setBattleStatus(battleStatus);
    }

    // ターン終了時の処理
    public static void turnEndProcess(Character self, boolean text, Scanner scanner){
        List<Map<StateChangeStatus, Map<StatusCounter, Double>>> stateChangeStatus = self.getStateChangeStatus();
        List<Map<StateChangeStatus, Map<StatusCounter, Double>>> removeList = new ArrayList<>();
        Map<StatusCounter, Double> miniBuff;
        int remainingTurn;
        for(int i = 0; i < stateChangeStatus.size(); i++){
            Map<StateChangeStatus, Map<StatusCounter, Double>> buff = stateChangeStatus.get(i);
            for(StateChangeStatus category : buff.keySet()){
                miniBuff = buff.get(category);
                remainingTurn = (int)(miniBuff.get(StatusCounter.turnCount) - 1);
                if(remainingTurn == 0){
                    buff.remove(category);
                    if(miniBuff.get(StatusCounter.buffRate) > 0){
                        Print.println(self.getJName() + "の" + category.jName + "増加が無くなった", true, Print.highSpeed, text);
                    }else{
                        Print.println(self.getJName() + "の" + category.jName + "減少が無くなった", true, Print.highSpeed, text);
                    }
                    if(buff.size() == 0){
                        removeList.add(buff);
                    }
                }else{
                    miniBuff.replace(StatusCounter.turnCount, miniBuff.get(StatusCounter.turnCount) - 1);
                }
            }
        }
        for(Map<StateChangeStatus, Map<StatusCounter, Double>> removeBuff : removeList){
            stateChangeStatus.remove(removeBuff);
        }
        self.setStateChangeStatus(stateChangeStatus);
    }


    // 能力増加効果・能力減少効果・ギア数など全て込みでステータスを再計算
    public static void reset(State state){
        Character player1 = state.getPlayer1();
        Character player2 = state.getPlayer2();
        player1.readyBattleState();
        player2.readyBattleState();
        if(state.getField().get(Field.ReverseField).get(FieldCounter.flag) == 1){
            player1.getBattleStatus().replace(BattleStatus.s, player2.getMainStatus().get(MainStatus.s));
            player2.getBattleStatus().replace(BattleStatus.s, player1.getMainStatus().get(MainStatus.s));
        }
        for(Character SE: new Character[]{player1, player2}){
            execute(SE);
            for(ActionState category: ActionState.values()){
                ChangeActionState.execute(SE, category);
            }
        }
        state.setPlayer(player1, player2);
    }

    // 能力変化しているかどうかを判定する
    public static boolean checkAnyBuff(Character self){
        return checkBuffNum(self) != 0;
    }

    // 能力変化の数を判定する
    public static int checkBuffNum(Character self){
        return self.getStateChangeStatus().size();
    }
}
