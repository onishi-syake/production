package battle.state_change;

import java.util.Random;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import battle.state_change.ChangeAbnormalState.AbnormalState;
import battle.state_change.ChangeAbnormalState.AbnormalStateCounter;
import battle.state_change.ChangeBattleStatus.StateChangeStatus;
import battle.state_change.ChangeBattleStatus.StatusCounter;
import battle.state_change.ChangeField.Field;
import battle.state_change.ChangeField.FieldCounter;
import battle.CalculateDamage;
import battle.State;
import battle.InputAction.Action;
import character.Character;
import character.Character.BattleStatus;
import character.Character.MainStatus;
import character.Player.TrainStatus;
import character.Character.Attribute;
import data.action.Special;
import data.action.Spell;
import data.item.BattleItem;
import log.BattleTemporaryLog;
import log.OneTurnBattleLog.Success;
import text.Print;

//防御とテンションの処理。
public final class ChangeActionState {
    public enum ActionState{
        Defense(0,0,0),// 防御
        sucDef(0,0,0),// 防御成功
        sucSDef(0,0,0),// カウンターシールド成功
        SpecialDefense(0,0,0),// カウンターシールド
        Tension(0,0,0),// 溜める
        sucTen(0,0,0),// 溜める成功
        SpecialTension(0,0,0),// フルチャージ
        Stone(0,0,0),//ストーン
        Rock(0,0,0),//ロック
        Lava(0,0,0),//ラヴァ
        Meteor(0,0,0),//メテオ
        Update(0, 0, 0),// アップデート
        On_SpellReflect(0,0,0),// スペルリフレクト
        On_TheEnd(0,0,0),// オン・ジエンド
        Attacked(0,0,0),// 攻撃された
        oldChargeSpecial(0,0,0),// 旧必殺技
        newChargeSpecial(0, 0, 0),// 新必殺技
        UsedSpecial(0,0,0),// 旧必殺技を使ったか
        UseItem(0,0,0),// アイテムを使ったか
        Swoon(0,0,0),// 怯み
        Escape(0,0,0)// 逃げる
        ;

        public final Map<ActionStateCounter,Integer> DEFAULT_NUM;// 初期値
        private ActionState(int flag, int count, int atk){
            this.DEFAULT_NUM = Collections.unmodifiableMap(new EnumMap<>(ActionStateCounter.class){{put(ActionStateCounter.flag,flag);put(ActionStateCounter.count,count);put(ActionStateCounter.damage,atk);}});
        }
    }
    public enum ActionStateCounter{
        flag,// その状態かどうか
        count,// ターン数
        damage// ダメージ（石系呪文用） 
    }
    // アップデートのバックアップ
    public class UpdateBackup{
        private Attribute attribute;// 必殺技
        private Map<MainStatus, Integer> mainStatus;// 元のステータス
        private Map<BattleStatus, Integer> battleStatus;// 戦闘能力増加効果等込みのステータス
        private List<Map<StateChangeStatus, Map<StatusCounter, Double>>> stateChangeStatus;// 能力増加効果・能力減少効果
        private Map<AbnormalState, Map<AbnormalStateCounter, Integer>> stateAbnormal;// 状態異常
        private Map<ActionState, Map<ActionStateCounter, Integer>> stateAction;// 行動による変化
        private List<Spell> spellSlot;// 呪文スロット
        private Map<BattleItem, Integer> itemList;// アイテム
        private int lastAction;// 前回行動
        private int secondLastAction;// 前々回行動
        // バックアップ作成
        public UpdateBackup(Character chara){
            this.attribute = chara.getAttribute();
            this.mainStatus = new EnumMap<>(chara.getMainStatus());
            this.battleStatus = new EnumMap<>(chara.getBattleStatus());
            this.stateChangeStatus = ChangeBattleStatus.deepCopyStateChangeStatus(chara.getStateChangeStatus());
            this.stateAbnormal = new HashMap<AbnormalState, Map<AbnormalStateCounter, Integer>>(){{
                for(AbnormalState key : AbnormalState.values()){
                    put(key, new EnumMap<>(chara.getStateAbnormal().get(key)));
                }
            }};
            this.stateAction = new HashMap<ActionState, Map<ActionStateCounter, Integer>>(){{
                for(ActionState key : ActionState.values()){
                    if(key == ActionState.Update){
                        put(key, new EnumMap<ActionStateCounter, Integer>(ActionStateCounter.class){{
                            put(ActionStateCounter.flag, 0);
                            put(ActionStateCounter.count, 0);
                            put(ActionStateCounter.damage, 0);
                        }});
                        continue;
                    }
                    put(key, new EnumMap<>(chara.getStateAction().get(key)));
                }
            }};
            this.spellSlot = new ArrayList<>(chara.getSpellSlot());
            this.itemList = new EnumMap<>(chara.getItemList());
            this.lastAction = chara.getLastAction();
            this.secondLastAction = chara.getSecondLastAction();
        }
        //　コピーコンストラクタ
        public UpdateBackup(UpdateBackup updateBackup){
            this.attribute = updateBackup.attribute;
            this.mainStatus = new EnumMap<>(updateBackup.mainStatus);
            this.battleStatus = new EnumMap<>(updateBackup.battleStatus);
            this.stateChangeStatus = new ArrayList<>(){{
                for(Map<StateChangeStatus, Map<StatusCounter, Double>> buff : updateBackup.stateChangeStatus){
                    add(new EnumMap<>(StateChangeStatus.class){{
                        for(StateChangeStatus key : buff.keySet()){{
                            put(key, new EnumMap<>(buff.get(key)));
                        }}
                    }});
                }
            }};
            this.stateAbnormal = new HashMap<AbnormalState, Map<AbnormalStateCounter, Integer>>(){{
                for(AbnormalState key : AbnormalState.values()){
                    put(key, new EnumMap<>(updateBackup.stateAbnormal.get(key)));
                }
            }};
            this.stateAction = new HashMap<ActionState, Map<ActionStateCounter, Integer>>(){{
                for(ActionState key : ActionState.values()){
                    put(key, new EnumMap<>(updateBackup.stateAction.get(key)));
                }

            }};
            this.spellSlot = new ArrayList<>(updateBackup.spellSlot);
            this.itemList = new EnumMap<>(updateBackup.itemList);
            this.lastAction = updateBackup.lastAction;
            this.secondLastAction = updateBackup.secondLastAction;
        }

        // バックアップを復元
        public void returnBackup(Character chara, boolean text){
            Print.println(chara.getJName() + "はバックアップを復元した", Print.middleSpeed, text);
            chara.setAttribute(this.attribute);
            chara.setMainStatus(this.mainStatus);
            chara.setBattleStatus(this.battleStatus);
            chara.setStateChangeStatus(this.stateChangeStatus);
            chara.setStateAbnormal(this.stateAbnormal);
            chara.setStateAction(this.stateAction);
            chara.setSpellSlot(this.spellSlot);
            chara.setItemList(this.itemList);
            chara.setLastAction(this.secondLastAction);
            chara.setLastAction(this.lastAction);
            chara.setUpdateBackup(null);
        }
    }

    //下限、上限
    public static final double DEFENSE_RATE = 0.25;
    public static final double DEFENSE_VARIANCE = 1.0;

    public static final int addTenBuffSucTenCoef = 1;// 溜める成功時に溜めるのギア増加量が増える量

    // 行動状態フィールドの初期状態
    public static Map<ActionState, Map<ActionStateCounter, Integer>> initializedActionStateMap(){
        return new HashMap<>(){{
            for(ActionState key: ActionState.values()){
                put(key, new EnumMap<>(key.DEFAULT_NUM));
            }
        }};
    }

    //かかった時の処理。
    public static void onset(State state, boolean self_is_player1, boolean enemy_is_player1, ActionState category, BattleTemporaryLog log, boolean text, Scanner scanner, Random rand){
        Character self = state.getPlayer(self_is_player1);
        Character enemy = state.getPlayer(enemy_is_player1);
        Map<BattleStatus, Integer> battleStatus = self.getBattleStatus();
        Map<ActionState, Map<ActionStateCounter, Integer>> stateAction = self.getStateAction();
        Map<ActionStateCounter, Integer> stateActionField = stateAction.get(category);
        Map<ActionStateCounter, Integer> selfTensionField;
        Map<ActionStateCounter, Integer> selfSucTenField;
        Map<ActionStateCounter, Integer> enemyTensionField;
        int addTension;
        switch(category){
            case Defense:
                // Print.println(self.getJName() + "は" + Action.defense.jName + "の態勢に入った" + Print.sleep(2), true, Print.middleSpeed, text);
                // 
                //Print.println(self.jName + "は" + Action.defense.jName + "状態になった", Print.middleSpeed, text);
                break;
            
            case sucDef:
                if(stateAction.get(ActionState.Defense).get(ActionStateCounter.flag) == 0) return;
                // Print.println("", true, Print.highSpeed, text);
                Print.print(self.getJName() + "は", true, Print.middleSpeed, text);
                
                onset(state, !self_is_player1, !enemy_is_player1, ActionState.Swoon, log, text, scanner, rand);

                // // Print.println("<br>" + self.jName + "は"  + Action.defense.jName + "したことにより" + Action.attack.jName + "を無効化し、MPを回復した", Print.middleSpeed, text);
                // selfTensionField = stateAction.get(ActionState.Tension);
                // addTension = 2;
                // // 属性でMP回復量2倍
                // // int MPHealCoef = 1;
                // if(self.getAttribute() == Attribute.D){// TODO 属性封印
                //     // Print.println("<br>防御属性によりMPの回復量が2倍になった！", Print.middleSpeed, text);
                //     // MPHealCoef *= 2;
                //     // addTension *= 2;
                //     // ChangeActionState.onset(state, self_is_player1, enemy_is_player1, ActionState.newChargeSpecial, log, text, scanner, rand);
                // }
                // // CalculateDamage.changeParameter(self, MainStatus.mp, -self.getMainStatus().get(MainStatus.maxMp) * MPHealCoef / 2, text);
                // Print.println("テンションが" + addTension + "こ増えた", Print.middleSpeed, text);
                // selfTensionField.replace(ActionStateCounter.count, selfTensionField.get(ActionStateCounter.count) + addTension);
                // stateAction.replace(ActionState.Tension, selfTensionField);
                log.setSuccess(self_is_player1, true, Success.sucDef);
                break;

            case sucSDef:
                if(stateAction.get(ActionState.SpecialDefense).get(ActionStateCounter.flag) == 0) return;
                if(stateAction.get(ActionState.SpecialDefense).get(ActionStateCounter.flag) == 1 && enemy.getStateAction().get(ActionState.SpecialDefense).get(ActionStateCounter.flag) == 1) return;
                //Print.println("<br>" + self.jName + "は敵の行動を抑え、カウンターを放った", Print.middleSpeed, text);
                Print.println("", true, Print.highSpeed, text);
                Print.println(self.getJName() + "は敵の行動を無効化し、カウンターを放った！" + Print.sleep(2), true, Print.middleSpeed, text);
                
                Special.SpecialAttack.execute(state, self_is_player1, enemy_is_player1, false, log, text, rand, scanner);
                log.setSuccess(self_is_player1, true, Success.sucSDef);
                break;

            case SpecialDefense:
                Print.println(self.getJName() + "は反撃の体勢に入った" + Print.sleep(2), true, Print.middleSpeed, text);
                
                //Print.println(self.jName + "はスペシャルディフェンス状態になった", Print.middleSpeed, text);
                break;

            case Tension:
                if(stateAction.get(ActionState.Attacked).get(ActionStateCounter.flag) == 1){
                    Print.println("しかし、" + Action.attack.jName + "を受けて" + self.getJName() + "は溜められなかった！" + Print.sleep(2), true, Print.middleSpeed, text);
                    
                    break;
                }
                /* Print.print(self.jName + "は", Print.middleSpeed, text);
                for(int i = 0; i < stateActionField.get(ActionStateCounter.count); i++){
                    if(i % 2 == 0){
                        Print.print("とっても", Print.lowSpeed, text);
                    }
                }
                Print.println("溜めるしている", Print.middleSpeed, text); */
                log.setSuccess(self_is_player1, true, Success.sucCha);
                /*if(stateActionField.get(ActionStateCounter.count) >= 7){
                    log.setSuccess(self_is_player1, true, Success.chargeRecovery);
                    mainStatus.replace(MainStatus.hp, mainStatus.get(MainStatus.maxHp));
                    mainStatus.replace(MainStatus.mp, mainStatus.get(MainStatus.maxMp));
                    //BattleItem.Bannnouyaku.execute(state, self_is_player1, enemy_is_player1, text, scanner);
                    stateActionField.replace(ActionStateCounter.count, 0);
                    Print.println("テンションが極まり、HPと精神力が全回復し、状態異常が治癒した", Print.lowSpeed, text);
                    Print.println("テンションが無くなった", Print.lowSpeed, text);
                    break;
                }*/
                int attributeCCoef = 1;
                //属性で増加テンション2倍
                if(self.getAttribute() == Attribute.C){//TODO 属性封印
                    // Print.println("<br>溜める属性によりテンションの増加量が2倍になった！", Print.middleSpeed, text);
                    // Print.nextLine(scanner, text);
                    // attributeCCoef *= 2;
                    // ChangeActionState.onset(state, self_is_player1, enemy_is_player1, ActionState.newChargeSpecial, log, text, scanner, rand);
                }
                addTension = (2 + stateAction.get(ActionState.sucTen).get(ActionStateCounter.count) * addTenBuffSucTenCoef) * attributeCCoef;
                Print.println("テンションが" + addTension + "上昇した！" + Print.sleep(2), true, Print.middleSpeed, text);
                
                Print.nextLine(scanner, text);
                stateActionField.replace(ActionStateCounter.count, stateActionField.get(ActionStateCounter.count) + addTension);
                Print.println("テンションが上昇しやすくなった！" + Print.sleep(2), true, Print.middleSpeed, text);
                
                selfSucTenField = stateAction.get(ActionState.sucTen);
                selfSucTenField.replace(ActionStateCounter.count, selfSucTenField.get(ActionStateCounter.count) + 1);
                stateAction.replace(ActionState.sucTen, selfSucTenField);
                break;

            case sucTen:
                break;

            case SpecialTension:
                if(stateAction.get(ActionState.Attacked).get(ActionStateCounter.flag) == 1){
                    Print.println("しかし、" + Action.attack.jName + "を受けて" + self.getJName() + "は溜められなかった！" + Print.sleep(2), true, Print.middleSpeed, text);
                    
                    break;
                }
                // selfTensionField = stateAction.get(ActionState.Tension);
                // // Print.print(self.jName + "は", Print.middleSpeed, text);
                // // for(int i = 0; selfTensionField.get(ActionStateCounter.count) > i; i++){
                // //     if(i % 2 == 0){
                // //         Print.print("とっても", Print.middleSpeed, text);
                // //     }
                // // }
                // // Print.println("溜めるしている", Print.middleSpeed, text);
                // addTension = 2;
                // Print.println("テンションが" + addTension + "こ増えた", Print.middleSpeed, text);
                // Print.nextLine(scanner, text);
                // selfTensionField.replace(ActionStateCounter.count, selfTensionField.get(ActionStateCounter.count) + addTension);
                // stateAction.replace(ActionState.Tension, selfTensionField);
                // ChangeAbnormalState.onset(state, self_is_player1, AbnormalState.Rapture, log, scanner, text, rand);
                onset(state, self_is_player1, enemy_is_player1, ActionState.Tension, log, text, scanner, rand);
                CalculateDamage.changeParameter(self, MainStatus.hp, -self.getMainStatus().get(MainStatus.maxHp), text);
                CalculateDamage.changeParameter(self, MainStatus.mp, -self.getMainStatus().get(MainStatus.maxMp), text);
                ChangeBattleStatus.releaseAllDebuff(self.getStateChangeStatus(), text);
                for(AbnormalState aState : AbnormalState.values()){
                    if(!aState.good && aState != AbnormalState.Nervous){
                        ChangeAbnormalState.cure(self, aState, text);
                    }
                }
                log.setSuccess(self_is_player1, true, Success.sucSCha);
                break;

            case Stone:
                stateActionField.replace(ActionStateCounter.flag, 2);
                stateActionField.replace(ActionStateCounter.count, stateActionField.get(ActionStateCounter.count) + 1);
                return;

            case Rock:
                stateActionField.replace(ActionStateCounter.flag, 2);
                stateActionField.replace(ActionStateCounter.count, stateActionField.get(ActionStateCounter.count) + 1);
                return;

            case Lava:
                stateActionField.replace(ActionStateCounter.flag, 2);
                stateActionField.replace(ActionStateCounter.count, stateActionField.get(ActionStateCounter.count) + 1);
                return;

            case Meteor:
                stateActionField.replace(ActionStateCounter.flag, 2);
                stateActionField.replace(ActionStateCounter.count, stateActionField.get(ActionStateCounter.count) + 1);
                return;

            case Update:
                Print.println(self.getJName() + "はアップデートを始めた" + Print.sleep(2), true, Print.middleSpeed, text);
                
                stateActionField.replace(ActionStateCounter.count, 5);
                self.setUpdateBackup(new ChangeActionState().new UpdateBackup(self));
                break;

            case On_SpellReflect:
                break;

            case On_TheEnd:
                //Print.println("世界は一度終了した", Print.middleSpeed, text);
                Print.println("このターンは終了した！" + Print.sleep(2), true, Print.middleSpeed, text);
                
                stateActionField.replace(ActionStateCounter.count, 2);
                break;

            case Attacked:
                break;

            case oldChargeSpecial:
                Print.println(self.getJName() + "は必殺技を打つ準備をした" + Print.sleep(2), true, Print.middleSpeed, text);
                
                stateActionField.replace(ActionStateCounter.count, 2);

                Print.println("お互いのテンションは 0 になった！" + Print.sleep(2), true, Print.middleSpeed, text);
                
                selfTensionField = self.getStateAction().get(ActionState.Tension);
                if(selfTensionField.get(ActionStateCounter.count) != 0){
                    selfTensionField.replace(ActionStateCounter.flag, -1);
                }
                selfTensionField.replace(ActionStateCounter.count, 0);
                stateAction.replace(ActionState.Tension, selfTensionField);

                enemyTensionField = enemy.getStateAction().get(ActionState.Tension);
                if(enemyTensionField.get(ActionStateCounter.count) != 0){
                    enemyTensionField.replace(ActionStateCounter.flag, -1);
                }
                enemyTensionField.replace(ActionStateCounter.count, 0);
                enemy.getStateAction().replace(ActionState.Tension, enemyTensionField);
                break;

            case newChargeSpecial:
                int chargeSpecialNum = 2;
                if(stateActionField.get(ActionStateCounter.count) < chargeSpecialNum){
                    stateActionField.replace(ActionStateCounter.count, stateActionField.get(ActionStateCounter.count) + 1);
                }
                if(stateActionField.get(ActionStateCounter.count) != chargeSpecialNum){
                    return;
                }
                break;

            case UsedSpecial:
                break;

            case UseItem:
                break;

            case Swoon:
                Print.println(self.getJName() + "を怯ませた！" + Print.sleep(2), true, Print.middleSpeed, text);
                stateActionField.replace(ActionStateCounter.count, 2);
                break;

            case Escape:
                break;
        }
        stateActionField.replace(ActionStateCounter.flag, 1);
        self.setBattleStatus(battleStatus);
        stateAction.replace(category, stateActionField);
        self.setStateAction(stateAction);
        state.setPlayer(self, self_is_player1);
        state.setPlayer(enemy, enemy_is_player1);
        ChangeBattleStatus.reset(state);
    }

    //効果のメイン実行処理
    public static void execute(Character self, ActionState category){
        Map<BattleStatus, Integer> battleStatus = self.getBattleStatus();
        Map<MainStatus, Integer> mainStatus = self.getMainStatus();
        Map<ActionState, Map<ActionStateCounter, Integer>> stateAction = self.getStateAction();
        Map<ActionStateCounter, Integer> stateActionField = stateAction.get(category);
        switch(category){
            case Defense:
            case sucDef:
            case sucSDef:
            case SpecialDefense:
                break;

            case Tension:
                if(stateActionField.get(ActionStateCounter.count) == 0) return;                
                battleStatus.replace(BattleStatus.a, battleStatus.get(BattleStatus.a) * stateActionField.get(ActionStateCounter.count));
                int newS = (int)(battleStatus.get(BattleStatus.s) * (1 + 0.01 * Math.pow(2, stateActionField.get(ActionStateCounter.count))));
                if(newS == battleStatus.get(BattleStatus.s).intValue()){
                    newS = battleStatus.get(BattleStatus.s) + 1;
                }
                battleStatus.replace(BattleStatus.s, newS);
                break;

            case sucTen:
            case SpecialTension:
            case Stone:
            case Rock:
            case Lava:
            case Meteor:
            case Update:
            case On_SpellReflect:
            case On_TheEnd:
            case Attacked:
            case oldChargeSpecial:
            case newChargeSpecial:
            case UsedSpecial:
            case UseItem:
            case Swoon:
            case Escape:
                break;
        }
        self.setBattleStatus(battleStatus);
        self.setMainStatus(mainStatus);
        stateAction.replace(category, stateActionField);
        self.setStateAction(stateAction);
    }

    //ターン終了時実行される処理。
    public static void turnEndProcess(State state, boolean self_is_player1, ActionState category, BattleTemporaryLog log, boolean text, Scanner scanner, Random rand){
        Character self = state.getPlayer(self_is_player1);
        Map<BattleStatus, Integer> battleStatus = self.getBattleStatus();
        Map<ActionState, Map<ActionStateCounter, Integer>> stateAction = self.getStateAction();
        Map<ActionStateCounter, Integer> stateActionField = stateAction.get(category);

        if(stateActionField.get(ActionStateCounter.flag) == 0) return;

        switch(category){
            case Defense:
                stateActionField.replace(ActionStateCounter.flag, 0);
                break;

            case sucDef:
                break;
            
            case sucSDef:
                break;

            case SpecialDefense:
                stateActionField.replace(ActionStateCounter.flag, 0);
                break;

            case Tension:
                if(stateActionField.get(ActionStateCounter.flag) == -1){
                    Print.println("", true, Print.highSpeed, text);
                    Print.println(self.getJName() + "のテンションが元に戻った", true, Print.middleSpeed, text);
                    
                }
                stateActionField.replace(ActionStateCounter.flag, 0);
                ChangeBattleStatus.reset(state);
                break;

            case sucTen:
                break;

            case SpecialTension:
                stateActionField.replace(ActionStateCounter.flag, 0);
                break;

            case Stone:
                if(stateActionField.get(ActionStateCounter.flag) == 2){
                    stateActionField.replace(ActionStateCounter.flag, 1);
                }else if(stateActionField.get(ActionStateCounter.flag) == 1){
                    stateActionField.replace(ActionStateCounter.count, 0);
                    stateActionField.replace(ActionStateCounter.flag, 0);
                }
                if(stateActionField.get(ActionStateCounter.count) == 5){
                    Print.println("5 回連続で打って効果が切れてしまった！" + Print.sleep(2), true, Print.highSpeed, text);
                    
                    stateActionField.replace(ActionStateCounter.count, 0);
                    stateActionField.replace(ActionStateCounter.flag, 0);
                }
                break;

            case Rock:
                if(stateActionField.get(ActionStateCounter.flag) == 2){
                    stateActionField.replace(ActionStateCounter.flag, 1);
                }else if(stateActionField.get(ActionStateCounter.flag) == 1){
                    stateActionField.replace(ActionStateCounter.count, 0);
                    stateActionField.replace(ActionStateCounter.flag, 0);
                }
                if(stateActionField.get(ActionStateCounter.count) == 5){
                    Print.println("5 回連続で打って効果が切れてしまった！" + Print.sleep(2), true, Print.highSpeed, text);
                    
                    stateActionField.replace(ActionStateCounter.count, 0);
                    stateActionField.replace(ActionStateCounter.flag, 0);
                }
                break;

            case Lava:
                if(stateActionField.get(ActionStateCounter.flag) == 2){
                    stateActionField.replace(ActionStateCounter.flag, 1);
                }else if(stateActionField.get(ActionStateCounter.flag) == 1){
                    stateActionField.replace(ActionStateCounter.count, 0);
                    stateActionField.replace(ActionStateCounter.flag, 0);
                }
                if(stateActionField.get(ActionStateCounter.count) == 5){
                    Print.println("5 回連続で打って効果が切れてしまった！" + Print.sleep(2), true, Print.highSpeed, text);
                    
                    stateActionField.replace(ActionStateCounter.count, 0);
                    stateActionField.replace(ActionStateCounter.flag, 0);
                }
                break;

            case Meteor:
                if(stateActionField.get(ActionStateCounter.flag) == 2){
                    stateActionField.replace(ActionStateCounter.flag, 1);
                }else if(stateActionField.get(ActionStateCounter.flag) == 1){
                    stateActionField.replace(ActionStateCounter.count, 0);
                    stateActionField.replace(ActionStateCounter.flag, 0);
                }
                if(stateActionField.get(ActionStateCounter.count) == 5){
                    Print.println("5 回連続で打って効果が切れてしまった！" + Print.sleep(2), true, Print.highSpeed, text);
                    
                    stateActionField.replace(ActionStateCounter.count, 0);
                    stateActionField.replace(ActionStateCounter.flag, 0);
                }
                break;

            case Update:
                if(stateActionField.get(ActionStateCounter.flag) == 0){
                    break;
                }
                if(stateActionField.get(ActionStateCounter.count) == 0){
                    Print.println(self.getJName() + "はアップデートに成功した！" + Print.sleep(2), true, Print.middleSpeed, text);
                    
                    CalculateDamage.changeParameter(self, MainStatus.hp, -self.getMainStatus().get(MainStatus.maxHp), text);
                    stateActionField.replace(ActionStateCounter.flag, 0);
                }else{
                    Print.println(self.getJName() + "のアップデートまで残り " + stateActionField.get(ActionStateCounter.count) + " ターンです" + Print.sleep(2), true, Print.middleSpeed, text);
                    
                }
                stateActionField.replace(ActionStateCounter.count, stateActionField.get(ActionStateCounter.count) - 1);
                break;

            case On_SpellReflect:
                stateActionField.replace(ActionStateCounter.flag, 0);
                break;

            case On_TheEnd:
                stateActionField.replace(ActionStateCounter.flag, 0);
                stateActionField.replace(ActionStateCounter.count, 0);
                break;
                

            case Attacked:
                stateActionField.replace(ActionStateCounter.flag, 0);
                break;

            case oldChargeSpecial:
                stateActionField.replace(ActionStateCounter.count, stateActionField.get(ActionStateCounter.count) - 1);
                if(stateActionField.get(ActionStateCounter.count) == 0){
                    stateActionField.replace(ActionStateCounter.flag, 0);
                }
                break;

            case newChargeSpecial:
                break;

            case UsedSpecial:
                break;

            case UseItem:
                break;

            case Swoon:
                stateActionField.replace(ActionStateCounter.count, stateActionField.get(ActionStateCounter.count) - 1);
                if(stateActionField.get(ActionStateCounter.count) == 0){
                    stateActionField.replace(ActionStateCounter.flag, 0);
                }
                break;

            case Escape:
                break;

        }
        self.setBattleStatus(battleStatus);
        stateAction.replace(category, stateActionField);
        self.setStateAction(stateAction);
        state.setPlayer(self, self_is_player1);
    }
}
