package battle.state_change;

import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

import battle.CalculateDamage;
import battle.State;
import battle.InputAction.Action;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import character.Character;
import character.Character.MainStatus;
import text.Print;

public final class ChangeField {
    public enum Field{
        TensionField(   4,0,0,
                        "テンションフィールド",
                        /*"辺りに霧が立ち込めた",
                        "霧によりお互いのテンションが増えた",
                        "辺りの霧が晴れた"),*/
                        "お互いのテンションがターンの終了時に増えるようになった",
                        "テンションフィールドによりお互いのテンションが増えた",
                        "ターンの終わりにテンションが増えなくなった"),
        SpecialField(   5,0,0,
                        "スペシャルフィールド",
                        /*"辺りが異様な空気感に包まれた",
                        "の行動が" + Action.special.jName + "に!",
                        "辺りの空気感が元に戻った"),*/
                        "お互いの基本行動が必殺技に変化した",
                        "の行動が必殺技になった",
                        "基本行動が元に戻った"),
        ReverseField(  5,0,0,
                    "リバースフィールド",
                    /* "辺りの空間が歪んだ",
                    "",
                    "辺りの空間の歪みが直った"), */
                    "お互いの素早さが入れ替わった",
                    "",
                    "お互いの素早さが元に戻った"),
        RegenField(9, 0, 0, 
                    "リジェネフィールド",
                    "お互いのHPが徐々に回復するようになった",
                    "",
                    "ターンの最後にライフが回復しなくなった")
        ;
        public final int turn;// 継続ターン
        public final Map<FieldCounter,Integer> DEFAULT_NUM;// デフォルト値（初期フラグと残りターン）
        public final String jName;// 名前
        public final String affected;// 掛かった時のメッセージ
        public final String execute;// 効果発揮時のメッセージ
        public final String cure;// 解除時のメッセージ
        private Field(int turn, int flag, int count, String name, String affected, String execute, String cure){
            this.turn = turn;
            this.DEFAULT_NUM = Collections.unmodifiableMap(new EnumMap<>(FieldCounter.class){{put(FieldCounter.flag,flag);put(FieldCounter.count,count);}});
            this.jName = name;
            this.affected = affected;
            this.execute = execute;
            this.cure = cure;
        }
    }
    public enum FieldCounter{
        flag,// フラグ
        count// 残りターン
    }
    // フィールドの初期状態
    public static Map<Field, Map<FieldCounter, Integer>> initializedFieldMap(){
        return new HashMap<>(){{
            for(Field key : Field.values()){
                Map<FieldCounter, Integer> miniField = new EnumMap<>(FieldCounter.class);
                for(FieldCounter counter : FieldCounter.values()){
                    miniField.put(counter, key.DEFAULT_NUM.get(counter));                
                }
                put(key, miniField);
            }
        }};
    }
    //かかった時の処理
    // フィールドは上書き
    public static void onset(State state, Field category, int addTurn, boolean text){
        Map<Field,Map<FieldCounter, Integer>> field = ChangeField.initializedFieldMap();
        Map<FieldCounter, Integer> counterField = field.get(category);
        Print.println(category.affected + Print.sleep(2), true, Print.middleSpeed, text);
        
        counterField.replace(FieldCounter.count, category.turn + addTurn);
        counterField.replace(FieldCounter.flag, 1);
        field.replace(category, counterField);
        state.setField(field);
    }
    //効果の実行
    public static void execute(Character self, Map<Field,Map<FieldCounter, Integer>> field, Field category, boolean text){
        Map<FieldCounter, Integer> counterField = field.get(category);
        Map<ActionState, Map<ActionStateCounter, Integer>> actionMap = self.getStateAction();
        Map<ActionStateCounter, Integer> TensionMap = actionMap.get(ActionState.Tension);
        if(counterField.get(FieldCounter.flag) == 0) return;
        switch(category){
            case TensionField:
            case SpecialField:
            case ReverseField:
            case RegenField:
                break;
        }
    }
    //治った時の処理。
    public static boolean cure(Map<Field,Map<FieldCounter, Integer>> field, Field category, boolean text){
        Map<FieldCounter, Integer> counterField = field.get(category);
        //罹ってなかったら偽
        if(counterField.get(FieldCounter.flag) == 0){
            return false;
        }
        for(FieldCounter counter : FieldCounter.values()){
            counterField.replace(counter, category.DEFAULT_NUM.get(counter));
        }
        Print.println(category.jName + "が切れた" + Print.sleep(2), true, Print.middleSpeed, text);
        // Print.println(category.cure + Print.sleep(2), true, Print.middleSpeed, text);
        
        field.replace(category, counterField);
        return true;
    }
    //ターン終了時実行される処理。
    public static void turnEndProcess(State state, Field category, boolean text){
        Character player1 = state.getPlayer1();
        Character player2 = state.getPlayer2();
        Map<Field,Map<FieldCounter, Integer>> field = state.getField();
        Map<FieldCounter, Integer> counterField = field.get(category);
        if(counterField.get(FieldCounter.flag) == 0) return;
        switch(category){
            case TensionField :
                player1.getStateAction().get(ActionState.Tension).replace(ActionStateCounter.count, player1.getStateAction().get(ActionState.Tension).get(ActionStateCounter.count) + 5 - counterField.get(FieldCounter.count));
                player2.getStateAction().get(ActionState.Tension).replace(ActionStateCounter.count, player2.getStateAction().get(ActionState.Tension).get(ActionStateCounter.count) + 5 - counterField.get(FieldCounter.count));
                Print.println("", true, Print.highSpeed, text);
                Print.println(category.execute + Print.sleep(2), true, Print.middleSpeed, text);
                
                break;
            case RegenField:
                Print.println(Field.RegenField.jName + "発動！" + Print.sleep(2), true, Print.highSpeed, text);
                
                Print.println("", true, Print.highSpeed, text);
                CalculateDamage.changeParameter(player1, MainStatus.hp, -player1.getMainStatus().get(MainStatus.maxHp) * 15 / 100, text);
                CalculateDamage.changeParameter(player2, MainStatus.hp, -player2.getMainStatus().get(MainStatus.maxHp) * 15 / 100, text);
                break;
            case SpecialField :
                break;
            case ReverseField :
                break;
        }
        if(counterField.get(FieldCounter.count) == 0){
            cure(field, category, text);
        }
        counterField.replace(FieldCounter.count, counterField.get(FieldCounter.count) - 1);
        field.replace(category, counterField);
        state.setPlayer(player1, player2);
        state.setField(field);
    };

    public static Map<Field,Map<FieldCounter, Integer>> getActiveField(Map<Field,Map<FieldCounter, Integer>> nowField){
        return new HashMap<>(){{
            for(Field fieldCategory : nowField.keySet()){
                if(nowField.get(fieldCategory).get(FieldCounter.flag) != 0){
                    put(fieldCategory, nowField.get(fieldCategory));
                }
            }
        }};
    }

    public static int getActiveFieldNum(Map<Field,Map<FieldCounter, Integer>> nowField){
        return getActiveField(nowField).size();
    }
}
