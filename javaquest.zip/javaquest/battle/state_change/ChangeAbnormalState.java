package battle.state_change;

import java.util.Map;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import java.util.Random;

import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import battle.state_change.ChangeField.Field;
import battle.state_change.ChangeField.FieldCounter;
import battle.CalculateDamage;
import battle.InputAction;
import battle.State;
import character.Character;
import character.Character.MainStatus;
import data.action.Special;
import data.action.Spell;
import log.BattleTemporaryLog;
import text.Print;

//状態異常の処理
public final class ChangeAbnormalState {
    // countはそのターンを含めて入力
    public enum AbnormalState{
        SuperLag(false, 0, 0, -1, -1, 1, 0, 0, 4, 0,
            "ハッキング",
            null,
            "行動が前のターンに入力したものになる。選択した行動が相手に伝えられる",
            "ハッキング状態になった",
            "ハッキング状態にならない",
            "の行動はハッキング状態で前のターンに入力した行動になった",
            "",
            "ハッキング状態が治った"),
        Lag(false,0,0,-1,-1,1,0,0,5,0,
            "ラグ",
            /*"はラグった",
            "はラグらない",
            "の回線は不安定だ",
            "はラグが治った"),*/
            SuperLag,
            "行動が前のターンに入力したものになる",
            "ラグ状態になった",
            "ラグ状態にならない",
            "の行動はラグ状態で前のターンに入力した行動になった",
            "",
            "ラグ状態が治った"),
        SuperNervous(false,0,0,-1,-1,1,0,0,4,0,
                    "超緊張",//ヘビーオイル
                    null,
                    "前回と前々回の行動が選択できくなる",
                    "は超緊張状態になった",
                    "は超緊張状態にならない",
                    "同じ行動は2回続けて選択できない",
                    "前前回と同じ行動も選択できない",
                    "は超緊張状態が治った"),
        Nervous(false,1,0,-1,-1,1,0,15,5,0,
                    "緊張",// オイル
                    SuperNervous,
                    "前回の行動が選択できくなる。最初から掛かっている",
                    "は緊張状態になった",
                    "は緊張状態にならない",
                    "同じ行動は2回続けて選択できない",
                    "",
                    "は緊張状態が治った"),
        SuperPoison(  false,0,0,-1,-1,1,0,0,4,0,
                "猛毒",//融解
                null,
                "ターン終了時に最大体力の 15% のダメージを受ける",
                "は猛毒状態になった",
                "は猛毒状態にならない",
                "は猛毒が体にまわった",
                "",
                "は猛毒状態が治った"),
        Poison(  false,0,0,-1,-1,1,0,0,5,0,
                "毒",//溶解
                SuperPoison,
                "ターン終了時に最大体力の 5% のダメージを受ける",
                "は毒状態になった",
                "は毒状態にならない",
                "は毒が体にまわった",
                "",
                "は毒状態が治った"),
        SuperBond(  false,0,0,-1,-1,1,0,0,4,0,
                    "超臆病",// 接着
                    null,
                    "相手と同じジャンルの行動を選択すると行動が失敗する。行動のジャンルは基本行動、呪文、必殺技、呪文追加の4つ",
                    "は超臆病状態になった",
                    "は超臆病状態にならない",
                    "は超臆病状態により相手と同じジャンルの行動が出来ない",
                    "",
                    "は超臆病状態が治った"),
        Bond(  false,0,0,-1,-1,1,0,0,5,0,
                    "臆病",// 粘着
                    SuperBond,
                    "相手と同じ基本行動を選択すると行動が失敗する。基本行動は攻撃、防御、溜めるのこと",
                    "は臆病状態になった",
                    "は臆病状態にならない",
                    "は臆病状態により相手と同じ行動が出来ない",
                    "",
                    "は臆病状態が治った"),
        SuperStomatitis( false,0,0,-1,-1,1,0,0,4,0,
                    "コミュ症",//腐食
                    null,
                    "呪文が使えなくなる",
                    "はコミュ症状態になった",
                    "はコミュ症状態にならない",
                    "はコミュ症状態により呪文を使えない",
                    "",
                    "はコミュ症状態が治った"),
        Stomatitis( false,0,0,-1,-1,1,0,0,5,0,
                    "口内炎",//サビ
                    SuperStomatitis,
                    "呪文の発動が遅くなる",
                    "は口内炎状態になった",
                    "は口内炎状態にならない",
                    "は口内炎状態により呪文の発動が遅くなった",
                    "",
                    "は口内炎状態が治った"),
        Rapture(true,0,0,-1,-1,1,0,0,5,0,
                "有頂天",
                /*"は有頂天になった",
                "は有頂天にならない",
                "は有頂天でテンションが増えた",
                "は冷めた")*/
                null,
                "ターン終了時にテンションが 2上昇する",
                "は有頂天状態になった",
                "は有頂天状態にならない",
                "は有頂天状態によりテンションが上昇した",
                "",
                "は有頂天状態が治った")
        ;
        public final boolean good;// 悪性状態異常かどうか（万能薬で直せるかどうかなどで使用）
        public final Map<AbnormalStateCounter,Integer> DEFAULT_NUM;// 掛かるターンや初めからかかっているかなどの初期値を保存
        public final String jName;// 名前
        public final AbnormalState superAbnormalState;// 上位状態異常を保存
        public final String explain;// 説明
        public final String affected;// 罹った時のメッセージ
        public final String notAffected;// 罹らない時のメッセージ
        public final String execute1;// 効果処理時のメッセージ
        public final String execute2;// 効果処理時のメッセージ2（効果が複数あるもの用）
        public final String cure;// 回復時のメッセージ
        private AbnormalState(boolean good, int flag, int resistance, int nextBattleAction, int nextItemAction, int enemyActionRepeatNum, int count, int initialCount, int sufferCount, int noMove, String jName, AbnormalState superAbnormalState, String explain, String affected, String notAffected, String execute1, String execute2, String cure){
            this.good = good;
            this.DEFAULT_NUM = Collections.unmodifiableMap(new EnumMap<>(AbnormalStateCounter.class){{put(AbnormalStateCounter.flag,flag);put(AbnormalStateCounter.resistance,resistance);put(AbnormalStateCounter.nextBattleAction,nextBattleAction);put(AbnormalStateCounter.nextItemAction,nextItemAction);put(AbnormalStateCounter.enemyActionRepeatNum,enemyActionRepeatNum);put(AbnormalStateCounter.count,count);put(AbnormalStateCounter.initialCount,initialCount);put(AbnormalStateCounter.sufferCount,sufferCount);put(AbnormalStateCounter.noMove,noMove);}});
            this.jName = jName;
            this.superAbnormalState = superAbnormalState;
            this.explain = explain;
            this.affected = affected;
            this.notAffected = notAffected;
            this.execute1 = execute1;
            this.execute2 = execute2;
            this.cure = cure;
        }
    }
    public enum AbnormalStateCounter{
        flag,// 罹っているかどうか
        resistance,// 耐性を持っているかどうか
        nextBattleAction,// 次の行動は何か（ラグ用）
        nextItemAction,// 次の使用アイテムは何か(ラグ用)
        enemyActionRepeatNum,// 敵の行動回数（接着用）
        count,// 残りターン
        initialCount,// 初期ターン
        sufferCount,// 罹った時のターン
        noMove// 行動可能かどうか
    }
    // 状態異常フィールドの初期状態
    public static Map<AbnormalState, Map<AbnormalStateCounter, Integer>> initializedAbnormalStateMap(){
        return new HashMap<>(){{
            for(AbnormalState aKey: AbnormalState.values()){
                put(aKey, new EnumMap<>(AbnormalStateCounter.class){{
                    for(AbnormalStateCounter cKey : AbnormalStateCounter. values()){
                        if(cKey == AbnormalStateCounter.count){
                            put(cKey, aKey.DEFAULT_NUM.get(AbnormalStateCounter.initialCount));
                        }else{
                            put(cKey, aKey.DEFAULT_NUM.get(cKey));
                        }
                    }
                }});
            }
        }};
    }
    // public static final int stomaHPRate = 200;// サビ状態の時に呪文を使用したときに受けるダメージの係数(mpに掛ける)
    // public static final int stomaMPRate = 20;// サビ状態の時に通常行動を使用したときに減るmpの量
    //かかった時の処理。
    public static void onset(State state, boolean self_is_player1, AbnormalState category, BattleTemporaryLog log, Scanner scanner, boolean text, Random rand){
        onset(state, self_is_player1, category, 0, log, scanner, text, rand);
    }
    // 罹った時の処理（addTurnでターンを延ばせる）
    public static void onset(State state, boolean self_is_player1, AbnormalState category, int addTurn, BattleTemporaryLog log, Scanner scanner, boolean text, Random rand){
        Character self = state.getPlayer(self_is_player1);
        Character enemy = state.getPlayer(!self_is_player1);
        Map<AbnormalState, Map<AbnormalStateCounter, Integer>> stateAbnormal = self.getStateAbnormal();
        Map<AbnormalStateCounter, Integer> abnormalChangeField = stateAbnormal.get(category);
        if(self.getStateAction().get(ActionState.SpecialDefense).get(ActionStateCounter.flag) == 1 && enemy.getStateAction().get(ActionState.SpecialDefense).get(ActionStateCounter.flag) == 1){
            //Print.println("お互いの盾は砕け散って状態異常になった", Print.middleSpeed, text);
            Print.println("お互いがスペシャルディフェンスを使ったことで、どちらも無効化されて状態異常になった！" + Print.sleep(2), true, Print.middleSpeed, text);
            
        }else if(self.getStateAction().get(ActionState.SpecialDefense).get(ActionStateCounter.flag) == 1){
            ChangeActionState.onset(state, self_is_player1, !self_is_player1, ActionState.sucSDef, log, text, scanner, rand);
            return;
        }
        if(abnormalChangeField.get(AbnormalStateCounter.resistance) == 1){
            Print.println(self.getJName() + category.notAffected + Print.sleep(2), true, Print.middleSpeed, text);
            
            return;
        }else{
            if((category.superAbnormalState == null || abnormalChangeField.get(AbnormalStateCounter.flag) == 0) && !(category.superAbnormalState != null && self.getStateAbnormal().get(category.superAbnormalState).get(AbnormalStateCounter.flag) == 1)){
                Print.println(self.getJName() + category.affected + Print.sleep(2), true, Print.middleSpeed, text);
                
                //flag判定があるのでフラグを立てるより先にヘジテンスを処理
                /*if(category == AbnormalState.Hesitance){
                    if(abnormalChangeField.get(AbnormalStateCounter.flag) == 0){
                        abnormalChangeField.replace(AbnormalStateCounter.count, 5);
                    }
                }*/
                abnormalChangeField.replace(AbnormalStateCounter.flag, 1);
                if(category == AbnormalState.Lag || category == AbnormalState.SuperLag){
                    /* Print.println(AbnormalState.Lag.jName + "状態に成ったので次のターンの行動を選択してください", Print.middleSpeed, text);
                    int nextAction = InputAction.select(state, self_is_player1, text, scanner, rand);
                    int nextBattleAction = (nextAction - 1) % (InputAction.ACTION_NUM) + 1;
                    int nextItemAction = ((nextAction - 1) / (InputAction.ACTION_NUM));
                    abnormalChangeField.replace(AbnormalStateCounter.nextBattleAction, nextBattleAction);
                    abnormalChangeField.replace(AbnormalStateCounter.nextItemAction, nextItemAction); */
                    abnormalChangeField.replace(AbnormalStateCounter.nextBattleAction, -1);
                    abnormalChangeField.replace(AbnormalStateCounter.nextItemAction, 0);
                }
                abnormalChangeField.replace(AbnormalStateCounter.count, category.DEFAULT_NUM.get(AbnormalStateCounter.sufferCount) + 1 + addTurn);
            }else{
                cure(self, category, text);
                onset(state, self_is_player1, category.superAbnormalState, log, scanner, text, rand);
                return;
            }
        }
        stateAbnormal.replace(category, abnormalChangeField); 
        self.setStateAbnormal(stateAbnormal);
        state.setPlayer(self, self_is_player1);
    }
      
    //効果のメイン実行処理
    public static boolean execute(Character self, Map<Field,Map<FieldCounter, Integer>> field, AbnormalState category, int battleAction, int enemyBattleAction, boolean text){
        Map<AbnormalState, Map<AbnormalStateCounter, Integer>> stateAbnormal = self.getStateAbnormal();
        Map<AbnormalStateCounter, Integer> abnormalChangeField = stateAbnormal.get(category);
        if(abnormalChangeField.get(AbnormalStateCounter.flag) == 0) return false;
        switch(category){
            case Lag:
            case SuperLag:
            Print.println("", Print.highSpeed, text);
                Print.println(self.getJName() + category.execute1, true, Print.middleSpeed, text);
                break;

            case Nervous:
            case SuperNervous:
                int count = 0;
                // for(int beforeAct : category == AbnormalState.SuperParalysis ? new int[]{self.getLastAction(), self.getSecondLastAction()} : new int[]{self.getLastAction()}){
                lastOrSecondLastLoop:
                for(int beforeAct : category == AbnormalState.Nervous ? new int[]{self.getLastAction()} : new int[]{self.getLastAction(), self.getSecondLastAction()}){
                    count++;
                    int[] NBAct = new int[] {battleAction, beforeAct};
                    // if(category == AbnormalState.SuperOil){
                    //     for(int i = 0; i < NBAct.length; i++){
                    //         if(InputAction.ACTION_NUM < NBAct[i]){
                    //             //アイテムは判定なし
                    //             continue;
                    //         }else if(1 <= NBAct[i] && NBAct[i] < 4){
                    //             //通常行動
                    //             NBAct[i] = 1;
                    //         }else if(4 <= NBAct[i] && NBAct[i] < 4 + Spell.NUM){
                    //             //呪文
                    //             NBAct[i] = 4;
                    //         }else if(4 + Spell.NUM <= NBAct[i] && NBAct[i] < 4 + Spell.NUM + 1 + Special.NUM){
                    //             //必殺技
                    //             NBAct[i] = 4 + Spell.NUM;
                    //         }else if(4 + Spell.NUM + 1 + Special.NUM <= NBAct[i] && NBAct[i] <= InputAction.ACTION_NUM){
                    //             //呪文追加
                    //             NBAct[i] = 4 + Spell.NUM + Special.NUM;
                    //         }
                    //     }
                    // }else{
                        for(int i = 0; i < NBAct.length; i++){
                            if(NBAct[i] == -1){
                                continue lastOrSecondLastLoop;
                            }
                            if((NBAct[i] == 4 + Spell.Stone.ordinal() && self.getStateAction().get(ActionState.Stone).get(ActionStateCounter.flag) == 1) || 
                                (NBAct[i] == 4 + Spell.Rock.ordinal() && self.getStateAction().get(ActionState.Rock).get(ActionStateCounter.flag) == 1) || 
                                (NBAct[i] == 4 + Spell.Lava.ordinal() && self.getStateAction().get(ActionState.Lava).get(ActionStateCounter.flag) == 1) || 
                                (NBAct[i] == 4 + Spell.Meteor.ordinal() && self.getStateAction().get(ActionState.Meteor).get(ActionStateCounter.flag) == 1)){
                                if(i == 0){// 今回の方はスルー
                                    continue lastOrSecondLastLoop;
                                }else{// 前回行動なら呪文は禁止
                                    NBAct[i] = 4;
                                }
                            }
                            if(4 <= NBAct[i] && NBAct[i] < 4 + Spell.NUM){
                                //呪文
                                NBAct[i] = 4;
                            }
                            if(4 + Spell.NUM < NBAct[i] && NBAct[i] <= 4 + Spell.NUM + Special.NUM){
                                // 必殺技を通常攻撃と同じ番号に
                                NBAct[i] = NBAct[i] - 4 - Spell.NUM;
                            }
                        }
                    // }
                    if(NBAct[0] == NBAct[1]){
                        if(count == 1){
                            Print.println(category.execute1 + Print.sleep(2), true, Print.middleSpeed, text);
                            
                        }else{
                            Print.println(category.execute2 + Print.sleep(2), true, Print.highSpeed, text);
                            
                        }
                        return true;
                    }
                }
                return false;

            case Poison:
            case SuperPoison:
                break;

            // 臆病は通常行動に対して、同じ行動か判定。接着は全行動に対して、同じカテゴリか判定
            case Bond:
            case SuperBond:
                //通常行動は変更の必要なし
                int[] SEAct = new int[] {battleAction, enemyBattleAction};
                for(int i = 0; i < SEAct.length; i++){
                    if(InputAction.ACTION_NUM < SEAct[i]){
                        //アイテムは判定なし
                        break;
                    }else if(1 <= SEAct[i] && SEAct[i] < 4){
                        // 通常行動
                        if(category == AbnormalState.Bond){
                            
                        }else{
                            SEAct[i] = 1;
                        }
                    }else if(4 <= SEAct[i] && SEAct[i] < 4 + Spell.NUM){
                        //呪文
                        if(category == AbnormalState.Bond){
                            break;
                        }else{
                            SEAct[i] = 4;
                        }
                    }else if(4 + Spell.NUM <= SEAct[i] && SEAct[i] < 4 + Spell.NUM + Special.NUM){
                        //必殺技
                        if(category == AbnormalState.Bond){
                            break;
                        }else{
                            SEAct[i] = SEAct[i] - Spell.NUM + 1;
                        }
                    }else if(4 + Spell.NUM + Special.NUM <= SEAct[i] && SEAct[i] <= InputAction.ACTION_NUM){
                        //呪文追加
                        if(category == AbnormalState.Bond){
                            break;
                        }else{
                            SEAct[i] = 8;
                        }
                    }
                }
                if(SEAct[0] == SEAct[1]){
                    Print.println(self.getJName() + category.execute1 + Print.sleep(2), true, Print.middleSpeed, text);
                    
                    abnormalChangeField.replace(AbnormalStateCounter.noMove, 1);
                    // // 行動を2倍にする
                    // if(category == AbnormalState.SuperBond){
                    //     abnormalChangeField.replace(AbnormalStateCounter.enemyActionRepeatNum, 2);
                    // }
                }
                break;

            case Stomatitis:
                break;
            case SuperStomatitis:
                if(4 <= battleAction && battleAction < 4 + Spell.NUM){
                    return true;
                }
                break;

            case Rapture:
                break;
        }
        stateAbnormal.replace(category, abnormalChangeField);
        self.setStateAbnormal(stateAbnormal);
        return false;
    }

    //治った時の処理。
    public static boolean cure(Character self, AbnormalState category, boolean text){
        Map<AbnormalState, Map<AbnormalStateCounter, Integer>> stateAbnormal = self.getStateAbnormal();
        Map<AbnormalStateCounter, Integer> abnormalChangeField = stateAbnormal.get(category);
        //罹ってなかったら偽
        if(abnormalChangeField.get(AbnormalStateCounter.flag) == 0){
            return false;
        }
        for(AbnormalStateCounter counter : AbnormalStateCounter.values()){
            if(counter == AbnormalStateCounter.resistance){
                continue;
            }
            if(counter == AbnormalStateCounter.flag || counter == AbnormalStateCounter.count){
                abnormalChangeField.replace(counter, 0);
                continue;
            }
            abnormalChangeField.replace(counter, category.DEFAULT_NUM.get(counter));
        }
        Print.println(self.getJName() + category.cure, true, Print.middleSpeed, text);
        stateAbnormal.replace(category, abnormalChangeField);
        self.setStateAbnormal(stateAbnormal);
        return true;
    }

    //耐性を得る、もしくは失う処理。
    public static void setResistance(Character self, AbnormalState category, int resistance, boolean text){
        Map<AbnormalState, Map<AbnormalStateCounter, Integer>> stateAbnormal = self.getStateAbnormal();
        Map<AbnormalStateCounter, Integer> abnormalChangeField = stateAbnormal.get(category);
        if(resistance == 0){
            if(abnormalChangeField.get(AbnormalStateCounter.resistance) == 1){
                Print.println(self.getJName() + "は" + category.jName + "耐性を失った！" + Print.sleep(2), true, Print.middleSpeed, text);
                
                abnormalChangeField.replace(AbnormalStateCounter.resistance, 0);
            }
        }
        if(resistance == 1){
            if(abnormalChangeField.get(AbnormalStateCounter.resistance) == 0){
                Print.println(self.getJName() + "は" + category.jName + "耐性を得た！" + Print.sleep(2), true, Print.middleSpeed, text);
                
                abnormalChangeField.replace(AbnormalStateCounter.resistance, 1);
            }
        }
        stateAbnormal.replace(category, abnormalChangeField);
        self.setStateAbnormal(stateAbnormal);
    }

    //ターン終了時実行される処理。
    public static void turnEndProcess(Character self, AbnormalState category, boolean text, Scanner scanner, Random rand){
        Map<AbnormalState, Map<AbnormalStateCounter, Integer>> stateAbnormal = self.getStateAbnormal();
        Map<AbnormalStateCounter, Integer> abnormalChangeField = stateAbnormal.get(category);
        if(abnormalChangeField.get(AbnormalStateCounter.flag) == 0) return;
        int nextAct;
        String nextActCat;
        switch(category){
            case Poison:
            case SuperPoison:
                Print.println("", true, Print.highSpeed, text);
                Print.println(self.getJName() + category.execute1 + Print.sleep(2), true, Print.middleSpeed, text);
                
                CalculateDamage.changeParameter(self, MainStatus.hp, self.getMainStatus().get(MainStatus.maxHp) * (category == AbnormalState.SuperPoison ? 15 : 5) / 100, text);
                Print.nextLine(scanner, text);
                break;
            case Rapture:
                self.getStateAction().get(ActionState.Tension).replace(ActionStateCounter.count, self.getStateAction().get(ActionState.Tension).get(ActionStateCounter.count) + 2);
                Print.println("", true, Print.highSpeed, text);
                Print.println(self.getJName() + category.execute1 + Print.sleep(2), true, Print.middleSpeed, text);
                
                Print.nextLine(scanner, text);
                break;
            case Bond:
            case SuperBond:
                /*abnormalChangeField.replace(AbnormalStateCounter.count, abnormalChangeField.get(AbnormalStateCounter.count) - 1);
                if(abnormalChangeField.get(AbnormalStateCounter.count) == 0){
                    cure(self, category, Print.highSpeed, text);
                    Print.nextLine(scanner, text);
                }*/
                break;
            case SuperLag:
                nextAct = abnormalChangeField.get(AbnormalStateCounter.nextBattleAction);

                nextActCat = "???";
                if(nextAct == -1){
                    nextActCat = "無行動";
                }else if(nextAct == 0){
                    nextActCat = "逃げる";
                }else if(nextAct == 1){
                    nextActCat = "攻撃";
                }else if(nextAct == 2){
                    nextActCat = "防御";
                }else if(nextAct == 3){
                    nextActCat = "溜める";
                }else if(nextAct < 4 + Spell.NUM){
                    nextActCat = Spell.values()[nextAct-4].jName;
                }else if(nextAct == 4 + Spell.NUM){
                    nextActCat = "必殺技準備";
                }else if(nextAct <= 4 + Spell.NUM + Special.NUM){
                    nextActCat = Special.values()[nextAct - (4 + Spell.NUM + 1)].jName;
                }
                Print.println("次の" + self.getJName() + "の行動は" + nextActCat + "です" + Print.sleep(2), true, Print.middleSpeed, text);
                Print.nextLine(scanner, text);
                break;
            case Lag:
                // nextAct = abnormalChangeField.get(AbnormalStateCounter.nextBattleAction);

                // nextActCat = "???";
                // if(nextAct == -1){
                //     nextActCat = "無行動";
                // }else if(nextAct == 0){
                //     nextActCat = "逃げる";
                // }else if(nextAct <= 3){
                //     nextActCat = "基本行動";
                // }else if(nextAct < 4 + Spell.NUM){
                //     nextActCat = "呪文";
                // }else if(nextAct <= 4 + Spell.NUM + Special.NUM){
                //     nextActCat = "必殺技";
                // }
                // Print.println("次の" + self.jName + "の行動は" + nextActCat + "です", Print.middleSpeed, text);
                // Print.nextLine(scanner, text);
                break;
            case Stomatitis:
            case SuperStomatitis:
            case Nervous:
            case SuperNervous:
            break;


            /*
                sleepの遺骸
                int count = abnormalChangeField.get(AbnomalStateCounter.count);
                if(Math.random() < count++ / 8.0){
                    abnormalChangeField.replace("flag", 0);
                    Print.println(name + "は目が覚めた", Print.lowSpeed, text);
                }
                stateAbnormal.put("Confusion", abnormalChangeField);
                self.setStateAbnormal(stateAbnormal);
                break;

                */
        }
        abnormalChangeField.replace(AbnormalStateCounter.count, abnormalChangeField.get(AbnormalStateCounter.count) - 1);
        if(abnormalChangeField.get(AbnormalStateCounter.count) == 0){
            cure(self, category, text);
            Print.nextLine(scanner, text);
        }else if(abnormalChangeField.get(AbnormalStateCounter.count) > 0 && category != AbnormalState.Nervous){
            // Print.println(self.getJName() + "の" + category.jName + "状態は残り " + abnormalChangeField.get(AbnormalStateCounter.count) + " ターンです" + Print.sleep(2), true, Print.highSpeed, text);
            // Print.println("", true, Print.highSpeed, text);
            // Print.nextLine(scanner, text);
        }
                
        stateAbnormal.replace(category, abnormalChangeField);
        self.setStateAbnormal(stateAbnormal);
    }

    //何かしらの悪い状態異常に掛かっているかどうかを判定する
    // 何か一つでも掛かっていたらtrue、掛かっていなかったらfalse
    public static boolean checkAnyAbnormal(Character self, boolean skipOil){
        return checkAbnormalNum(self, skipOil) != 0;
    }
    public static boolean checkAnyAbnormal(Character self){
        return checkAnyAbnormal(self, false);
    }
    // 悪い状態異常に罹ってる数を判定する
    public static int checkAbnormalNum(Character self, boolean skipOil){
        return checkAbnormal(self, skipOil).size();
    }
    // 罹ってる悪い状態異常を判定する
    public static List<AbnormalState> checkAbnormal(Character self, boolean skipOil){
        Map<AbnormalState, Map<AbnormalStateCounter, Integer>> stateAbnormal = self.getStateAbnormal();
        Map<AbnormalStateCounter, Integer> abnormalStateCounter;
        List<AbnormalState> onsetStates = new ArrayList<>();
        for(AbnormalState abnormalState : stateAbnormal.keySet()){
            if(abnormalState.good){
                continue;
            }
            if(skipOil && abnormalState == AbnormalState.Nervous){
                continue;
            }
            abnormalStateCounter = stateAbnormal.get(abnormalState);
            if(abnormalStateCounter.get(AbnormalStateCounter.flag) == 1){
                onsetStates.add(abnormalState);
            }
        }
        return onsetStates;
    }
    public static int checkAbnormalNum(Character self){
        return checkAbnormalNum(self, false);
    }
}
