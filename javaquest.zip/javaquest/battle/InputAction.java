package battle;

import java.util.Scanner;

import action.montecarlo.Montecarlo;

import java.util.Random;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import battle.state_change.ChangeAbnormalState;
import battle.state_change.ChangeActionState;
import battle.state_change.ChangeBattleStatus;
import battle.state_change.ChangeWeather;
import battle.state_change.ChangeAbnormalState.AbnormalState;
import battle.state_change.ChangeAbnormalState.AbnormalStateCounter;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import battle.state_change.ChangeBattleStatus.StateChangeStatus;
import battle.state_change.ChangeField.Field;
import battle.state_change.ChangeField.FieldCounter;
import character.Character;
import character.Enemy;
import character.Player;
import character.Character.Attribute;
import character.Character.BattleStatus;
import character.Character.MainStatus;
import character.Player.TrainStatus;
import data.action.Special;
import data.action.Spell;
import data.item.BattleItem;
import game.LocationCategory;
import text.Print;
import text.Print.Color;

//actionをintで受け取るまで
public final class InputAction {
    public static final int ACTION_NUM = 3 + Spell.NUM + 1 + Special.NUM + Spell.NUM;//アイテムと逃げる以外の全行動数
    // 行動選択の方法
    public enum Auto{
        select,// 自分で選択
        cycle,// サイクル行動
        random,// ランダム行動
        biasedRandom,// 重み付きランダム行動
        aiRandom,// 論外手を除いたランダム行動
        playout,// 良手からランダム行動
        mcs,// モンテカルロ
        enemyMCTS,// モンテカルロ
        mctsS,// モンテカルロ小
        mctsL,// モンテカルロ大
    }
    // 行動の名前と説明
    public enum Action{
        information("情報"){
            @Override
            public void explain(boolean text) {
                Print.setFrameStart(text);
                Print.println("自分や敵の各ステータスを確認できる", Print.highSpeed, text);
                Print.setFrameEnd(text);
            }
        },
        attack("攻撃"){
            @Override
            public void explain(boolean text) {
                Print.setFrameStart(text);
                Print.println("通常攻撃。自分の攻撃力と同じダメージを敵に与える。複数回当たるとその分ダメージが増加する", Print.highSpeed, text);
                Print.setFrameEnd(text);
            }
        },
        defense("防御"){
            @Override
            public void explain(boolean text) {
                Print.setFrameStart(text);
                Print.println("敵の通常攻撃を無効にする", Print.highSpeed, text);
                Print.println("防御に成功したとき、テンションが 2 上昇する。行動順決定時、自分の素早さが1.5倍で判定される", Print.highSpeed, text);
                Print.setFrameEnd(text);
            }
        },
        tension("溜める"){
            @Override
            public void explain(boolean text) {
                Print.setFrameStart(text);
                Print.println("テンションが上昇する。自分の行動前に敵からダメージを受けると失敗する", Print.highSpeed, text);
                Print.println("行動順決定時、自分の素早さが3分の2で判定される", Print.highSpeed, text);
                Print.setFrameEnd(text);
            }
        },
        spell("呪文"){
            @Override
            public void explain(boolean text) {
                Print.setFrameStart(text);
                Print.println("魔力を消費して呪文を唱える。攻撃呪文は防御されない", Print.highSpeed, text);
                Print.setFrameEnd(text);
            }
        },
        replaceOrb("オーブ入れ替え"){
            @Override
            public void explain(boolean text){
                Print.setFrameStart(text);
                Print.println("ターンを消費してスロットのオーブを 1つ入れ替える", Print.highSpeed, text);
                Print.setFrameEnd(text);
            }
        },
        changeSlot("オーブセット"){
            @Override
            public void explain(boolean text){
                Print.setFrameStart(text);
                Print.println("ターンを消費せずスロットのオーブ全てを入れ替える(1ターン目のみ)", Print.highSpeed, text);
                Print.setFrameEnd(text);
            }
        },
        // special("必殺技"){
        //     @Override
        //     public void explain(boolean text) {
        //         Print.setFrameStart(text);
        //         Print.println("行動時、お互いのテンションを0にする。次のターンの行動選択肢の「攻撃」「防御」「溜める」が", Print.highSpeed, text);
        //         Print.println("「スペシャルアタック」「カウンターシールド」「フルチャージ」に変更される。戦闘中1回のみ選択可能。", Print.highSpeed, text);
        //         Print.setFrameEnd(text);
        //     }
        // },
        //addSpell("呪文追加","覚えている呪文の中から１つ選択し、敵に宣言した上で呪文スロットに加える。"),
        // escape("逃げる"){
        //     @Override
        //     public void explain(boolean text) {
        //         Print.setFrameStart(text);
        //         Print.println("戦闘から離脱する。", Print.highSpeed, text);
        //         Print.setFrameEnd(text);
        //     }
        // },
        //changeSpell("呪文変更","ターンを消費せず戦闘中に使える呪文のスロットを変更する。１ターン目のみ選択できる。"),
        ;
        public final String jName;// 名前
        public abstract void explain(boolean text);
        private Action(String name){
            this.jName = name;
        }
    }
    //行動をカウントするためのフィールド
    public static int[] actionCount = new int[1 + (ACTION_NUM) * (BattleItem.NUM + 1)];
    //プレイヤーもしくはコンピューターからの入力を受け付ける。
    public static int select(State state, boolean self_is_player1, boolean text, Scanner scanner, Random rand){
        int selfAction = -1;
        Character self = state.getPlayer(self_is_player1);
        int [] legalActions;
        switch (state.getAuto(self_is_player1)){
            case select:
                if(state.getTurn() == 0){
                    selfAction = -1;
                }else{
                    final int INPUT = 1;
                    switch(state.getSavedLocation(LocationCategory.selectBattleAction)){
                        case LocationCategory.NO_CHOICE:
                            state.saveLocation(LocationCategory.selectBattleAction, INPUT);
                            return select(state, self_is_player1, text, scanner, rand);
                        
                        case INPUT:
                            selfAction = input(state, self_is_player1, text, false, scanner);
                            if(state.getSavedLocation(LocationCategory.inputBattleAction) == LocationCategory.FINISH){
                                state.saveLocation(LocationCategory.inputBattleAction, LocationCategory.NO_CHOICE);
                                state.saveLocation(LocationCategory.selectBattleAction, LocationCategory.FINISH);
                                break;
                            }else{
                                return LocationCategory.NO_CHOICE;
                            }

                        default:
                            System.out.println(state.getSavedLocation(LocationCategory.selectBattleAction));
                            System.out.println("error select default");
                    }
                }
            break;

            case cycle:
            legalActions = state.getLegalAction(self_is_player1);
            selfAction = legalActions[(int) (rand.nextDouble() * legalActions.length)]; 
            if(self instanceof Enemy){
                Enemy eSelf = (Enemy)self;
                int i;
                for(i = 0; i < legalActions.length; i++){
                    if(legalActions[i] == eSelf.getCycleAction(state.getTurn())){
                        selfAction = eSelf.getCycleAction(state.getTurn());
                    }
                }
            }
            break;

            case random:
            //legalActions.lengthが0になることがある模様
            legalActions = state.getLegalAction(self_is_player1);
            selfAction = legalActions[(int) (rand.nextDouble() * legalActions.length)]; 
            break;

            case biasedRandom:
            int[] biasedActions = self.biasedAction(state, self_is_player1, ChangeWeather.nowWeather(state), state.getField(), state.getTurn());
            selfAction = biasedActions[(int) (rand.nextDouble() * biasedActions.length)];
            break;

            case aiRandom:
            //aiLegalActions.lengthが0になることがある模様
            int [] aiLegalActions = state.aiLegalActions(self_is_player1);
            selfAction = aiLegalActions[(int) (rand.nextDouble() * aiLegalActions.length)];
            // stone連続確率半分
            for(int act : aiLegalActions){
                if(act == 4 + Spell.Stone.ordinal() && self.getStateAction().get(ActionState.Stone).get(ActionStateCounter.flag) == 1){
                    if(rand.nextBoolean()){
                        selfAction = act;
                    }
                    break;
                }
            }
            break;

            case playout:
            int [] poLegalActions = state.playoutActions(self_is_player1);
            selfAction = poLegalActions[(int) (rand.nextDouble() * poLegalActions.length)];
            break;

            case mcs:
            selfAction = Montecarlo.mcsAct(state.forAI(), self_is_player1, false, scanner, rand);
            break;

            case enemyMCTS:
            if(state.getTurn() == 0){
                changeSpellForAI(self, rand);
                selfAction = -1;
                // selfAction = state.getLegalAction(self_is_player1)[rand.nextInt(state.getLegalAction(self_is_player1).length)];
                break;
            }
            // selfAction = Montecarlo.mctsAct(state.forAI(), self_is_player1, 200, 100, 5, false, false, scanner, rand);
            selfAction = Montecarlo.mctsAct(state.forAI(), self_is_player1, 50, 30, 5, false, false, scanner, rand);
            break;

            case mctsL:
            selfAction = Montecarlo.mctsAct(state.forAI(), self_is_player1, 100, 50, 5, false, false, scanner, rand);
            break;

            case mctsS:
            selfAction = Montecarlo.mctsAct(state.forAI(), self_is_player1, 30, 20, 5, false, false, scanner, rand);
            break;
        }
        if(selfAction >= 0){
            actionCount[selfAction]++;
        }
        state.saveLocation(LocationCategory.selectBattleAction, LocationCategory.FINISH);
        return selfAction;
    }

    //プレイヤーから入力を受け付ける。
    private static int input(State state, boolean self_is_player1, boolean text, boolean usingItem , Scanner scanner){
        //TODO ここいきなりplayerクラスでself作ってよくね？
        Character self = state.getPlayer(self_is_player1);
        Map<Field,Map<FieldCounter, Integer>> field = state.getField();
        int input;

        int item_action_num = state.getSavedLocation(LocationCategory.isUsingItem) == LocationCategory.TRUE ? state.temp_item_action_num : 0;
        final int EXPLAIN = 1;
        final int NO_MOVE = 2;
        final int INPUT = 3;
        final int CHANT_SPELL = 4;
        final int REPLACE_ORB = 5;
        final int CHANGE_SLOT = 6;
        final int INFOMATION = 7;
        switch(state.getSavedLocation(LocationCategory.inputBattleAction)){
            case LocationCategory.NO_CHOICE:
                state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
                if(state.getAuto(true) == Auto.select && state.getAuto(false) == Auto.select){
                    Print.skipStart(true, text);
                    for(int i = 0; i < 100; i++){
                        Print.println("", true, Print.highSpeed, text);
                    }
                    Print.println(Color.yellow.toColor(self.getJName() + "の入力です"), true, Print.highSpeed, text);
                    Print.clearStaticText(text);
                    Print.changeWaitTextToLT(text);
                    Print.skipEnd(true, text);
                    return LocationCategory.NO_CHOICE;
                }else{
                    return input(state, self_is_player1, text, usingItem, scanner);
                }

            case EXPLAIN:
                Print.displayBattleMenu(state, self_is_player1, text);

                Print.println("", Print.highSpeed, text);
                String attack = Action.attack.jName;
                String defense = Action.defense.jName;
                String tension = Action.tension.jName + "(x" + ((self.getStateAction().get(ActionState.sucTen).get(ActionStateCounter.count) * ChangeActionState.addTenBuffSucTenCoef + 2) * (self.getAttribute() == Attribute.C ? 1 : 1)) + " )";
                if(self.getStateAction().get(ActionState.oldChargeSpecial).get(ActionStateCounter.flag) == 1 || field.get(Field.SpecialField).get(FieldCounter.flag) == 1){
                    attack = Special.SpecialAttack.jName;
                    defense = Special.SpecialDefense.jName;
                    tension = Special.SpecialTension.jName;
                }else if(self.getStateAction().get(ActionState.newChargeSpecial).get(ActionStateCounter.flag) == 1){
                    if(self.getAttribute() == Attribute.A){
                        attack = Special.SpecialAttack.jName;
                    }
                    if(self.getAttribute() == Attribute.D){
                        defense = Special.SpecialDefense.jName;
                    }
                    if(self.getAttribute() == Attribute.C){
                        tension = Special.SpecialTension.jName;
                    }
                }else{
                    if(self.getAttribute() == Attribute.A){
                        attack += " [" + self.getStateAction().get(ActionState.newChargeSpecial).get(ActionStateCounter.count) + "]";
                    }
                    if(self.getAttribute() == Attribute.D){
                        defense += " [" + self.getStateAction().get(ActionState.newChargeSpecial).get(ActionStateCounter.count) + "]";
                    }
                    if(self.getAttribute() == Attribute.C){
                        tension += " [" + self.getStateAction().get(ActionState.newChargeSpecial).get(ActionStateCounter.count) + "]";
                    }
                }
                Print.setFrameStart(text);
                Print.startTable(text);
                Print.println("1:" + attack, Print.highSpeed, text);
                
                Print.println("2:" + defense, Print.highSpeed, text);
                
                Print.println("3:" + tension, Print.highSpeed, text);

                Print.separateRow(text);
                Print.print(Print.space(2, text), Print.highSpeed, text);
                Print.separateRow(text);
                
                if(self instanceof Player){
                    Player selfPlayer = (Player)self;
                    /*if(!selfPlayer.getUseSpell()){
                        Print.println("<br>(-番号入力で詳細)", Print.highSpeed, text);
                    //}else if(!selfPlayer.getUseItem()){
                    }else if(!BattleLimitation.useItem.useAble()){
                        Print.println("<br>4:" + Action.spell.jName +
                                    //"<br>7:" + Action.escape.name + 
                                    "(-番号入力で詳細)", Print.highSpeed, text);
                    //}else if(!selfPlayer.getUseSpecial()){
                    }else if(!BattleLimitation.useSpecial.useAble()){
                        Print.println("<br>4:" + Action.spell.jName + " 5:" + Action.item.jName +
                                    //"<br>7:" + Action.escape.name + 
                                    "(-番号入力で詳細)", Print.highSpeed, text);
                    }else{
                        Print.println("<br>4:" + Action.spell.jName + " 5:" + Action.item.jName + " 6:" + Action.special.jName +
                                    //"<br>7:" + Action.escape.name + 
                                    "(-番号入力で詳細)", Print.highSpeed, text);
                    }*/
                    if(selfPlayer.getUseSpell()){
                        Print.println("4:" + Action.spell.jName, Print.highSpeed, text);
                        
                        Print.println("5:" + Action.replaceOrb.jName, Print.highSpeed, text);
                        
                        if(state.getTurn() == 1){
                            Print.println("6:" + Action.changeSlot.jName, Print.highSpeed, text);
                            
                        }
                    }
                    
                    // if(selfPlayer.getUseItem()){
                    //     Print.println("5:" + Action.item.jName, Print.highSpeed, text);
                    //     
                    // }
                    // if(selfPlayer.getUseSpecial()){
                    //     Print.println("6:" + Action.special.jName, Print.highSpeed, text);
                    //     
                    // }
                }else{
                    Print.println("4:" + Action.spell.jName, Print.highSpeed, text);
                    
                    Print.println("5:" + Action.replaceOrb.jName, Print.highSpeed, text);
                    
                    if(state.getTurn() == 1){
                        Print.println("6:" + Action.changeSlot.jName, Print.highSpeed, text);
                        
                    }
                }
                Print.separateRow(text);
                Print.print(Print.space(2, text), Print.highSpeed, text);
                Print.separateRow(text);
                Print.println("7:" + Action.information.jName, Print.highSpeed, text);
                Print.endTable(text);
                
                Print.setFrameEnd(text);
                if(self.getLegalAction(state, ChangeWeather.nowWeather(state), field, state.getTurn())[0] == -1){
                    Print.println("", true, Print.highSpeed, text);
                    Print.println("選択できる行動がありません", true, Print.highSpeed, text);
                    Print.nextLine(scanner, text);
                    state.saveLocation(LocationCategory.inputBattleAction, NO_MOVE);
                    Print.changeWaitTextToLT(text);
                    return LocationCategory.NO_CHOICE;
                }else{
                    Print.tempSlowLiftStart(true, text);
                    Print.skipStart(true, text);
                    Print.println("", true, Print.highSpeed, text);
                    Print.println("", true, Print.highSpeed, text);
                    Print.println("", true, Print.highSpeed, text);
                    Print.println("", true, Print.highSpeed, text);
                    Print.println("", true, Print.highSpeed, text);
                    Print.println(Color.yellow.toColor(self.getJName() + "の行動を選択してください"), true, Print.highSpeed, text);
                    Print.skipEnd(true, text);
                    Print.tempSlowLiftEnd(true, text);
                }
                state.saveLocation(LocationCategory.inputBattleAction, INPUT);
                return LocationCategory.NO_CHOICE;

            case NO_MOVE:
                state.saveLocation(LocationCategory.inputBattleAction, LocationCategory.FINISH);
                return -1;

            case INPUT:
                input = state.takeNextAction();//入力した数字とinputを同じにする
                Action select;

                if(input < 0){
                    if((self.getStateAction().get(ActionState.oldChargeSpecial).get(ActionStateCounter.flag) == 1 || field.get(Field.SpecialField).get(FieldCounter.flag) == 1)
                        && (-3 <= input && input <= -1)){
                            Print.setFrameStart(text);
                            Print.println(Special.values()[-input - 1].explain, Print.highSpeed, text);
                            Print.setFrameEnd(text);
                            Print.nextLine(scanner, text);
                            state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
                            return input(state, self_is_player1, text, usingItem, scanner);
                        }
                    try{
                        select = Action.values()[-input];
                    }catch(Exception e){
                        System.out.println("正しく入力してください");
                        state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
                        return input(state, self_is_player1, text, usingItem, scanner);
                    }
                    select.explain(text);
                    Print.nextLine(scanner, text);
                    state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
                    return input(state, self_is_player1, text, usingItem, scanner);
                }
                try{
                    if(input == Action.values().length){
                        input = 0;
                    }
                    select = Action.values()[input];
                }catch(Exception e){
                    System.out.println("正しく入力してください");
                    state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
                    return input(state, self_is_player1, text, usingItem, scanner);
                }
                switch(select){
                    case attack:
                    case defense:
                    case tension:
                        if(!checkLegal(state, normalAction(self, field, input) + item_action_num, self, field, text, scanner)){
                            state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
                            state.saveLocation(LocationCategory.isUsingItem, LocationCategory.NO_CHOICE);
                            return input(state, self_is_player1, text, usingItem, scanner);
                        }
                        state.saveLocation(LocationCategory.inputBattleAction, LocationCategory.FINISH);
                        state.saveLocation(LocationCategory.isUsingItem, LocationCategory.NO_CHOICE);
                        return normalAction(self, field, input) + item_action_num;
                    // case escape:
                    //     System.out.println("正しく入力してください");
                    //     state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
                    //     return input(state, self_is_player1, text, usingItem, scanner);
                    //     //input = escape(state, self_is_player1, text, usingItem, scanner);
                    case spell:
                        if((self instanceof Player && ((Player)self).getUseSpell()) || !(self instanceof Player)){
                            state.saveLocation(LocationCategory.inputBattleAction, CHANT_SPELL);
                            return input(state, self_is_player1, text, usingItem, scanner);
                        }else{
                            System.out.println("正しく入力してください");
                            state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
                            return input(state, self_is_player1, text, usingItem, scanner);
                        }

                    case replaceOrb:
                        if((self instanceof Player && ((Player)self).getUseSpell()) || !(self instanceof Player)){
                            state.saveLocation(LocationCategory.inputBattleAction, REPLACE_ORB);
                            return input(state, self_is_player1, text, usingItem, scanner);
                        }else{
                            System.out.println("正しく入力してください");
                            state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
                            return input(state, self_is_player1, text, usingItem, scanner);
                        }

                    case changeSlot:
                        if((self instanceof Player && ((Player)self).getUseSpell() || !(self instanceof Player)) && state.getTurn() == 1){
                            state.saveLocation(LocationCategory.inputBattleAction, CHANGE_SLOT);
                            return input(state, self_is_player1, text, usingItem, scanner);
                        }else{
                            System.out.println("正しく入力してください");
                            state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
                            return input(state, self_is_player1, text, usingItem, scanner);
                        }

                    // case item:
                    //     if(self instanceof Player && ((Player)self).getUseItem()){
                    //         state.saveLocation(LocationCategory.inputBattleAction, ITEM);
                    //         return input(state, self_is_player1, text, usingItem, scanner);
                    //     }else{
                    //         System.out.println("正しく入力してください");
                    //         state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
                    //         return input(state, self_is_player1, text, usingItem, scanner);
                    //     }

                    // case special:
                    //     if(self instanceof Player && ((Player)self).getUseSpecial()){
                    //         state.saveLocation(LocationCategory.inputBattleAction, SPECIAL);
                    //         return input(state, self_is_player1, text, usingItem, scanner);
                    //     }else{
                    //         System.out.println("正しく入力してください");
                    //         state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
                    //         return input(state, self_is_player1, text, usingItem, scanner);
                    //     }

                    case information:
                        state.saveLocation(LocationCategory.inputBattleAction, INFOMATION);
                        return input(state, self_is_player1, text, usingItem, scanner);
                }

            case CHANT_SPELL:
                input = chantSpell(state, self_is_player1, text, usingItem, scanner);//TODO
                if(state.getSavedLocation(LocationCategory.chantSpell) == LocationCategory.FINISH){
                    if(!checkLegal(state, input + item_action_num, self, field, text, scanner)){
                        state.saveLocation(LocationCategory.chantSpell, LocationCategory.NO_CHOICE);
                        state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
                        state.saveLocation(LocationCategory.isUsingItem, LocationCategory.NO_CHOICE);
                        return input(state, self_is_player1, text, usingItem, scanner);
                    }
                    state.saveLocation(LocationCategory.chantSpell, LocationCategory.NO_CHOICE);
                    state.saveLocation(LocationCategory.inputBattleAction, LocationCategory.FINISH);
                    state.saveLocation(LocationCategory.isUsingItem, LocationCategory.NO_CHOICE);
                    return input + item_action_num;
                }
                if(state.getSavedLocation(LocationCategory.chantSpell) == LocationCategory.NO_RETURN_FINISH){
                    state.saveLocation(LocationCategory.chantSpell, LocationCategory.NO_CHOICE);
                    state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
                    return input(state, self_is_player1, text, usingItem, scanner);
                }
                return LocationCategory.NO_CHOICE;
                // input = moveSpell(state, self_is_player1, text, usingItem, scanner);//TODO
                // if(state.getSavedLocation(LocationCategory.moveSpell) == LocationCategory.FINISH){
                //     if(!checkLegal(state, input + item_action_num, self, field, text, scanner)){
                //         state.saveLocation(LocationCategory.moveSpell, LocationCategory.NO_CHOICE);
                //         state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
                //         state.saveLocation(LocationCategory.isUsingItem, LocationCategory.NO_CHOICE);
                //         return input(state, self_is_player1, text, usingItem, scanner);
                //     }
                //     state.saveLocation(LocationCategory.moveSpell, LocationCategory.NO_CHOICE);
                //     state.saveLocation(LocationCategory.inputBattleAction, LocationCategory.FINISH);
                //     state.saveLocation(LocationCategory.isUsingItem, LocationCategory.NO_CHOICE);
                //     return input + item_action_num;
                // }
                // if(state.getSavedLocation(LocationCategory.moveSpell) == LocationCategory.NO_RETURN_FINISH){
                //     state.saveLocation(LocationCategory.moveSpell, LocationCategory.NO_CHOICE);
                //     state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
                //     return input(state, self_is_player1, text, usingItem, scanner);
                // }
                // return LocationCategory.NO_CHOICE;

            case REPLACE_ORB:
                input = replaceOrb(state, self_is_player1, text, usingItem, scanner);//TODO
                if(state.getSavedLocation(LocationCategory.replaceOrb) == LocationCategory.FINISH){
                    if(!checkLegal(state, input + item_action_num, self, field, text, scanner)){
                        state.saveLocation(LocationCategory.replaceOrb, LocationCategory.NO_CHOICE);
                        state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
                        state.saveLocation(LocationCategory.isUsingItem, LocationCategory.NO_CHOICE);
                        return input(state, self_is_player1, text, usingItem, scanner);
                    }
                    state.saveLocation(LocationCategory.replaceOrb, LocationCategory.NO_CHOICE);
                    state.saveLocation(LocationCategory.inputBattleAction, LocationCategory.FINISH);
                    state.saveLocation(LocationCategory.isUsingItem, LocationCategory.NO_CHOICE);
                    return input + item_action_num;
                }
                if(state.getSavedLocation(LocationCategory.replaceOrb) == LocationCategory.NO_RETURN_FINISH){
                    state.saveLocation(LocationCategory.replaceOrb, LocationCategory.NO_CHOICE);
                    state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
                    return input(state, self_is_player1, text, usingItem, scanner);
                }
                return LocationCategory.NO_CHOICE;

            case CHANGE_SLOT:
                changeSpellFromBattle(state, self_is_player1, text, usingItem, scanner);//TODO
                if(state.getSavedLocation(LocationCategory.changeSpellFromBattle) == LocationCategory.NO_RETURN_FINISH){
                    state.saveLocation(LocationCategory.changeSpellFromBattle, LocationCategory.NO_CHOICE);
                    state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
                    return input(state, self_is_player1, text, usingItem, scanner);
                }
                return LocationCategory.NO_CHOICE;
                

            // case ITEM:
            //     input = useItem(state, self_is_player1, text, usingItem, scanner);//TODO
            //     if(state.getSavedLocation(LocationCategory.useBattleItem) == LocationCategory.FINISH){
            //         state.saveLocation(LocationCategory.useBattleItem, LocationCategory.NO_CHOICE);
            //         state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
            //         state.temp_item_action_num = input;
            //         state.saveLocation(LocationCategory.isUsingItem, LocationCategory.TRUE);
            //         return input(state, self_is_player1, text, usingItem, scanner);
            //     }
            //     if(state.getSavedLocation(LocationCategory.useBattleItem) == LocationCategory.NO_RETURN_FINISH){
            //         state.saveLocation(LocationCategory.useBattleItem, LocationCategory.NO_CHOICE);
            //         state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
            //         return input(state, self_is_player1, text, usingItem, scanner);
            //     }
            //     return LocationCategory.NO_CHOICE;

            // case SPECIAL:
            //     input = chargeSpecial(state, self_is_player1, text, usingItem, scanner);//TODO
            //     if(state.getSavedLocation(LocationCategory.chargeSpecial) == LocationCategory.FINISH){
            //         if(!checkLegal(state, input + item_action_num, self, field, text, scanner)){
            //             state.saveLocation(LocationCategory.chargeSpecial, LocationCategory.NO_CHOICE);
            //             state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
            //             state.saveLocation(LocationCategory.isUsingItem, LocationCategory.NO_CHOICE);
            //             return input(state, self_is_player1, text, usingItem, scanner);
            //         }
            //         state.saveLocation(LocationCategory.chargeSpecial, LocationCategory.NO_CHOICE);
            //         state.saveLocation(LocationCategory.inputBattleAction, LocationCategory.FINISH);
            //         state.saveLocation(LocationCategory.isUsingItem, LocationCategory.NO_CHOICE);
            //         return input + item_action_num;
            //     }
            //     if(state.getSavedLocation(LocationCategory.chargeSpecial) == LocationCategory.NO_RETURN_FINISH){
            //         state.saveLocation(LocationCategory.chargeSpecial, LocationCategory.NO_CHOICE);
            //         state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
            //         return input(state, self_is_player1, text, usingItem, scanner);
            //     }
            //     return LocationCategory.NO_CHOICE;

            case INFOMATION:
                information(state, self_is_player1, text, usingItem, scanner);//TODO
                if(state.getSavedLocation(LocationCategory.displayBattleField) == LocationCategory.FINISH){
                    state.saveLocation(LocationCategory.displayBattleField, LocationCategory.NO_CHOICE);
                    state.saveLocation(LocationCategory.inputBattleAction, EXPLAIN);
                    return input(state, self_is_player1, text, usingItem, scanner);
                }
                return LocationCategory.NO_CHOICE;
                

            default:
                System.out.println("error inputBattleAction");
                state.saveLocation(LocationCategory.inputBattleAction, LocationCategory.FINISH);
                return LocationCategory.NO_CHOICE;
        }
    }

    // プレイヤーの入力に対して、行動が合法かどうかを判定する(コンピュータは元から合法手の中から選んでいるためチェックする必要が無い)
    private static boolean checkLegal(State state, int action, Character self, Map<Field,Map<FieldCounter, Integer>> field, boolean text, Scanner scanner){
        if(ChangeAbnormalState.execute(self, field, AbnormalState.Nervous, action % ACTION_NUM, 0, text) || 
        ChangeAbnormalState.execute(self, field, AbnormalState.SuperNervous, action % ACTION_NUM, 0, text) || 
        ChangeAbnormalState.execute(self, field, AbnormalState.SuperStomatitis, action % ACTION_NUM, 0, text)){
            return false;
        }
        for(int act: self.getLegalAction(state, ChangeWeather.nowWeather(state), field, state.getTurn())){
            if(act == action){
                return true;
            }
        }
        Print.println("その行動は選択できません", true, Print.highSpeed, text);
        Print.nextLine(scanner, text);
        return false;
    }

    // // 呪文関連選択
    // private static int moveSpell(State state, boolean self_is_player1, boolean text, boolean usingItem , Scanner scanner){
    //     // Print.print("<br>呪文は" + MainStatus.mp.jName + "を利用して相手を攻撃する。スロットに入っていない呪文は使用できない。", Print.highSpeed, text);
    //     // Print.print("<br>1:使用 2:スロット入れ替え", Print.highSpeed, text);
    //     // if(state.getTurn() == 1){
    //     //     Print.println(" 3:初期スロット変更", Print.highSpeed, text);
    //     // }else{
    //     //     Print.println("", Print.highSpeed, text);
    //     // }
    //     // int select = Print.input(scanner, text);
    //     // while(select < 0 && select > (state.getTurn() == 1 ? 3 : 2)){
    //     //     System.out.println("正しく入力してください");
    //     //     select = Print.input(scanner, text);
    //     // }
    //     // switch(select){
    //     //     case 0:
    //     //         select = input(state, self_is_player1, text, usingItem, scanner);
    //     //         break;
    //     //     case 1:
    //     //         select = chantSpell(state, self_is_player1, text, usingItem, scanner);
    //     //         break;
    //     //     case 2:
    //     //         select = addSpell(state, self_is_player1, text, usingItem, scanner);
    //     //         break;
    //     //     case 3:
    //     //         select = changeSpellFromBattle(state, self_is_player1, text, usingItem, scanner);
    //     //         break;
    //     // }
    //     int select;
    //     final int EXPLAIN = 1;
    //     final int SELECT = 2;
    //     final int CHANT_SPELL = 3;
    //     final int ADD_SPELL = 4;
    //     final int CHANGE_SPELL = 5;
    //     switch(state.getSavedLocation(LocationCategory.moveSpell)){
    //         case LocationCategory.NO_CHOICE:
    //             state.saveLocation(LocationCategory.moveSpell, EXPLAIN);
    //             return moveSpell(state, self_is_player1, text, usingItem, scanner);

    //         case EXPLAIN:
    //             Print.displayBattleMenu(state, self_is_player1, text);
    //             Print.println("", Print.highSpeed, text);
    //             Print.setFrameStart(text);
    //             Print.println("呪文は" + MainStatus.mp.jName + "を利用して相手を攻撃する。スロットにオーブが入っていない呪文は使用できない。", Print.highSpeed, text);
    //             
    //             Print.print("1:使用 2:オーブ入れ替え", Print.highSpeed, text);
    //             if(state.getTurn() == 1){
    //                 Print.print(" 3:初期オーブ変更", Print.highSpeed, text);
    //             }
    //             Print.setFrameEnd(text);
    //             Print.println("", Print.highSpeed, text);
    //             state.saveLocation(LocationCategory.moveSpell, SELECT);
    //             return LocationCategory.NO_CHOICE;

    //         case SELECT:
    //             select = state.takeNextAction();
    //             if(select < 0 && select > (state.getTurn() == 1 ? 3 : 2)){
    //                 System.out.println("正しく入力してください moveSpell");
    //                 return LocationCategory.NO_CHOICE;
    //             }
    //             switch(select){
    //                 case 0:
    //                     state.saveLocation(LocationCategory.moveSpell, LocationCategory.NO_RETURN_FINISH);
    //                     return LocationCategory.NO_CHOICE;
    //                 case 1:
    //                     state.saveLocation(LocationCategory.moveSpell, CHANT_SPELL);
    //                     return moveSpell(state, self_is_player1, text, usingItem, scanner);
    //                 case 2:
    //                     state.saveLocation(LocationCategory.moveSpell, ADD_SPELL);
    //                     return moveSpell(state, self_is_player1, text, usingItem, scanner);
    //                 case 3:
    //                     state.saveLocation(LocationCategory.moveSpell, CHANGE_SPELL);
    //                     return moveSpell(state, self_is_player1, text, usingItem, scanner);
    //                 default:
    //                     System.out.println("error moveSpell");
    //                     state.saveLocation(LocationCategory.moveSpell, LocationCategory.NO_RETURN_FINISH);
    //                     return LocationCategory.NO_CHOICE;
    //             }

    //         case CHANT_SPELL:
    //             select = chantSpell(state, self_is_player1, text, usingItem, scanner);//TODO
    //             if(state.getSavedLocation(LocationCategory.chantSpell) == LocationCategory.FINISH){
    //                 state.saveLocation(LocationCategory.chantSpell, LocationCategory.NO_CHOICE);
    //                 state.saveLocation(LocationCategory.moveSpell, LocationCategory.FINISH);
    //                 return select;
    //             }
    //             if(state.getSavedLocation(LocationCategory.chantSpell) == LocationCategory.NO_RETURN_FINISH){
    //                 state.saveLocation(LocationCategory.chantSpell, LocationCategory.NO_CHOICE);
    //                 state.saveLocation(LocationCategory.moveSpell, LocationCategory.NO_RETURN_FINISH);
    //                 return LocationCategory.NO_CHOICE;
    //             }
    //             return LocationCategory.NO_CHOICE;
                
    //         case ADD_SPELL:
    //             select = replaceOrb(state, self_is_player1, text, usingItem, scanner);//TODO
    //             if(state.getSavedLocation(LocationCategory.replaceOrb) == LocationCategory.FINISH){
    //                 state.saveLocation(LocationCategory.replaceOrb, LocationCategory.NO_CHOICE);
    //                 state.saveLocation(LocationCategory.moveSpell, LocationCategory.FINISH);
    //                 return select;
    //             }
    //             if(state.getSavedLocation(LocationCategory.replaceOrb) == LocationCategory.NO_RETURN_FINISH){
    //                 state.saveLocation(LocationCategory.replaceOrb, LocationCategory.NO_CHOICE);
    //                 state.saveLocation(LocationCategory.moveSpell, LocationCategory.NO_RETURN_FINISH);
    //                 return LocationCategory.NO_CHOICE;
    //             }
    //             return LocationCategory.NO_CHOICE;

    //         case CHANGE_SPELL:
    //             changeSpellFromBattle(state, self_is_player1, text, usingItem, scanner);//TODO
    //             if(state.getSavedLocation(LocationCategory.changeSpellFromBattle) == LocationCategory.NO_RETURN_FINISH){
    //                 state.saveLocation(LocationCategory.changeSpellFromBattle, LocationCategory.NO_CHOICE);
    //                 state.saveLocation(LocationCategory.moveSpell, LocationCategory.NO_RETURN_FINISH);
    //                 return LocationCategory.NO_CHOICE;
    //             }
    //             return LocationCategory.NO_CHOICE;

    //         default:
    //             System.out.println("error moveSpell");
    //             state.saveLocation(LocationCategory.moveSpell, LocationCategory.NO_RETURN_FINISH);
    //             return LocationCategory.NO_CHOICE;

    //     }
    // }

    // 呪文スロット総入れ替え
    private static int changeSpellFromBattle(State state, boolean self_is_player1, boolean text, boolean usingItem , Scanner scanner){
        state.sendNextAction(self_is_player1);
        Character self = state.getPlayer(self_is_player1);
        if(state.getTurn() != 1){
            Print.println("オーブは 1 ターン目のみ変更可能", Print.highSpeed, text);
            state.saveLocation(LocationCategory.changeSpellFromBattle, LocationCategory.NO_RETURN_FINISH);
            return LocationCategory.NO_CHOICE;
        }
        changeSpell(self, text, scanner);
        if(self.getSavedLocation(LocationCategory.changeSpell) == LocationCategory.FINISH){
            self.saveLocation(LocationCategory.changeSpell, LocationCategory.NO_CHOICE);
            state.saveLocation(LocationCategory.changeSpellFromBattle, LocationCategory.NO_RETURN_FINISH);
        }
        return LocationCategory.NO_CHOICE;
    }

    // 呪文スロット総入れ替え
    public static void changeSpell(Character self, boolean text, Scanner scanner){
        Spell[] selfSpellArray = self.getSpellArray();
        int selfSpellNum = selfSpellArray.length;
        List<Spell> selfSpellSlot = self.getSpellSlot();
        boolean isDynamic = false;
        int input;
        final int EXPLAIN = 1;
        final int NO_SPELL_STEP = 2;
        final int SET_SPELL = 3;
        final int CHECK_SLOT = 4;
        switch(self.getSavedLocation(LocationCategory.changeSpell)){
            case LocationCategory.NO_CHOICE:
                if(selfSpellNum == 0){
                    Print.println("習得している呪文がありません", true, Print.highSpeed, text);
                    Print.clearStaticText(text);
                    Print.changeWaitTextToLT(text);
                    self.saveLocation(LocationCategory.changeSpell, NO_SPELL_STEP);
                    return;
                }
                self.setSpellSlot(new ArrayList<>());
                self.saveLocation(LocationCategory.changeSpell, EXPLAIN);
                changeSpell(self, text, scanner);
                return;

            case NO_SPELL_STEP:
                self.saveLocation(LocationCategory.changeSpell, LocationCategory.FINISH);
                return;
                


            case EXPLAIN:
                // Print.println("", isDynamic, Print.highSpeed, text);
                // Print.println("所持オーブ一覧", isDynamic, Print.highSpeed, text);
                // 
                Print.startFrame(isDynamic, text);

                Print.println("現在のスロット", Print.highSpeed, text);
                for(int i = 0; i < self.getSpellSlotNum(); i++){
                    Print.print((i + 1) + " ", Print.highSpeed, text);
                    if(i < self.getSpellSlot().size()){
                        Print.print(self.getSpellSlot().get(i).jName, Print.highSpeed, text);
                    }else{
                        Print.print("____", Print.highSpeed, text);
                    }
                    Print.print(Print.space(2, text), Print.highSpeed, text);
                }
                Print.println("", Print.highSpeed, text);
                Print.println("", Print.highSpeed, text);
                

                // Print.println("スロット数 : " + self.getSpellSlotNum(), isDynamic, Print.highSpeed, text);
                Print.println("所持オーブ", isDynamic, Print.highSpeed, text);
                
                for(int i = 0; i < selfSpellNum; i++){
                    Color color = Color.white;
                    if(selfSpellSlot.contains(selfSpellArray[i])){
                        color = Color.gray;
                    }
                    Print.println(color.toColor((i + 1) + ":" + selfSpellArray[i].getLevelName(self)), isDynamic, Print.highSpeed, text);
                }
                Print.println("", isDynamic, Print.highSpeed, text);
                
                Print.println("Enter:選択終了", isDynamic, Print.highSpeed, text);
                Print.tempSlowLiftStart(true, text);
                Print.skipStart(true, text);
                Print.println(Color.yellow.toColor((selfSpellSlot.size() + 1) + "つ目のオーブを入力してください"), true, Print.highSpeed, text);
                Print.skipEnd(true, text);
                Print.tempSlowLiftEnd(true, text);
                self.saveLocation(LocationCategory.changeSpell, SET_SPELL);
                return;
                

            case SET_SPELL:
                input = self.takeNextAction();
                if(input == 0){
                    for(int i = 0; i < self.getSpellSlotNum() - selfSpellSlot.size(); i++){
                        selfSpellSlot.add(Spell.NULL);
                    }
                    Print.startFrame(isDynamic, text);
                    Print.println("現在のスロット", isDynamic, Print.highSpeed, text);
                    Print.displaySpellSlot(self, isDynamic, text);
                    Print.endFrame(isDynamic, text);
                    Print.println("", isDynamic, Print.highSpeed, text);
                    Print.println("このスロットでよろしいですか", isDynamic, Print.highSpeed, text);
                    Print.println("", isDynamic, Print.highSpeed, text);
                    Print.println("Enter:はい" + Print.space(2, text) + "1:いいえ", isDynamic, Print.highSpeed, text);
                    Print.changeWaitTextToLT(text);
                    self.saveLocation(LocationCategory.changeSpell, CHECK_SLOT);
                    return;
                }
                if(input < 0 || selfSpellNum < input){
                    Print.println("正しく入力してください", isDynamic, Print.highSpeed, text);
                    Print.nextLine(scanner, text);
                    self.saveLocation(LocationCategory.changeSpell, EXPLAIN);
                    changeSpell(self, text, scanner);
                    return;
                }
                if(selfSpellSlot.contains(selfSpellArray[input - 1])){
                    Print.println("そのオーブは既に選択しています", true, Print.highSpeed, text);
                    
                    Print.nextLine(scanner, text);
                    self.saveLocation(LocationCategory.changeSpell, EXPLAIN);
                    Print.changeWaitTextToLT(text);
                    // changeSpell(self, text, scanner);
                    return;
                }else{
                    selfSpellSlot.add(selfSpellArray[input-1]);
                    if(selfSpellSlot.size() < self.getSpellSlotNum() && selfSpellSlot.size() < selfSpellNum){
                        self.setSpellSlot(selfSpellSlot);
                        self.saveLocation(LocationCategory.changeSpell, EXPLAIN);
                        changeSpell(self, text, scanner);
                        return;
                    }
                }
                for(int i = 0; i < self.getSpellSlotNum() - selfSpellSlot.size(); i++){
                    selfSpellSlot.add(Spell.NULL);
                }
                self.setSpellSlot(selfSpellSlot);
                Print.startFrame(isDynamic, text);
                Print.println("現在のスロット", isDynamic, Print.highSpeed, text);
                Print.displaySpellSlot(self, isDynamic, text);
                Print.endFrame(isDynamic, text);
                Print.println("", isDynamic, Print.highSpeed, text);
                Print.println("このスロットでよろしいですか", isDynamic, Print.highSpeed, text);
                Print.println("", isDynamic, Print.highSpeed, text);
                Print.println("Enter:はい" + Print.space(2, text) + "1:いいえ", isDynamic, Print.highSpeed, text);
                Print.changeWaitTextToLT(text);
                self.saveLocation(LocationCategory.changeSpell, CHECK_SLOT);
                return;

            case CHECK_SLOT:
                input = self.takeNextAction();
                if(input == 0){
                    Print.clearStaticText(text);
                    self.saveLocation(LocationCategory.changeSpell, LocationCategory.FINISH);
                    return;
                }else if(input == 1){
                    self.saveLocation(LocationCategory.changeSpell, LocationCategory.NO_CHOICE);
                    changeSpell(self, text, scanner);
                    return;
                }else{
                    Print.startFrame(isDynamic, text);
                    Print.println("現在のスロット", isDynamic, Print.highSpeed, text);
                    Print.displaySpellSlot(self, isDynamic, text);
                    Print.endFrame(isDynamic, text);
                    Print.println("", isDynamic, Print.highSpeed, text);
                    Print.println("このスロットでよろしいですか", isDynamic, Print.highSpeed, text);
                    Print.println("", isDynamic, Print.highSpeed, text);
                    Print.println("Enter:はい" + Print.space(2, text) + "1:いいえ", isDynamic, Print.highSpeed, text);
                    Print.changeWaitTextToLT(text);
                    return;
                }
                
            default:
                System.out.println("error changeSpell");
                return;
        }
    }

    // AI用スペル入れ替え（基本ランダム、Jokeを優先）
    public static void changeSpellForAI(Character self, Random rand){
        List<Spell> newSpellSlot = new ArrayList<>();
        List<Spell> learnedSpells = new ArrayList<>(self.getLearnedSpellLevel().keySet());
        // boolean firstBase = false;
        // boolean firstOn = false;
        while(newSpellSlot.size() < self.getSpellSlotNum() && learnedSpells.size() != 0){
            if(learnedSpells.contains(Spell.On_Joke)){
                newSpellSlot.add(Spell.On_Joke);
                learnedSpells.remove(Spell.On_Joke);
                continue;
            }
            // if(!firstBase){
            //     List<Spell> baseSpell = new ArrayList<>(){{add(Spell.Fire); add(Spell.Wind); add(Spell.Stone);}};
            //     for(Spell spell : new ArrayList<>(baseSpell)){
            //         if(!learnedSpells.contains(spell)){
            //             baseSpell.remove(spell);
            //         }
            //     }
            //     if(baseSpell.size() != 0){
            //         int idx = rand.nextInt(baseSpell.size());
            //         newSpellSlot.add(baseSpell.get(idx));
            //         learnedSpells.remove(baseSpell.get(idx));
            //     }
            //     firstBase = true;
            //     continue;
            // }
            // if(!firstOn){
            //     List<Spell> onSpell = new ArrayList<>(){{add(Spell.On_SpellReflect); add(Spell.On_StateChange);}};
            //     for(Spell spell : new ArrayList<>(onSpell)){
            //         if(!learnedSpells.contains(spell)){
            //             onSpell.remove(spell);
            //         }
            //     }
            //     if(onSpell.size() != 0){
            //         int idx = rand.nextInt(onSpell.size());
            //         newSpellSlot.add(onSpell.get(idx));
            //         learnedSpells.remove(onSpell.get(idx));
            //     }
            //     firstOn = true;
            //     continue;
            // }
            int idx = rand.nextInt(learnedSpells.size());
            newSpellSlot.add(learnedSpells.get(idx));
            learnedSpells.remove(idx);
        }
        self.setSpellSlot(newSpellSlot);
        return;
    }

    // 通常行動
    private static int normalAction(Character self, Map<Field,Map<FieldCounter, Integer>> field, int input){
        if(self.getStateAction().get(ActionState.oldChargeSpecial).get(ActionStateCounter.flag) == 1 || field.get(Field.SpecialField).get(FieldCounter.flag) == 1){
            input += (3 + Spell.NUM + 1);
        }else if(self.getStateAction().get(ActionState.newChargeSpecial).get(ActionStateCounter.flag) == 1 && self.getAttribute().ordinal() + 1 == input){
            input += (3 + Spell.NUM + 1);
        }
        return input;
    }

    // 逃げる
    private static int escape(State state, boolean self_is_player1, boolean text, boolean usingItem , Scanner scanner){
        if(usingItem){
            Print.println("", Print.highSpeed, text);
            Print.println("既にアイテムは選ばれている", Print.highSpeed, text);
            return input(state, self_is_player1, text, usingItem, scanner);
        }
        return 0;
    }
    
    // 呪文使用
    private static int chantSpell(State state, boolean self_is_player1, boolean text, boolean usingItem , Scanner scanner){
        // Character self = state.getPlayer(self_is_player1);
        // Print.println("<br>どの" + Action.spell.jName + "をつかいますか(-番号入力で詳細)", Print.highSpeed, text);
        // Print.displaySpellSlot(self, text);

        // int inputSpellNum = Print.input(scanner, text) - 1;
        // if(inputSpellNum == -1){
        //     return input(state, self_is_player1, text, usingItem, scanner);
        // }
        // try{
        //     if(inputSpellNum < -1){
        //         Spell inputN = self.getSpellSlot().get(-inputSpellNum - 2);
        //         if(inputN == Spell.NULL){
        //             System.out.println("正しく入力してください");
        //             return input(state, self_is_player1, text, usingItem, scanner);  
        //         }
        //         Print.println("<br>" + inputN.getExplain(state, self_is_player1, scanner), Print.highSpeed, text);
        //         Print.nextLine(scanner, text);
        //         return chantSpell(state, self_is_player1, text, usingItem, scanner);
        //     }
        //     Spell inputSpell = self.getSpellSlot().get(inputSpellNum);
        //     if(inputSpell == Spell.NULL){
        //         System.out.println("正しく入力してください");
        //         return input(state, self_is_player1, text, usingItem, scanner);  
        //     }
        //     return inputSpell.ordinal() + 4;
        // }
        // catch(Exception e){
        //     System.out.println("正しく入力してください");
        //     return input(state, self_is_player1, text, usingItem, scanner);
        // }

        final int EXPLAIN = 1;
        final int INPUT = 2;
        final int CHECK_SPELL = 3;
        Character self = state.getPlayer(self_is_player1);
        switch(state.getSavedLocation(LocationCategory.chantSpell)){
            case LocationCategory.NO_CHOICE:
                state.saveLocation(LocationCategory.chantSpell, EXPLAIN);
                return chantSpell(state, self_is_player1, text, usingItem, scanner);

            case EXPLAIN:
                Print.displayBattleMenu(state, self_is_player1, text);
                Print.println("", Print.highSpeed, text);
                Print.setFrameStart(text);
                Print.println("どの" + Action.spell.jName + "をつかいますか", Print.highSpeed, text);
                
                Print.displaySpellSlot(self, false, text);
                Print.setFrameEnd(text);
                state.saveLocation(LocationCategory.chantSpell, INPUT);
                return LocationCategory.NO_CHOICE;

            case INPUT:
                int inputSpellNum = state.takeNextAction() - 1;
                if(inputSpellNum == -1){
                    state.saveLocation(LocationCategory.chantSpell, LocationCategory.NO_RETURN_FINISH);
                    return LocationCategory.NO_CHOICE;
                }
                try{
                    if(inputSpellNum < -1){
                        Spell inputSpell = self.getSpellSlot().get(-inputSpellNum - 2);
                        if(inputSpell == Spell.NULL){
                            System.out.println("正しく入力してください");
                            state.saveLocation(LocationCategory.chantSpell, LocationCategory.NO_RETURN_FINISH);
                            return LocationCategory.NO_CHOICE;
                        }
                        Print.println("", Print.highSpeed, text);
                        inputSpell.explain(state, self_is_player1, text, scanner);
                        Print.nextLine(scanner, text);
                        state.saveLocation(LocationCategory.chantSpell, EXPLAIN);
                        return chantSpell(state, self_is_player1, text, usingItem, scanner);
                    }
                    Spell inputSpell = self.getSpellSlot().get(inputSpellNum);
                    if(inputSpell == Spell.NULL){
                        System.out.println("正しく入力してください");
                        state.saveLocation(LocationCategory.chantSpell, LocationCategory.NO_RETURN_FINISH);
                        return LocationCategory.NO_CHOICE;
                    }
                    self.setTempSpell(inputSpell);
                    Print.displayBattleMenu(state, self_is_player1, text);
                    inputSpell.explain(state, self_is_player1, text, scanner);
                    Print.println("", Print.highSpeed, text);
                    Print.println("Enter:決定 1:キャンセル", Print.highSpeed, text);
                    Print.changeWaitTextToLT(text);
                    state.saveLocation(LocationCategory.chantSpell, CHECK_SPELL);
                    return LocationCategory.NO_CHOICE;
                }catch(Exception e){
                    System.out.println("正しく入力してください");
                    state.saveLocation(LocationCategory.chantSpell, LocationCategory.NO_RETURN_FINISH);
                    return LocationCategory.NO_CHOICE;
                }

            case CHECK_SPELL:
                if(state.takeNextAction() == 0){
                    Spell checkSpell = self.getTempSpell();
                    state.saveLocation(LocationCategory.chantSpell, LocationCategory.FINISH);
                    return checkSpell.ordinal() + 4;
                }else{
                    state.saveLocation(LocationCategory.chantSpell, LocationCategory.NO_RETURN_FINISH);
                    return LocationCategory.NO_CHOICE;
                }
                

            default:
                System.out.println("error chantSpell");
                state.saveLocation(LocationCategory.chantSpell, LocationCategory.NO_RETURN_FINISH);
                return LocationCategory.NO_CHOICE;

                
        }
    }

    // // アイテム使用
    // private static int useItem(State state, boolean self_is_player1, boolean text, boolean usingItem , Scanner scanner){
    //     Character self = state.getPlayer(self_is_player1);
    //     // if(usingItem){
    //     //     Print.println("<br>既に" + Action.item.jName + "は選ばれている", Print.highSpeed, text);
    //     //     return input(state, self_is_player1, text, usingItem, scanner);
    //     // }
    //     // if(self.getStateAction().get(ActionState.UseItem).get(ActionStateCounter.flag) == 1){
    //     //     Print.println("<br>既に" + Action.item.jName + "を使っている", Print.highSpeed, text);
    //     //     return input(state, self_is_player1, text, usingItem, scanner);
    //     // }
    //     // Print.println("<br>アイテムは戦闘中に1回のみ使用でき、ターンを消費しない。アイテムには使用条件がある。", Print.highSpeed, text);
    //     // Print.println("<br>何の" + Action.item.jName + "を使いますか(-番号入力で詳細)", Print.highSpeed, text);
    //     // List<BattleItem> havaItems = new ArrayList<BattleItem>();
    //     // //添え字表示用変数
    //     // int j = 0;
    //     // for(BattleItem item : BattleItem.values()){
    //     //     for(int i = 0; i < self.getItemList().get(item); i++){
    //     //         havaItems.add(item);
    //     //         Print.print(++j + ":" + item.jName + "    ", Print.highSpeed, text);
    //     //     }
    //     //     /* if(self.getItemList().get(item) > 0){
    //     //         havaItems.add(item);
    //     //         Print.print(" ", Print.highSpeed, text);
    //     //         Print.print(++j + ":" + item.jName + "×" + self.getItemList().get(item), Print.highSpeed, text);
    //     //     } */
    //     // }
    //     // Print.println("", Print.highSpeed, text);
    //     // int inputItemNum = Print.input(scanner, text) - 1;
    //     // if(inputItemNum == -1){
    //     //     return input(state, self_is_player1, text, usingItem, scanner);
    //     // }               
    //     // try{
    //     //     if(inputItemNum < -1){
    //     //         BattleItem inputN2 = havaItems.get(-inputItemNum - 2);
    //     //         Print.println("<br>" + inputN2.battleExplain, Print.middleSpeed, text);
    //     //         Print.nextLine(scanner, text);
    //     //         return useItem(state, self_is_player1, text, usingItem, scanner);
    //     //     }
    //     //     BattleItem inputItem = havaItems.get(inputItemNum);
    //     //     if(!inputItem.battleUseAble(self)){
    //     //         Print.println("使用条件を満たしていません", Print.highSpeed, text);
    //     //         return input(state, self_is_player1, text, usingItem, scanner);
    //     //     }
    //     //     Print.println("<br>" + Action.item.jName + "を使うターンの行動を決めてください", Print.highSpeed, text);
    //     //     return (inputItem.ordinal() + 1) * (ACTION_NUM)
    //     //      + input(state, self_is_player1, text, true, scanner);
    //     // }
    //     // catch(Exception e){
    //     //     System.out.println("正しく入力してください");
    //     //     return useItem(state, self_is_player1, text, usingItem, scanner);
    //     // }
    //     List<BattleItem> havaItems = new ArrayList<BattleItem>();
    //     for(BattleItem item : BattleItem.values()){
    //         for(int i = 0; i < self.getItemList().get(item); i++){
    //             havaItems.add(item);
    //         }
    //     }
    //     final int EXPLAIN = 1;
    //     final int SELECT = 2;
    //     switch(state.getSavedLocation(LocationCategory.useBattleItem)){
    //         case LocationCategory.NO_CHOICE:
    //             if(usingItem){
    //                 Print.println("", Print.highSpeed, text);
    //                 Print.println("既にアイテムは選ばれている", Print.highSpeed, text);
    //                 state.saveLocation(LocationCategory.useBattleItem, LocationCategory.NO_RETURN_FINISH);
    //                 return LocationCategory.NO_CHOICE;
    //             }
    //             if(self.getStateAction().get(ActionState.UseItem).get(ActionStateCounter.flag) == 1){
    //                 Print.println("", Print.highSpeed, text);
    //                 Print.println("既にアイテムを使っている", Print.highSpeed, text);
    //                 state.saveLocation(LocationCategory.useBattleItem, LocationCategory.NO_RETURN_FINISH);
    //                 return LocationCategory.NO_CHOICE;
    //             }

    //         case EXPLAIN:
    //             Print.println("", Print.highSpeed, text);
    //             Print.println("アイテムは戦闘中に 1回のみ使用でき、ターンを消費しない。アイテムには使用条件がある。", Print.highSpeed, text);
    //             Print.println("", Print.highSpeed, text);
    //             Print.println("何のアイテムを使いますか", Print.highSpeed, text);
    //             int j = 0;
    //             for(BattleItem item : havaItems){
    //                 Print.print(++j + ":" + item.jName + "    ", Print.highSpeed, text);
    //             }
    //             Print.println("", Print.highSpeed, text);
    //             state.saveLocation(LocationCategory.useBattleItem, SELECT);
    //             return LocationCategory.NO_CHOICE;

    //         case SELECT:
    //             int inputItemNum = state.takeNextAction() - 1;
    //             if(inputItemNum == -1){
    //                 state.saveLocation(LocationCategory.useBattleItem, LocationCategory.NO_RETURN_FINISH);
    //                 return LocationCategory.NO_CHOICE;
    //             }               
    //             try{
    //                 if(inputItemNum < -1){
    //                     BattleItem inputN2 = havaItems.get(-inputItemNum - 2);
    //                     Print.println("", Print.highSpeed, text);
    //                     Print.println(inputN2.battleExplain, Print.middleSpeed, text);
    //                     Print.nextLine(scanner, text);
    //                     state.saveLocation(LocationCategory.useBattleItem, EXPLAIN);
    //                     return useItem(state, self_is_player1, text, usingItem, scanner);
    //                 }
    //                 BattleItem inputItem = havaItems.get(inputItemNum);
    //                 if(!inputItem.battleUseAble(self)){
    //                     Print.println("使用条件を満たしていません", Print.highSpeed, text);
    //                     state.saveLocation(LocationCategory.useBattleItem, LocationCategory.NO_RETURN_FINISH);
    //                     return LocationCategory.NO_CHOICE;
    //                 }
    //                 Print.println("", Print.highSpeed, text);
    //                 Print.println(Action.item.jName + "を使うターンの行動を決めてください", Print.highSpeed, text);
    //                 state.saveLocation(LocationCategory.useBattleItem, LocationCategory.FINISH);
    //                 return (inputItem.ordinal() + 1) * (ACTION_NUM);
    //             }
    //             catch(Exception e){
    //                 System.out.println("正しく入力してください");
    //                 state.saveLocation(LocationCategory.useBattleItem, EXPLAIN);
    //                 return useItem(state, self_is_player1, text, usingItem, scanner);
    //             }

    //         default:
    //             System.out.println("error useBattleItem");
    //             state.saveLocation(LocationCategory.useBattleItem, LocationCategory.NO_RETURN_FINISH);
    //             return LocationCategory.NO_CHOICE;
    //     }
    // }

    // // 旧必殺技チャージ
    // private static int chargeSpecial(State state, boolean self_is_player1, boolean text, boolean usingItem , Scanner scanner){
    //     Character self = state.getPlayer(self_is_player1);
    //     if(self.getStateAction().get(ActionState.UsedSpecial).get(ActionStateCounter.flag) == 1){
    //         Print.println("", Print.highSpeed, text);
    //         Print.println("既に" + Action.special.jName + "は使われている", Print.highSpeed, text);
    //         state.saveLocation(LocationCategory.chargeSpecial, LocationCategory.NO_RETURN_FINISH);
    //         return LocationCategory.NO_CHOICE;
    //     }
    //     if(!self.getUseSpecial()){
    //         Print.println("", Print.highSpeed, text);
    //         System.out.println(Action.special.jName + "は使えない");
    //         state.saveLocation(LocationCategory.chargeSpecial, LocationCategory.NO_RETURN_FINISH);
    //         return LocationCategory.NO_CHOICE;
    //     }
    //     state.saveLocation(LocationCategory.chargeSpecial, LocationCategory.FINISH);
    //     return 4 + Spell.NUM;
    // }

    // 呪文スロット1つ入れ替え
    private static int replaceOrb(State state, boolean self_is_player1, boolean text, boolean usingItem , Scanner scanner){
        Character self = state.getPlayer(self_is_player1);
        List<Spell> spellArray = new ArrayList<>();
        List<Spell> slot = self.getSpellSlot();
        for(Spell spell : self.getLearnedSpellLevel().keySet()){
            if(slot.contains(spell) || spell == Spell.NULL){
                continue;
            }
            spellArray.add(spell);
        }
        // if(spellArray.size() == 0){
        //     Print.println("入れ替えられるオーブがありません", Print.highSpeed, text);
        //     Print.nextLine(scanner, text);
        //     return input(state, self_is_player1, text, usingItem, scanner);
        // }
        // Print.println("どの" + Action.spell.jName + "を入れ替えますか<br>" + Print.toRed("※ 最後尾の呪文が入れ替えられます<br>"), Print.highSpeed, text);
        // Print.println("所持" + Action.spell.jName, Print.highSpeed, text);
        // for(int i = 0; i < spellArray.size(); i++){
        //     Print.print(" ", Print.highSpeed, text);
        //     Print.print((i + 1) + ":" + spellArray.get(i).getLevelName(self), Print.highSpeed, text);
        // }
        // Print.println("<br>現在のスロット:", Print.highSpeed, text);
        // for(int i = 0; i < slot.size(); i++){
        //     Print.print(" " + (i + 1) + ":" + slot.get(i).getLevelName(self), Print.highSpeed, text);
        // }
        // Print.println("", Print.highSpeed, text);
        // int inputAS = Print.input(scanner, text) - 1;
        // if(inputAS == -1){
        //     return input(state, self_is_player1, text, usingItem, scanner);
        // }
        // if(inputAS < 0 || inputAS >= spellArray.size()){
        //     System.out.println("正しく入力してください");
        //     Print.nextLine(scanner, text);
        //     return addSpell(state, self_is_player1, text, usingItem, scanner);
        // }
        // Spell inputN = spellArray.get(inputAS);
        // inputAS = inputN.ordinal();
        // if(0 <= inputAS && inputAS < Spell.NUM){
        //     return inputAS + 4 + Spell.NUM + 1 + Special.NUM;
        // }else{
        //     System.out.println("正しく入力してください");
        //     Print.nextLine(scanner, text);
        //     return addSpell(state, self_is_player1, text, usingItem, scanner);
        // }
        final int EXPLAIN = 1;
        final int SELECT = 2;
        switch(state.getSavedLocation(LocationCategory.replaceOrb)){
            case LocationCategory.NO_CHOICE:
                state.saveLocation(LocationCategory.replaceOrb, EXPLAIN);
                return replaceOrb(state, self_is_player1, text, usingItem, scanner);

            case EXPLAIN:
                if(spellArray.size() == 0){
                    Print.println("入れ替えられるオーブがありません", true, Print.highSpeed, text);
                    Print.nextLine(scanner, text);
                    state.saveLocation(LocationCategory.replaceOrb, LocationCategory.NO_RETURN_FINISH);
                    return LocationCategory.NO_CHOICE;
                }
                Print.displayBattleMenu(state, self_is_player1, text);
                Print.startFrame(false, text);
                Print.tempSlowLiftStart(true, text);
                Print.skipStart(true, text);
                Print.println(Color.yellow.toColor("追加するオーブを選択してください"), true, Print.highSpeed, text);
                
                Print.println(Color.scarlet.toColor("※ 最後尾の呪文が入れ替えられます"), true, Print.highSpeed, text);
                Print.skipEnd(true, text);
                Print.tempSlowLiftEnd(true, text);
                
                Print.println("現在のスロット:", Print.highSpeed, text);
                for(int i = 0; i < slot.size(); i++){
                    Print.print(" " + (i + 1) + " " + slot.get(i).getLevelName(self), Print.highSpeed, text);

                }
                Print.println("", Print.highSpeed, text);
                Print.println("", Print.highSpeed, text);

                Print.println("所持オーブ", Print.highSpeed, text);
                Print.startTable(text);
                Print.startRow(text);
                for(int i = 0; i < spellArray.size(); i++){
                    Print.print((i + 1) + ":" + spellArray.get(i).getLevelName(self), Print.highSpeed, text);
                    Print.print(Print.space(4, text), Print.highSpeed, text);
                    if((i + 1) % 4 == 0){
                        Print.endRow(text);
                        Print.startRow(text);
                    }else{
                        Print.separateRow(text);
                    }
                }
                Print.endRow(text);
                Print.endTable(text);
                Print.endFrame(false, text);
                state.saveLocation(LocationCategory.replaceOrb, SELECT);
                return LocationCategory.NO_CHOICE;

            case SELECT:
                
                int inputAS = state.takeNextAction() - 1;
                if(inputAS == -1){
                    state.saveLocation(LocationCategory.replaceOrb, LocationCategory.NO_RETURN_FINISH);
                    return LocationCategory.NO_CHOICE;
                }
                if(inputAS < 0 || inputAS >= spellArray.size()){
                    System.out.println("正しく入力してください");
                    Print.nextLine(scanner, text);
                    state.saveLocation(LocationCategory.replaceOrb, EXPLAIN);
                    return replaceOrb(state, self_is_player1, text, usingItem, scanner);
                }
                Spell inputN = spellArray.get(inputAS);
                inputAS = inputN.ordinal();
                if(0 <= inputAS && inputAS < Spell.NUM){
                    state.saveLocation(LocationCategory.replaceOrb, LocationCategory.FINISH);
                    return inputAS + 4 + Spell.NUM + 1 + Special.NUM;
                }else{
                    System.out.println("正しく入力してください");
                    Print.nextLine(scanner, text);
                    state.saveLocation(LocationCategory.replaceOrb, EXPLAIN);
                    return replaceOrb(state, self_is_player1, text, usingItem, scanner);
                }
            
            default:
                System.out.println("error addSpell");
                state.saveLocation(LocationCategory.replaceOrb, LocationCategory.NO_RETURN_FINISH);
                return LocationCategory.NO_CHOICE;

                
        }
    }

    // 詳細情報表示
    private static int information(State state, boolean self_is_player1, boolean text, boolean usingItem , Scanner scanner){
        Print.displayBattleField(state, self_is_player1, text, scanner);
        return LocationCategory.NO_CHOICE;
    }

    //行動のカウントを初期化する
    public static void actionCountReseter(){
        for (int i = 0; i < actionCount.length; i++){
            actionCount[i] = 0;
        }
    }

    // 行動のカウントを表示
    public static void printCount(){
        for (int i = 0; i < actionCount.length; i++){
            System.out.printf("%d:%d", i, actionCount[i]);
        }
    }
}
