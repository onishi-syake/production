package battle;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Map;
import java.util.Random;

import battle.state_change.ChangeAbnormalState;
import battle.state_change.ChangeAbnormalState.AbnormalState;
import battle.state_change.ChangeAbnormalState.AbnormalStateCounter;
import battle.state_change.ChangeActionState;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import battle.state_change.ChangeBattleStatus;
import battle.state_change.ChangeField;
import battle.state_change.ChangeWeather;
import battle.state_change.ChangeBattleStatus.StateChangeStatus;
import battle.state_change.ChangeField.Field;
import battle.state_change.ChangeField.FieldCounter;
import battle.state_change.ChangeWeather.Weather;
import battle.InputAction.Auto;
import character.Character;
import character.CharacterForAI;
import character.Player;
import character.Character.BattleStatus;
import character.Character.MainStatus;
import character.CharacterForAI.LagAct;
import data.action.Special;
import data.action.Spell;
import data.item.BattleItem;
import game.LocationCategory;
import log.BattleLog;
import log.BattleTemporaryLog;
import log.OneTurnBattleLog;
import text.Print;
import text.Print.Color;

//メインバトルに関するstaticメソッドをまとめたクラス。

public final class Battle {
    //ログを出力
    // stateを作って戦闘開始
    public static BattleLog startBattle(Character player1, Character player2, Auto autoP1, Auto autoP2, boolean text, Scanner scanner, Random rand){
        State state = new State(player1, player2, autoP1, autoP2);
        ChangeBattleStatus.reset(state);
        return battle(state, text, scanner, rand);
    }

    // AI用の戦闘関数？
    public static State[] startBattleForAI(Character player1, Character player2, Auto autoP1, Auto autoP2, boolean text, Scanner scanner, Random rand){
        State state = new State(player1, player2, autoP1, autoP2);
        ChangeBattleStatus.reset(state);
        ArrayList<State> list = new ArrayList<>();
        int[] P12Action;
        while(true){
            P12Action = new int[]{InputAction.select(state, true, text, scanner, rand), InputAction.select(state, false, text, scanner, rand)};
            list.add(state);
            state = oneTurnBattle(state, P12Action, new BattleTemporaryLog(), text, scanner, rand);
            if(state.isEnd(text, text)) break;
            if (state.getPlayer1().getStateAction().get(ActionState.Escape).get(ActionStateCounter.flag) == 1 || state.getPlayer2().getStateAction().get(ActionState.Escape).get(ActionStateCounter.flag) == 1) break;
        }
        list.add(state);
        state.endBattle();
        return list.stream().toArray(State[]::new);
    }

    // 戦闘関数
    public static BattleLog battle(State state, boolean text, Scanner scanner, Random rand){
        State afterState;
        int[] P12Action;
        ArrayList<OneTurnBattleLog> log = new ArrayList<>();
        while(true){
            P12Action = new int[]{InputAction.select(state, true, text, scanner, rand), InputAction.select(state, false, text, scanner, rand)};
            BattleTemporaryLog hit = new BattleTemporaryLog();
            // TODO debug start
            // System.out.println("legalAction");
            // for(int legalAction : state.getPlayer1().getLegalAction(ChangeWeather.nowWeather(state), state.getField(), state.getTurn())){
            //     System.out.print(legalAction + " ");
            // }
            // System.out.println("aiLegalAction");
            // for(int aiLegalAction : state.aiLegalActions(true)){
            //     System.out.print(aiLegalAction + " ");
            // }
            // TODO debug end
            afterState = oneTurnBattle(state, P12Action, hit, text, scanner, rand);
            if(afterState.getTurn() != 1){
                log.add(new log.OneTurnBattleLog(state, afterState, P12Action[0], P12Action[1], hit));
            }
            state = afterState;
            if(state.isEnd(text, text)) break;
            if (state.getPlayer1().getStateAction().get(ActionState.Escape).get(ActionStateCounter.flag) == 1 || state.getPlayer2().getStateAction().get(ActionState.Escape).get(ActionStateCounter.flag) == 1) break;
        }
        state.endBattle();
        return new BattleLog(log, state);
    }

    public static State battle(State state, boolean text, Scanner scanner, Random rand, int NO_USE){
        // 後で作る（育成と接続する用）
        final int SELECT_P1_ACTION = 1;
        final int SELECT_P2_ACTION = 2;
        final int EXECUTE_ONE_TURU_BATTLE = 3;
        boolean self_is_player1;
        int action;
        switch(state.getSavedLocation(LocationCategory.battle)){
            case LocationCategory.NO_CHOICE:
                Print.slowStart(true, text);
                state.saveLocation(LocationCategory.battle, SELECT_P1_ACTION);
                return battle(state, text, scanner, rand, NO_USE);

            case SELECT_P1_ACTION:
                self_is_player1 = true;
                action = InputAction.select(state, self_is_player1, text, scanner, rand);
                if(state.getSavedLocation(LocationCategory.selectBattleAction) == LocationCategory.FINISH){
                    state.saveLocation(LocationCategory.selectBattleAction, LocationCategory.NO_CHOICE);
                    state.temp_p1_action = action;
                    if(state.temp_p2_action_selected){
                        state.temp_p2_action_selected = false;
                        state.saveLocation(LocationCategory.battle, EXECUTE_ONE_TURU_BATTLE);
                        return battle(state, text, scanner, rand, NO_USE);
                    }
                    state.saveLocation(LocationCategory.battle, SELECT_P2_ACTION);
                    return battle(state, text, scanner, rand, NO_USE);
                }else{
                    return state;
                }

            case SELECT_P2_ACTION:
                self_is_player1 = false;
                action = InputAction.select(state, self_is_player1, text, scanner, rand);
                if(state.getSavedLocation(LocationCategory.selectBattleAction) == LocationCategory.FINISH){
                    state.saveLocation(LocationCategory.selectBattleAction, LocationCategory.NO_CHOICE);
                    state.temp_p2_action = action;
                    state.saveLocation(LocationCategory.battle, EXECUTE_ONE_TURU_BATTLE);
                    return battle(state, text, scanner, rand, NO_USE);
                }else{
                    return state;
                }

            case EXECUTE_ONE_TURU_BATTLE:
                State afterState;
                ArrayList<OneTurnBattleLog> log = new ArrayList<>();
                BattleTemporaryLog hit = new BattleTemporaryLog();
                int[] P12Action = new int[]{state.temp_p1_action, state.temp_p2_action};
                afterState = oneTurnBattle(state, P12Action, hit, text, scanner, rand);
                if(afterState.getTurn() != 1){
                    log.add(new log.OneTurnBattleLog(state, afterState, P12Action[0], P12Action[1], hit));
                }
                state = afterState;
                if (state.isEnd(text, false) || state.getPlayer1().getStateAction().get(ActionState.Escape).get(ActionStateCounter.flag) == 1 || state.getPlayer2().getStateAction().get(ActionState.Escape).get(ActionStateCounter.flag) == 1){
                    state.endBattle();
                    state.saveLocation(LocationCategory.battle, LocationCategory.FINISH);
                    Print.clearStaticText(text);
                    Print.slowEnd(true, text);
                    return state;
                }
                state.saveLocation(LocationCategory.battle, SELECT_P1_ACTION);
                if(state.getAuto(true) == Auto.select && state.getAuto(false) == Auto.select){
                    Print.changeWaitTextToLT(text);
                    return state;
                }else{
                    return battle(state, text, scanner, rand, NO_USE);
                }

            default:
                System.out.println("error battle");
                return state;
        }
    }

    // AI用戦闘関数
    public static State battleForAI(State state, boolean text, Scanner scanner, Random rand){
        int[] P12Action;
        while(true){
            P12Action = new int[]{InputAction.select(state, true, text, scanner, rand), InputAction.select(state, false, text, scanner, rand)};
            state = oneTurnBattle(state, P12Action, new BattleTemporaryLog(), text, scanner, rand);
            if(state.isEnd(text, text)) break;
            if (state.getPlayer1().getStateAction().get(ActionState.Escape).get(ActionStateCounter.flag) == 1 || state.getPlayer2().getStateAction().get(ActionState.Escape).get(ActionStateCounter.flag) == 1) break;
        }
        state.endBattle();
        return state;
    }

    //1ターンごとの処理。
    public static State oneTurnBattle(State state, int[] P12Action, BattleTemporaryLog log, boolean text, Scanner scanner, Random rand){
        state = state.modifiableCopy();
        state.countTurn();
        if(state.getTurn() == 1){
            if(P12Action[0] != -1){
                state.getPlayer1().setSpellSlot(new ArrayList<>(state.getP1SlotList().get(P12Action[0])));
            }
            if(P12Action[1] != -1){
                state.getPlayer2().setSpellSlot(new ArrayList<>(state.getP2SlotList().get(P12Action[1])));
            }
        }else{
            if (state.isEnd(text, false)){
                return state;
            }
            Map<Field,Map<FieldCounter, Integer>> field = state.getField();
            int[] P12BattleAction = new int[]{(P12Action[0] - 1) % (InputAction.ACTION_NUM) + 1, (P12Action[1] - 1) % (InputAction.ACTION_NUM) + 1};
            int[] P12ItemAction = new int[]{((P12Action[0]-1) / (InputAction.ACTION_NUM)), ((P12Action[1]-1) / (InputAction.ACTION_NUM))};
            int[] actionRepeatNum = new int[]{1, 1};

            //ラグによる差し替え
            for(int i = 0; i < 2; i++){
                for(AbnormalState lags : new AbnormalState[]{AbnormalState.Lag, AbnormalState.SuperLag}){
                    Character nowPlayer = state.getPlayer(i);
                    if(nowPlayer instanceof CharacterForAI){
                        ((CharacterForAI)nowPlayer).setLagAct(LagAct.NULL);
                    }
                    if(nowPlayer.getStateAbnormal().get(lags).get(AbnormalStateCounter.flag) == 1){
                        ChangeAbnormalState.execute(nowPlayer, field, lags, P12BattleAction[i], P12BattleAction[(i+1)%2], text);
                        int battleTemp = P12BattleAction[i];
                        int itemTemp = P12ItemAction[i];
                        P12BattleAction[i] = nowPlayer.getStateAbnormal().get(lags).get(AbnormalStateCounter.nextBattleAction);
                        P12ItemAction[i] = nowPlayer.getStateAbnormal().get(lags).get(AbnormalStateCounter.nextItemAction);
                        nowPlayer.getStateAbnormal().get(lags).replace(AbnormalStateCounter.nextBattleAction, battleTemp);
                        nowPlayer.getStateAbnormal().get(lags).replace(AbnormalStateCounter.nextItemAction, itemTemp);
                        if(nowPlayer instanceof CharacterForAI){
                            ((CharacterForAI)nowPlayer).setLagAct((itemTemp) * (InputAction.ACTION_NUM) + battleTemp);
                        }
                        if(P12BattleAction[i] == -1){
                            Print.println("選択不可で無行動になった", Print.highSpeed, text);
                        }
                        Print.nextLine(scanner, text);
                    }
                }
            }
            //ヘジテンスによる行動不能
            for(int i = 0; i < 2; i++){
                for(AbnormalState aState : new AbnormalState[]{AbnormalState.Bond, AbnormalState.SuperBond}){
                    ChangeAbnormalState.execute(state.getPlayer(i), field, aState, P12BattleAction[i], P12BattleAction[(i+1)%2], text);
                    if(state.getPlayer(i).getStateAbnormal().get(aState).get(AbnormalStateCounter.noMove) == 1){
                        state.getPlayer(i).getStateAbnormal().get(aState).replace(AbnormalStateCounter.noMove, 0);
                        P12BattleAction[i] = -1;
                    }
                    if(state.getPlayer(i).getStateAbnormal().get(aState).get(AbnormalStateCounter.enemyActionRepeatNum) != 1){
                        actionRepeatNum[(i+1)%2] = state.getPlayer(i).getStateAbnormal().get(aState).get(AbnormalStateCounter.enemyActionRepeatNum);
                        state.getPlayer(i).getStateAbnormal().get(aState).replace(AbnormalStateCounter.enemyActionRepeatNum, 1);
                    }
                }
            }

            boolean SG = judgeSG(P12BattleAction[0], P12BattleAction[1], state, text, scanner);
            log.setFirstPlayer(SG);

            Print.skipStart(true, text);
            Print.println(Color.gray.toColor("表示中にEnterで早送りできます"), true, Print.highSpeed, text);
            Print.skipEnd(true, text);
            Print.printHorizontalLine(state.getPlayer(SG).nameColor, true, text);
            Print.print(Print.sleep(10), true, Print.highSpeed, text);

            //先手の行動処理
            //-1%3==-1になることを利用して逃げるとactionの最大値を区別できるようにしている
            for(int noUse = 0; noUse < actionRepeatNum[SG ? 0 : 1]; noUse++){
                state = ExecuteAction.act(state, SG, !SG, log, true, P12BattleAction[SG ? 0 : 1], P12BattleAction[SG ? 1 : 0], true, text, scanner, rand);
                Print.nextLine(scanner, text);
            }
            //ジエンドによる2回行動
            if(state.getPlayer(SG).getStateAction().get(ActionState.On_TheEnd).get(ActionStateCounter.count) == 1){
                state = ExecuteAction.act(state, SG, !SG, log, true, P12BattleAction[SG ? 0 : 1], P12BattleAction[SG ? 1 : 0], true, text, scanner, rand);
                Print.nextLine(scanner, text);
            }
            // 逃げる
            if(P12BattleAction[SG ? 0 : 1] == 0){
                state.getPlayer(SG).getStateAction().get(ActionState.Escape).replace(ActionStateCounter.flag, 1);
                return state;
            }

            if (state.isEnd(text, false)){
                return state;
            }

            //ジエンドによるターン終了
            if(state.getPlayer(SG).getStateAction().get(ActionState.On_TheEnd).get(ActionStateCounter.count) == 2){
                //ジエンド用ターン終了時の処理
                for(int i = 0; i < 2; i++){
                    //防御、溜める等のターン終了処理
                    for(ActionState category : new ActionState[]{ActionState.Defense, ActionState.SpecialDefense, ActionState.Tension, ActionState.SpecialTension, ActionState.On_SpellReflect ,ActionState.Attacked}){
                        ChangeActionState.turnEndProcess(state, i == 0, category, log, text, scanner, rand);
                    }
                }
                state.getPlayer(SG).getStateAction().get(ActionState.On_TheEnd).replace(ActionStateCounter.count, 1);
                // 呪文使用状況をリセット
                state.resetSpellUsed();
                return state;
            }
        
            //前回行動の保存
            state.getPlayer(SG).setLastAction(P12BattleAction[SG ? 0 : 1]);
            
            // アイテムの即時使用
            for(boolean actor : new boolean[]{true, false}){
                BattleItem.usePassive(state, actor, !actor, log, rand, text, scanner);
            }

            Print.printHorizontalLine(state.getPlayer(!SG).nameColor, true, text);
            Print.print(Print.sleep(10), true, Print.highSpeed, text);

            //後手の行動処理
            for(int noUse = 0; noUse < actionRepeatNum[SG ? 1 : 0]; noUse++){
                state = ExecuteAction.act(state, !SG, SG, log, true, P12BattleAction[SG ? 1 : 0], P12BattleAction[SG ? 0 : 1], true, text, scanner, rand);
                Print.nextLine(scanner, text);
            }
            //ジエンドによる2回行動
            if(state.getPlayer(!SG).getStateAction().get(ActionState.On_TheEnd).get(ActionStateCounter.count) == 1){
                state = ExecuteAction.act(state, !SG, SG, log, true, P12BattleAction[SG ? 1 : 0], P12BattleAction[SG ? 0 : 1], true, text, scanner, rand);
                Print.nextLine(scanner, text);
            }
            if(P12BattleAction[SG ? 1 : 0] == 0){
                state.getPlayer(!SG).getStateAction().get(ActionState.Escape).replace(ActionStateCounter.flag, 1);
                return state;
            }

            if (state.isEnd(text, false)){
                return state;
            }

            //ジエンドによるターン終了
            if(state.getPlayer(!SG).getStateAction().get(ActionState.On_TheEnd).get(ActionStateCounter.count) == 2){
                //ジエンド用ターン終了時の処理
                for(int i = 0; i < 2; i++){
                    //防御、溜める等のターン終了処理
                    for(ActionState category : new ActionState[]{ActionState.Defense, ActionState.SpecialDefense, ActionState.Tension, ActionState.SpecialTension, ActionState.On_SpellReflect ,ActionState.Attacked}){
                        ChangeActionState.turnEndProcess(state, i == 0, category, log, text, scanner, rand);
                    }
                }
                state.getPlayer(!SG).getStateAction().get(ActionState.On_TheEnd).replace(ActionStateCounter.count, 1);
                // 呪文使用状況をリセット
                state.resetSpellUsed();
                return state;
            }
        
            //前回行動の保存
            state.getPlayer(!SG).setLastAction(P12BattleAction[SG ? 1 : 0]);
            
            // アイテムの即時使用
            for(boolean actor : new boolean[]{true, false}){
                BattleItem.usePassive(state, actor, !actor, log, rand, text, scanner);
            }

            Print.printHorizontalLine(true, text);
            Print.print(Print.sleep(10), true, Print.highSpeed, text);

            //先手のアイテム処理
            if(P12ItemAction[SG ? 0 : 1] > 0){
                state = ExecuteAction.act(state, SG, !SG, log, false, P12ItemAction[SG ? 0 : 1] + InputAction.ACTION_NUM, P12ItemAction[SG ? 1 : 0] + InputAction.ACTION_NUM, true, text, scanner, rand);
                //onset第二引数は使用しないが、引数として必要であるため適当に入れている
                ChangeActionState.onset(state, SG, !SG, ActionState.UseItem, log, text, scanner, rand);
                Print.nextLine(scanner, text);
            }

            if (state.isEnd(text, false)){
                return state;
            }

            //後手のアイテム処理
            if(P12ItemAction[SG ? 1 : 0] > 0){
                state = ExecuteAction.act(state, !SG, SG, log, false, P12ItemAction[SG ? 1 : 0] + InputAction.ACTION_NUM, P12ItemAction[SG ? 0 : 1] + InputAction.ACTION_NUM, true, text, scanner, rand);
                //onset第二引数は使用しないが、引数として必要であるため適当に入れている
                ChangeActionState.onset(state, !SG, SG, ActionState.UseItem, log, text, scanner, rand);
                Print.nextLine(scanner, text);
            }


            //ターン終了時の処理
            for(int i = 0; i < 2; i++){
                //防御、溜める等のターン終了処理
                for(ActionState category : ActionState.values()){
                    ChangeActionState.turnEndProcess(state, i == 0, category, log, text, scanner, rand);
                }
                //能力増加効果、能力減少効果のターン終了処理
                ChangeBattleStatus.turnEndProcess(state.getPlayer(i), text, scanner);
                //状態異常のターン終了処理
                for(AbnormalState category : AbnormalState.values()){
                    ChangeAbnormalState.turnEndProcess(state.getPlayer(i), category, text, scanner, rand);//abnormalstateつかってる
                }
            }
            //フィールドのターン終了処理
            for(Field category : Field.values()){
                ChangeField.turnEndProcess(state, category, text);
            }
            //天候のターン終了処理
            ChangeWeather.turnEndProcess(state, text, scanner);

            // 呪文使用状況をリセット
            state.resetSpellUsed();
            
            // アイテムの即時使用
            for(boolean actor : new boolean[]{true, false}){
                BattleItem.usePassive(state, actor, !actor, log, rand, text, scanner);
            }

            // 能力増加効果・能力減少効果・テンション等の再計算
            ChangeBattleStatus.reset(state);

            //MP回復(1Tはbase割合分回復、それ以降は1TごとにTcoef分増加)
            // double mpHealBase = -0.1;
            // double mpHealTurnCoef = -0.02;
            // 回復量は毎ターン1
            int mpHealMount = -1;
            for(boolean FS : new boolean[]{true, false}){
                // CalculateDamage.changeParameter(state.getPlayer(FS), MainStatus.mp, (int)(state.getPlayer(FS).getMainStatus().get(MainStatus.maxMp) * (mpHealBase + (state.getTurn() - 2) * mpHealTurnCoef)), text);
                CalculateDamage.changeParameter(state.getPlayer(FS), MainStatus.mp, mpHealMount, false);
            }
        }
        return state;
    }   

    //P1が先手ならtrue,P2が先手ならfalse
    private static boolean judgeSG(int P1Action, int P2Action, State state, boolean text, Scanner scanner){
        Character[] P12 = new Character[]{state.getPlayer1(), state.getPlayer2()};
        int[] P12Action = new int[]{P1Action, P2Action};
        double[] P12SpeedUp = new double[] {1, 1};
        int[] P12Priority = new int[] {0, 0};
        int[] P12Speed = new int[]{P12[0].getBattleStatus().get(BattleStatus.s), P12[1].getBattleStatus().get(BattleStatus.s)};
        for (int i = 0; i < P12Priority.length; i++){
            int action = P12Action[i];

            if(4 <= action && action < Spell.NUM + 4){
                Spell spell = Spell.values()[action-4];
                P12Priority[i] = spell.priority;
                if(P12[i].getStateAbnormal().get(AbnormalState.Stomatitis).get(AbnormalStateCounter.flag).intValue() == 1){
                    P12Priority[i] -= 1;
                }
                if(spell == Spell.RegenField || spell == Spell.TensionField || spell == Spell.ReverseField || spell == Spell.SpecialField){
                    P12SpeedUp[i] *= 2;
                }
            }else if(4 + Spell.NUM + 1 <= action && action < 4 + Spell.NUM + Special.NUM + 1){
                P12Priority[i] = Special.values()[action-(4 + Spell.NUM + 1)].priority;
            }else if(action == 4 + Spell.NUM){
                P12Priority[i] = 5;
            }

            switch(action){
                case 2:
                    // Print.println(P12[i].jName + "は防御したので、" + MainStatus.s.jName + "が1.5倍で計算される", Print.middleSpeed, text);
                    // Print.nextLine(scanner, text);
                    P12SpeedUp[i] *= 2;
                    break;
                case 3:
                    // Print.println(P12[i].jName + "は溜めるしたので、" + MainStatus.s.jName + "が0.66倍で計算される", Print.middleSpeed, text);
                    // Print.nextLine(scanner, text);
                    P12Priority[i] = -1;
                    break;
            }
            //ジエンドによる後攻化
            if(P12[i].getStateAction().get(ActionState.On_TheEnd).get(ActionStateCounter.count) == 1){
                P12Priority[i] = -10;
            }
        }
        if(P12Priority[0] > P12Priority[1]){
            return true;
        } else if(P12Priority[0] < P12Priority[1]){
            return false;
        }
        P12Speed[0] *= P12SpeedUp[0];
        // P12Speed[0] = CalculateDamage.randomProcess((int)P12Speed[0], CalculateDamage.BASE_VARIANCE_RATE, rand);
        P12Speed[1] *= P12SpeedUp[1];
        //Print.println(P1Speed + "", 2, true);//state.getAuto(false) == Auto.enemyMCTS);
        //Print.println(P2Speed + "", 2, true);//state.getAuto(false) == Auto.enemyMCTS);
        boolean result;
        if(P12Speed[0] > P12Speed[1]){
            result = true;
        }else if(P12Speed[0] < P12Speed[1]){
            result = false;
        }else{
            result = state.getTurn() % 2 == 1;
        }
        // if(P12Action[result ? 1 : 0] == 2 && (P12Action[result ? 0 : 1] == 1 || P12Action[result ? 0 : 1] == 4 + Spell.NUM + 1 + Special.SpecialAttack.ordinal())){
        //     Print.println(P12[result ? 1 : 0].getJName() + "は防御したが、", true, Print.middleSpeed, text);
            
        //     Print.println("倍も高い" + MainStatus.s.jName + "に先手を取られた！", true, Print.middleSpeed, text);
            
        //     Print.nextLine(scanner, text);
        // }
        return result;

    }
}
