package battle;

import java.util.Map;
import java.util.stream.IntStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;

import battle.InputAction.Auto;
import battle.state_change.ChangeAbnormalState;
import battle.state_change.ChangeBattleStatus;
import battle.state_change.ChangeField;
import battle.state_change.ChangeAbnormalState.AbnormalState;
import battle.state_change.ChangeAbnormalState.AbnormalStateCounter;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import battle.state_change.ChangeActionState.UpdateBackup;
import battle.state_change.ChangeBattleStatus.StateChangeStatus;
import battle.state_change.ChangeBattleStatus.StatusCounter;
import battle.state_change.ChangeField.Field;
import battle.state_change.ChangeField.FieldCounter;
import battle.state_change.ChangeWeather;
import battle.state_change.ChangeWeather.Weather;
import battle.state_change.ChangeWeather.WeatherCounter;
import battle.state_change.ChangeWeather.WeatherRelation;
import character.Character;
import character.Character.MainStatus;
import data.action.Special;
import data.action.Spell;
import data.item.BattleItem;
import game.LocationCategory;
import log.unmodifiable.UnmodifiableState;
import text.Print;

public class State implements Serializable {
    private Character player1;// プレーヤー1
    private Character player2;// プレーヤー2
    private Auto p1Auto;// プレーヤー1の選択方法
    private Auto p2Auto;// プレーヤー2の選択方法
    private List<List<Spell>> p1SlotList;// プレーヤー1の呪文スロットの取り得る組み合わせのリスト
    private List<List<Spell>> p2SlotList;// プレーヤー2の呪文スロットの取り得る組み合わせのリスト
    private Map<Field,Map<FieldCounter, Integer>> field = new EnumMap<>(Field.class);// フィールド
    private Map<Weather,Map<WeatherCounter, Integer>> weather = new EnumMap<>(Weather.class);// 天候
    private boolean spellUsed;// このターンに呪文が使われたかどうか
    private int turn;// 何ターン目か
    private boolean p1Escape = false;// プレーヤー1が逃げれるか
    private boolean P2Escape = false;// プレーヤー2が逃げれるか
    
    // for state
    private int nextAction;
    private Map<LocationCategory, Integer> savedAction;
    public int temp_p1_action;
    public int temp_p2_action;
    public boolean temp_p2_action_selected;
    public int temp_item_action_num;

    //メインコンストラクタ
    public State(Character player1, Character player2, Auto p1Auto, Auto p2Auto, Map<Field,Map<FieldCounter, Integer>> field, Map<Weather,Map<WeatherCounter, Integer>> weather, boolean spellUsed, int turn, boolean p1Escape, boolean P2Escape){
        this.player1 = player1;
        this.player2 = player2;
        this.p1Auto = p1Auto;
        this.p2Auto = p2Auto;
        this.field = field;
        this.weather = weather;
        this.spellUsed = spellUsed;
        this.turn = turn;
        this.p1Escape = p1Escape;
        this.P2Escape = P2Escape;
    }
    //初期生成
    public State(Character player1, Character player2, Auto p1Auto, Auto p2Auto){
        this.player1 = player1;
        this.player2 = player2;
        this.p1Auto = p1Auto;
        this.p2Auto = p2Auto;
        List<List<Spell>> p1Slot = getSpellForAi(player1);
        int p1SlotSize = p1Slot.size();
        List<List<Spell>> p2Slot = getSpellForAi(player2);
        int p2SlotSize = p2Slot.size();
        this.p1SlotList = Collections.unmodifiableList(new ArrayList<List<Spell>>(){{for(int i = 0; i < p1SlotSize; i++){
            this.add(Collections.unmodifiableList(p1Slot.get(i)));
        }}});
        this.p2SlotList = Collections.unmodifiableList(new ArrayList<List<Spell>>(){{for(int i = 0; i < p2SlotSize; i++){
            this.add(Collections.unmodifiableList(p2Slot.get(i)));
        }}});
        this.field = ChangeField.initializedFieldMap();
        for(Weather key : Weather.values()){
            Map<WeatherCounter, Integer> miniWeather = new EnumMap<>(WeatherCounter.class);
            for(WeatherCounter counter : WeatherCounter.values()){
                miniWeather.put(counter, key.DEFAULT_NUM.get(counter));                
            }
            this.weather.put(key, miniWeather);
        }
        this.spellUsed = false;
        this.turn = 0;
        this.nextAction = LocationCategory.NO_CHOICE;
        this.savedAction = new HashMap<>(){{
            for(LocationCategory act : LocationCategory.values()){
                put(act, LocationCategory.NO_CHOICE);
            }
        }};
    }

    //コピーコンストラクタ
    protected State(State state){
        this.player1 = state.player1.modifiableCopy();
        this.player2 = state.player2.modifiableCopy();
        this.p1Auto = state.p1Auto;
        this.p2Auto = state.p2Auto;
        for(Field key : Field.values()){
            this.field.put(key, new EnumMap<>(state.field.get(key)));
        }
        for(Weather key : Weather.values()){
            this.weather.put(key, new EnumMap<>(state.weather.get(key)));
        }
        this.spellUsed = state.spellUsed;
        this.turn = state.turn;
        this.p1SlotList = new ArrayList<List<Spell>>() {{
            for(List<Spell> spellSlot : state.p1SlotList){
                add(new ArrayList<>(spellSlot));
            }
        }};
        this.p2SlotList = new ArrayList<List<Spell>>() {{
            for(List<Spell> spellSlot : state.p2SlotList){
                add(new ArrayList<>(spellSlot));
            }
        }};
        this.p1Escape = state.p1Escape;
        this.P2Escape = state.P2Escape;
        this.nextAction = state.nextAction;
        this.savedAction = new HashMap<>(state.savedAction);
        this.temp_p1_action = state.temp_p1_action;
        this.temp_p2_action = state.temp_p2_action;
        this.temp_p2_action_selected = state.temp_p2_action_selected;
        this.temp_item_action_num = state.temp_item_action_num;
    }

    // 合法手取得
    public int[] getLegalAction(boolean player1){
        if(this.turn == 0){
            return IntStream.range(0, player1 ? this.p1SlotList.size() : this.p2SlotList.size()).toArray();
        }else{
            return player1 ? this.player1.getLegalAction(this, ChangeWeather.nowWeather(this), this.field, this.turn) : this.player2.getLegalAction(this, ChangeWeather.nowWeather(this), this.field, this.turn);
        }
    }

    public List<Integer> normalActionAddAllItem(int action){
        /**
         * 通常行動の番号を入力
         * アイテムを含めた行動番号のリストを出力
         * BattleItem.NUM + 1回ループの理由はアイテム不使用で+1回、BattleItemの一番最後にある空スロットアイテムで-1回だから
         */
        return new ArrayList<Integer>(){{
            for(int i = 0; i < BattleItem.NUM; i++){
                add(i * InputAction.ACTION_NUM + action);
            }
        }};
    }

    public List<Integer> itemActionAddAllAction(int itemOrdinal){
        /**
         * アイテムのordinalを入力
         * そのアイテムを利用する行動全ての番号のリストを出力
         */
        return new ArrayList<Integer>(){{
            int noItemNum = 1;
            int escapeNum = 1;
            for(int i = 0; i < InputAction.ACTION_NUM; i++){
                add((itemOrdinal + noItemNum) * InputAction.ACTION_NUM + i + escapeNum);
            }
        }};
    }
    
    // 悪手を除いた合法手
    public int[] aiLegalActions(boolean self_is_player1){
        int[] selfLegalActions = this.getLegalAction(self_is_player1);
        if(this.turn == 0){
            return selfLegalActions;
        }else{
            int normalActionNum = 3;
            int oldSpecialChargeNum = 1;
            int escapeNum = 1;

            Character self = this.getPlayer(self_is_player1);
            Character enemy = this.getPlayer(!self_is_player1);


            Map<MainStatus, Integer> selfMainStatus = self.getMainStatus();
            Map<AbnormalState, Map<AbnormalStateCounter, Integer>> selfStateAbnomal = self.getStateAbnormal();
            Map<ActionState, Map<ActionStateCounter, Integer>> selfstateAction = self.getStateAction();
            List<Map<StateChangeStatus, Map<StatusCounter, Double>>> selfStateChangeStatus = self.getStateChangeStatus();

            Map<AbnormalState, Map<AbnormalStateCounter, Integer>> enemyStateAbnomal = enemy.getStateAbnormal();

            ArrayList<Integer> legalActionList = new ArrayList<Integer>(selfLegalActions.length);
            for(int i = 0; i < selfLegalActions.length; i++){
                legalActionList.add(selfLegalActions[i]);
            }

            // //魔力剤 MP1/2以上で削除
            // if(selfMainStatus.get(MainStatus.mp) > selfMainStatus.get(MainStatus.maxMp) / 2){
            //     for(int i = InputAction.ACTION_NUM * (BattleItem.Maryokuzai.ordinal() + 1) + 1; i <= InputAction.ACTION_NUM * (BattleItem.Maryokuzai.ordinal() + 2); i++){
            //         if(legalActionList.contains(i)){
            //             legalActionList.remove(legalActionList.indexOf(i));
            //         }
            //     }
            // }
            //万能薬 悪い状態異常に罹っていないとき削除
            if(!ChangeAbnormalState.checkAnyAbnormal(self)){
                for(int act : itemActionAddAllAction(BattleItem.Bannnouyaku.ordinal())){
                    if(legalActionList.contains(act)){
                        legalActionList.remove(legalActionList.indexOf(act));
                    }
                }
            }
            // //ヒール HP2/3以上で削除
            // if(selfMainStatus.get(MainStatus.hp) > selfMainStatus.get(MainStatus.maxHp) * 2 / 3){
            //     for(int act : normalActionAddAllItem(normalActionNum + Spell.LargeHeal.ordinal() + escapeNum)){
            //         if(legalActionList.contains(act)){
            //             legalActionList.remove(legalActionList.indexOf(act));
            //         }
            //     }
            // }
            // //ラージヒール HP1/2以上かつ状態異常に罹っていないとき削除
            // if(selfMainStatus.get(MainStatus.hp) > selfMainStatus.get(MainStatus.maxHp) / 2 && !ChangeAbnormalState.checkAnyAbnormal(self)){
            //     for(int act : normalActionAddAllItem(normalActionNum + Spell.LargeHeal.ordinal() + escapeNum)){
            //         if(legalActionList.contains(act)){
            //             legalActionList.remove(legalActionList.indexOf(act));
            //         }
            //     }
            // }
            // //無効天候呪文　天候により効果が無効になる呪文を削除
            // for(Spell spell : Spell.values()){
            //     if(spell == Spell.NULL){
            //         continue;
            //     }
            //     if(ChangeWeather.makeRelation(this, spell, false, null) == ChangeWeather.WeatherRelation.bombEffect){
            //         for(int act : normalActionAddAllItem(normalActionNum + spell.ordinal() + escapeNum)){
            //             if(legalActionList.contains(act)){
            //                 legalActionList.remove(legalActionList.indexOf(act));
            //             }
            //         }
            //     }
            // }
            //状態異常系呪文 状態異常に罹っているとき削除（上位状態異常、時間制限が出たため削除なし）
            // for(AbnormalState category : AbnormalState.values()){
            //     if(!category.good && (enemyStateAbnomal.get(category).get(AbnormalStateCounter.flag) == 1 || enemyStateAbnomal.get(category).get(AbnormalStateCounter.resistance) == 1)){
            //         try{
            //             Spell.valueOf(category.name());
            //         }catch(Exception e){
            //             continue;
            //         }
            //         for(int j = 0; j < BattleItem.NUM; j++){
            //             int abnomalStateSpellIndex = j * InputAction.ACTION_NUM + normalActionLength + Spell.valueOf(category.name()).ordinal() + 1;
            //             if(legalActionList.contains(abnomalStateSpellIndex)){
            //                 legalActionList.remove(legalActionList.indexOf(abnomalStateSpellIndex));
            //             }
            //         }
            //     }
            // }
            // //トラウマ及びカース 状態異常に罹っていないとき
            // //TODO 上位状態異常を追加したので変更の必要あり
            // if(enemyStateAbnomal.get(AbnormalState.Lag).get(AbnormalStateCounter.flag) == 1 || enemyStateAbnomal.get(AbnormalState.Hesitance).get(AbnormalStateCounter.flag) == 1 || enemyStateAbnomal.get(AbnormalState.Lag).get(AbnormalStateCounter.resistance) == 1 || enemyStateAbnomal.get(AbnormalState.Hesitance).get(AbnormalStateCounter.resistance) == 1){
            //     for(int j = 0; j < BattleItem.NUM; j++){
            //         int abnomalStateSpellIndex = j * InputAction.ACTION_NUM + normalActionLength + Spell.Trauma.ordinal() + 1;
            //         if(legalActionList.contains(abnomalStateSpellIndex)){
            //             legalActionList.remove(legalActionList.indexOf(abnomalStateSpellIndex));
            //         }
            //     }
            // }
            // if(enemyStateAbnomal.get(AbnormalState.Stomatitis).get(AbnormalStateCounter.flag) == 1 || enemyStateAbnomal.get(AbnormalState.Poison).get(AbnormalStateCounter.flag) == 1 || enemyStateAbnomal.get(AbnormalState.Stomatitis).get(AbnormalStateCounter.resistance) == 1 || enemyStateAbnomal.get(AbnormalState.Poison).get(AbnormalStateCounter.resistance) == 1){
            //     for(int j = 0; j < BattleItem.NUM; j++){
            //         int abnomalStateSpellIndex = j * InputAction.ACTION_NUM + normalActionLength + Spell.Chaos.ordinal() + 1;
            //         if(legalActionList.contains(abnomalStateSpellIndex)){
            //             legalActionList.remove(legalActionList.indexOf(abnomalStateSpellIndex));
            //         }
            //     }
            // }
            // 能力増加効果呪文 能力増加効果が既に掛かっている時に削除
            for(StateChangeStatus buffCategory : StateChangeStatus.values()){
                try{
                    if(ChangeBattleStatus.calculateBuffRate(selfStateChangeStatus, buffCategory) > 0){
                        for(int act : normalActionAddAllItem(normalActionNum + Spell.valueOf(buffCategory.name() + "Up").ordinal() + escapeNum)){
                            if(legalActionList.contains(act)){
                                legalActionList.remove(legalActionList.indexOf(act));
                            }
                        }
                    }
                }catch(IllegalArgumentException e){
                    System.out.println("error exception aiLegalAction buffSpell remove");
                }
            }
            //フィールド呪文 フィールドが既にそのフィールドのとき削除
            try{
                for(Field field : Field.values()){
                    if(this.field.get(field).get(FieldCounter.flag) == 1){
                        for(int act : normalActionAddAllItem(normalActionNum + Spell.valueOf(field.name()).ordinal() + escapeNum)){
                            if(legalActionList.contains(act)){
                                legalActionList.remove(legalActionList.indexOf(act));
                            }
                        }
                    }
                }
            }catch(Exception e){
                System.out.println("error フィールド名と呪文名が一致しません");
            }
            //呪文追加　maxMpが足りないとき削除
            for(Spell key : Spell.values()){
                if(key == Spell.NULL){
                    continue;
                }
                if(self.getMainStatus().get(MainStatus.maxMp) < key.getCost(self)){
                    for(int act : normalActionAddAllItem(escapeNum + normalActionNum + Spell.NUM + oldSpecialChargeNum + Special.NUM + key.ordinal())){
                        if(legalActionList.contains(act)){
                            legalActionList.remove(legalActionList.indexOf(act));
                        }
                    }
                }
            }
            int legalActionSize = legalActionList.size();
            int[] legalActionArray = new int[legalActionSize];
            for(int i = 0; i < legalActionSize; i++){
                legalActionArray[i] = legalActionList.get(i);
            }
            // 旧必殺技は廃止（戻す際には必殺技が打てない状況を考慮する必要がある）
            // if(selfstateAction.get(ActionState.oldChargeSpecial).get(ActionStateCounter.flag) == 1){
            //     ArrayList<Integer> legalItemList= new ArrayList<>();
            //     legalItemList.add(0);
            //     for (int i = 0; i < BattleItem.NUM; i++){
            //         if (ExecuteAction.legalItem(BattleItem.values()[i], self, false)){
            //             legalItemList.add(i+1);
            //         }
            //     }
            //     int legalItemNum = legalItemList.size();
            //     legalActionArray = new int[Special.NUM * legalItemNum];
            //     for(int i = 1; i <= Special.NUM; i++){
            //         for(int j  = 0; j < legalItemNum; j++){
            //             legalActionArray[i + j * Special.NUM - 1] = normalActionLength + Spell.NUM + 1 + i + legalItemList.get(j) * InputAction.ACTION_NUM;
            //         }
            //     }
            // }
            return legalActionArray;
        }
    }

    // 良手のみの合法手
    public int[] playoutActions(boolean self_is_player1){
        List<Integer> aiLegalActions = new ArrayList<>(Arrays.stream(this.aiLegalActions(self_is_player1)).boxed().toList());
        List<Integer> playoutActions = new ArrayList<>(aiLegalActions);
        List<Integer> topPriorityLegalActions = new ArrayList<>();
        List<Integer> secondPriorityLegalActions = new ArrayList<>();
        if(this.turn == 0){
            return playoutActions.stream().mapToInt(i->i).toArray();
        }else{
            Character self = this.getPlayer(self_is_player1);
            Character enemy = this.getPlayer(!self_is_player1);
            int normalActionNum = 3;
            int oldSpecialChargeNum = 1;
            int escapeNum = 1;

            //まずは弱い択を除外する
            //呪文追加削除
            for(Spell spell : Spell.values()){
                if(spell == Spell.NULL){
                    continue;
                }
                for(int act : normalActionAddAllItem(escapeNum + normalActionNum + Spell.NUM + oldSpecialChargeNum + Special.NUM + spell.ordinal())){
                    if(playoutActions.contains(act)){
                        playoutActions.remove(playoutActions.indexOf(act));
                    }
                }
            }
            //口内炎で呪文打たない
            // if(self.getStateAbnormal().get(AbnormalState.Stomatitis).get(AbnormalStateCounter.flag) == 1){
            //     for(Spell spell : Spell.values()){
            //         if(spell == Spell.NULL){
            //             continue;
            //         }
            //         for(int act : normalActionAddAllItem(escapeNum + normalActionNum + spell.ordinal())){
            //             if(playoutActions.contains(act)){
            //                 playoutActions.remove(playoutActions.indexOf(act));
            //             }
            //         }
            //     }
            // }
            // 状態異常は永続でではなくなったので、序盤で優先する必要が無い
            // if(this.turn <= 3){
            //     for(AbnormalState category : AbnormalState.values()){
            //         if(category.good){
            //             continue;
            //         }
            //         try{
            //             Spell.valueOf(category.name());
            //         }catch(Exception e){
            //             continue;
            //         }
            //         for(int j = 0; j < BattleItem.NUM; j++){
            //             int abnomalStateSpellIndex = j * InputAction.ACTION_NUM + 3 + Spell.valueOf(category.name()).ordinal() + 1;
            //             if(aiLegalActions.contains(abnomalStateSpellIndex)){
            //                 for(int k = 0; k < 3; k++){
            //                     aiLegalActions.add(abnomalStateSpellIndex);
            //                 }
            //             }
            //         }
            //     }
            // }

            // 天候が悪い呪文は削除
            for(Spell spell : self.getSpellSlot()){
                if(spell == Spell.NULL){
                    continue;
                }
                WeatherRelation relation = ChangeWeather.makeRelation(ChangeWeather.nowWeather(this), spell.weather, false, null);
                if(relation == WeatherRelation.littleEffect){
                    for(int act : normalActionAddAllItem(escapeNum + normalActionNum + spell.ordinal())){
                        if(playoutActions.contains(act)){
                            playoutActions.remove(playoutActions.indexOf(act));
                        }
                    }
                }
            }

            //除外択を除外した後に何も選択肢が残らなかったら除外せずに返す
            if(playoutActions.size() == 0){
                return aiLegalActions.stream().mapToInt(i->i).toArray();
            }


            //次に最優先の選択肢があるか調べる
            // 相手の前回行動が石系ならば防御を打つ
            if(enemy.getStateAction().get(ActionState.Stone).get(ActionStateCounter.flag) == 1 || enemy.getStateAction().get(ActionState.Rock).get(ActionStateCounter.flag) == 1 || enemy.getStateAction().get(ActionState.Lava).get(ActionStateCounter.flag) == 1 || enemy.getStateAction().get(ActionState.Meteor).get(ActionStateCounter.flag) == 1){
                int defenseOrdinal = 1;
                for(int act : normalActionAddAllItem(escapeNum + defenseOrdinal)){
                    if(playoutActions.contains(act)){
                        topPriorityLegalActions.add(act);
                    }
                }
                for(int act : normalActionAddAllItem(escapeNum + normalActionNum + Spell.NUM + oldSpecialChargeNum + Special.SpecialDefense.ordinal())){
                    if(playoutActions.contains(act)){
                        topPriorityLegalActions.add(act);
                    }
                }
            }

            //スペシャルフィールドなら必殺技最優先
            if(this.field.get(Field.SpecialField).get(FieldCounter.flag) == 1){
                for(Special special : Special.values()){
                    for(int act : normalActionAddAllItem(escapeNum + normalActionNum + Spell.NUM + oldSpecialChargeNum + special.ordinal())){
                        if(playoutActions.contains(act)){
                            topPriorityLegalActions.add(act);
                        }
                    }
                }
            }

            // 最優先の行動があるならそれだけを選択肢にする
            if(topPriorityLegalActions.size() != 0){
                return topPriorityLegalActions.stream().mapToInt(i->i).toArray();
            }


            //最後に優先度の高い行動があるかを調べる
            // 天候が良い呪文は優先
            for(Spell spell : self.getSpellSlot()){
                if(spell == Spell.NULL){
                    continue;
                }
                WeatherRelation relation = ChangeWeather.makeRelation(ChangeWeather.nowWeather(this), spell.weather, false, null);
                if(relation == WeatherRelation.largeEffect || relation == WeatherRelation.bombEffect){
                    for(int act : normalActionAddAllItem(escapeNum + normalActionNum + spell.ordinal())){
                        if(playoutActions.contains(act)){
                            secondPriorityLegalActions.add(playoutActions.indexOf(act));
                        }
                    }
                }
            }
            //テンションが多い時に攻撃呪文を打つ
            if(self.getStateAction().get(ActionState.Tension).get(ActionStateCounter.count) >= 4){
                for(Spell spell : new Spell[]{Spell.Fire, Spell.Wind, Spell.Stone}){
                    for(int act : normalActionAddAllItem(escapeNum + normalActionNum + spell.ordinal())){
                        if(playoutActions.contains(act)){
                            secondPriorityLegalActions.add(act);
                        }
                    }
                }
            }
            // //テンションが少ない時に能力増加効果呪文を打つ
            // if(self.getStateAction().get(ActionState.Tension).get(ActionStateCounter.count) < 4){
            //     for(Spell spell : new Spell[]{Spell.AUp, Spell.SUp}){
            //         for(int act : normalActionAddAllItem(escapeNum + normalActionNum + spell.ordinal())){
            //             if(playoutActions.contains(act)){
            //                 secondPriorityLegalActions.add(act);
            //             }
            //         }
            //     }
            // }
            //状態異常に多く罹っている時に万能薬を使う・ラージヒールを打つ
            if(ChangeAbnormalState.checkAbnormalNum(self) >= 2){
                for(int act : itemActionAddAllAction(BattleItem.Bannnouyaku.ordinal())){
                    if(playoutActions.contains(act)){
                        secondPriorityLegalActions.add(act);
                    }
                }
                // for(int act : normalActionAddAllItem(escapeNum + normalActionNum + Spell.LargeHeal.ordinal())){
                //     if(playoutActions.contains(act)){
                //         secondPriorityLegalActions.add(act);
                //     }
                // }
            }
            //基本行動で有利な択は優先する
            int attackOrdinal = 0;
            int defenseOrdinal = 1;
            int TensionOrdinal = 2;
            //敵の前回行動が攻撃なら溜める
            if(enemy.getLastAction() == escapeNum + attackOrdinal){
                for(int act : normalActionAddAllItem(escapeNum + TensionOrdinal)){
                    if(playoutActions.contains(act)){
                        secondPriorityLegalActions.add(act);
                    }
                }
            }
            //敵の前回行動が防御なら攻撃
            if(enemy.getLastAction() == escapeNum + defenseOrdinal){
                for(int act : normalActionAddAllItem(escapeNum + attackOrdinal)){
                    if(playoutActions.contains(act)){
                        secondPriorityLegalActions.add(act);
                    }
                }
            }
            //敵の前回行動が溜めるなら防御
            if(enemy.getLastAction() == escapeNum + TensionOrdinal){
                for(int act : normalActionAddAllItem(escapeNum + defenseOrdinal)){
                    if(playoutActions.contains(act)){
                        secondPriorityLegalActions.add(act);
                    }
                }
            }
            //敵が能力増加効果を積んでるならステイトチェンジ
            if(ChangeBattleStatus.calculateBuffRate(enemy.getStateChangeStatus(), StateChangeStatus.A) > 0 || 
              ChangeBattleStatus.calculateBuffRate(enemy.getStateChangeStatus(), StateChangeStatus.D) > 0 || 
              ChangeBattleStatus.calculateBuffRate(enemy.getStateChangeStatus(), StateChangeStatus.S) > 0){
                for(int act : normalActionAddAllItem(escapeNum + normalActionNum + Spell.On_StateChange.ordinal())){
                    if(playoutActions.contains(act)){
                        secondPriorityLegalActions.add(act);
                    }
                }
            }

            // 優先する行動があるならそれだけを選択肢にする
            if(secondPriorityLegalActions.size() != 0){
                return secondPriorityLegalActions.stream().mapToInt(i->i).toArray();
            }

            // もし最優先・優先する行動がないならplayoutActionsを選択肢にする
            return playoutActions.stream().mapToInt(i->i).toArray();
        }
    }
    // ゲッタ・セッタ
    public Character getPlayer1(){
        return this.player1;
    }
    public void setPlayer1(Character player){
        this.player1 = player;
    }
    public Character getPlayer2(){
        return this.player2;
    }
    public void setPlayer2(Character player){
        this.player2 = player;
    }
    public Auto getAuto(boolean player1){
        return player1 ? this.p1Auto : this.p2Auto;
    }
    public Character getPlayer(int index){
        return index == 0 ? this.player1 : this.player2;
    }
    public Character getPlayer(boolean player1){
        return player1 ? this.player1 : this.player2;
    }
    public void setPlayer(Character player, boolean player1){
        if(player1){
            this.player1 = player;
        }else{
            this.player2 = player;
        }
    }
    public void setPlayer(Character player1, Character player2){
        this.player1 = player1;
        this.player2 = player2;
    }
    public void setAuto(Auto auto){
        this.p1Auto = auto;
        this.p2Auto = auto;
    }
    public List<List<Spell>> getP1SlotList(){
        return this.p1SlotList;
    }
    public List<List<Spell>> getP2SlotList(){
        return this.p2SlotList;
    }
    public Map<Field,Map<FieldCounter, Integer>> getField(){
        return this.field;
    }
    public void setField(Map<Field,Map<FieldCounter, Integer>> field){
        this.field = field;
    }
    public Map<Weather,Map<WeatherCounter, Integer>> getWeather(){
        return this.weather;
    }
    public void setWeather(Map<Weather,Map<WeatherCounter, Integer>> weather){
        this.weather = weather;
    }
    public void useSpell(){
        this.spellUsed = true;
    }
    public void resetSpellUsed(){
        this.spellUsed = false;
    }
    public boolean getSpellUsed(){
        return this.spellUsed;
    }
    public int getTurn(){
        return this.turn;
    }
    public void countTurn(){
        this.turn++;;
    }
    public boolean getP1Escape(){
        return this.p1Escape;
    }
    public boolean getP2Escape(){
        return this.P2Escape;
    }
    public void getNextAction(int action){
        this.nextAction = action;
    }
    public int takeNextAction(){
        int temp = this.nextAction;
        this.nextAction = LocationCategory.NO_CHOICE;
        return temp;
    }
    public void sendNextAction(boolean player1){
        this.getPlayer(player1).getNextAction(this.nextAction);
        this.nextAction = LocationCategory.NO_CHOICE;
    }
    public void saveLocation(LocationCategory category, Integer location){
        this.savedAction.replace(category, location);
    }
    public int getSavedLocation(LocationCategory category){
        return this.savedAction.get(category);
    }
    // 戦闘終了・パラメータを初期化する
    public void endBattle(){
        this.p1Escape = this.player1.getStateAction().get(ActionState.Escape).get(ActionStateCounter.flag) == 1;
        this.P2Escape = this.player2.getStateAction().get(ActionState.Escape).get(ActionStateCounter.flag) == 1;
        this.player1.endBattle();
        this.player2.endBattle();
    }
    // 変更可能コピー
    public State modifiableCopy(){
        return new State(this);
    }
    // 変更不能コピー
    public UnmodifiableState unmodifiableCopy(){
        return new UnmodifiableState(this);
    }
    public StateForAI forAI(){
        return new StateForAI(this);
    }
    //試合終了してるかどうか
    public boolean isEnd(boolean text, boolean downText){
        if(turn >= 1000){
            return true;
        }
        for(Character chara: new Character[]{this.player1, this.player2}){
            if(chara.getMainStatus().get(MainStatus.hp) <= 0){
                if(chara.getStateAction().get(ActionState.Update).get(ActionStateCounter.flag) == 1){
                    chara.getUpdateBackup().returnBackup(chara, text);
                }else{
                    Print.println(chara.getJName() + "は倒れた！" + Print.sleep(10), true, Print.lowSpeed, downText);
                }
            }
        }
        return this.player1.getMainStatus().get(MainStatus.hp) <= 0 || this.player2.getMainStatus().get(MainStatus.hp) <= 0;
    }
    //どっちが勝ったか。1ならselfの勝ち、-1ならenemyの勝ち、0なら引き分け
    public int isWin(boolean player1){
        if(turn >= 50){
            return 0;
        }
        boolean P1Escape = this.player1.getStateAction().get(ActionState.Escape).get(ActionStateCounter.flag) == 1;
        boolean P2Escape = this.player2.getStateAction().get(ActionState.Escape).get(ActionStateCounter.flag) == 1;
        if(P1Escape && P2Escape) return 0;
        if(P1Escape) return player1 ? -1 : 1;
        if(P2Escape) return player1 ? 1 : -1;
        if(this.player1.getMainStatus().get(MainStatus.hp) <= 0 && this.player2.getMainStatus().get(MainStatus.hp) <= 0) return 0;
        if(this.player1.getMainStatus().get(MainStatus.hp) == this.player2.getMainStatus().get(MainStatus.hp)) return 0;
        if(this.player1.getMainStatus().get(MainStatus.hp) > this.player2.getMainStatus().get(MainStatus.hp)) return player1 ? 1 : -1;
        return player1 ? -1 : 1;
    }

    public int[] getDataArray(){//TODO weatherを保存する
        List<Integer> dataList = new ArrayList<>();
        dataList.addAll(this.player1.getDataArray());
        dataList.addAll(this.player2.getDataArray());
        dataList.add(this.p1Auto.ordinal());
        dataList.add(this.p2Auto.ordinal());
        for(Field key : Field.values()){
            for(FieldCounter counter : FieldCounter.values()){
                dataList.add(this.field.get(key).get(counter));
            }
        }
        dataList.add(this.turn);
        return dataList.stream().mapToInt(i -> i).toArray();
    }

    // 取り得る呪文スロットの組み合わせ全てのリスト
    private static List<List<Spell>> getSpellForAi(Character self){
        List<List<Spell>> spellSlotList = new ArrayList<List<Spell>>();
        List<Spell> spellList = new ArrayList<Spell>();
        List<Spell> spellSlot = new ArrayList<Spell>();
        Map<Spell, Integer> learnedSpellLevel = self.getLearnedSpellLevel();

        if(learnedSpellLevel.size()-1 <= self.getSpellSlotNum()){
            for(Spell spell: learnedSpellLevel.keySet()){
                if(spell != Spell.NULL){
                    spellSlot.add(spell);
                }
            }
            for(int i = 0; i < self.getSpellSlotNum() - spellSlot.size(); i++){
                spellSlot.add(Spell.NULL);
            }
            spellSlotList.add(spellSlot);
            if(spellSlotList.size() == 0){
                System.out.println("size 0 v2");
                spellSlotList.add(new ArrayList<Spell>());
            }
            return spellSlotList;
        }

        for(Spell spell: learnedSpellLevel.keySet()){
            if(spell != Spell.NULL){
                spellList.add(spell);
            }
        }
        fillList(spellSlotList, spellList, spellSlot, learnedSpellLevel.containsKey(Spell.NULL) ? learnedSpellLevel.size() - 1 : learnedSpellLevel.size(), 0, self.getSpellSlotNum(), -1);
        if(spellSlotList.size() == 0){
            System.out.println("size 0 v1");
            spellSlotList.add(new ArrayList<Spell>());
        }
        return spellSlotList;
    }

    // 呪文スロットの組み合わせを引数から決める
    private static void fillList(List<List<Spell>> spellSlotList, List<Spell> spellList, List<Spell> spellSlot, 
     int spellNum, int filledNum, int spellSlotNum, int beforeChoiceIndex){
        List<Spell> copySpellSlot;
        for(int i = beforeChoiceIndex + 1; i < spellNum - spellSlotNum + filledNum + 1; i++){
            copySpellSlot = new ArrayList<Spell>(spellSlot);
            copySpellSlot.add(spellList.get(i));
            if(filledNum + 1 == spellSlotNum){
                spellSlotList.add(copySpellSlot);
            } else{
                fillList(spellSlotList, spellList, copySpellSlot, spellNum, filledNum + 1, spellSlotNum, i);
            }
        }
    }
}
