import java.util.Arrays;
import java.util.EnumMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import battle.InputAction.Auto;
import character.Player;
import character.Character.Attribute;
import character.Skill;
import data.action.Spell;
import data.item.StartItemSet;
import data.stage.Stage;
import limitation.TrainLimitation;
import text.Print;
import train.Train;
import train.TrainState;
import train.TrainState.Mode;

public class JavaQuest_old {
    public static void main(String[] args) {
        long start = System.currentTimeMillis();
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();
        int choice = -1;
        if(TrainState.saveDataNums().contains(Integer.MIN_VALUE)){
            System.out.println("中断データがあります。再開しますか？<br>1:はい" + Print.space(2, true) + "2:いいえ");
            if(sc.nextInt() == 1){
                sc.nextLine();
                Train.train(TrainState.load(Integer.MIN_VALUE, true, true), StartItemSet.None, true, sc, rand);
                return;
            }else{
                sc.nextLine();
            }
        }
        /* System.out.println("名前を名付けてください");
        String name = sc.nextLine();
        if(name.equals("")){
            name = "勇者";
        } */
        String name = "勇者";
        Mode mode;
        Stage stage = Stage.last;
        Attribute attribute;
        Skill skill = Skill.NULL;
        StartItemSet startItemSet = StartItemSet.Tairyokuzai1;
        int hp = 1000;
        int mp = 5;
        int atk = 100;
        int def = 100;
        int spd = 100;
        int electricity = 80;
        int maxElectricity = 100;
        int oil = 200;
        int gasoline = 100;
        int money = 0;

        //モード選択
        List<Mode> modeList = Arrays.asList(Mode.values());
        do{
            try{
                System.out.println("モードを選択してください");
                for(int i = 0; i < modeList.size(); i++){
                    System.out.print((i + 1) + ":" + modeList.get(i).jName + "    ");
                }
                System.out.println();
                choice = sc.nextInt();
                sc.nextLine();
            }
            catch(InputMismatchException e){
                choice = -1;
            }
        }while(choice <= 0 || modeList.size() < choice);
        mode = modeList.get(choice - 1);

        //必殺技選択
        if(TrainLimitation.attribute.useAble(mode)){
            double randouble = rand.nextDouble();
            if(randouble < 1.0 / 3){
                attribute = Attribute.A;
            }else if(randouble < 2.0 / 3){
                attribute = Attribute.D;
            }else{
                attribute = Attribute.C;
            }
            /*if(TrainLimitation.attributeS.useAble() && rand.nextDouble() < 0.1){
                attribute = Attribute.S;
            }*/
            System.out.println("<br>あなたの必殺技は乱数によって" + attribute.jName + "に決定した");
            // System.out.println(attribute.jName + "でプレイしますか（いいえを選ぶと必殺技なしになります）<br>1:はい  2:いいえ");
            // if(sc.nextInt() == 2){
            //     attribute = Attribute.Null;
            // }
            sc.nextLine();
        }else{
            attribute = Attribute.Null;
        }

        if(mode != Mode.debug){
            Train.train(new TrainState(new Player(name, attribute, skill, new int[] {hp, hp, mp, mp, atk, def, 10, spd, 2, oil, oil, electricity, maxElectricity, gasoline, gasoline, money}, new EnumMap<Spell, Integer>(Spell.class), mode), stage, mode, Auto.select, Auto.select, rand), startItemSet, true, sc, rand)/*.endState.save(98, true)*/;
            sc.close();
            long playSecond = ((System.currentTimeMillis() - start) / 1000) % 60;
            long playMinute = ((System.currentTimeMillis() - start) / 1000) / 60;
            System.out.println("プレイ時間 : " + playMinute + "分 " + playSecond + "秒");
            return;
        }

        int debugHp = 1000;
        int debugMp = 5;
        int debugAtk = 100;
        int debugDef = 100;
        int debugSpd = 100;
        int debugMotivation = 700;
        int debugActivity = 700;
        int debugHealth = 700;
        int debugMoney = 10000;

        choice = -1;
        //ステージ選択
        List<Stage> stageList = Arrays.asList(Stage.values());
        do{
            try{
                System.out.println("ステージを選択してください");
                for(int i = 0; i < stageList.size(); i++){
                    System.out.print((i + 1) + ":" + stageList.get(i).jName + "    ");
                }
                System.out.println();
                choice = sc.nextInt();
                sc.nextLine();
            }
            catch(InputMismatchException e){
                choice = -1;
            }
        }while(choice <= 0 || stageList.size() < choice);
        stage = stageList.get(choice - 1);

        // int activity = TrainLimitation.trainingSize.useAble() ? 100 : 70;
        //スキル選択
        choice = -1;
        List<Skill> skillList = Skill.skillList(mode);
        if(stage.skill == null){
            do{
                try{
                    System.out.println("<br>スキルを選択してください");
                    for(int i = 0; i < skillList.size(); i++){
                        System.out.print((i + 1) + ":" + skillList.get(i).jName + "    ");
                    }
                    System.out.println();
                    choice = sc.nextInt();
                    sc.nextLine();
                }
                catch(InputMismatchException e){
                    choice = -1;
                }
            }while(choice <= 0 || skillList.size() < choice);
            skill = skillList.get(choice - 1);
        }else{
            skill = stage.skill;
        }
        //持ち込みアイテム選択
        StartItemSet[] startItemSets = StartItemSet.values();
        do{
            try{
                System.out.println("<br>持ち込みアイテムを選択してください");
                for(int i = 0; i < startItemSets.length; i++){
                    System.out.print((i + 1) + ":" + startItemSets[i].name() + "    ");
                }
                System.out.println();
                choice = sc.nextInt();
                sc.nextLine();
            }
            catch(InputMismatchException e){
                choice = -1;
            }
        }while(choice <= 0 || startItemSets.length < choice);
        startItemSet = startItemSets[choice - 1];

        Train.train(new TrainState(new Player(name, attribute, skill, new int[] {debugHp, debugHp, debugMp, debugMp, debugAtk, debugDef, 10, debugSpd, 2, debugMotivation, debugMotivation, debugActivity, debugActivity, debugHealth, debugHealth, debugMoney}, new EnumMap<Spell, Integer>(Spell.class), mode), stage, mode, Auto.select, Auto.select, rand), startItemSet, true, sc, rand)/*.endState.save(98, true)*/;
        sc.close();
        long playSecond = ((System.currentTimeMillis() - start) / 1000) % 60;
        long playMinute = ((System.currentTimeMillis() - start) / 1000) / 60;
        System.out.println("プレイ時間 : " + playMinute + "分 " + playSecond + "秒");
        //TrainState state = TrainState.load(98, true);
    }
}
