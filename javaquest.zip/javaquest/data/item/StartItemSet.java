package data.item;

import java.util.HashMap;
import java.util.Map;

// 持ち込みアイテムセット
// 開封メソッドが有った方が良いかも
public enum StartItemSet {
    None(new HashMap<Item, Integer>(){{
        //なにもなし
    }}),
    // Mezamasidokei1(new EnumMap<>(DisposableItem.class){{
    //     this.put(DisposableItem.Mezamasidokei, 1);
    // }}),
    // Mezamasidokei3(new EnumMap<>(DisposableItem.class){{
    //     this.put(DisposableItem.Mezamasidokei, 3);
    // }}),
    Tairyokuzai1(new HashMap<Item, Integer>(){{
        this.put(BattleItem.Tairyokuzai, 1);
    }}),
    Maryokuzai1(new HashMap<Item, Integer>(){{
        this.put(BattleItem.Maryokuzai, 1);
    }}),
    Zoukyouzai1(new HashMap<Item, Integer>(){{
        this.put(BattleItem.Zoukyouzai, 1);
    }}),
    Bannnouyaku1(new HashMap<Item, Integer>(){{
        this.put(BattleItem.Bannnouyaku, 1);
    }}),
    Tairyokuzai2(new HashMap<Item, Integer>(){{
        this.put(BattleItem.Tairyokuzai, 2);
    }}),
    Maryokuzai2(new HashMap<Item, Integer>(){{
        this.put(BattleItem.Maryokuzai, 2);
    }}),
    Zoukyouzai2(new HashMap<Item, Integer>(){{
        this.put(BattleItem.Zoukyouzai, 2);
    }}),
    Bannnouyaku2(new HashMap<Item, Integer>(){{
        this.put(BattleItem.Bannnouyaku, 2);
    }}),
    // GoodYakusou3(new EnumMap<>(DisposableItem.class){{
    //     this.put(DisposableItem.GoodYakusou, 3);
    // }}),
    // GoodMamusidrink3(new EnumMap<>(DisposableItem.class){{
    //     this.put(DisposableItem.GoodMamusidrink, 3);
    // }}),
    // GoodKaruisi3(new EnumMap<>(DisposableItem.class){{
    //     this.put(DisposableItem.GoodKaruisi, 3);
    // }}),
    // HeavyRain3(new EnumMap<>(DisposableItem.class){{
    //     this.put(DisposableItem.GoodSoap, 3);
    // }}),
    Elixir1(new HashMap<Item, Integer>(){{
        this.put(BattleItem.Elixir, 1);
    }}),
    Tent1(new HashMap<Item, Integer>(){{
        this.put(DisposableItem.Tent, 1);
    }}),
    ;
    public final Map<Item, Integer> items;
    private StartItemSet(Map<Item, Integer> items){
        this.items = items;
    }
}
