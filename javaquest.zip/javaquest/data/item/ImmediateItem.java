package data.item;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import battle.CalculateDamage;
import battle.InputAction;
import battle.InputAction.Action;
import battle.InputAction.Auto;
import battle.state_change.ChangeAbnormalState.AbnormalState;
import character.Player;
import character.Character.MainStatus;
import character.Player.SpellBookLevel;
import character.Player.TrainStatus;
import data.action.Spell;
import data.card.CardWithParams;
import data.card.ItemCard;
import data.card.TrainEvent;
import limitation.TrainLimitation;
import limitation.TrainLimitation.TrainLimitationCounter;
import text.Print;
import train.Train;
import train.TrainState;
import train.TrainState.Mode;
import train.TrainState.shuffleModeWithAddCard;

public enum ImmediateItem implements Item{
    // Engine("エンジン",
    //             10,
    //             1,//TODO 2乗無くす
    //             "自分のガソリンを20%増加させる。<br>これを買えば強化効率は1.2倍になる",
    //             false,
    //             EnumSet.of(Shop.Normal),
    //             EnumSet.of(Mode.easy, Mode.normal, Mode.hard)){
    //     @Override
    //     public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
    //         Player self = trainState.getSelf();
    //         int beforeMaxMotivation = self.getTrainStatus().get(TrainStatus.maxGasoline);
    //         int increaseMaxMotivation;
    //         CalculateDamage.trainProgress(self, TrainStatus.maxGasoline, true, 20, text);
    //         increaseMaxMotivation = self.getTrainStatus().get(TrainStatus.maxGasoline) - beforeMaxMotivation;
    //         CalculateDamage.trainDamage(self, TrainStatus.gasoline, -increaseMaxMotivation, text);
    //         trainState.setSelf(self);
    //         return trainState;
    //     }
    //     @Override
    //     public boolean useAble(TrainState trainState){
    //         return trainState.getSelf().getTrainStatus().get(TrainStatus.maxGasoline) < TrainStatus.maxGasoline.maxNum;
    //     }
    // },

    /*AttributeA("攻撃属性の種",
                100,
                "攻撃属性を手に入れる",
                false,
                EnumSet.of(Shop.Normal)){
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            Player self = trainState.getSelf();
            self.setBaseAttribute(attributes.A);
            trainState.setSelf(self);
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            return true;
        }
    },

    AttributeD("防御属性の種",
                100,
                "防御属性を手に入れる",
                false,
                EnumSet.of(Shop.Normal)){
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            Player self = trainState.getSelf();
            self.setBaseAttribute(attributes.D);
            trainState.setSelf(self);
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            return true;
        }
    },

    AttributeC("溜める属性の種",
                100,
                "溜める属性を手に入れる",
                false,
                EnumSet.of(Shop.Normal)){
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            Player self = trainState.getSelf();
            self.setBaseAttribute(attributes.C);
            trainState.setSelf(self);
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            return true;
        }
    },

    AttributeS("呪文属性の種",
                500,
                "呪文属性を手に入れる",
                false,
                EnumSet.of(Shop.Dark)){
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            Player self = trainState.getSelf();
            self.setBaseAttribute(attributes.S);
            trainState.setSelf(self);
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            return true;
        }
    },

    Pocket("スロット",
            300,
            1,
            "魔法スロット増加",
            true,
            EnumSet.of(Shop.Normal)){
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            Player self = trainState.getSelf();
            self.setSpellSlotNum(self.getSpellSlotNum() + 1);
            trainState.setSelf(self);
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            return true;
        }
    },*/
    HPMedicine("HP剤", 
            600, 
            1, 
            true, 
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard)){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println(TrainStatus.hp.jName + "を" + TrainStatus.maxHp.jName + "の 70%回復する「HP剤」を手札に加える", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            trainState.getHands().add(new CardWithParams(-1, ItemCard.HPMedicine, new ArrayList<>(), true));
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            return true;
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
    },

    ConMedicine("集中力剤", 
            600, 
            1, 
            true, 
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard)){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println(TrainStatus.concentration.jName + "を 50 回復する「集中力剤」を手札に加える", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            trainState.getHands().add(new CardWithParams(-1, ItemCard.ConMedicine, new ArrayList<>(), true));
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            return true;
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
    },

    MotivMedicine("やる気剤", 
            600, 
            1, 
            true, 
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard)){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println(TrainStatus.motivation.jName + "を 50 回復する「やる気剤」を手札に加える", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            trainState.getHands().add(new CardWithParams(-1, ItemCard.MotivMedicine, new ArrayList<>(), true));
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            return true;
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
    },

    Reload("引き直し", 
            200, 
            1, 
            false, 
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard)){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println("購入すると即座に手札を全てデッキに戻し、同じ枚数だけ引き直す", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            Print.println("", true, Print.highSpeed, text);
            Print.println("手札を全てデッキに戻し、同じ枚数だけ引き直した" + Print.sleep(10), true, Print.highSpeed, text);
            Print.println("", true, Print.highSpeed, text);
            int resetNum = CardWithParams.cardsSize(trainState.getHands());
            trainState.saveAddCard(CardWithParams.takeCard(trainState.getHands()), shuffleModeWithAddCard.Last);
            trainState.addCardToDeck(true, false);
            trainState.setHands(new ArrayList<>());
            trainState.setHands(CardWithParams.drawCard(trainState, resetNum, false, rand));
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            return true;
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
    },

    // HPMedicineDouble("HP剤 2個セット", 
    //         800, 
    //         1, 
    //         false, 
    //         EnumSet.of(Shop.Normal),
    //         EnumSet.of(Mode.easy, Mode.normal, Mode.hard)){
    //     @Override
    //     public String getJName(TrainState trainState){
    //         return this.jName;
    //     }
    //     @Override
    //     public void explain(boolean text){
    //         Print.println(TrainStatus.hp.jName + "を" + TrainStatus.maxHp.jName + "の 50%回復する「HP剤」を 2個手札に加える", Print.highSpeed, text);
    //     }
    //     @Override
    //     public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
    //         trainState.getHands().add(new CardWithParams(-1, ItemCard.HPMedicine, new ArrayList<>(), true));
    //         trainState.getHands().add(new CardWithParams(-1, ItemCard.HPMedicine, new ArrayList<>(), true));
    //         return trainState;
    //     }
    //     @Override
    //     public boolean useAble(TrainState trainState){
    //         return true;
    //     }
    //     @Override
    //     public int getCost(Player self) {
    //         return this.cost;
    //     }
    // },

    // ConMedicineDouble("集中力剤 2個セット", 
    //         800, 
    //         1, 
    //         false, 
    //         EnumSet.of(Shop.Normal),
    //         EnumSet.of(Mode.easy, Mode.normal, Mode.hard)){
    //     @Override
    //     public String getJName(TrainState trainState){
    //         return this.jName;
    //     }
    //     @Override
    //     public void explain(boolean text){
    //         Print.println(TrainStatus.concentration.jName + "を 30回復する「集中力剤」を 2個手札に加える", Print.highSpeed, text);
    //     }
    //     @Override
    //     public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
    //         trainState.getHands().add(new CardWithParams(-1, ItemCard.ConMedicine, new ArrayList<>(), true));
    //         trainState.getHands().add(new CardWithParams(-1, ItemCard.ConMedicine, new ArrayList<>(), true));
    //         return trainState;
    //     }
    //     @Override
    //     public boolean useAble(TrainState trainState){
    //         return true;
    //     }
    //     @Override
    //     public int getCost(Player self) {
    //         return this.cost;
    //     }
    // },

    // MotivMedicineDouble("やる気剤 2個セット", 
    //         800, 
    //         1, 
    //         false, 
    //         EnumSet.of(Shop.Normal),
    //         EnumSet.of(Mode.easy, Mode.normal, Mode.hard)){
    //     @Override
    //     public String getJName(TrainState trainState){
    //         return this.jName;
    //     }
    //     @Override
    //     public void explain(boolean text){
    //         Print.println(TrainStatus.motivation.jName + "を 30回復する「やる気剤」を 2個手札に加える", Print.highSpeed, text);
    //     }
    //     @Override
    //     public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
    //         trainState.getHands().add(new CardWithParams(-1, ItemCard.MotivMedicine, new ArrayList<>(), true));
    //         trainState.getHands().add(new CardWithParams(-1, ItemCard.MotivMedicine, new ArrayList<>(), true));
    //         return trainState;
    //     }
    //     @Override
    //     public boolean useAble(TrainState trainState){
    //         return true;
    //     }
    //     @Override
    //     public int getCost(Player self) {
    //         return this.cost;
    //     }
    // },

    FireBook(SpellBookLevel.Fire, 
            800,
            1,
            false,
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard),
            new LinkedHashMap<>(){{
                put(Spell.Fire, 1);
            }},
            new LinkedHashMap<>(){{
                put(Spell.Fire, 1);
            }}){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println("呪文「ファイア」が使えるようになる", Print.highSpeed, text);
            Print.println("基本的な攻撃呪文", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            return spellBookExecute(trainState, this.spellBook, this.spellLearnLevels, this.spellInitialLevels, text, scanner, rand);
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            for(Spell spell : Spell.strengthenSpellCategory().get(Spell.Fire)){
                if(self.getLearnedSpellLevel().containsKey(spell)){
                    return false;
                }
            }
            return true;
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
    },

    FireStrengthen(SpellBookLevel.Flame,
            1000,
            1,
            false,
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard),
            new LinkedHashMap<>(){{
                put(Spell.Flame, 1);
            }},
            new LinkedHashMap<>(){{
                put(Spell.Flame, 1);
            }}){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println("呪文「ファイア」を強化し、呪文「フレイム」にする", Print.highSpeed, text);
            Print.println("敵に大ダメージを与える呪文", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            strengthenSpell(trainState.getSelf(), Spell.Fire, Spell.Flame);
            Print.println(Spell.Fire.jName + "が" + Spell.Flame.jName + "に強化された", Print.highSpeed, text);
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            for(Spell spell : Spell.strengthenSpellCategory().get(Spell.Fire)){
                if(spell == Spell.Fire){
                    continue;
                }
                if(self.getLearnedSpellLevel().containsKey(spell)){
                    return false;
                }
            }
            return true;
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
    },

    FlameStrengthen(SpellBookLevel.Explosion,
            1000,
            1,
            false,
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard),
            new LinkedHashMap<>(){{
                put(Spell.Explosion, 1);
            }},
            new LinkedHashMap<>(){{
                put(Spell.Explosion, 1);
            }}){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println("呪文「フレイム」を強化し、呪文「エプロン」にする", Print.highSpeed, text);
            Print.println("敵に特大ダメージを与える呪文", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            strengthenSpell(trainState.getSelf(), Spell.Flame, Spell.Explosion);
            Print.println(Spell.Flame.jName + "が" + Spell.Explosion.jName + "に強化された", Print.highSpeed, text);
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            for(Spell spell : Spell.strengthenSpellCategory().get(Spell.Fire)){
                if(spell == Spell.Fire || spell == Spell.Flame){
                    continue;
                }
                if(self.getLearnedSpellLevel().containsKey(spell)){
                    return false;
                }
            }
            return true;
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
    },

    ExplosionStrengthen(SpellBookLevel.BigBang,
            1000,
            1,
            false,
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard),
            new LinkedHashMap<>(){{
                put(Spell.BigBang, 1);
            }},
            new LinkedHashMap<>(){{
                put(Spell.BigBang, 1);
            }}){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println("呪文「エプロン」を強化し、呪文「ビッグバン」にする", Print.highSpeed, text);
            Print.println("敵に超特大ダメージを与える呪文", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            strengthenSpell(trainState.getSelf(), Spell.Explosion, Spell.BigBang);
            Print.println(Spell.Explosion.jName + "が" + Spell.BigBang.jName + "に強化された", Print.highSpeed, text);
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            for(Spell spell : Spell.strengthenSpellCategory().get(Spell.Fire)){
                if(spell == Spell.Fire || spell == Spell.Flame || spell == Spell.Explosion){
                    continue;
                }
                if(self.getLearnedSpellLevel().containsKey(spell)){
                    return false;
                }
            }
            return true;
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
    },

    WindBook(SpellBookLevel.Wind, 
            800,
            1,
            false,
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard),
            new LinkedHashMap<>(){{
                put(Spell.Wind, 1);
            }},
            new LinkedHashMap<>(){{
                put(Spell.Wind, 1);
            }}){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println("呪文「ウィンド」が使えるようになる", Print.highSpeed, text);
            Print.println("先制で敵に小ダメージを与える呪文", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            return spellBookExecute(trainState, this.spellBook, this.spellLearnLevels, this.spellInitialLevels, text, scanner, rand);
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            for(Spell spell : Spell.strengthenSpellCategory().get(Spell.Wind)){
                if(self.getLearnedSpellLevel().containsKey(spell)){
                    return false;
                }
            }
            return true;
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
    },

    WindStrengthen(SpellBookLevel.Gust,
            1000,
            1,
            false,
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard),
            new LinkedHashMap<>(){{
                put(Spell.Gust, 1);
            }},
            new LinkedHashMap<>(){{
                put(Spell.Gust, 1);
            }}){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println("呪文「ウィンド」を強化し、呪文「ガスト」にする", Print.highSpeed, text);
            Print.println("先制で敵に中ダメージを与える呪文", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            strengthenSpell(trainState.getSelf(), Spell.Wind, Spell.Gust);
            Print.println(Spell.Wind.jName + "が" + Spell.Gust.jName + "に強化された", Print.highSpeed, text);
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            for(Spell spell : Spell.strengthenSpellCategory().get(Spell.Wind)){
                if(spell == Spell.Wind){
                    continue;
                }
                if(self.getLearnedSpellLevel().containsKey(spell)){
                    return false;
                }
            }
            return true;
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
    },

    GustStrengthen(SpellBookLevel.Tornado,
            1000,
            1,
            false,
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard),
            new LinkedHashMap<>(){{
                put(Spell.Tornado, 1);
            }},
            new LinkedHashMap<>(){{
                put(Spell.Tornado, 1);
            }}){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println("呪文「ガスト」を強化し、呪文「トルネード」にする", Print.highSpeed, text);
            Print.println("先制で敵に大ダメージを与える呪文", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            strengthenSpell(trainState.getSelf(), Spell.Gust, Spell.Tornado);
            Print.println(Spell.Gust.jName + "が" + Spell.Tornado.jName + "に強化された", Print.highSpeed, text);
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            for(Spell spell : Spell.strengthenSpellCategory().get(Spell.Wind)){
                if(spell == Spell.Wind || spell == Spell.Gust){
                    continue;
                }
                if(self.getLearnedSpellLevel().containsKey(spell)){
                    return false;
                }
            }
            return true;
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
    },

    TornadoStrengthen(SpellBookLevel.Storm,
            1000,
            1,
            false,
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard),
            new LinkedHashMap<>(){{
                put(Spell.Storm, 1);
            }},
            new LinkedHashMap<>(){{
                put(Spell.Storm, 1);
            }}){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println("呪文「トルネード」を強化し、呪文「ストーム」にする", Print.highSpeed, text);
            Print.println("先制で敵に特大ダメージを与える呪文", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            strengthenSpell(trainState.getSelf(), Spell.Tornado, Spell.Storm);
            Print.println(Spell.Tornado.jName + "が" + Spell.Storm.jName + "に強化された", Print.highSpeed, text);
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            for(Spell spell : Spell.strengthenSpellCategory().get(Spell.Wind)){
                if(spell == Spell.Wind || spell == Spell.Gust || spell == Spell.Tornado){
                    continue;
                }
                if(self.getLearnedSpellLevel().containsKey(spell)){
                    return false;
                }
            }
            return true;
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
    },

    StoneBook(SpellBookLevel.Stone, 
            800,
            1,
            false,
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard),
            new LinkedHashMap<>(){{
                put(Spell.Stone, 1);
            }},
            new LinkedHashMap<>(){{
                put(Spell.Stone, 1);
            }}){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println("呪文「ストーン」が使えるようになる", Print.highSpeed, text);
            Print.println("石を飛ばしてダメージを相手に与える。連続で出すことが可能で、そのたびに威力が増加する", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            return spellBookExecute(trainState, this.spellBook, this.spellLearnLevels, this.spellInitialLevels, text, scanner, rand);
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            for(Spell spell : Spell.strengthenSpellCategory().get(Spell.Stone)){
                if(self.getLearnedSpellLevel().containsKey(spell)){
                    return false;
                }
            }
            return true;
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
    },

    StoneStrengthen(SpellBookLevel.Rock,
            1000,
            1,
            false,
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard),
            new LinkedHashMap<>(){{
                put(Spell.Rock, 1);
            }},
            new LinkedHashMap<>(){{
                put(Spell.Rock, 1);
            }}){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println("呪文「ストーン」を強化し、呪文「ロック」にする", Print.highSpeed, text);
            Print.println("岩を投げて大ダメージを相手に与える。連続で出すことが可能で、そのたびに威力が増加する", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            strengthenSpell(trainState.getSelf(), Spell.Stone, Spell.Rock);
            Print.println(Spell.Stone.jName + "が" + Spell.Rock.jName + "に強化された", Print.highSpeed, text);
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            for(Spell spell : Spell.strengthenSpellCategory().get(Spell.Stone)){
                if(spell == Spell.Stone){
                    continue;
                }
                if(self.getLearnedSpellLevel().containsKey(spell)){
                    return false;
                }
            }
            return true;
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
    },

    RockStrengthen(SpellBookLevel.Lava,
            1000,
            1,
            false,
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard),
            new LinkedHashMap<>(){{
                put(Spell.Lava, 1);
            }},
            new LinkedHashMap<>(){{
                put(Spell.Lava, 1);
            }}){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println("呪文「ロック」を強化し、呪文「ラヴァ」にする", Print.highSpeed, text);
            Print.println("溶岩を投げて特大ダメージを相手に与える。連続で出すことが可能で、そのたびに威力が増加する", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            strengthenSpell(trainState.getSelf(), Spell.Rock, Spell.Lava);
            Print.println(Spell.Rock.jName + "が" + Spell.Lava.jName + "に強化された", Print.highSpeed, text);
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            for(Spell spell : Spell.strengthenSpellCategory().get(Spell.Stone)){
                if(spell == Spell.Stone || spell == Spell.Rock){
                    continue;
                }
                if(self.getLearnedSpellLevel().containsKey(spell)){
                    return false;
                }
            }
            return true;
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
    },

    LavaStrengthen(SpellBookLevel.Meteor,
            1000,
            1,
            false,
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard),
            new LinkedHashMap<>(){{
                put(Spell.Meteor, 1);
            }},
            new LinkedHashMap<>(){{
                put(Spell.Meteor, 1);
            }}){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println("呪文「ラヴァ」を強化し、呪文「メテオ」にする", Print.highSpeed, text);
            Print.println("隕石を落として特大ダメージを相手に与える。連続で出すことが可能で、そのたびに威力が増加する", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            strengthenSpell(trainState.getSelf(), Spell.Lava, Spell.Meteor);
            Print.println(Spell.Lava.jName + "が" + Spell.Meteor.jName + "に強化された", Print.highSpeed, text);
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            for(Spell spell : Spell.strengthenSpellCategory().get(Spell.Stone)){
                if(spell == Spell.Stone || spell == Spell.Rock || spell == Spell.Lava){
                    continue;
                }
                if(self.getLearnedSpellLevel().containsKey(spell)){
                    return false;
                }
            }
            return true;
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
    },

    HealBook(SpellBookLevel.Heal, 
            1200,
            1,
            false,
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard),
            new LinkedHashMap<>(){{
                put(Spell.Heal, 1);
            }},
            new LinkedHashMap<>(){{
                put(Spell.Heal, 1);
            }}){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println("呪文「ヒール」が使えるようになる", Print.highSpeed, text);
            Print.println("基本的な回復呪文", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            return spellBookExecute(trainState, this.spellBook, this.spellLearnLevels, this.spellInitialLevels, text, scanner, rand);
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            return !self.getLearnedSpellLevel().containsKey(Spell.Heal);
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
    },

    AUpBook(SpellBookLevel.AUp, 
            800,
            1,
            false,
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard),
            new LinkedHashMap<>(){{
                put(Spell.AUp, 1);
            }},
            new LinkedHashMap<>(){{
                put(Spell.AUp, 1);
            }}){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println("呪文「アタックアップ」が使えるようになる", Print.highSpeed, text);
            Print.println("攻撃力アップ呪文。攻撃力が 5ターンの間増加する", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            return spellBookExecute(trainState, this.spellBook, this.spellLearnLevels, this.spellInitialLevels, text, scanner, rand);
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            return !self.getLearnedSpellLevel().containsKey(Spell.AUp);
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
    },

    SUpBook(SpellBookLevel.SUp, 
            800,
            1,
            false,
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard),
            new LinkedHashMap<>(){{
                put(Spell.SUp, 1);
            }},
            new LinkedHashMap<>(){{
                put(Spell.SUp, 1);
            }}){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println("呪文「スピードアップ」が使えるようになる", Print.highSpeed, text);
            Print.println("素早さアップ呪文。素早さを 5ターン増加する", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            return spellBookExecute(trainState, this.spellBook, this.spellLearnLevels, this.spellInitialLevels, text, scanner, rand);
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            return !self.getLearnedSpellLevel().containsKey(Spell.SUp);
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
    },

    DUpBook(SpellBookLevel.DUp, 
            1200,
            1,
            false,
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard),
            new LinkedHashMap<>(){{
                put(Spell.DUp, 1);
            }},
            new LinkedHashMap<>(){{
                put(Spell.DUp, 1);
            }}){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println("呪文「ディフェンスアップ」が使えるようになる", Print.highSpeed, text);
            Print.println("防御力アップ呪文。防御力を 5ターン増加する", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            return spellBookExecute(trainState, this.spellBook, this.spellLearnLevels, this.spellInitialLevels, text, scanner, rand);
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            return !self.getLearnedSpellLevel().containsKey(Spell.DUp);
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
    },

    NervousBook(SpellBookLevel.Nervous, 
                1200,
                1,
                false,
                EnumSet.of(Shop.Shine),
                EnumSet.of(Mode.normal, Mode.hard),
                new LinkedHashMap<>(){{
                    put(Spell.Nervous, 1);
                }},
                new LinkedHashMap<>(){{
                    put(Spell.Nervous, 3);
                }}){
        @Override
        public void explain(boolean text){
            Print.println("呪文「緊迫斬り」が使えるようになる", Print.highSpeed, text);
            Print.println("攻撃しつつ、敵を緊張状態にする。緊張状態のキャラクターは連続して同じ行動が出来ない", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            return spellBookExecute(trainState, this.spellBook, this.spellLearnLevels, this.spellInitialLevels, text, scanner, rand);
            //return setSpellExecute(trainState, new SpellBookLevel[]{SpellBookLevel.Lag, SpellBookLevel.Hesitance}, Spell.Trauma, text, scanner, rand);
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            return !self.getLearnedSpellLevel().containsKey(Spell.Nervous);
        }
    },

    LagBook(SpellBookLevel.Lag, 
                1200,
                1,
                false,
                EnumSet.of(Shop.Normal),
                EnumSet.of(Mode.normal, Mode.hard),
                new LinkedHashMap<>(){{
                    put(Spell.Lag, 1);
                }},
                new LinkedHashMap<>(){{
                    put(Spell.Lag, 1);
                }}){
        @Override
        public void explain(boolean text){
            Print.println("呪文「回線斬り」が使えるようになる", Print.highSpeed, text);
            Print.println("攻撃しつつ、相手をラグ状態にする。ラグ状態になると行動を前のターンに決めなければならない", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            return spellBookExecute(trainState, this.spellBook, this.spellLearnLevels, this.spellInitialLevels, text, scanner, rand);
            //return setSpellExecute(trainState, new SpellBookLevel[]{SpellBookLevel.Lag, SpellBookLevel.Hesitance}, Spell.Trauma, text, scanner, rand);
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            return !self.getLearnedSpellLevel().containsKey(Spell.Lag);
        }
    },

    BondBook(SpellBookLevel.Bond, 
                1000,
                1,
                false,
                EnumSet.of(Shop.Normal),
                EnumSet.of(Mode.normal, Mode.hard),
                new LinkedHashMap<>(){{
                    put(Spell.Bond, 1);
                }},
                new LinkedHashMap<>(){{
                    put(Spell.Bond, 1);
                }}){
        @Override
        public void explain(boolean text){
            Print.println("呪文「臆病斬り」が使えるようになる", Print.highSpeed, text);
            Print.println("攻撃しつつ、相手を臆病状態にする。臆病状態になると相手と同じ行動をしたときに失敗する。ただし、呪文は失敗しない", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            return spellBookExecute(trainState, this.spellBook, this.spellLearnLevels, this.spellInitialLevels, text, scanner, rand);
            //return setSpellExecute(trainState, new SpellBookLevel[]{SpellBookLevel.Lag, SpellBookLevel.Hesitance}, Spell.Trauma, text, scanner, rand);
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            return !self.getLearnedSpellLevel().containsKey(Spell.Bond);
        }
    },

    PoisonBook(SpellBookLevel.Poison, 
                1000,
                1,
                false,
                EnumSet.of(Shop.Normal),
                EnumSet.of(Mode.normal, Mode.hard),
                new LinkedHashMap<>(){{
                    put(Spell.Poison, 1);
                }},
                new LinkedHashMap<>(){{
                    put(Spell.Poison, 1);
                }}){
        @Override
        public void explain(boolean text){
            Print.println("呪文「毒斬り」が使えるようになる", Print.highSpeed, text);
            Print.println("攻撃しつつ、相手を毒状態にする。毒状態になるとターンの終了時に最大HPに比例したダメージを受ける", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            return spellBookExecute(trainState, this.spellBook, this.spellLearnLevels, this.spellInitialLevels, text, scanner, rand);
            //return setSpellExecute(trainState, new SpellBookLevel[]{SpellBookLevel.Venom, SpellBookLevel.Stomatitis}, Spell.Curse, text, scanner, rand);
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            return !self.getLearnedSpellLevel().containsKey(Spell.Poison);
        }
    },

    StomatitisBook(SpellBookLevel.Stomatitis, 
                800,
                1,
                false,
                EnumSet.of(Shop.Normal),
                EnumSet.of(Mode.normal, Mode.hard),
                new LinkedHashMap<>(){{
                    put(Spell.Stomatitis, 1);
                }},
                new LinkedHashMap<>(){{
                    put(Spell.Stomatitis, 1);
                }}){
        @Override
        public void explain(boolean text){
            Print.println("呪文「沈黙斬り」が使えるようになる", Print.highSpeed, text);
            Print.println("攻撃しつつ、相手を口内炎状態にする。口内炎状態になると呪文を使用したときに後手になる", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            return spellBookExecute(trainState, this.spellBook, this.spellLearnLevels, this.spellInitialLevels, text, scanner, rand);
            //return setSpellExecute(trainState, new SpellBookLevel[]{SpellBookLevel.Venom, SpellBookLevel.Stomatitis}, Spell.Curse, text, scanner, rand);
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            return !self.getLearnedSpellLevel().containsKey(Spell.Stomatitis);
        }
    },

    On_StateChangeBook(SpellBookLevel.On_StateChange, 
                800,
                1,
                false,
                EnumSet.of(Shop.Normal),
                EnumSet.of(Mode.normal, Mode.hard),
                new LinkedHashMap<>(){{
                    put(Spell.On_StateChange, 1);
                }},
                new LinkedHashMap<>(){{
                    put(Spell.On_StateChange, 1);
                }}){
        @Override
        public void explain(boolean text){
            Print.println("呪文「On-ステイトチェンジ」が使えるようになる", Print.highSpeed, text);
            Print.println("相手と全ての状態変化を入れ替える", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            return spellBookExecute(trainState, this.spellBook, this.spellLearnLevels, this.spellInitialLevels, text, scanner, rand);
            //return setSpellExecute(trainState, new SpellBookLevel[]{SpellBookLevel.Venom, SpellBookLevel.Stomatitis}, Spell.Curse, text, scanner, rand);
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            return !self.getLearnedSpellLevel().containsKey(Spell.On_StateChange);
        }
    },

    On_SpellReflectBook(SpellBookLevel.On_SpellReflect, 
                1000,
                1,
                false,
                EnumSet.of(Shop.Normal),
                EnumSet.of(Mode.normal, Mode.hard),
                new LinkedHashMap<>(){{
                    put(Spell.On_SpellReflect, 1);
                }},
                new LinkedHashMap<>(){{
                    put(Spell.On_SpellReflect, 1);
                }}){
        @Override
        public void explain(boolean text){
            Print.println("呪文「On-スペルリフレクト」が使えるようになる", Print.highSpeed, text);
            Print.println("相手の打ってきた呪文を跳ね返す。先制で行動できる", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            return spellBookExecute(trainState, this.spellBook, this.spellLearnLevels, this.spellInitialLevels, text, scanner, rand);
            //return setSpellExecute(trainState, new SpellBookLevel[]{SpellBookLevel.Venom, SpellBookLevel.Stomatitis}, Spell.Curse, text, scanner, rand);
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            return !self.getLearnedSpellLevel().containsKey(Spell.On_SpellReflect);
        }
    },

    // TraumaBook(SpellBookLevel.Trauma.jName, 
    //             2000,
    //             1,
    //             Spell.Trauma.jName + "が使える<br>テンションを消費しに相手の攻撃力と素早さを下げる。",
    //             false,
    //             EnumSet.of(Shop.Shine),
    //             EnumSet.of(Mode.normal, Mode.hard)){
    //     @Override
    //     public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
    //         return spellBookExecute(trainState, SpellBookLevel.Trauma, new Spell[]{Spell.Trauma}, text, scanner, rand);
    //     }
    //     @Override
    //     public boolean useAble(TrainState trainState){
    //         Player self = trainState.getSelf();
    //         return self.getSpellBookLevel().get(SpellBookLevel.Trauma) < 1;
    //     }
    // },

    // ChaosBook(SpellBookLevel.Chaos.jName, 
    //             2000,
    //             1,
    //             Spell.Chaos.jName + "が使える<br>HPを半分消費し、相手に全ての状態異常を掛ける。",
    //             false,
    //             EnumSet.of(Shop.Shine),
    //             EnumSet.of(Mode.normal, Mode.hard)){
    //     @Override
    //     public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
    //         return spellBookExecute(trainState, SpellBookLevel.Chaos, new Spell[]{Spell.Chaos}, text, scanner, rand);
    //         //return setSpellExecute(trainState, new SpellBookLevel[]{SpellBookLevel.Venom, SpellBookLevel.Stomatitis}, Spell.Curse, text, scanner, rand);
    //     }
    //     @Override
    //     public boolean useAble(TrainState trainState){
    //         Player self = trainState.getSelf();
    //         return self.getSpellLevel().containsKey(Spell.Lag) &&
    //             self.getSpellLevel().containsKey(Spell.Hesitance) &&
    //             self.getSpellLevel().containsKey(Spell.Poison) &&
    //             self.getSpellLevel().containsKey(Spell.Stomatitis) &&
    //             self.getSpellBookLevel().get(SpellBookLevel.Chaos) < 1;
    //     }
    // },

    // On_StateChangeBook(SpellBookLevel.On_StateChange, 
    //             10,
    //             1,
    //             Spell.On_StateChange.jName + "が使える<br>お互いの状態変化を入れ替える。",
    //             false,
    //             EnumSet.of(Shop.Shine),
    //             EnumSet.of(Mode.normal, Mode.hard),
    //             new LinkedHashMap<>(){{
    //                 put(Spell.On_StateChange, 1);
    //             }}){
    //     @Override
    //     public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
    //         return spellBookExecute(trainState, this.spellBook, this.spellInitialLevels, text, scanner, rand);
    //     }
    //     @Override
    //     public boolean useAble(TrainState trainState){
    //         Player self = trainState.getSelf();
    //         return self.getSpellBookLevel().get(SpellBookLevel.On_StateChange) < 1;
    //     }
    // },

    // On_SpellReflectBook(SpellBookLevel.On_SpellReflect, 
    //             10,
    //             1,
    //             Spell.On_SpellReflect.jName + "が使える<br>相手の呪文を跳ね返す",
    //             false,
    //             EnumSet.of(Shop.Shine),
    //             EnumSet.of(Mode.normal, Mode.hard),
    //             new LinkedHashMap<>(){{
    //                 put(Spell.On_SpellReflect, 1);
    //             }}){
    //     @Override
    //     public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
    //         return spellBookExecute(trainState, this.spellBook, this.spellInitialLevels, text, scanner, rand);
    //     }
    //     @Override
    //     public boolean useAble(TrainState trainState){
    //         Player self = trainState.getSelf();
    //         return self.getSpellBookLevel().get(SpellBookLevel.On_SpellReflect) < 1;
    //     }
    // },

    // On_MoveCounterBook(SpellBookLevel.On_MoveCounter,
    //             2000,
    //             1,
    //             Spell.On_MoveCounter.jName + "が使える<br>相手と同じ行動を相手より後にする。",
    //             false,
    //             EnumSet.of(Shop.Shine),
    //             EnumSet.of(Mode.normal, Mode.hard),
    //             new LinkedHashMap<>(){{
    //                 put(Spell.On_MoveCounter, 1);
    //             }}){
    //     @Override
    //     public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
    //         return spellBookExecute(trainState, this.spellBook, this.spellInitialLevels, text, scanner, rand);
    //     }
    //     @Override
    //     public boolean useAble(TrainState trainState){
    //         Player self = trainState.getSelf();
    //         return self.getSpellBookLevel().get(SpellBookLevel.On_MoveCounter) < 1;
    //     }
    // },

    TensionFieldBook(SpellBookLevel.TensionField, 
                1200,
                1,
                false,
                EnumSet.of(Shop.Shine),
                EnumSet.of(Mode.normal, Mode.hard),
                new LinkedHashMap<>(){{
                    put(Spell.TensionField, 1);
                }},
                new LinkedHashMap<>(){{
                    put(Spell.TensionField, 3);
                }}){
        @Override
        public void explain(boolean text){
            Print.println("呪文「テンションフィールド」が使えるようになる", Print.highSpeed, text);
            Print.println("防御しつつ、お互いのテンションがターンの終了時に増えるフィールドを貼る", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            return spellBookExecute(trainState, this.spellBook, this.spellLearnLevels, this.spellInitialLevels, text, scanner, rand);
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            return !self.getLearnedSpellLevel().containsKey(Spell.TensionField);
        }
    },

    SpecialFieldBook(SpellBookLevel.SpecialField, 
                1000,
                1,
                false,
                EnumSet.of(Shop.Shine),
                EnumSet.of(Mode.normal, Mode.hard),
                new LinkedHashMap<>(){{
                    put(Spell.SpecialField, 1);
                }},
                new LinkedHashMap<>(){{
                    put(Spell.SpecialField, 3);
                }}){
        @Override
        public void explain(boolean text){
            Print.println("呪文「スペシャルフィールド」が使えるようになる", Print.highSpeed, text);
            Print.println("防御しつつ、お互いの通常行動が必殺技になるフィールドを貼る", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            return spellBookExecute(trainState, this.spellBook, this.spellLearnLevels, this.spellInitialLevels, text, scanner, rand);
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            return !self.getLearnedSpellLevel().containsKey(Spell.SpecialField);
        }
    },

    // PassionFieldBook(SpellBookLevel.PassionField.jName, 
    //             2000,
    //             1,
    //             Spell.PassionField.jName + "が使える<br>お互いに連続で同じ行動ができるようになる。",
    //             false,
    //             EnumSet.of(Shop.Dark),
    //             EnumSet.of(Mode.normal, Mode.hard)){
    //     @Override
    //     public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
    //         return spellBookExecute(trainState, SpellBookLevel.PassionField, new Spell[]{Spell.PassionField}, text, scanner, rand);
    //     }
    //     @Override
    //     public boolean useAble(TrainState trainState){
    //         Player self = trainState.getSelf();
    //         return self.getSpellBookLevel().get(SpellBookLevel.PassionField) < 1;
    //     }
    // },

    ReverseFieldBook(SpellBookLevel.ReverseField, 
                1200,
                1,
                false,
                EnumSet.of(Shop.Shine),
                EnumSet.of(Mode.normal, Mode.hard),
                new LinkedHashMap<>(){{
                    put(Spell.ReverseField, 1);
                }},
                new LinkedHashMap<>(){{
                    put(Spell.ReverseField, 3);
                }}){
        @Override
        public void explain(boolean text){
            Print.println("呪文「リバースフィールド」が使えるようになる", Print.highSpeed, text);
            Print.println("防御しつつ、お互いの基礎素早さが逆転するフィールドを貼る", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            return spellBookExecute(trainState, this.spellBook, this.spellLearnLevels, this.spellInitialLevels, text, scanner, rand);
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            return !self.getLearnedSpellLevel().containsKey(Spell.ReverseField);
        }
    },

    RegenFieldBook(SpellBookLevel.RegenField, 
                1200,
                1,
                false,
                EnumSet.of(Shop.Shine),
                EnumSet.of(Mode.normal, Mode.hard),
                new LinkedHashMap<>(){{
                    put(Spell.RegenField, 1);
                }},
                new LinkedHashMap<>(){{
                    put(Spell.RegenField, 3);
                }}){
        @Override
        public void explain(boolean text){
            Print.println("呪文「リジェネフィールド」が使えるようになる", Print.highSpeed, text);
            Print.println("防御しつつ、お互い毎ターン回復するフィールドを貼る", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            return spellBookExecute(trainState, this.spellBook, this.spellLearnLevels, this.spellInitialLevels, text, scanner, rand);
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            return !self.getLearnedSpellLevel().containsKey(Spell.RegenField);
        }
    },

    /*On_StateChange("ステイトチェンジの魔道書", 
                1000,
                Spell.On_StateChange.jName + "が使える"){
        @Override
        public void execute(Player self, boolean text, Scanner scanner){
            Map<Spell, Integer> spellLevel = self.getSpellLevel();
            Map<SpellBookLevel, Integer> spellBookLevel = self.getSpellBookLevel();

            if(spellBookLevel.containsKey(SpellBookLevel.Cure)){
                spellBookLevel.replace(SpellBookLevel.Cure, spellBookLevel.get(SpellBookLevel.Cure) + 1);
            }else{
                spellBookLevel.put(SpellBookLevel.Cure, 1);
            }

            if(spellLevel.containsKey(Spell.Cure)){
                if(spellLevel.get(Spell.Cure) < Spell.maxLevel){
                    spellLevel.replace(Spell.Cure, spellLevel.get(Spell.Cure) + 1);
                }
            }else{
                spellLevel.put(Spell.Cure, 1);
                Print.println("スロットを変更しますか<br>1:はい" + Print.space(2, text) + "2:いいえ", Print.highSpeed, text);
                if(Print.input(scanner, Print.lowSpeed, text) == 1){
                    self.setSpellSlot(InputAction.changeSpell(self, text, scanner).getSpellSlot());
                }
            }

            self.setSpellBookLevel(spellBookLevel);
            self.setSpellLevel(spellLevel);
        }
        @Override
        public boolean useAble(Player self){
            return true;
        }
    },*/

    labHP("[肉体改造ラボ]" + Print.space(2, true) + "ラボカード", 
            3500, 
            1, 
            false, 
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard)){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println("全ての訓練で HPの消費を 0 にする「" + this.jName + "」を手札に加える", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            trainState.getHands().add(new CardWithParams(-1, TrainEvent.labHP, new ArrayList<>(), true));
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            return !trainState.getSelf().getNoCostStatus().contains(TrainEvent.labHP.noCostStatus) && !CardWithParams.takeCard(trainState.getHands()).contains(TrainEvent.labHP) && 
            !trainState.getSelf().getNoCostStatus().contains(TrainEvent.labCon.noCostStatus) && !CardWithParams.takeCard(trainState.getHands()).contains(TrainEvent.labCon) && 
            !trainState.getSelf().getNoCostStatus().contains(TrainEvent.labMoti.noCostStatus) && !CardWithParams.takeCard(trainState.getHands()).contains(TrainEvent.labMoti);
            // これはラインナップの方で使う
            // return trainState.getTrainLimitations().get(TrainLimitation.labHP).get(TrainLimitationCounter.flag) == 1;
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
        @Override
        public boolean getDoInflate(){
            return false;
        }
        @Override
        public boolean isAbleFree(){
            return false;
        }
        },

    labCon("[精神改造ラボ]" + Print.space(2, true) + "ラボカード", 
            2500, 
            1, 
            false, 
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard)){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println("全ての訓練で 集中力の消費を 0 にする「" + this.jName + "」を手札に加える", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            trainState.getHands().add(new CardWithParams(-1, TrainEvent.labCon, new ArrayList<>(), true));
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            return !trainState.getSelf().getNoCostStatus().contains(TrainEvent.labHP.noCostStatus) && !CardWithParams.takeCard(trainState.getHands()).contains(TrainEvent.labHP) && 
            !trainState.getSelf().getNoCostStatus().contains(TrainEvent.labCon.noCostStatus) && !CardWithParams.takeCard(trainState.getHands()).contains(TrainEvent.labCon) && 
            !trainState.getSelf().getNoCostStatus().contains(TrainEvent.labMoti.noCostStatus) && !CardWithParams.takeCard(trainState.getHands()).contains(TrainEvent.labMoti);
            // これはラインナップの方で使う
            // return trainState.getTrainLimitations().get(TrainLimitation.labHP).get(TrainLimitationCounter.flag) == 1;
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
        @Override
        public boolean getDoInflate(){
            return false;
        }
        @Override
        public boolean isAbleFree(){
            return false;
        }
        },

    labMoti("[感情改造ラボ]" + Print.space(2, true) + "ラボカード", 
            3000, 
            1, 
            false, 
            EnumSet.of(Shop.Normal),
            EnumSet.of(Mode.easy, Mode.normal, Mode.hard)){
        @Override
        public String getJName(TrainState trainState){
            return this.jName;
        }
        @Override
        public void explain(boolean text){
            Print.println("全ての訓練で やる気の消費を 0 にする「" + this.jName + "」を手札に加える", Print.highSpeed, text);
        }
        @Override
        public TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand){
            trainState.getHands().add(new CardWithParams(-1, TrainEvent.labMoti, new ArrayList<>(), true));
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            return !trainState.getSelf().getNoCostStatus().contains(TrainEvent.labHP.noCostStatus) && !CardWithParams.takeCard(trainState.getHands()).contains(TrainEvent.labHP) && 
            !trainState.getSelf().getNoCostStatus().contains(TrainEvent.labCon.noCostStatus) && !CardWithParams.takeCard(trainState.getHands()).contains(TrainEvent.labCon) && 
            !trainState.getSelf().getNoCostStatus().contains(TrainEvent.labMoti.noCostStatus) && !CardWithParams.takeCard(trainState.getHands()).contains(TrainEvent.labMoti);
            // これはラインナップの方で使う
            // return trainState.getTrainLimitations().get(TrainLimitation.labHP).get(TrainLimitationCounter.flag) == 1;
        }
        @Override
        public int getCost(Player self) {
            return this.cost;
        }
        @Override
        public boolean getDoInflate(){
            return false;
        }
        @Override
        public boolean isAbleFree(){
            return false;
        }
    },
    ;
    //フィールド
    public final String jName;// 名前
    public final int cost;// 値段
    public final int setNum;// セット売りの数
    public final boolean someBuyable;// 複数買い可能かどうか
    public final EnumSet<Shop> shop;// 売られるショップの種類
    public final EnumSet<Mode> mode;// 売られる難易度
    public final SpellBookLevel spellBook;// 対応する呪文オーブ
    public final Map<Spell, Integer> spellLearnLevels;// 呪文を覚えられるレベル
    public final Map<Spell, Integer> spellInitialLevels;// 呪文を呪文オーブで覚えたときの初期レベル
    //通常アイテムコンストラクタ
    private ImmediateItem(String name, int cost, int setNum, boolean someBuyable, EnumSet<Shop> shop, EnumSet<Mode> mode){
        this(name, cost, setNum, someBuyable, shop, mode, null, null, null);
    }
    //呪文オーブコンストラクタ
    //spellLevelsはlinkedHashMapを使う
    private ImmediateItem(SpellBookLevel spellBookLevel, int cost, int setNum, boolean someBuyable, EnumSet<Shop> shop, EnumSet<Mode> mode, Map<Spell, Integer> spellLearnLevels, Map<Spell, Integer> spellInitialLevels){
        this(spellBookLevel.jName, cost, setNum, someBuyable, shop, mode, spellBookLevel, spellLearnLevels, spellInitialLevels);

    }
    //メインコンストラクタ
    private ImmediateItem(String name, int cost, int setNum, boolean someBuyable, EnumSet<Shop> shop, EnumSet<Mode> mode, SpellBookLevel spellBookLevel, Map<Spell, Integer> spellLearnLevels, Map<Spell, Integer> spellInitialLevels){
        this.jName = name;
        this.cost = cost;
        this.setNum = setNum;
        this.someBuyable = someBuyable;
        this.shop = shop;
        this.mode = mode;
        this.spellBook = spellBookLevel;
        this.spellLearnLevels = spellLearnLevels;
        this.spellInitialLevels = spellInitialLevels;
    }

    @Override
    public String getJName(TrainState trainState){
        return this.jName;
    }
    @Override
    public String getJName(){
        return this.jName;
    }
    @Override
    public int getCost(Player self){
        return this.cost;
    }
    @Override
    public boolean getDoInflate(){
        return true;
    }
    @Override
    public boolean isAbleFree(){
        return true;
    }
    @Override
    public int getSetNum(){
        return this.setNum;
    }
    @Override
    public boolean getSomeBuyAble(){
        return this.someBuyable;
    }
    //処理の抽象メソッド
    public abstract TrainState execute(TrainState trainState, boolean text, Scanner scanner, Random rand);

    //使用可能判定の抽象メソッド
    public abstract boolean useAble(TrainState trainState);

    // 制限付きを除いたアイテムの配列
    public static ImmediateItem[] shopValues(TrainState trainState){
        return Collections.unmodifiableList(new ArrayList<>(){{
            // this.add(Engine);
            // if(!trainState.isUsedShopFirstFree || trainState.isBossRewardShopFree()){
            //     this.add(HPMedicineDouble);
            //     this.add(ConMedicineDouble);
            //     this.add(MotivMedicineDouble);
            // }else{
                this.add(HPMedicine);
                this.add(ConMedicine);
                this.add(MotivMedicine);
                this.add(Reload);
            // }

            if(trainState.getTrainLimitations().get(TrainLimitation.fireSpell).get(TrainLimitationCounter.flag) == 1){
                this.add(FireBook);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.StrengthenFire).get(TrainLimitationCounter.flag) == 1){
                this.add(FireStrengthen);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.StrengthenFlame).get(TrainLimitationCounter.flag) == 1){
                this.add(FlameStrengthen);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.StrengthenExplosion).get(TrainLimitationCounter.flag) == 1){
                this.add(ExplosionStrengthen);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.windSpell).get(TrainLimitationCounter.flag) == 1){
                this.add(WindBook);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.StrengthenWind).get(TrainLimitationCounter.flag) == 1){
                this.add(WindStrengthen);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.StrengthenGust).get(TrainLimitationCounter.flag) == 1){
                this.add(GustStrengthen);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.StrengthenTornado).get(TrainLimitationCounter.flag) == 1){
                this.add(TornadoStrengthen);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.stoneSpell).get(TrainLimitationCounter.flag) == 1){
                this.add(StoneBook);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.StrengthenStone).get(TrainLimitationCounter.flag) == 1){
                this.add(StoneStrengthen);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.StrengthenRock).get(TrainLimitationCounter.flag) == 1){
                this.add(RockStrengthen);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.StrengthenLava).get(TrainLimitationCounter.flag) == 1){
                this.add(LavaStrengthen);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.healSpell).get(TrainLimitationCounter.flag) == 1){
                this.add(HealBook);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.aUpSpell).get(TrainLimitationCounter.flag) == 1){
                this.add(AUpBook);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.sUpSpell).get(TrainLimitationCounter.flag) == 1){
                this.add(SUpBook);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.dUpSpell).get(TrainLimitationCounter.flag) == 1){
                this.add(DUpBook);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.NervousSpell).get(TrainLimitationCounter.flag) == 1){
                this.add(NervousBook);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.lagSpell).get(TrainLimitationCounter.flag) == 1){
                this.add(LagBook);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.bondSpell).get(TrainLimitationCounter.flag) == 1){
                this.add(BondBook);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.poisonSpell).get(TrainLimitationCounter.flag) == 1){
                this.add(PoisonBook);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.stomatitisSpell).get(TrainLimitationCounter.flag) == 1){
                this.add(StomatitisBook);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.On_StateChangeSpell).get(TrainLimitationCounter.flag) == 1){
                this.add(On_StateChangeBook);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.On_SpellReflectSpell).get(TrainLimitationCounter.flag) == 1){
                this.add(On_SpellReflectBook);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.TensionFieldSpell).get(TrainLimitationCounter.flag) == 1){
                this.add(TensionFieldBook);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.SpecialFieldSpell).get(TrainLimitationCounter.flag) == 1){
                this.add(SpecialFieldBook);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.ReverseFieldSpell).get(TrainLimitationCounter.flag) == 1){
                this.add(ReverseFieldBook);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.RegenFieldSpell).get(TrainLimitationCounter.flag) == 1){
                this.add(RegenFieldBook);
            }
            
            if(trainState.getTrainLimitations().get(TrainLimitation.labHP).get(TrainLimitationCounter.flag) == 1){
                this.add(labHP);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.labCon).get(TrainLimitationCounter.flag) == 1){
                this.add(labCon);
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.labMoti).get(TrainLimitationCounter.flag) == 1){
                this.add(labMoti);
            }
            // if(trainState.getTrainLimitations().get(TrainLimitation.shineShop).get(TrainLimitationCounter.flag) == 1){
            //     // this.add(AUpBook);
            //     // this.add(SUpBook);
            //     this.add(OilBook);
            //     this.add(LagBook);
            //     this.add(HesitanceBook);
            //     this.add(PoisonBook);
            //     this.add(StomatitisBook);
            //     this.add(TensionFieldBook);
            //     this.add(SpecialFieldBook);
            //     //this.add(PassionFieldBook);
            //     this.add(TrickRoomBook);
            //     this.add(SuddenDeathBook);
            //     // this.add(On_StateChangeBook);
            //     // this.add(On_SpellReflectBook);
            // }
            // if(trainState.getTrainLimitations().get(TrainLimitation.fieldSpell)){
            // }
            // if(trainState.getTrainLimitations().get(TrainLimitation.onSpell)){
                // this.add(On_MoveCounterBook);
            // }
            // if(trainState.getTrainLimitations().get(TrainLimitation.advanceAbnormalSpell)){
            //     this.add(TraumaBook);
            //     this.add(ChaosBook);
            // }

        }}).toArray(new ImmediateItem[0]);
    }

    //アイテムの総数
    //行動用
    public static final int NUM = ImmediateItem.values().length;

    // 呪文オーブの呪文習得処理
    private static TrainState spellBookExecute(TrainState trainState, SpellBookLevel spellBook, Map<Spell, Integer> spellLearnLevels, Map<Spell, Integer> spellInitialLevels, boolean text, Scanner scanner, Random rand){
        Player self = trainState.getSelf();
        Map<Spell, Integer> spellLevel = self.getSpellLevel();
        Map<SpellBookLevel, Integer> spellBookLevels = self.getSpellBookLevel();
        int spellBookLevel = spellBookLevels.get(spellBook) + 1;

        spellBookLevels.replace(spellBook, spellBookLevel);

        //TODO mapで取得レベル持たせた方が良くね？
        for(Spell spell : spellLearnLevels.keySet()){
            if(spellLearnLevels.get(spell) <= spellBookLevel){
                int nowSpellLevel = spellLevel.get(spell);
                int addSpellLevel = (spellLearnLevels.get(spell) == spellBookLevel) ? spellInitialLevels.get(spell) : 1;
                int resultSpellLevel = nowSpellLevel + addSpellLevel > Spell.maxLevel ? Spell.maxLevel : nowSpellLevel + addSpellLevel;
                if(nowSpellLevel == Spell.maxLevel){
                    continue;
                }
                // Print.println(nowSpellLevel == 0 ? spell.jName + "を習得した" : spell.jName + "の扱いが上手くなった", true, Print.middleSpeed, text);
                Print.nextLine(scanner, text);
                spellLevel.replace(spell, resultSpellLevel);
                // if(nowSpellLevel == 0){
                //     Print.println("スロットを変更しますか<br>1:はい" + Print.space(2, text) + "2:いいえ", Print.highSpeed, text);
                //     if(trainState.getAuto() == Auto.select && Print.input(scanner, text) == 1){
                //         InputAction.changeSpell(self, text, scanner);
                //     }
                // }
            }
        }
        self.setSpellBookLevel(spellBookLevels);
        self.setSpellLevel(spellLevel);
        trainState.setSelf(self);
        return trainState;
    }

    public static void strengthenSpell(Player self, Spell beforeSpell, Spell afterSpell){
        self.getSpellLevel().replace(beforeSpell, 0);
        self.getSpellLevel().replace(afterSpell, 1);
        if(self.getSpellSlot().contains(beforeSpell)){
            int idx = self.getSpellSlot().indexOf(beforeSpell);
            self.getSpellSlot().remove(beforeSpell);
            self.getSpellSlot().add(idx, afterSpell);
        }
    }

    public static List<ImmediateItem> baseSpellItem = new ArrayList<>(){{
        add(FireBook);
        add(WindBook);
        add(StoneBook);
        add(HealBook);
        add(AUpBook);
        add(SUpBook);
        add(DUpBook);
        add(NervousBook);
        add(LagBook);
        add(BondBook);
        add(PoisonBook);
        add(StomatitisBook);
        add(On_StateChangeBook);
        add(On_SpellReflectBook);
        add(TensionFieldBook);
        add(SpecialFieldBook);
        add(ReverseFieldBook);
        add(RegenFieldBook);
    }};
}
