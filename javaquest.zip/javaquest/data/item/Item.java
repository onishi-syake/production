package data.item;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import character.Player;
import train.TrainState;
import train.TrainState.Mode;

public interface Item {
    public enum Shop {
        Dark("闇商人"),
        Shine("光商人"),
        Normal("ショップ"),
        ;
        public final String jName;
        private Shop(String name){
            this.jName = name;
        }
        public static final int NUM = values().length;
    }
    String getJName(TrainState trainState);// 名前（stateの状況によって変わる名前）
    String getJName();// 名前
    int getCost(Player self);// 値段
    boolean getDoInflate();// インフレするかどうか
    boolean isAbleFree();// 無料に出来るかどうか
    int getSetNum();// セット売りの数
    void explain(boolean text);// 説明
    boolean getSomeBuyAble();// 複数買い可能かどうか
    // 引数のショップのアイテムラインナップを返す
    public static List<Item> shopItemList(TrainState trainState, Shop shop){
        return Collections.unmodifiableList(new ArrayList<>(){{
            for(ImmediateItem key : ImmediateItem.shopValues(trainState)){
                for(Shop sKey : key.shop){
                    if(sKey == shop){
                        if(key.useAble(trainState)){
                            this.add(key);
                        }
                    }
                }
            }
            for(DisposableItem key : DisposableItem.shopValues(trainState)){
                for(Shop sKey : key.shop){
                    if(sKey == shop){
                        this.add(key);
                    }
                }
            }
            for(BattleItem key : BattleItem.shopValues(trainState)){
                for(Shop sKey : key.shop){
                    if(sKey == shop){
                        this.add(key);
                    }
                }
            }
        }});
    }
    // インフレ係数
    public static double inflationCoef(int turn){
        double coef = 1;
        coef *= Math.pow(2, (int)((turn - 1) / 4));
        if(((turn - 1) % 4) >= 2){
            coef *= 1.5;
        }
        return coef;
    }
    // ショップの種類の数
    public static int shopNUM(TrainState trainState, Shop shop, Mode mode){
        return Item.shopItemList(trainState, shop).size();
    }
}
