package data.item;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumSet;
import java.util.Random;
import java.util.Scanner;

import battle.CalculateDamage;
import battle.State;
import battle.InputAction.Auto;
import battle.state_change.ChangeAbnormalState;
import battle.state_change.ChangeBattleStatus;
import battle.state_change.ChangeAbnormalState.AbnormalState;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import battle.state_change.ChangeBattleStatus.StateChangeStatus;
import character.Character;
import character.Player;
import character.Character.MainStatus;
import character.Player.TrainStatus;
import game.LocationCategory;
import limitation.TrainLimitation;
import limitation.TrainLimitation.TrainLimitationCounter;
import log.BattleTemporaryLog;
import text.Print;
import train.Train;
import train.TrainState;
import train.TrainState.Mode;

public enum BattleItem implements Item{
    Tairyokuzai("HP回復",
                3,
                1,
                // "自分のHPを全回復する。HPが半分以下の時にしか使えない",
                "自分のHPを全回復する。HPが1/3以下になると自動発動",
                true,
                EnumSet.of(Shop.Normal),
                EnumSet.of(Mode.normal, Mode.hard)){
        @Override
        public void battleExecute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, Random rand, boolean text, Scanner scanner){
            Character target = state.getPlayer(!target_is_player1);
            CalculateDamage.changeParameter(target, MainStatus.hp, -target.getMainStatus().get(MainStatus.maxHp), text);
            state.setPlayer(target, !target_is_player1);
        }
        @Override
        public boolean battleUseAble(Character actor){
            // return (actor.getMainStatus().get(MainStatus.maxHp) / 2) >= actor.getMainStatus().get(MainStatus.hp);
            return false;
        }
        @Override
        public boolean passiveUseAble(Character actor){
            if(!actor.getIsDamaged()){
                return false;
            }
            return (actor.getMainStatus().get(MainStatus.maxHp) / 3) >= actor.getMainStatus().get(MainStatus.hp);
        }
        int healRate = 100;
        @Override
        public TrainState trainExecute(TrainState trainState, Random rand, boolean text){
            CalculateDamage.trainDamage(trainState.getSelf(), TrainStatus.maxHp, -healRate, text);
            return trainState;
        }
    },
    Maryokuzai( "MP回復",
                3,
                1,
                "MPを全回復する。MPが1/3以下になると自動発動",
                true,
                EnumSet.of(Shop.Normal),
                EnumSet.of(Mode.normal, Mode.hard)){
        @Override
        public void battleExecute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, Random rand, boolean text, Scanner scanner){
            Character actor = state.getPlayer(actor_is_player1);
            Character target = state.getPlayer(!target_is_player1);
            // CalculateDamage.changeParameter(target, MainStatus.maxMp, -actor.getMainStatus().get(MainStatus.maxMp), text);
            CalculateDamage.changeParameter(target, MainStatus.mp, -actor.getMainStatus().get(MainStatus.maxMp), text);
            state.setPlayer(target, !target_is_player1);
        }
        @Override
        public boolean battleUseAble(Character actor){
            // return (actor.getMainStatus().get(MainStatus.maxMp) / 2) >= actor.getMainStatus().get(MainStatus.mp);
            return false;
        }
        @Override
        public boolean passiveUseAble(Character actor){
            return (actor.getMainStatus().get(MainStatus.maxMp) / 3) >= actor.getMainStatus().get(MainStatus.mp);
        }
        int healRate = 100;
        @Override
        public TrainState trainExecute(TrainState trainState, Random rand, boolean text){
            CalculateDamage.trainDamage(trainState.getSelf(), TrainStatus.maxGasoline, -healRate, text);
            return trainState;
        }
    },
    Zoukyouzai("超強化",
                3,
                1,
               "自分の攻撃力、素早さを増加させる。HPが1/3以下になると自動発動",
               true,
               EnumSet.of(Shop.Normal),
               EnumSet.of(Mode.normal, Mode.hard)){
        @Override
        public void battleExecute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, Random rand, boolean text, Scanner scanner){
            ChangeBattleStatus.onset(state, !target_is_player1, StateChangeStatus.A, 50, 5, text, scanner);
            ChangeBattleStatus.onset(state, !target_is_player1, StateChangeStatus.D, 50, 5, text, scanner);
            ChangeBattleStatus.onset(state, !target_is_player1, StateChangeStatus.S, 50, 5, text, scanner);
        }
        @Override
        public boolean battleUseAble(Character actor){
            // return (actor.getMainStatus().get(MainStatus.maxHp) / 2) >= actor.getMainStatus().get(MainStatus.hp);
            return false;
        }
        @Override
        public boolean passiveUseAble(Character actor){
            if(!actor.getIsDamaged()){
                return false;
            }
            return (actor.getMainStatus().get(MainStatus.maxHp) / 3) >= actor.getMainStatus().get(MainStatus.hp);
        }
        int healRate = 100;
        int growRate = 10;
        @Override
        public TrainState trainExecute(TrainState trainState, Random rand, boolean text){
            CalculateDamage.trainProgress(trainState.getSelf(), TrainStatus.maxMotivation, false, growRate, text);
            CalculateDamage.trainDamage(trainState.getSelf(), TrainStatus.maxMotivation, -healRate, text);
            Train.choiceUpdate(trainState, text, rand);
            return trainState;
        }
    },
    Bannnouyaku("状態異常反射",
                3,
                1,
                "相手に掛けられた状態異常を全て相手に跳ね返す。状態異常になると自動発動",
                // "オイル状態を含む自分の悪い状態異常を全て治し、治した状態の耐性を得る。オイル以外の状態異常になると自動発動",
                true,
                EnumSet.of(Shop.Normal),
                EnumSet.of(Mode.normal, Mode.hard)){
        @Override
        public void battleExecute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, Random rand, boolean text, Scanner scanner){
            Character target = state.getPlayer(!target_is_player1);
            for(AbnormalState aState : AbnormalState.values()){
                if(!aState.good && aState != AbnormalState.Nervous){
                    if(ChangeAbnormalState.cure(target, aState, text)){
                        // ChangeAbnormalState.setResistance(target, aState, 1, text);
                        ChangeAbnormalState.onset(state, target_is_player1, aState, 0, log, scanner, text, rand);
                    }
                }
            }
            state.setPlayer(target, !target_is_player1);
        }
        @Override
        public boolean battleUseAble(Character actor){
            // return true;//(actor.getMainStatus().get(MainStatus.maxHp) / 2) >= actor.getMainStatus().get(MainStatus.hp);
            return false;
        }
        @Override
        public boolean passiveUseAble(Character actor){
            return ChangeAbnormalState.checkAnyAbnormal(actor, true);
        }
        int healRate = 100;
        @Override
        public TrainState trainExecute(TrainState trainState, Random rand, boolean text){
            CalculateDamage.trainDamage(trainState.getSelf(), TrainStatus.maxConcentration, -healRate, text);
            return trainState;
        }
    },
    Elixir("エリクサー",
                10,
                1,
                "HPを全回復し、MPを全回復し、攻撃力と素早さを増加させ、状態異常を全て解除する。HPが1/5以下になると自動発動",
                false,
                EnumSet.of(Shop.Normal),
                EnumSet.of(Mode.normal, Mode.hard)){
        @Override
        public void battleExecute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, Random rand, boolean text, Scanner scanner){
            for(BattleItem item : new BattleItem[]{BattleItem.Tairyokuzai, BattleItem.Maryokuzai, BattleItem.Bannnouyaku, BattleItem.Zoukyouzai}){
                item.battleExecute(state, actor_is_player1, target_is_player1, log, rand, text, scanner);
            }
        }
        @Override
        public boolean battleUseAble(Character actor){
            // return (actor.getMainStatus().get(MainStatus.maxHp) / 4) >= actor.getMainStatus().get(MainStatus.hp);
            return false;
        }
        @Override
        public boolean passiveUseAble(Character actor){
            if(!actor.getIsDamaged()){
                return false;
            }
            return (actor.getMainStatus().get(MainStatus.maxHp) / 5) >= actor.getMainStatus().get(MainStatus.hp);
        }
        int elixirTurn = 1;
        @Override
        public TrainState trainExecute(TrainState trainState, Random rand, boolean text){
            Player self = trainState.getSelf();
            self.setElixirTurn(self.getElixirTurn() + elixirTurn);
            trainState.setSelf(self);
            return trainState;
        }
    },

    None("なし",
                0,
                0,
                "",
                false,
                EnumSet.noneOf(Shop.class),
                EnumSet.of(Mode.easy, Mode.normal, Mode.hard)){
        @Override
        public void battleExecute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, Random rand, boolean text, Scanner scanner){
        }
        @Override
        public boolean battleUseAble(Character actor){
            return false;
        }
        @Override
        public boolean passiveUseAble(Character actor){
            return false;
        }
        @Override
        public TrainState trainExecute(TrainState trainState, Random rand, boolean text){
            return trainState;
        }
    },
    ;

    //フィールド
    public final String jName;// 名前
    public final int cost;// 値段
    public final int setNum;// セット売りする数
    public final String battleExplain;// 戦闘用の説明
    public final boolean someBuyable;// 複数個購入
    public final EnumSet<Shop> shop;// 売っている店
    public final EnumSet<Mode> mode;// 販売される難易度
    //コンストラクタ
    private BattleItem(String name, int cost, int setNum, String battleExplain, boolean someBuyable, EnumSet<Shop> shop, EnumSet<Mode> mode){
        this.jName = name;
        this.cost = cost;
        this.setNum = setNum;
        this.battleExplain = battleExplain;
        this.someBuyable = someBuyable;
        this.shop = shop;
        this.mode = mode;
    }

    @Override
    public String getJName(TrainState trainState){
        return this.jName;
    }    
    @Override
    public String getJName(){
        return this.jName;
    }
    @Override
    public int getCost(Player self){
        return this.cost;
    }
    @Override
    public int getSetNum(){
        return this.setNum;
    }
    @Override
    public void explain(boolean text){
        Print.println(this.battleExplain, Print.highSpeed, text);
    }
    @Override
    public boolean getDoInflate(){
        return true;
    }
    @Override
    public boolean isAbleFree(){
        return true;
    }
    @Override
    public boolean getSomeBuyAble(){
        return this.someBuyable;
    }
    //戦闘時処理の抽象メソッド
    public abstract void battleExecute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, Random rand, boolean text, Scanner scanner);
    
    //鍛錬処理の抽象メソッド
    public abstract TrainState trainExecute(TrainState trainState, Random rand, boolean text);

    //使用可能判定の抽象メソッド
    public abstract boolean battleUseAble(Character actor);

    // 即時使用判定の抽象メソッド
    public abstract boolean passiveUseAble(Character actor);

    // 即時使用アイテムの使用
    public static void usePassive(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, Random rand, boolean text, Scanner scanner){
        Character actor = state.getPlayer(actor_is_player1);
        if(actor.passiveItem.passiveUseAble(actor) && actor.getStateAction().get(ActionState.UseItem).get(ActionStateCounter.flag) == 0){
            Print.println("", Print.middleSpeed, text);
            Print.println(actor.getJName() + "の" + actor.passiveItem.jName + "発動！", true, Print.middleSpeed, text);
            actor.passiveItem.battleExecute(state, actor_is_player1, target_is_player1, log, rand, text, scanner);
            actor.getStateAction().get(ActionState.UseItem).replace(ActionStateCounter.flag, 1);
        }
    }

    //所持アイテム数を取得
    public static int getItemNum(Character self, boolean skipNone){
        int num = 0;
        for(BattleItem item: BattleItem.values()){
            if(item == BattleItem.None && skipNone){
                continue;
            }
            num += self.getItemList().get(item);
        }
        return num;
    }

    //余剰アイテムを捨てる
    public static void dromItem(Player self, Auto auto, Random rand, Scanner scanner, boolean text){
        if(Auto.select == auto){
            choiceDropItem(self, scanner, text);
        }else{
            randomDropItem(self, rand);
        }
    }

    //余剰アイテムをランダムに捨てる
    public static void randomDropItem(Character self, Random rand){
        if(BattleItem.NUM == 0){
            return;
        }
        BattleItem dropItem;
        if(self.getItemSlotNum() < BattleItem.getItemNum(self, false)){
            self.getItemList().replace(BattleItem.None, BattleItem.getItemNum(self, true) >= self.getItemSlotNum() ? 0 : self.getItemSlotNum() - BattleItem.getItemNum(self, true));
        }
        while(self.getItemSlotNum() < BattleItem.getItemNum(self, true)){
            dropItem = BattleItem.values()[rand.nextInt(BattleItem.NUM)];
            if(self.getItemList().get(dropItem) > 0){
                self.getItemList().replace(dropItem, self.getItemList().get(dropItem) - 1);
            }
        }
    }

    //余剰アイテムを選択して捨てる(現状人間専用)
    public static void choiceDropItem(Player self, Scanner scanner, boolean text){
        int index = -1;
        if(self.getItemSlotNum() < BattleItem.getItemNum(self, false)){
            self.getItemList().replace(BattleItem.None, BattleItem.getItemNum(self, true) >= self.getItemSlotNum() ? 0 : self.getItemSlotNum() - BattleItem.getItemNum(self, true));
        }
        while(self.getItemSlotNum() < BattleItem.getItemNum(self, true)){
            Print.println("", Print.middleSpeed, text);
            Print.print("戦闘用アイテムが溢れた。捨てるアイテムを選んでください", Print.middleSpeed, text);
            Print.println("  所持数： " + BattleItem.getItemNum(self, true) + " 所持可能枠： " + self.getItemSlotNum(), Print.middleSpeed, text);
            Print.println("", Print.middleSpeed, text);
            Print.displayBattleItem(self, text);
            while(index <= 0 || BattleItem.getItemNum(self, true) < index){
                index = Print.input(scanner, text);
            }
            for(BattleItem key: self.getItemList().keySet()){
                index -= self.getItemList().get(key);
                if(index <= 0){
                    self.getItemList().replace(key, self.getItemList().get(key) - 1);
                    break;
                }
            }
        }
    }

    // 制限されていないアイテムの配列
    public static BattleItem[] shopValues(TrainState trainState){
        return Collections.unmodifiableList(new ArrayList<>(){{
            // if(trainState.getTrainLimitations().get(TrainLimitation.Tairyokuzai).get(TrainLimitationCounter.flag) == 1){
            //     this.add(Tairyokuzai);
            // }
            // if(trainState.getTrainLimitations().get(TrainLimitation.Maryokuzai).get(TrainLimitationCounter.flag) == 1){
            //     this.add(Maryokuzai);
            // }
            // if(trainState.getTrainLimitations().get(TrainLimitation.Bannnouyaku).get(TrainLimitationCounter.flag) == 1){
            //     this.add(Bannnouyaku);
            // }
            // if(trainState.getTrainLimitations().get(TrainLimitation.Zoukyouzai).get(TrainLimitationCounter.flag) == 1){
            //     this.add(Zoukyouzai);
            // }
            // if(trainState.getTrainLimitations().get(TrainLimitation.Elixir).get(TrainLimitationCounter.flag) == 1){
            //     this.add(Elixir);
            // }
        }}).toArray(new BattleItem[0]);
    }

    //アイテムの総数
    //行動用
    public static final int NUM = BattleItem.values().length;


    public static void setPassiveItem(TrainState[] trainStateNB, Scanner scanner, boolean text, Random rand){
        int input;
        Player player = trainStateNB[0].getSelf();
        BattleItem item;
        // while(input < 1 || BattleItem.NUM - 1 < input){
        //     Print.println("変更する戦闘スキルを選んでください。(-番号入力で詳細)<br>スキルは戦闘中に発動条件を満たしたとき、1度だけ発動します。<br>", Print.highSpeed, text);
        //     for(BattleItem bItem : BattleItem.values()){
        //         if(bItem == None){
        //             continue;
        //         }
        //         Print.println((bItem.ordinal() + 1) + " : " + bItem.jName, Print.highSpeed, text);
        //     }
        //     input = Train.makeAction(trainStateNB[0], trainStateNB[1], scanner, text, rand);
        //     if(input <= -BattleItem.NUM || BattleItem.NUM - 1 < input){
        //         Print.println("正しく入力してください", Print.highSpeed, text);
        //         Print.nextLine(scanner, text);
        //     }
        //     if(-BattleItem.NUM < input && input < 0){
        //         Print.println(BattleItem.values()[-input - 1].jName + "<br>" + BattleItem.values()[-input - 1].battleExplain, Print.highSpeed, text);
        //         Print.nextLine(scanner, text);
        //     }
        // }
        // item = BattleItem.values()[input - 1];
        // player.passiveItem = item;
        // Print.println(item.jName + "に変更しました", Print.highSpeed, text);
        // Print.nextLine(scanner, text);

        final int CHOICE_PASSIVE_ITEM = 1;
        switch(trainStateNB[0].getSavedLocation(LocationCategory.setPassiveItem)){
            case LocationCategory.NO_CHOICE:
                Print.println("変更する戦闘スキルを選んでください", Print.highSpeed, text);
                Print.println("スキルは戦闘中に発動条件を満たしたとき、 1 度だけ発動します", Print.middleSpeed, text);
                Print.println("", Print.middleSpeed, text);
                for(BattleItem bItem : BattleItem.values()){
                    if(bItem == None){
                        continue;
                    }
                    Print.println((bItem.ordinal() + 1) + " : " + bItem.jName, Print.highSpeed, text);
                }
                trainStateNB[0].saveLocation(LocationCategory.setPassiveItem, CHOICE_PASSIVE_ITEM);
                return;
            case CHOICE_PASSIVE_ITEM:
                input = Train.makeAction(trainStateNB[0], trainStateNB[1], scanner, text, rand);
                if(input <= -BattleItem.NUM || BattleItem.NUM - 1 < input){
                    Print.println("正しく入力してください", Print.highSpeed, text);
                    Print.nextLine(scanner, text);
                    trainStateNB[0].saveLocation(LocationCategory.setPassiveItem, LocationCategory.NO_CHOICE);
                    setPassiveItem(trainStateNB, scanner, text, rand);
                    return;
                }
                if(-BattleItem.NUM < input && input < 0){
                    Print.println(BattleItem.values()[-input - 1].jName, Print.highSpeed, text);
                    Print.println(BattleItem.values()[-input - 1].battleExplain, Print.highSpeed, text);
                    Print.nextLine(scanner, text);
                    trainStateNB[0].saveLocation(LocationCategory.setPassiveItem, LocationCategory.NO_CHOICE);
                    setPassiveItem(trainStateNB, scanner, text, rand);
                    return;
                }
                if(1 <= input && input <= BattleItem.NUM - 1){
                    item = BattleItem.values()[input - 1];
                    player.passiveItem = item;
                    Print.println(item.jName + "に変更した", Print.highSpeed, text);
                    Print.nextLine(scanner, text);
                    trainStateNB[0].saveLocation(LocationCategory.setPassiveItem, LocationCategory.FINISH);
                    return;
                }
        }
    }
}
