package data.item;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumSet;
import java.util.Random;

import battle.CalculateDamage;
import character.Player;
import character.Player.TrainStatus;
import data.card.CardWithParams;
import data.card.ItemCard;
import limitation.TrainLimitation;
import text.Print;
import train.Train;
import train.TrainState;
import train.TrainState.Mode;

//itemをbattleItemに変更する必要がある
public enum DisposableItem implements Item{
    // HPMedicine("HP剤",
    //         2,
    //         1,
    //         "自分の" + TrainStatus.hp.jName + "を全回復する。",
    //         true,
    //         EnumSet.of(Shop.Normal),
    //         EnumSet.of(Mode.easy, Mode.normal, Mode.hard)){
    //         int healRate = 50;
    //     @Override
    //     public TrainState execute(TrainState trainState, Random rand, boolean text){
    //         trainState.getHands().add(new CardWithParams(-1, ItemCard.HPMedicine, null));
    //         return trainState;
    //     }
    //     @Override
    //     public boolean useAble(TrainState trainState){
    //         return true;
    //     }
    //     @Override
    //     public boolean aiUseAble(TrainState trainState){
    //         return trainState.getSelf().getTrainStatus().get(TrainStatus.hp) <= trainState.getSelf().getTrainStatus().get(TrainStatus.maxHp) * (1-healRate/100.0);
    //     }
    // },

    // Mamusidrink("まむしドリンク",
    //             200,
    //             1,
    //             "自分の" + TrainStatus.motivation.jName + "を全回復する。",
    //             true,
    //             EnumSet.of(Shop.Normal),
    //             EnumSet.of(Mode.normal, Mode.hard)){
    //             int healRate = 100;
    //     @Override
    //     public TrainState execute(TrainState trainState, Random rand, boolean text){
    //         CalculateDamage.trainDamage(trainState.getSelf(), TrainStatus.maxMotivation, -healRate, text);
    //         return trainState;
    //     }
    //     @Override
    //     public boolean useAble(TrainState trainState){
    //         return true;
    //     }
    //     @Override
    //     public boolean aiUseAble(TrainState trainState){
    //         return trainState.getSelf().getTrainStatus().get(TrainStatus.motivation) <= trainState.getSelf().getTrainStatus().get(TrainStatus.maxMotivation) * (1-healRate/100.0);
    //     }
    // },

    // ElecMedicine("エレキ剤",
    //         3,
    //         1,
    //         "自分の" + TrainStatus.motivation.jName + "を全回復する。",
    //         true,
    //         EnumSet.of(Shop.Normal),
    //         EnumSet.of(Mode.normal, Mode.hard)){
    //         int healRate = 50;
    //     @Override
    //     public TrainState execute(TrainState trainState, Random rand, boolean text){
    //         trainState.getHands().add(new CardWithParams(-1, ItemCard.ConMedicine, null));
    //         // Train.menusNumUpdate(trainState, rand);TODO メニュー数を増やして選択肢の数も増やす
    //         return trainState;
    //     }
    //     @Override
    //     public boolean useAble(TrainState trainState){
    //         return true;
    //     }
    //     @Override
    //     public boolean aiUseAble(TrainState trainState){
    //         return trainState.getSelf().getTrainStatus().get(TrainStatus.motivation) <= trainState.getSelf().getTrainStatus().get(TrainStatus.maxMotivation) * (1-healRate/100.0);
    //     }
    // },

    // MotivMedicine("オイル剤",
    //         2,
    //         1,
    //         "自分の" + TrainStatus.concentration.jName + "を全回復する。",
    //         true,
    //         EnumSet.of(Shop.Normal),
    //         EnumSet.of(Mode.normal, Mode.hard)){
    //         int healRate = 100;
    //     @Override
    //     public TrainState execute(TrainState trainState, Random rand, boolean text){
    //         trainState.getHands().add(new CardWithParams(-1, ItemCard.MotivMedicine, null));
    //         return trainState;
    //     }
    //     @Override
    //     public boolean useAble(TrainState trainState){
    //         return true;
    //     }
    //     @Override
    //     public boolean aiUseAble(TrainState trainState){
    //         return trainState.getSelf().getTrainStatus().get(TrainStatus.concentration) <= trainState.getSelf().getTrainStatus().get(TrainStatus.maxConcentration) * (1-healRate/100.0);
    //     }
    // },
    // GoodYakusou("特やくそう",
    //         300,
    //         3,
    //         "自分の" + TrainStatus.hp.jName + "を全回復する。",
    //         false,
    //         EnumSet.of(Shop.Shine),
    //         EnumSet.of(Mode.normal, Mode.hard)){
    //         int healRate = 100;
    //     @Override
    //     public TrainState execute(TrainState trainState, Random rand, boolean text){
    //         CalculateDamage.trainDamage(trainState.getSelf(), TrainStatus.maxHp, -healRate, text);
    //         return trainState;
    //     }
    //     @Override
    //     public boolean useAble(TrainState trainState){
    //         return true;
    //     }
    //     @Override
    //     public boolean aiUseAble(TrainState trainState){
    //         return trainState.getSelf().getTrainStatus().get(TrainStatus.hp) <= trainState.getSelf().getTrainStatus().get(TrainStatus.maxHp) * (1-0.5);
    //     }
    // },

    // GoodMamusidrink("ヤマタノオロチ",
    //             200,
    //             3,
    //             "自分の" + TrainStatus.motivation.jName + "を全回復する。",
    //             false,
    //             EnumSet.of(Shop.Shine),
    //             EnumSet.of(Mode.normal, Mode.hard)){
    //             int healRate = 100;
    //     @Override
    //     public TrainState execute(TrainState trainState, Random rand, boolean text){
    //         CalculateDamage.trainDamage(trainState.getSelf(), TrainStatus.maxMotivation, -healRate, text);
    //         return trainState;
    //     }
    //     @Override
    //     public boolean useAble(TrainState trainState){
    //         return true;
    //     }
    //     @Override
    //     public boolean aiUseAble(TrainState trainState){
    //         return trainState.getSelf().getTrainStatus().get(TrainStatus.motivation) <= trainState.getSelf().getTrainStatus().get(TrainStatus.maxMotivation) * (1-0.5);
    //     }
    // },

    // GoodKaruisi("スーパーアクティブサプリ",
    //         200,
    //         3,
    //         "自分の" + TrainStatus.activity.jName + "を全回復する。",
    //         false,
    //         EnumSet.of(Shop.Shine),
    //         EnumSet.of(Mode.normal, Mode.hard)){
    //         int healRate = 100;
    //     @Override
    //     public TrainState execute(TrainState trainState, Random rand, boolean text){
    //         CalculateDamage.trainDamage(trainState.getSelf(), TrainStatus.maxActivity, -healRate, text);
    //         // Train.menusNumUpdate(trainState, rand);TODO メニュー数を増やして選択肢の数も増やす
    //         return trainState;
    //     }
    //     @Override
    //     public boolean useAble(TrainState trainState){
    //         return true;
    //     }
    //     @Override
    //     public boolean aiUseAble(TrainState trainState){
    //         return trainState.getSelf().getTrainStatus().get(TrainStatus.activity) <= trainState.getSelf().getTrainStatus().get(TrainStatus.maxActivity) * (1-0.5);
    //     }
    // },

    // GoodSoap("ヘルシーフルコース",
    //         200,
    //         3,
    //         "自分の" + TrainStatus.health.jName + "を全回復する。",
    //         false,
    //         EnumSet.of(Shop.Shine),
    //         EnumSet.of(Mode.normal, Mode.hard)){
    //         int healRate = 100;
    //     @Override
    //     public TrainState execute(TrainState trainState, Random rand, boolean text){
    //         CalculateDamage.trainDamage(trainState.getSelf(), TrainStatus.maxHealth, -healRate, text);
    //         return trainState;
    //     }
    //     @Override
    //     public boolean useAble(TrainState trainState){
    //         return true;
    //     }
    //     @Override
    //     public boolean aiUseAble(TrainState trainState){
    //         return trainState.getSelf().getTrainStatus().get(TrainStatus.health) <= trainState.getSelf().getTrainStatus().get(TrainStatus.maxHealth) * (1-0.5);
    //     }
    // },

    // Monster("モンスター",
    //         500,
    //         1,
    //         "このターンの間、HP、精神力、行動力、健康値が減らなくなる。ただし、ギルドが選択肢から選択肢から無くなる。勇者戦時は無効。",
    //         false,
    //         EnumSet.of(Shop.Shine),
    //         EnumSet.of(Mode.normal, Mode.hard)){
    //         int monsterTurn = 1;
    //     @Override
    //     public TrainState execute(TrainState trainState, Random rand, boolean text){
    //         Player self = trainState.getSelf();
    //         self.setMonsterTurn(self.getMonsterTurn() + monsterTurn);
    //         trainState.setSelf(self);
    //         Train.dropBattle(trainState, trainState.getTurn(), rand);
    //         return trainState;
    //     }
    //     @Override
    //     public boolean useAble(TrainState trainState){
    //         return true;
    //     }
    //     @Override
    //     public boolean aiUseAble(TrainState trainState){
    //         return true;
    //     }
    // },

    Tent("修理セット",
            10,
            1,
            "自分のHP・エレキ・オイルを全回復する",
            false,
            EnumSet.noneOf(Shop.class),
            EnumSet.of(Mode.normal, Mode.hard)){
            int healRate = 100;
        @Override
        public TrainState execute(TrainState trainState, Random rand, boolean text){
            CalculateDamage.trainDamage(trainState.getSelf(), TrainStatus.maxHp, -healRate, text);
            CalculateDamage.trainDamage(trainState.getSelf(), TrainStatus.maxMotivation, -healRate, text);
            CalculateDamage.trainDamage(trainState.getSelf(), TrainStatus.maxConcentration, -healRate, text);
            // CalculateDamage.trainDamage(trainState.getSelf(), TrainStatus.maxGasoline, -healRate, text);
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            return true;
        }
        @Override
        public boolean aiUseAble(TrainState trainState){
            return trainState.getSelf().getTrainStatus().get(TrainStatus.hp) <= trainState.getSelf().getTrainStatus().get(TrainStatus.maxHp) * (1-healRate/100.0) || 
                trainState.getSelf().getTrainStatus().get(TrainStatus.concentration) <= trainState.getSelf().getTrainStatus().get(TrainStatus.maxConcentration) * (1-healRate/100.0) || 
                trainState.getSelf().getTrainStatus().get(TrainStatus.motivation) <= trainState.getSelf().getTrainStatus().get(TrainStatus.maxMotivation) * (1-healRate/100.0);
                // ||  trainState.getSelf().getTrainStatus().get(TrainStatus.gasoline) <= trainState.getSelf().getTrainStatus().get(TrainStatus.maxGasoline) * (1-healRate/100.0);
        }
    },

    /*Monster("モンスター",
                100,
                1,
                "このターンの経験値効率を2倍にする。" + TrainStatus.hp.jName + "が5割未満の時のみ使用可能",
                true,
                EnumSet.of(Shop.Normal)){
        @Override
        public TrainState execute(TrainState trainState, Random rand, boolean text){
            Player self = trainState.getSelf();
            self.setUseMonster(true);
            trainState.setSelf(self);
            return trainState;
        }
        @Override
        public boolean useAble(TrainState trainState){
            Player self = trainState.getSelf();
            return (self.getTrainStatus().get(TrainStatus.maxHp) / 2) >= self.getTrainStatus().get(TrainStatus.hp);
        }
        @Override
        public boolean aiUseAble(TrainState trainState){
            Player self = trainState.getSelf();
            return (self.getTrainStatus().get(TrainStatus.maxHp) / 2) >= self.getTrainStatus().get(TrainStatus.hp);
        }
    },*/

    // Mezamasidokei("目覚まし時計",
    //             2,
    //             1,
    //             "このターンの行動を再度抽選",
    //             true,
    //             EnumSet.of(Shop.Normal),
    //             EnumSet.of(Mode.normal, Mode.hard)){
    //     @Override
    //     public TrainState execute(TrainState trainState, Random rand, boolean text){
    //         Train.choiceUpdate(trainState, text, rand);
    //         return trainState;
    //     }
    //     @Override
    //     public boolean useAble(TrainState trainState){
    //         return true;
    //     }
    //     @Override
    //     public boolean aiUseAble(TrainState trainState){
    //         return true;
    //     }
    // },
    ;   

    //フィールド
    public final String jName;// 名前
    public final int cost;// 値段
    public final int setNum;// セット売りの数
    public final String explain;// 説明
    public final boolean someBuyable;// 複数買い出来るか
    public final EnumSet<Shop> shop;// 売られるショップの種類
    public final EnumSet<Mode> mode;// 売られる難易度
    //コンストラクタ
    private DisposableItem(String name, int cost, int setNum, String explain, boolean someBuyable, EnumSet<Shop> shop, EnumSet<Mode> mode){
        this.jName = name;
        this.setNum = setNum;
        this.cost = cost;
        this.explain = explain;
        this.someBuyable = someBuyable;
        this.shop = shop;
        this.mode = mode;
    }

    @Override
    public String getJName(TrainState trainState){
        return this.jName;
    }
    @Override
    public String getJName(){
        return this.jName;
    }
    @Override
    public int getCost(Player self){
        return this.cost;
    }
    @Override
    public boolean getDoInflate(){
        return true;
    }
    @Override
    public boolean isAbleFree(){
        return true;
    }
    @Override
    public int getSetNum(){
        return this.setNum;
    }
    @Override
    public void explain(boolean text){
        Print.println(this.explain, Print.highSpeed, text);
    }
    @Override
    public boolean getSomeBuyAble(){
        return this.someBuyable;
    }
    //処理の抽象メソッド
    public abstract TrainState execute(TrainState trainState, Random rand, boolean text);

    //使用可能判定の抽象メソッド
    public abstract boolean useAble(TrainState trainState);

    // AIが利用可能かの抽象メソッド
    public abstract boolean aiUseAble(TrainState trainState);

    // 制限付きを除いたアイテムの総数
    public static DisposableItem[] shopValues(TrainState trainState){
        return Collections.unmodifiableList(new ArrayList<>(){{
            // this.add(HPMedicine);
            // if(trainState.getTrainLimitations().get(TrainLimitation.healItem)){
                // this.add(Mamusidrink);
                // this.add(ElecMedicine);
                // this.add(MotivMedicine);
            // }
            // if(TrainLimitation.wakeUp.useAble()){
            //     this.add(Mezamasidokei);
            // }
            // this.add(Tent);
            // if(trainState.getTrainLimitations().get(TrainLimitation.shineShop)){
                // this.add(GoodYakusou);
            // }
            // if(trainState.getTrainLimitations().get(TrainLimitation.GoodMamusidrink)){
            //     this.add(GoodMamusidrink);
            // }
            // if(trainState.getTrainLimitations().get(TrainLimitation.GoodKaruisi)){
            //     this.add(GoodKaruisi);
            // }
            // if(trainState.getTrainLimitations().get(TrainLimitation.HeavyRain)){
            //     this.add(GoodSoap);
            // }
            // if(trainState.getTrainLimitations().get(TrainLimitation.MonsterElixir)){
            //     this.add(Monster);
            // }
        }}).toArray(new DisposableItem[0]);
    }

    //アイテムの総数
    //行動用
    public static final int NUM = DisposableItem.values().length;
}
