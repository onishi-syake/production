package data.item;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import limitation.TrainLimitation;
import train.TrainState;

public enum ShineItemSet {
    // GoodYakusou3(
    //     "特薬草3個セット",
    //     new HashMap<Item, Integer>(){{
    //         put(DisposableItem.GoodYakusou, 3);
    //     }},
    //     DisposableItem.GoodYakusou.cost * 3,
    //     "HPを全回復できるアイテム<br>超特価で1個当たり薬草の半分の値段で買える!"
    // ),
    // GoodMamusidrink3(
    //     "ヤマタノオロチ3個セット",
    //     new HashMap<Item, Integer>(){{
    //         put(DisposableItem.GoodMamusidrink, 3);
    //     }},
    //     DisposableItem.GoodMamusidrink.cost * 3,
    //     "精神力を全回復できるアイテム<br>超特価で1個当たりまむしドリンクの半分の値段で買える!"
    // ),
    // GoodKaruisi3(
    //     "スーパーアクティブサプリ3個セット",
    //     new HashMap<Item, Integer>(){{
    //         put(DisposableItem.GoodKaruisi, 3);
    //     }},
    //     DisposableItem.GoodKaruisi.cost * 3,
    //     "行動力を全回復できるアイテム<br>超特価で1個当たりアクティブサプリの半分の値段で買える!"
    // ),
    // GoodSoap3(
    //     "ヘルシーフルコース3個セット",
    //     new HashMap<Item, Integer>(){{
    //         put(DisposableItem.GoodSoap, 3);
    //     }},
    //     DisposableItem.GoodSoap.cost * 3,
    //     "健康値を全回復できるアイテム<br>超特価で1個当たりヘルシーフードの半分の値段で買える!"
    // ),
    Elixir(
        "エリクサーセット",
        new HashMap<Item, Integer>(){{
            put(BattleItem.Elixir, 1);
        }},
        BattleItem.Elixir.cost * 1,
        " 3 ターンの間、戦闘以外のダメージを完全に無効にする究極のアイテム「モンスター」とHP剤・ガソリン/MP剤・エレキ/強化剤・オイル/万能薬の効果を併せ持った最強のアイテム「エリクサー」のセット"
    ),
    ;
    public final String name;// 名前
    public Map<Item, Integer> items;// 含まれるアイテムと個数
    public final int cost;// 値段
    public final String explain;// 説明
    private ShineItemSet(String name, Map<Item, Integer> items, int cost, String explain){
        this.name = name;
        this.items = items;
        this.cost = cost;
        this.explain = explain;
    }
    // 制限付きのアイテム配列
    public static ShineItemSet[] generalValues(TrainState trainState){
        return Collections.unmodifiableList(new ArrayList<>(){{
            // if(trainState.getTrainLimitations().get(TrainLimitation.shineShop)){
            //     this.add(GoodYakusou3);
            // // }
            // // if(trainState.getTrainLimitations().get(TrainLimitation.GoodMamusidrink)){
            //     this.add(GoodMamusidrink3);
            // // }
            // // if(trainState.getTrainLimitations().get(TrainLimitation.GoodKaruisi)){
            //     this.add(GoodKaruisi3);
            // // }
            // // if(trainState.getTrainLimitations().get(TrainLimitation.HeavyRain)){
            //     this.add(GoodSoap3);
            // }
            // if(trainState.getTrainLimitations().get(TrainLimitation.MonsterElixir)){
                // this.add(Elixir);
            // }
        }}).toArray(new ShineItemSet[0]);
    }
    // 制限付きの個数
    public static int generalNUM(TrainState trainState){
        return generalValues(trainState).length;
    }
}
