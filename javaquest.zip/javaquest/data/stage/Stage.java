package data.stage;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import battle.InputAction.Auto;
import character.Enemy;
import character.Skill;
import character.Character.Attribute;
import data.enemy.Boss;
// import data.enemy.Monster;
import data.item.BattleItem;

public enum Stage {
    // zeroInn("0番メンテ", Skill.zeroInn,
    // new Monster[]{
    //     Monster.SpdPoyoGood,
    //     Monster.SpdPoyoPerfect,
    // }),
    // guts("根性", Skill.guts,
    // new Monster[]{
    //     Monster.Special,
    //     Monster.Turtle,
    // }),
    // spellTaker("呪文テイカー", Skill.spellTaker,
    // new Monster[]{
    //     Monster.Gorst,
    //     Monster.Dark,
    // }),
    // trader("トレイダー", Skill.trader,
    // new ArrayList<Boss>(){{
    //     add(Boss.AbnormalMan);
    //     add(Boss.AbnormalMan);
    // }}, new HashMap<Boss, Boolean>(){{
    //     put(Boss.AbnormalMan, false);
    //     put(Boss.AbnormalMan, false);
    // }}),
    // longevity("長寿", Skill.longevity,
    // new ArrayList<Boss>(){{
    //     add(Boss.AbnormalMan);
    //     add(Boss.AbnormalMan);
    // }}, new HashMap<Boss, Boolean>(){{
    //     put(Boss.AbnormalMan, false);
    //     put(Boss.AbnormalMan, false);
    // }}),
    // KJA("KJA", Skill.KJA,
    // new Monster[]{
    //     Monster.GamblerGood,
    //     Monster.GamblerPerfect,
    // }),
    last("ラスト", null,
    new Boss[]{
        Boss.ApprenticeBrave,
        Boss.normalBrave,
        Boss.StrongestBrave,
        Boss.LegendaryBrave,
        Boss.DemiseBrave,
        Boss.FastidiousHero,
    }),
    ;
    public final String jName;// 名前
    public final Skill skill;// 固定スキル
    // public final Monster[] monsters;// 勇者（モンスターをそのまま）
    public final Boss[] bosses;// 勇者（ランダム勇者）
    // //ダンジョン用
    // private Stage(String jName, Skill skill, Monster[] monsters){
    //     this.jName = jName;
    //     this.skill = skill;
    //     this.monsters = monsters;
    //     this.bosses = null;
    // } 
    // ランダム勇者用
    private Stage(String jName, Skill skill, Boss[] bosses){
        this.jName = jName;
        this.skill = skill;
        // this.monsters = null;
        this.bosses = bosses;
    } 
    // 勇者をEnemyクラスのリストで出力
    public List<Enemy> getBosses(Auto auto, Random rand, BattleItem battleItem){
        List<Enemy> EnemiesList = new ArrayList<Enemy>();
        Attribute attribute;
        // if(this.monsters != null){
        //     for(Monster monster : this.monsters){
        //         EnemiesList.add(new Enemy(monster, auto));
        //     }
        // }else{
            for(Boss boss : this.bosses){
                if(boss == Boss.ApprenticeBrave){
                    attribute = Attribute.Null;
                }else if(boss == Boss.normalBrave){
                    attribute = Attribute.A;
                }else{
                    attribute = Attribute.values()[rand.nextInt(3)];
                }
                if(boss == Boss.ApprenticeBrave
                 || boss == Boss.LegendaryBrave
                //  || boss == Boss.DemiseBrave
                 || boss == Boss.FastidiousHero){
                    EnemiesList.add(new Enemy(boss, attribute, battleItem, rand, false));
                }else{
                    EnemiesList.add(new Enemy(boss, attribute, battleItem, rand, true));
                }
            }
        // }
        return EnemiesList;
    }
}
