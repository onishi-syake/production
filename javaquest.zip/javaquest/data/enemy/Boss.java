package data.enemy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import battle.InputAction.Auto;
import character.Character.MainStatus;
import data.action.Spell;

public enum Boss {
    ApprenticeBrave("見習い勇者",
            1,    //SpellSlot
            80,//status
            100,//defence
            5,    //MP
            2,      //aNum
            true,
            false,
            // 3000,    //賞金
            0,    //賞金
            Auto.enemyMCTS,
            -1,
            new HashMap<Map<Spell, Integer>, Integer>(){{
                put(new EnumMap<>(Spell.class){{
                    put(Spell.Fire, 1);
                    put(Spell.Wind, 1);
                    put(Spell.Stone, 1);
                }}, 1);
            }}
            ),
    normalBrave("普通の勇者",
            2,    //SpellSlot
            130,//status(強すぎたので一旦修正)
            200,//defence
            6,    //MP
            2,      //aNum
            true,
            false,
            // 5000,    //賞金
            0,    //賞金
            Auto.enemyMCTS,
            -1,
            new HashMap<Map<Spell, Integer>, Integer>(){{
                put(new EnumMap<>(Spell.class){{
                    put(Spell.Fire, 1);
                    put(Spell.Wind, 1);
                    put(Spell.Stone, 1);
                }}, 1);
                put(new EnumMap<>(Spell.class){{
                    put(Spell.AUp, 1);
                    put(Spell.SUp, 1);
                    put(Spell.DUp, 1);
                }}, 1);
                // put(new EnumMap<>(Spell.class){{
                //     put(Spell.Poison, 1);
                //     put(Spell.Bond, 1);
                //     put(Spell.Stomatitis, 1);
                // }}, 1);
            }}
            ),
    StrongestBrave("最強（自称）の勇者",
            2,    //SpellSlot
            240,//status
            50,//defence
            7,    //MP
            2,      //aNum
            true,
            false,
            // 10000,    //賞金
            0,    //賞金
            Auto.enemyMCTS,
            -1,
            new HashMap<Map<Spell, Integer>, Integer>(){{
                put(new EnumMap<>(Spell.class){{
                    put(Spell.Fire, 1);
                    put(Spell.Wind, 1);
                    put(Spell.Stone, 1);
                }}, 1);
                put(new EnumMap<>(Spell.class){{
                    put(Spell.AUp, 1);
                    put(Spell.SUp, 1);
                    put(Spell.DUp, 1);
                }}, 1);
                // put(new EnumMap<>(Spell.class){{
                //     put(Spell.Heal, 1);
                //     put(Spell.Poison, 1);
                //     put(Spell.Bond, 1);
                //     put(Spell.Lag, 1);
                //     put(Spell.Stomatitis, 1);
                //     put(Spell.Nervous, 1);
                //     put(Spell.TensionField, 1);
                //     put(Spell.SpecialField, 1);
                //     put(Spell.ReverseField, 1);
                //     put(Spell.RegenField, 1);
                // }}, 1);
                put(new EnumMap<>(Spell.class){{
                    put(Spell.On_StateChange, 1);
                    put(Spell.On_SpellReflect, 1);
                }}, 1);
            }}
            ),
    LegendaryBrave("伝説の勇者",
            3,    //SpellSlot
            400,//status
            200,//defence
            8,    //MP
            2,      //aNum
            true,
            false,
            // 16000,    //賞金
            0,    //賞金
            Auto.enemyMCTS,
            -1,
            new HashMap<Map<Spell, Integer>, Integer>(){{
                put(new EnumMap<>(Spell.class){{
                    put(Spell.Fire, 1);
                    put(Spell.Wind, 1);
                    put(Spell.Stone, 1);
                }}, 1);
                put(new EnumMap<>(Spell.class){{
                    put(Spell.AUp, 1);
                    put(Spell.SUp, 1);
                    put(Spell.DUp, 1);
                }}, 1);
                put(new EnumMap<>(Spell.class){{
                    put(Spell.Heal, 1);
                    put(Spell.Poison, 1);
                    put(Spell.Bond, 1);
                    put(Spell.Lag, 1);
                    put(Spell.Stomatitis, 1);
                    put(Spell.Nervous, 1);
                    put(Spell.TensionField, 1);
                    put(Spell.SpecialField, 1);
                    put(Spell.ReverseField, 1);
                    put(Spell.RegenField, 1);
                }}, 1);
                put(new EnumMap<>(Spell.class){{
                    put(Spell.On_StateChange, 1);
                    put(Spell.On_SpellReflect, 1);
                }}, 1);
            }}
            ),
    DemiseBrave("終焉の勇者",
            3,    //SpellSlot
            800,//status
            50,//defence
            9,    //MP
            2,      //aNum
            true,
            false,
            // 16000,    //賞金
            0,    //賞金
            Auto.enemyMCTS,
            -1,
            new HashMap<Map<Spell, Integer>, Integer>(){{
                put(new EnumMap<>(Spell.class){{
                    put(Spell.Fire, 1);
                    put(Spell.Wind, 1);
                    put(Spell.Stone, 1);
                }}, 1);
                put(new EnumMap<>(Spell.class){{
                    put(Spell.AUp, 1);
                    put(Spell.SUp, 1);
                    put(Spell.DUp, 1);
                }}, 1);
                put(new EnumMap<>(Spell.class){{
                    put(Spell.Heal, 1);
                    put(Spell.Poison, 1);
                    put(Spell.Bond, 1);
                    put(Spell.Lag, 1);
                    put(Spell.Stomatitis, 1);
                    put(Spell.Nervous, 1);
                    put(Spell.TensionField, 1);
                    put(Spell.SpecialField, 1);
                    put(Spell.ReverseField, 1);
                    put(Spell.RegenField, 1);
                }}, 2);
                put(new EnumMap<>(Spell.class){{
                    put(Spell.On_StateChange, 1);
                    put(Spell.On_SpellReflect, 1);
                }}, 1);
            }}
            ),
    FastidiousHero("こだわりの勇者",
            5,    //SpellSlot
            1600,//status
            100,//defence
            10,    //MP
            2,      //aNum
            true,
            false,
            // 16000,    //賞金
            0,    //賞金
            Auto.enemyMCTS,
            4 + Spell.On_Joke.ordinal(),
            new HashMap<Map<Spell, Integer>, Integer>(){{
                put(new EnumMap<>(Spell.class){{
                    put(Spell.Fire, 1);
                    put(Spell.Wind, 1);
                    put(Spell.Stone, 1);
                }}, 2);
                put(new EnumMap<>(Spell.class){{
                    put(Spell.AUp, 1);
                    put(Spell.SUp, 1);
                    put(Spell.DUp, 1);
                }}, 1);
                put(new EnumMap<>(Spell.class){{
                    put(Spell.Heal, 1);
                    put(Spell.Poison, 1);
                    put(Spell.Bond, 1);
                    put(Spell.Lag, 1);
                    put(Spell.Stomatitis, 1);
                    put(Spell.Nervous, 1);
                    put(Spell.TensionField, 1);
                    put(Spell.SpecialField, 1);
                    put(Spell.ReverseField, 1);
                    put(Spell.RegenField, 1);
                }}, 6);
                put(new EnumMap<>(Spell.class){{
                    put(Spell.On_StateChange, 1);
                    put(Spell.On_SpellReflect, 1);
                }}, 1);
                put(new EnumMap<>(Spell.class){{
                    put(Spell.On_Joke, 1);
                }}, 1);
            }}
            ),
    ;
    public final String jName;// 名前
    public final int spellSlotNum;// スロット数
    public final int status;// 基準ステータス値(ステータス実数値か基準ステータス値のどちらかを使う)
    public final int defence;// 防御力
    public final int[] mainStatus;// ステータス実数値(ステータス実数値か基準ステータス値のどちらかを使う)
    public final int mp;// MP
    public final int aNum;// 攻撃回数
    public final boolean useItem;// アイテムを使えるかどうか
    public final boolean useSpecial;// 必殺技を使えるかどうか
    public final int money;// 落とす金
    public final Auto auto;// 行動選択方法
    public final int firstAction;// 初回行動
    public final int[] cycleActions;// 行動サイクル（行動選択がサイクル型の時のみ）
    public final Map<Map<Spell, Integer>, Integer> spellCategoryNum;// 呪文レベル
    private Boss(String name, int spellSlotNum, int status, int defence, int mmp, int aNum, boolean useItem, boolean useSpecial, int money, Auto auto, int firstAction, Map<Map<Spell, Integer>, Integer> spellCategoryNum){
        this.jName = name;
        this.spellSlotNum = spellSlotNum;
        this.status = status;
        this.defence = defence;
        this.mainStatus = null;
        this.mp = mmp;
        this.aNum = aNum;
        this.useItem = useItem;
        this.useSpecial = useSpecial;
        this.spellCategoryNum = spellCategoryNum;
        this.money = money;
        this.auto = auto;
        this.firstAction = firstAction;
        this.cycleActions = null;
    }
    // //ステータスを指定して勇者作成
    // private Boss(String name, int spellSlotNum, int[] mainStatus, boolean useItem, boolean useSpecial, int money, int[] cycleActions, Map<Map<Spell, Integer>, Integer> spellCategoryNum){
    //     Random rand = new Random();
    //     this.jName = name;
    //     this.spellSlotNum = spellSlotNum;
    //     this.status = -1;
    //     this.mainStatus = mainStatus;
    //     this.defence = -1;
    //     this.mp = -1;
    //     this.aNum = -1;
    //     this.useItem = useItem;
    //     this.useSpecial = useSpecial;
    //     this.spellCategoryNum = spellCategoryNum;
    //     this.money = money;
    //     this.auto = Auto.cycle;
    //     this.cycleActions = cycleActions;
    // }

    public int[] getRandomMainStatusArray(Random rand){//乱数あり勇者ステータス作成
        if(this.mainStatus != null){
            return this.mainStatus;
        }
        int[] mainStatus = new int[MainStatus.NUM];
        int e = rand.nextInt(20);
        double eCoef = 100.0 / (100.0 - e);
        int status = this.status;
        int d = this.defence;
        // int d = rand.nextInt(3) == 0 ? 50 : (rand.nextInt(2) == 0 ? 100 : 200);
        // status = (int)(status / Math.cbrt(eCoef));//3乗根
        // status = (int)(status / Math.cbrt(Math.sqrt(d / 100.0)));
        if(d == 200){
            status = (int)(status * 0.9);
        }
        if(d == 50){
            status = (int)(status * 1.1);
        }
        status = (int)Math.round(((double)status) / 10) * 10;
        double aCoef = rand.nextInt(3);
        if(aCoef == 0.0){
            aCoef = 0.5;
        }
        double sCoef;
        do{
            sCoef = rand.nextInt(3);
            if(sCoef == 0.0){
                sCoef = 0.5;
            }
        }while(aCoef == sCoef);
        double hpCoef = 1 / aCoef / sCoef;
        mainStatus[0] = (int)(hpCoef * status * 10);
        mainStatus[1] = (int)(hpCoef * status * 10);
        mainStatus[2] = this.mp;
        mainStatus[3] = this.mp;
        mainStatus[4] = (int)(aCoef * status);
        mainStatus[5] = d;
        mainStatus[6] = e;
        mainStatus[7] = (int)(sCoef * status);
        mainStatus[8] = this.aNum;
        return mainStatus;
    }

    public int[] getFixedMainStatusArray(){//乱数なし勇者ステータス作成
        if(this.mainStatus != null){
            return this.mainStatus;
        }
        int[] mainStatus = new int[MainStatus.NUM];
        int d = this.defence;
        int e = 10;
        int status = (int)(this.status * (this.defence == 50 ? 1.1 : (this.defence == 200 ? 0.9 : 1.0)));
        status = (int)Math.round(((double)status) / 10) * 10;
        mainStatus[0] = status * 10;
        mainStatus[1] = status * 10;
        mainStatus[2] = this.mp;
        mainStatus[3] = this.mp;
        mainStatus[4] = status;
        mainStatus[5] = d;
        mainStatus[6] = e;
        mainStatus[7] = status;
        mainStatus[8] = this.aNum;
        return mainStatus;
    }
    public static final int NUM = values().length;
}
