package data.enemy;

import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Map;

import character.Character.MainStatus;

// モンスターの強さの列挙型。強さごとの基礎ステータスと落とす金を決めている。
public enum MonsterRank {
    tutorial(4, new EnumMap<MainStatus, Integer>(MainStatus.class){{
        put(MainStatus.hp, 250);
        put(MainStatus.maxHp, 250);
        put(MainStatus.mp, 7);
        put(MainStatus.maxMp, 7);
        put(MainStatus.a, 50);
        put(MainStatus.d, 100);
        put(MainStatus.e, 30);
        put(MainStatus.s, 50);
        put(MainStatus.aNum, 1);
    }}),
    mini(4, new EnumMap<MainStatus, Integer>(MainStatus.class){{
        put(MainStatus.hp, 350);
        put(MainStatus.maxHp, 350);
        put(MainStatus.mp, 8);
        put(MainStatus.maxMp, 8);
        put(MainStatus.a, 70);
        put(MainStatus.d, 100);
        put(MainStatus.e, 30);
        put(MainStatus.s, 70);
        put(MainStatus.aNum, 1);
    }}),
    miniPlus(5, new EnumMap<MainStatus, Integer>(MainStatus.class){{
        put(MainStatus.hp, 420);
        put(MainStatus.maxHp, 420);
        put(MainStatus.mp, 9);
        put(MainStatus.maxMp, 9);
        put(MainStatus.a, 84);
        put(MainStatus.d, 100);
        put(MainStatus.e, 30);
        put(MainStatus.s, 84);
        put(MainStatus.aNum, 1);
    }}),
    normal(7, new EnumMap<MainStatus, Integer>(MainStatus.class){{
        put(MainStatus.hp, 500);
        put(MainStatus.maxHp, 500);
        put(MainStatus.mp, 10);
        put(MainStatus.maxMp, 10);
        put(MainStatus.a, 100);
        put(MainStatus.d, 100);
        put(MainStatus.e, 30);
        put(MainStatus.s, 100);
        put(MainStatus.aNum, 1);
    }}),
    normalPlus(10, new EnumMap<MainStatus, Integer>(MainStatus.class){{
        put(MainStatus.hp, 600);
        put(MainStatus.maxHp, 600);
        put(MainStatus.mp, 11);
        put(MainStatus.maxMp, 11);
        put(MainStatus.a, 120);
        put(MainStatus.d, 100);
        put(MainStatus.e, 30);
        put(MainStatus.s, 120);
        put(MainStatus.aNum, 1);
    }}),
    good(14, new EnumMap<MainStatus, Integer>(MainStatus.class){{
        put(MainStatus.hp, 700);
        put(MainStatus.maxHp, 700);
        put(MainStatus.mp, 12);
        put(MainStatus.maxMp, 12);
        put(MainStatus.a, 140);
        put(MainStatus.d, 100);
        put(MainStatus.e, 30);
        put(MainStatus.s, 140);
        put(MainStatus.aNum, 1);
    }}),
    goodPlus(20, new EnumMap<MainStatus, Integer>(MainStatus.class){{
        put(MainStatus.hp, 840);
        put(MainStatus.maxHp, 840);
        put(MainStatus.mp, 13);
        put(MainStatus.maxMp, 13);
        put(MainStatus.a, 168);
        put(MainStatus.d, 100);
        put(MainStatus.e, 30);
        put(MainStatus.s, 168);
        put(MainStatus.aNum, 1);
    }}),
    great(28, new EnumMap<MainStatus, Integer>(MainStatus.class){{
        put(MainStatus.hp, 1000);
        put(MainStatus.maxHp, 1000);
        put(MainStatus.mp, 14);
        put(MainStatus.maxMp, 14);
        put(MainStatus.a, 200);
        put(MainStatus.d, 100);
        put(MainStatus.e, 30);
        put(MainStatus.s, 200);
        put(MainStatus.aNum, 1);
    }}),
    greatPlus(40, new EnumMap<MainStatus, Integer>(MainStatus.class){{
        put(MainStatus.hp, 1200);
        put(MainStatus.maxHp, 1200);
        put(MainStatus.mp, 15);
        put(MainStatus.maxMp, 15);
        put(MainStatus.a, 240);
        put(MainStatus.d, 100);
        put(MainStatus.e, 30);
        put(MainStatus.s, 240);
        put(MainStatus.aNum, 1);
    }}),
    perfect(56, new EnumMap<MainStatus, Integer>(MainStatus.class){{
        put(MainStatus.hp, 1400);
        put(MainStatus.maxHp, 1400);
        put(MainStatus.mp, 17);
        put(MainStatus.maxMp, 17);
        put(MainStatus.a, 280);
        put(MainStatus.d, 100);
        put(MainStatus.e, 30);
        put(MainStatus.s, 280);
        put(MainStatus.aNum, 1);
    }}),
    perfectPlus(80, new EnumMap<MainStatus, Integer>(MainStatus.class){{
        put(MainStatus.hp, 1680);
        put(MainStatus.maxHp, 1680);
        put(MainStatus.mp, 18);
        put(MainStatus.maxMp, 18);
        put(MainStatus.a, 336);
        put(MainStatus.d, 100);
        put(MainStatus.e, 30);
        put(MainStatus.s, 336);
        put(MainStatus.aNum, 1);
    }}),
    ultimate(112, new EnumMap<MainStatus, Integer>(MainStatus.class){{
        put(MainStatus.hp, 2000);
        put(MainStatus.maxHp, 2000);
        put(MainStatus.mp, 20);
        put(MainStatus.maxMp, 20);
        put(MainStatus.a, 400);
        put(MainStatus.d, 100);
        put(MainStatus.e, 30);
        put(MainStatus.s, 400);
        put(MainStatus.aNum, 1);
    }}),
    ultimatePlus(160, new EnumMap<MainStatus, Integer>(MainStatus.class){{
        put(MainStatus.hp, 2400);
        put(MainStatus.maxHp, 2400);
        put(MainStatus.mp, 22);
        put(MainStatus.maxMp, 22);
        put(MainStatus.a, 480);
        put(MainStatus.d, 100);
        put(MainStatus.e, 30);
        put(MainStatus.s, 480);
        put(MainStatus.aNum, 1);
    }}),
    god(224, new EnumMap<MainStatus, Integer>(MainStatus.class){{
        put(MainStatus.hp, 2800);
        put(MainStatus.maxHp, 2800);
        put(MainStatus.mp, 24);
        put(MainStatus.maxMp, 24);
        put(MainStatus.a, 560);
        put(MainStatus.d, 100);
        put(MainStatus.e, 30);
        put(MainStatus.s, 560);
        put(MainStatus.aNum, 1);
    }}),
    godPlus(320, new EnumMap<MainStatus, Integer>(MainStatus.class){{
        put(MainStatus.hp, 3360);
        put(MainStatus.maxHp, 3360);
        put(MainStatus.mp, 26);
        put(MainStatus.maxMp, 26);
        put(MainStatus.a, 672);
        put(MainStatus.d, 100);
        put(MainStatus.e, 30);
        put(MainStatus.s, 672);
        put(MainStatus.aNum, 1);
    }}),
    ;
    public final int money;// 落とす金
    public final Map<MainStatus, Integer> baseMainStatus;// 基礎ステータス
    private MonsterRank(int moeny, Map<MainStatus, Integer> baseMainStatus){
        this.money = moeny;
        this.baseMainStatus = baseMainStatus;
    }
    public static EnumSet<MonsterRank> easyRank(){
        return EnumSet.of(MonsterRank.mini, normal, good, great);
    }
}