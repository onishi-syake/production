package data.enemy;

import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;

import battle.InputAction.Auto;
import character.Character.MainStatus;
import character.Character.Attribute;
import data.action.Spell;

public enum Monster {
    // 4色ギア
    RedPoyoMini("レッドミニ",
            MonsterRank.mini,    //rank
            null,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    RedPoyoMiniPlus("レッドミニ+",
            MonsterRank.miniPlus,    //rank
            RedPoyoMini,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    RedPoyo("レッド",
            MonsterRank.normal,    //rank
            RedPoyoMiniPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    RedPoyoPlus("レッド+",
            MonsterRank.normalPlus,    //rank
            RedPoyo,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    RedPoyoGood("レッドグッド", 
            MonsterRank.good,    //rank
            RedPoyoPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    RedPoyoGoodPlus("レッドグッド+", 
            MonsterRank.goodPlus,    //rank
            RedPoyoGood,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    RedPoyoGreat(   "レッドグレート",
            MonsterRank.great,    //rank
            RedPoyoGoodPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    RedPoyoGreatPlus(   "レッドグレート+",
            MonsterRank.greatPlus,    //rank
            RedPoyoGreat,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    RedPoyoPerfect( "レッドパーフェクト",
            MonsterRank.perfect,    //rank
            RedPoyoGreatPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    RedPoyoPerfectPlus( "レッドパーフェクト+",
            MonsterRank.perfectPlus,    //rank
            RedPoyoPerfect,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    RedPoyoUltimate( "レッドアルティメット",
            MonsterRank.ultimate,    //rank
            RedPoyoPerfectPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    RedPoyoUltimatePlus( "レッドアルティメット+",
            MonsterRank.ultimatePlus,    //rank
            RedPoyoUltimate,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    RedPoyoGod( "レッドゴッド",
            MonsterRank.god,    //rank
            RedPoyoUltimatePlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    RedPoyoGodPlus( "レッドゴッド+",
            MonsterRank.godPlus,    //rank
            RedPoyoGod,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    BrownPoyoMini("ブラウンミニ",
            MonsterRank.mini,    //rank
            null,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Stone, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    BrownPoyoMiniPlus("ブラウンミニ+",
            MonsterRank.miniPlus,    //rank
            BrownPoyoMini,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Stone, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    BrownPoyo( "ブラウン",
            MonsterRank.normal,    //rank
            BrownPoyoMiniPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Stone, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    BrownPoyoPlus( "ブラウン+",
            MonsterRank.normalPlus,    //rank
            BrownPoyo,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Stone, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    BrownPoyoGood( "ブラウングッド",
            MonsterRank.good,    //rank
            BrownPoyoPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Stone, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    BrownPoyoGoodPlus( "ブラウングッド+",
            MonsterRank.goodPlus,    //rank
            BrownPoyoGood,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Stone, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    BrownPoyoGreat("ブラウングレート",
            MonsterRank.great,    //rank
            BrownPoyoGoodPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Stone, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    BrownPoyoGreatPlus("ブラウングレート+",
            MonsterRank.greatPlus,    //rank
            BrownPoyoGreat,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Stone, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    BrownPoyoPerfect(  "ブラウンパーフェクト",
            MonsterRank.perfect,    //rank
            BrownPoyoGreatPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Stone, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    BrownPoyoPerfectPlus(  "ブラウンパーフェクト+",
            MonsterRank.perfectPlus,    //rank
            BrownPoyoPerfect,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Stone, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    BrownPoyoUltimate( "ブラウンアルティメット",
            MonsterRank.ultimate,    //rank
            BrownPoyoPerfectPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Stone, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    BrownPoyoUltimatePlus( "ブラウンアルティメット+",
            MonsterRank.ultimatePlus,    //rank
            BrownPoyoUltimate,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Stone, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    BrownPoyoGod( "ブラウンゴッド",
            MonsterRank.god,    //rank
            BrownPoyoUltimatePlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Stone, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    BrownPoyoGodPlus( "ブラウンゴッド+",
            MonsterRank.godPlus,    //rank
            BrownPoyoGod,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Stone, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    GreenPoyoMini("グリーンミニ",
            MonsterRank.mini,    //rank
            null,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.a, 0.5);
                put(MainStatus.s, 2.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Wind, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    GreenPoyoMiniPlus("グリーンミニ+",
            MonsterRank.miniPlus,    //rank
            GreenPoyoMini,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.a, 0.5);
                put(MainStatus.s, 2.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Wind, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    GreenPoyo(  "グリーン",
            MonsterRank.normal,    //rank
            GreenPoyoMiniPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.a, 0.5);
                put(MainStatus.s, 2.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Wind, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    GreenPoyoPlus(  "グリーン+",
            MonsterRank.normalPlus,    //rank
            GreenPoyo,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.a, 0.5);
                put(MainStatus.s, 2.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Wind, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    GreenPoyoGood(  "グリーングッド",
            MonsterRank.good,    //rank
            GreenPoyoPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.a, 0.5);
                put(MainStatus.s, 2.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Wind, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    GreenPoyoGoodPlus(  "グリーングッド+",
            MonsterRank.goodPlus,    //rank
            GreenPoyoGood,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.a, 0.5);
                put(MainStatus.s, 2.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Wind, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    GreenPoyoGreat( "グリーングレート",
            MonsterRank.great,    //rank
            GreenPoyoGoodPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.a, 0.5);
                put(MainStatus.s, 2.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Wind, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    GreenPoyoGreatPlus( "グリーングレート+",
            MonsterRank.greatPlus,    //rank
            GreenPoyoGreat,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.a, 0.5);
                put(MainStatus.s, 2.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Wind, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    GreenPoyoPerfect(   "グリーンパーフェクト",
            MonsterRank.perfect,    //rank
            GreenPoyoGreatPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.a, 0.5);
                put(MainStatus.s, 2.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Wind, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    GreenPoyoPerfectPlus(   "グリーンパーフェクト+",
            MonsterRank.perfectPlus,    //rank
            GreenPoyoPerfect,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.a, 0.5);
                put(MainStatus.s, 2.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Wind, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    GreenPoyoUltimate( "グリーンアルティメット",
            MonsterRank.ultimate,    //rank
            GreenPoyoPerfectPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.a, 0.5);
                put(MainStatus.s, 2.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Wind, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    GreenPoyoUltimatePlus( "グリーンアルティメット+",
            MonsterRank.ultimatePlus,    //rank
            GreenPoyoUltimate,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.a, 0.5);
                put(MainStatus.s, 2.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Wind, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    GreenPoyoGod( "グリーンゴッド",
            MonsterRank.god,    //rank
            GreenPoyoUltimatePlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.a, 0.5);
                put(MainStatus.s, 2.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Wind, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    GreenPoyoGodPlus( "グリーンゴッド+",
            MonsterRank.godPlus,    //rank
            GreenPoyoGod,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.a, 0.5);
                put(MainStatus.s, 2.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Wind, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    WhitePoyoMini("ホワイトミニ",
            MonsterRank.mini,    //rank
            null,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.hp, 1.4);
                put(MainStatus.maxHp, 1.4);
                put(MainStatus.e, 0.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    WhitePoyoMiniPlus("ホワイトミニ+",
            MonsterRank.miniPlus,    //rank
            WhitePoyoMini,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.hp, 1.4);
                put(MainStatus.maxHp, 1.4);
                put(MainStatus.e, 0.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    WhitePoyo(   "ホワイト",
            MonsterRank.normal,    //rank
            WhitePoyoMiniPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.hp, 1.4);
                put(MainStatus.maxHp, 1.4);
                put(MainStatus.e, 0.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    WhitePoyoPlus(   "ホワイト+",
            MonsterRank.normalPlus,    //rank
            WhitePoyo,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.hp, 1.4);
                put(MainStatus.maxHp, 1.4);
                put(MainStatus.e, 0.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    WhitePoyoGood(   "ホワイトグッド",
            MonsterRank.good,    //rank
            WhitePoyoPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.hp, 1.4);
                put(MainStatus.maxHp, 1.4);
                put(MainStatus.e, 0.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    WhitePoyoGoodPlus(   "ホワイトグッド+",
            MonsterRank.goodPlus,    //rank
            WhitePoyoGood,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.hp, 1.4);
                put(MainStatus.maxHp, 1.4);
                put(MainStatus.e, 0.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    WhitePoyoGreat(  "ホワイトグレート",
            MonsterRank.great,    //rank
            WhitePoyoGoodPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.hp, 1.4);
                put(MainStatus.maxHp, 1.4);
                put(MainStatus.e, 0.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    WhitePoyoGreatPlus(  "ホワイトグレート+",
            MonsterRank.greatPlus,    //rank
            WhitePoyoGreat,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.hp, 1.4);
                put(MainStatus.maxHp, 1.4);
                put(MainStatus.e, 0.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    WhitePoyoPerfect("ホワイトパーフェクト",
            MonsterRank.perfect,    //rank
            WhitePoyoGreatPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.hp, 1.4);
                put(MainStatus.maxHp, 1.4);
                put(MainStatus.e, 0.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    WhitePoyoPerfectPlus("ホワイトパーフェクト+",
            MonsterRank.perfectPlus,    //rank
            WhitePoyoPerfect,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.hp, 1.4);
                put(MainStatus.maxHp, 1.4);
                put(MainStatus.e, 0.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    WhitePoyoUltimate( "ホワイトアルティメット",
            MonsterRank.ultimate,    //rank
            WhitePoyoPerfectPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.hp, 1.4);
                put(MainStatus.maxHp, 1.4);
                put(MainStatus.e, 0.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    WhitePoyoUltimatePlus( "ホワイトアルティメット+",
            MonsterRank.ultimatePlus,    //rank
            WhitePoyoUltimate,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.hp, 1.4);
                put(MainStatus.maxHp, 1.4);
                put(MainStatus.e, 0.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    WhitePoyoGod( "ホワイトゴッド",
            MonsterRank.god,    //rank
            WhitePoyoUltimatePlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.hp, 1.4);
                put(MainStatus.maxHp, 1.4);
                put(MainStatus.e, 0.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    WhitePoyoGodPlus( "ホワイトゴッド+",
            MonsterRank.godPlus,    //rank
            WhitePoyoGod,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.hp, 1.4);
                put(MainStatus.maxHp, 1.4);
                put(MainStatus.e, 0.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AbnormalPoyoMini("ガイ・アクミニ",
            MonsterRank.mini,    //rank
            null,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Poison, 1);
                this.put(Spell.Stomatitis, 1);
                this.put(Spell.Nervous, 1);
                this.put(Spell.Bond, 1);
                this.put(Spell.Lag, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AbnormalPoyoMiniPlus("ガイ・アクミニ+",
            MonsterRank.miniPlus,    //rank
            AbnormalPoyoMini,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Poison, 1);
                this.put(Spell.Stomatitis, 1);
                this.put(Spell.Nervous, 1);
                this.put(Spell.Bond, 1);
                this.put(Spell.Lag, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AbnormalPoyo("ガイ・アク",
            MonsterRank.normal,    //rank
            AbnormalPoyoMiniPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Poison, 1);
                this.put(Spell.Stomatitis, 1);
                this.put(Spell.Nervous, 1);
                this.put(Spell.Bond, 1);
                this.put(Spell.Lag, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AbnormalPoyoPlus("ガイ・アク+",
            MonsterRank.normalPlus,    //rank
            AbnormalPoyo,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Poison, 1);
                this.put(Spell.Stomatitis, 1);
                this.put(Spell.Nervous, 1);
                this.put(Spell.Bond, 1);
                this.put(Spell.Lag, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AbnormalPoyoGood("ガイ・アクグッド",
            MonsterRank.good,    //rank
            AbnormalPoyoPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Poison, 1);
                this.put(Spell.Stomatitis, 1);
                this.put(Spell.Nervous, 1);
                this.put(Spell.Bond, 1);
                this.put(Spell.Lag, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AbnormalPoyoGoodPlus("ガイ・アクグッド+",
            MonsterRank.goodPlus,    //rank
            AbnormalPoyoGood,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Poison, 1);
                this.put(Spell.Stomatitis, 1);
                this.put(Spell.Nervous, 1);
                this.put(Spell.Bond, 1);
                this.put(Spell.Lag, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AbnormalPoyoGreat("ガイ・アクグレート",
            MonsterRank.great,    //rank
            AbnormalPoyoGoodPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Poison, 1);
                this.put(Spell.Stomatitis, 1);
                this.put(Spell.Nervous, 1);
                this.put(Spell.Bond, 1);
                this.put(Spell.Lag, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AbnormalPoyoGreatPlus("ガイ・アクグレート+",
            MonsterRank.greatPlus,    //rank
            AbnormalPoyoGreat,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Poison, 1);
                this.put(Spell.Stomatitis, 1);
                this.put(Spell.Nervous, 1);
                this.put(Spell.Bond, 1);
                this.put(Spell.Lag, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AbnormalPoyoPerfect("ガイ・アクパーフェクト",
            MonsterRank.perfect,    //rank
            AbnormalPoyoGreatPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Poison, 1);
                this.put(Spell.Stomatitis, 1);
                this.put(Spell.Nervous, 1);
                this.put(Spell.Bond, 1);
                this.put(Spell.Lag, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AbnormalPoyoPerfectPlus("ガイ・アクパーフェクト+",
            MonsterRank.perfectPlus,    //rank
            AbnormalPoyoPerfect,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Poison, 1);
                this.put(Spell.Stomatitis, 1);
                this.put(Spell.Nervous, 1);
                this.put(Spell.Bond, 1);
                this.put(Spell.Lag, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AbnormalPoyoUltimate("ガイ・アクアルティメット",
            MonsterRank.ultimate,    //rank
            AbnormalPoyoPerfectPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Poison, 1);
                this.put(Spell.Stomatitis, 1);
                this.put(Spell.Nervous, 1);
                this.put(Spell.Bond, 1);
                this.put(Spell.Lag, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AbnormalPoyoUltimatePlus("ガイ・アクアルティメット+",
            MonsterRank.ultimatePlus,    //rank
            AbnormalPoyoUltimate,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Poison, 1);
                this.put(Spell.Stomatitis, 1);
                this.put(Spell.Nervous, 1);
                this.put(Spell.Bond, 1);
                this.put(Spell.Lag, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AbnormalPoyoGod("ガイ・アクゴッド",
            MonsterRank.god,    //rank
            AbnormalPoyoUltimatePlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Poison, 1);
                this.put(Spell.Stomatitis, 1);
                this.put(Spell.Nervous, 1);
                this.put(Spell.Bond, 1);
                this.put(Spell.Lag, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AbnormalPoyoGodPlus("ガイ・アクゴッド+",
            MonsterRank.godPlus,    //rank
            AbnormalPoyoGod,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Poison, 1);
                this.put(Spell.Stomatitis, 1);
                this.put(Spell.Nervous, 1);
                this.put(Spell.Bond, 1);
                this.put(Spell.Lag, 1);
                this.put(Spell.On_Joke, 1);
            }}),




    // NullPoyoMiniMinus("しなびたバーサーカーミニ",
    //         MonsterRank.mini,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             double coef = 1.1;
    //             put(MainStatus.hp, coef);
    //             put(MainStatus.maxHp, coef);
    //             put(MainStatus.mp, 1 / Math.pow(coef, 3));
    //             put(MainStatus.maxMp, 1 / Math.pow(coef, 3));
    //             put(MainStatus.a, coef);
    //             put(MainStatus.s, coef);
    //         }},
    //         0.9,    //賞金係数
    //         Auto.random,
    //         new EnumMap<Spell, Integer>(Spell.class)),
    // NullPoyoMinus(   "しなびたバーサーカー",
    //         MonsterRank.normal,    //rank
    //         Attribute.Null,    //attribute
    //             1,    //SpellSlot
    //             false,//useSpecial
    //             false,//useEscape
    //             new EnumMap<MainStatus, Double>(MainStatus.class){{
    //                 double coef = 1.1;
    //                 put(MainStatus.hp, coef);
    //                 put(MainStatus.maxHp, coef);
    //                 put(MainStatus.mp, 1 / Math.pow(coef, 3));
    //                 put(MainStatus.maxMp, 1 / Math.pow(coef, 3));
    //                 put(MainStatus.a, coef);
    //                 put(MainStatus.s, coef);
    //             }},
    //             0.9,    //賞金係数
    //             Auto.random,
    //             new EnumMap<Spell, Integer>(Spell.class)),
    // NullPoyoGoodMinus(   "しなびたバーサーカーグッド",
    //         MonsterRank.good,    //rank
    //         Attribute.Null,    //attribute
    //                 1,    //SpellSlot
    //                 false,//useSpecial
    //                 false,//useEscape
    //                 new EnumMap<MainStatus, Double>(MainStatus.class){{
    //                     double coef = 1.1;
    //                     put(MainStatus.hp, coef);
    //                     put(MainStatus.maxHp, coef);
    //                     put(MainStatus.mp, 1 / Math.pow(coef, 3));
    //                     put(MainStatus.maxMp, 1 / Math.pow(coef, 3));
    //                     put(MainStatus.a, coef);
    //                     put(MainStatus.s, coef);
    //                 }},
    //                 0.9,    //賞金係数
    //                 Auto.random,
    //                 new EnumMap<Spell, Integer>(Spell.class)),
    // NullPoyoGreatMinus(  "しなびたバーサーカーグレート",
    //         MonsterRank.great,    //rank
    //         Attribute.Null,    //attribute
    //                 1,    //SpellSlot
    //                 false,//useSpecial
    //                 false,//useEscape
    //                 new EnumMap<MainStatus, Double>(MainStatus.class){{
    //                     double coef = 1.1;
    //                     put(MainStatus.hp, coef);
    //                     put(MainStatus.maxHp, coef);
    //                     put(MainStatus.mp, 1 / Math.pow(coef, 3));
    //                     put(MainStatus.maxMp, 1 / Math.pow(coef, 3));
    //                     put(MainStatus.a, coef);
    //                     put(MainStatus.s, coef);
    //                 }},
    //                 0.9,    //賞金係数
    //                 Auto.random,
    //                 new EnumMap<Spell, Integer>(Spell.class)),
    // NullPoyoPerfectMinus("しなびたバーサーカーパーフェクト",
    //         MonsterRank.perfect,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             double coef = 1.1;
    //             put(MainStatus.hp, coef);
    //             put(MainStatus.maxHp, coef);
    //             put(MainStatus.mp, 1 / Math.pow(coef, 3));
    //             put(MainStatus.maxMp, 1 / Math.pow(coef, 3));
    //             put(MainStatus.a, coef);
    //             put(MainStatus.s, coef);
    //         }},
    //         0.9,    //賞金係数
    //         Auto.random,
    //         new EnumMap<Spell, Integer>(Spell.class)),
    // NullPoyoUltimateMinus( "しなびたバーサーカーアルティメット",
    //         MonsterRank.ultimate,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             double coef = 1.1;
    //             put(MainStatus.hp, coef);
    //             put(MainStatus.maxHp, coef);
    //             put(MainStatus.mp, 1 / Math.pow(coef, 3));
    //             put(MainStatus.maxMp, 1 / Math.pow(coef, 3));
    //             put(MainStatus.a, coef);
    //             put(MainStatus.s, coef);
    //         }},
    //         0.9,    //賞金係数
    //         Auto.random,
    //         new EnumMap<Spell, Integer>(Spell.class)),
    // NullPoyoGodMinus( "しなびたバーサーカーゴッド",
    //         MonsterRank.god,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             double coef = 1.1;
    //             put(MainStatus.hp, coef);
    //             put(MainStatus.maxHp, coef);
    //             put(MainStatus.mp, 1 / Math.pow(coef, 3));
    //             put(MainStatus.maxMp, 1 / Math.pow(coef, 3));
    //             put(MainStatus.a, coef);
    //             put(MainStatus.s, coef);
    //         }},
    //         0.9,    //賞金係数
    //         Auto.random,
    //         new EnumMap<Spell, Integer>(Spell.class)),


    
    NullPoyoMini("バーサーカーミニ",
            MonsterRank.mini,    //rank
            null,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxHp, 2.0);
                put(MainStatus.hp, 2.0);
                put(MainStatus.a, 3.5);
                put(MainStatus.s, 0.35);
            }},
            1,    //賞金係数
            2,    // レベルアップする訓練の列数
            Auto.random,
            new EnumMap<Spell, Integer>(Spell.class){{
                
            }}),
    NullPoyoMiniPlus("バーサーカーミニ+",
            MonsterRank.miniPlus,    //rank
            NullPoyoMini,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxHp, 2.0);
                put(MainStatus.hp, 2.0);
                put(MainStatus.a, 3.5);
                put(MainStatus.s, 0.35);
            }},
            1,    //賞金係数
            2,    // レベルアップする訓練の列数
            Auto.random,
            new EnumMap<Spell, Integer>(Spell.class){{
                
            }}),
    NullPoyo(   "バーサーカー",
            MonsterRank.normal,    //rank
            NullPoyoMiniPlus,
            Attribute.Null,    //attribute
                1,    //SpellSlot
                false,//useSpecial
                false,//useEscape
                new EnumMap<MainStatus, Double>(MainStatus.class){{
                    put(MainStatus.maxHp, 2.0);
                    put(MainStatus.hp, 2.0);
                    put(MainStatus.a, 3.5);
                    put(MainStatus.s, 0.35);
                }},
                1,    //賞金係数
                2,    // レベルアップする訓練の列数
                Auto.random,
                new EnumMap<Spell, Integer>(Spell.class){{
                    
                }}),
    NullPoyoPlus(   "バーサーカー+",
            MonsterRank.normalPlus,    //rank
            NullPoyo,
            Attribute.Null,    //attribute
                1,    //SpellSlot
                false,//useSpecial
                false,//useEscape
                new EnumMap<MainStatus, Double>(MainStatus.class){{
                    put(MainStatus.maxHp, 2.0);
                    put(MainStatus.hp, 2.0);
                    put(MainStatus.a, 3.5);
                    put(MainStatus.s, 0.35);
                }},
                1,    //賞金係数
                2,    // レベルアップする訓練の列数
                Auto.random,
                new EnumMap<Spell, Integer>(Spell.class){{
                    
                }}),
    NullPoyoGood(   "バーサーカーグッド",
            MonsterRank.good,    //rank
            NullPoyoPlus,
            Attribute.Null,    //attribute
                    1,    //SpellSlot
                    false,//useSpecial
                    false,//useEscape
                    new EnumMap<MainStatus, Double>(MainStatus.class){{
                        put(MainStatus.maxHp, 2.0);
                        put(MainStatus.hp, 2.0);
                        put(MainStatus.a, 3.5);
                        put(MainStatus.s, 0.35);
                    }},
                    1,    //賞金係数
                    2,    // レベルアップする訓練の列数
                    Auto.random,
                    new EnumMap<Spell, Integer>(Spell.class){{
                        
                    }}),
    NullPoyoGoodPlus(   "バーサーカーグッド+",
            MonsterRank.goodPlus,    //rank
            NullPoyoGood,
            Attribute.Null,    //attribute
                    1,    //SpellSlot
                    false,//useSpecial
                    false,//useEscape
                    new EnumMap<MainStatus, Double>(MainStatus.class){{
                        put(MainStatus.maxHp, 2.0);
                        put(MainStatus.hp, 2.0);
                        put(MainStatus.a, 3.5);
                        put(MainStatus.s, 0.35);
                    }},
                    1,    //賞金係数
                    2,    // レベルアップする訓練の列数
                    Auto.random,
                    new EnumMap<Spell, Integer>(Spell.class){{
                        
                    }}),
    NullPoyoGreat(  "バーサーカーグレート",
            MonsterRank.great,    //rank
            NullPoyoGoodPlus,
            Attribute.Null,    //attribute
                    1,    //SpellSlot
                    false,//useSpecial
                    false,//useEscape
                    new EnumMap<MainStatus, Double>(MainStatus.class){{
                        put(MainStatus.maxHp, 2.0);
                        put(MainStatus.hp, 2.0);
                        put(MainStatus.a, 3.5);
                        put(MainStatus.s, 0.35);
                    }},
                    1,    //賞金係数
                    2,    // レベルアップする訓練の列数
                    Auto.random,
                    new EnumMap<Spell, Integer>(Spell.class){{
                        
                    }}),
    NullPoyoGreatPlus(  "バーサーカーグレート+",
            MonsterRank.greatPlus,    //rank
            NullPoyoGreat,
            Attribute.Null,    //attribute
                    1,    //SpellSlot
                    false,//useSpecial
                    false,//useEscape
                    new EnumMap<MainStatus, Double>(MainStatus.class){{
                        put(MainStatus.maxHp, 2.0);
                        put(MainStatus.hp, 2.0);
                        put(MainStatus.a, 3.5);
                        put(MainStatus.s, 0.35);
                    }},
                    1,    //賞金係数
                    2,    // レベルアップする訓練の列数
                    Auto.random,
                    new EnumMap<Spell, Integer>(Spell.class){{
                        
                    }}),
    NullPoyoPerfect("バーサーカーパーフェクト",
            MonsterRank.perfect,    //rank
            NullPoyoGreatPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxHp, 2.0);
                put(MainStatus.hp, 2.0);
                put(MainStatus.a, 3.5);
                put(MainStatus.s, 0.35);
            }},
            1,    //賞金係数
            2,    // レベルアップする訓練の列数
            Auto.random,
            new EnumMap<Spell, Integer>(Spell.class){{
                
            }}),
    NullPoyoPerfectPlus("バーサーカーパーフェクト+",
            MonsterRank.perfectPlus,    //rank
            NullPoyoPerfect,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxHp, 2.0);
                put(MainStatus.hp, 2.0);
                put(MainStatus.a, 3.5);
                put(MainStatus.s, 0.35);
            }},
            1,    //賞金係数
            2,    // レベルアップする訓練の列数
            Auto.random,
            new EnumMap<Spell, Integer>(Spell.class){{
                
            }}),
    NullPoyoUltimate( "バーサーカーアルティメット",
            MonsterRank.ultimate,    //rank
            NullPoyoPerfectPlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxHp, 2.0);
                put(MainStatus.hp, 2.0);
                put(MainStatus.a, 3.5);
                put(MainStatus.s, 0.35);
            }},
            1,    //賞金係数
            2,    // レベルアップする訓練の列数
            Auto.random,
            new EnumMap<Spell, Integer>(Spell.class){{
                
            }}),
    NullPoyoUltimatePlus( "バーサーカーアルティメット+",
            MonsterRank.ultimatePlus,    //rank
            NullPoyoUltimate,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxHp, 2.0);
                put(MainStatus.hp, 2.0);
                put(MainStatus.a, 3.5);
                put(MainStatus.s, 0.35);
            }},
            1,    //賞金係数
            2,    // レベルアップする訓練の列数
            Auto.random,
            new EnumMap<Spell, Integer>(Spell.class){{
                
            }}),
    NullPoyoGod( "バーサーカーゴッド",
            MonsterRank.god,    //rank
            NullPoyoUltimatePlus,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxHp, 2.0);
                put(MainStatus.hp, 2.0);
                put(MainStatus.a, 3.5);
                put(MainStatus.s, 0.35);
            }},
            1,    //賞金係数
            2,    // レベルアップする訓練の列数
            Auto.random,
            new EnumMap<Spell, Integer>(Spell.class){{
                
            }}),
    NullPoyoGodPlus( "バーサーカーゴッド+",
            MonsterRank.godPlus,    //rank
            NullPoyoGod,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxHp, 2.0);
                put(MainStatus.hp, 2.0);
                put(MainStatus.a, 3.5);
                put(MainStatus.s, 0.35);
            }},
            1,    //賞金係数
            2,    // レベルアップする訓練の列数
            Auto.random,
            new EnumMap<Spell, Integer>(Spell.class){{
                
            }}),



    // NullPoyoMiniPlus("うるおったバーサーカーミニ",
    //         MonsterRank.mini,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             double coef = 1.3;
    //             put(MainStatus.hp, coef);
    //             put(MainStatus.maxHp, coef);
    //             put(MainStatus.mp, 1 / Math.pow(coef, 3));
    //             put(MainStatus.maxMp, 1 / Math.pow(coef, 3));
    //             put(MainStatus.a, coef);
    //             put(MainStatus.s, coef);
    //         }},
    //         1.1,    //賞金係数
    //         Auto.random,
    //         new EnumMap<Spell, Integer>(Spell.class)),
    // NullPoyoPlus(   "うるおったバーサーカー",
    //         MonsterRank.normal,    //rank
    //         Attribute.Null,    //attribute
    //             1,    //SpellSlot
    //             false,//useSpecial
    //             false,//useEscape
    //             new EnumMap<MainStatus, Double>(MainStatus.class){{
    //                 double coef = 1.3;
    //                 put(MainStatus.hp, coef);
    //                 put(MainStatus.maxHp, coef);
    //                 put(MainStatus.mp, 1 / Math.pow(coef, 3));
    //                 put(MainStatus.maxMp, 1 / Math.pow(coef, 3));
    //                 put(MainStatus.a, coef);
    //                 put(MainStatus.s, coef);
    //             }},
    //             1.1,    //賞金係数
    //             Auto.random,
    //             new EnumMap<Spell, Integer>(Spell.class)),
    // NullPoyoGoodPlus(   "うるおったバーサーカーグッド",
    //         MonsterRank.good,    //rank
    //         Attribute.Null,    //attribute
    //                 1,    //SpellSlot
    //                 false,//useSpecial
    //                 false,//useEscape
    //                 new EnumMap<MainStatus, Double>(MainStatus.class){{
    //                     double coef = 1.3;
    //                     put(MainStatus.hp, coef);
    //                     put(MainStatus.maxHp, coef);
    //                     put(MainStatus.mp, 1 / Math.pow(coef, 3));
    //                     put(MainStatus.maxMp, 1 / Math.pow(coef, 3));
    //                     put(MainStatus.a, coef);
    //                     put(MainStatus.s, coef);
    //                 }},
    //                 1.1,    //賞金係数
    //                 Auto.random,
    //                 new EnumMap<Spell, Integer>(Spell.class)),
    // NullPoyoGreatPlus(  "うるおったバーサーカーグレート",
    //         MonsterRank.great,    //rank
    //         Attribute.Null,    //attribute
    //                 1,    //SpellSlot
    //                 false,//useSpecial
    //                 false,//useEscape
    //                 new EnumMap<MainStatus, Double>(MainStatus.class){{
    //                     double coef = 1.3;
    //                     put(MainStatus.hp, coef);
    //                     put(MainStatus.maxHp, coef);
    //                     put(MainStatus.mp, 1 / Math.pow(coef, 3));
    //                     put(MainStatus.maxMp, 1 / Math.pow(coef, 3));
    //                     put(MainStatus.a, coef);
    //                     put(MainStatus.s, coef);
    //                 }},
    //                 1.1,    //賞金係数
    //                 Auto.random,
    //                 new EnumMap<Spell, Integer>(Spell.class)),
    // NullPoyoPerfectPlus("うるおったバーサーカーパーフェクト",
    //         MonsterRank.perfect,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             double coef = 1.3;
    //             put(MainStatus.hp, coef);
    //             put(MainStatus.maxHp, coef);
    //             put(MainStatus.mp, 1 / Math.pow(coef, 3));
    //             put(MainStatus.maxMp, 1 / Math.pow(coef, 3));
    //             put(MainStatus.a, coef);
    //             put(MainStatus.s, coef);
    //         }},
    //         1.1,    //賞金係数
    //         Auto.random,
    //         new EnumMap<Spell, Integer>(Spell.class)),
    // NullPoyoUltimatePlus( "うるおったバーサーカーアルティメット",
    //         MonsterRank.ultimate,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             double coef = 1.3;
    //             put(MainStatus.hp, coef);
    //             put(MainStatus.maxHp, coef);
    //             put(MainStatus.mp, 1 / Math.pow(coef, 3));
    //             put(MainStatus.maxMp, 1 / Math.pow(coef, 3));
    //             put(MainStatus.a, coef);
    //             put(MainStatus.s, coef);
    //         }},
    //         1.1,    //賞金係数
    //         Auto.random,
    //         new EnumMap<Spell, Integer>(Spell.class)),
    // NullPoyoGodPlus( "うるおったバーサーカーゴッド",
    //         MonsterRank.god,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             double coef = 1.3;
    //             put(MainStatus.hp, coef);
    //             put(MainStatus.maxHp, coef);
    //             put(MainStatus.mp, 1 / Math.pow(coef, 3));
    //             put(MainStatus.maxMp, 1 / Math.pow(coef, 3));
    //             put(MainStatus.a, coef);
    //             put(MainStatus.s, coef);
    //         }},
    //         1.1,    //賞金係数
    //         Auto.random,
    //         new EnumMap<Spell, Integer>(Spell.class)),
    AllPoyoMini("全ギアミニ",
            MonsterRank.mini,    //rank
            null,
            Attribute.Null,    //attribute
            4,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxMp, 2.0);
                put(MainStatus.mp, 2.0);
                put(MainStatus.d, 0.5);
            }},
            0,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.Wind, 1);
                this.put(Spell.Stone, 1);
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AllPoyoMiniPlus("全ギアミニ+",
            MonsterRank.miniPlus,    //rank
            AllPoyoMini,
            Attribute.Null,    //attribute
            4,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxMp, 2.0);
                put(MainStatus.mp, 2.0);
                put(MainStatus.d, 0.5);
            }},
            0,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.Wind, 1);
                this.put(Spell.Stone, 1);
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AllPoyo("全ギア",
            MonsterRank.normal,    //rank
            AllPoyoMiniPlus,
            Attribute.Null,    //attribute
            4,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxMp, 2.0);
                put(MainStatus.mp, 2.0);
                put(MainStatus.d, 0.5);
            }},
            0,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.Wind, 1);
                this.put(Spell.Stone, 1);
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AllPoyoPlus("全ギア+",
            MonsterRank.normalPlus,    //rank
            AllPoyo,
            Attribute.Null,    //attribute
            4,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxMp, 2.0);
                put(MainStatus.mp, 2.0);
                put(MainStatus.d, 0.5);
            }},
            0,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.Wind, 1);
                this.put(Spell.Stone, 1);
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AllPoyoGood("全ギアグッド",
            MonsterRank.good,    //rank
            AllPoyoPlus,
            Attribute.Null,    //attribute
            8,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxMp, 2.0);
                put(MainStatus.mp, 2.0);
                put(MainStatus.d, 0.5);
            }},
            0,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.Wind, 1);
                this.put(Spell.Stone, 1);
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AllPoyoGoodPlus("全ギアグッド+",
            MonsterRank.goodPlus,    //rank
            AllPoyoGood,
            Attribute.Null,    //attribute
            8,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxMp, 2.0);
                put(MainStatus.mp, 2.0);
                put(MainStatus.d, 0.5);
            }},
            0,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.Wind, 1);
                this.put(Spell.Stone, 1);
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AllPoyoGreat("全ギアグレート",
            MonsterRank.great,    //rank
            AllPoyoGoodPlus,
            Attribute.Null,    //attribute
            8,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxMp, 2.0);
                put(MainStatus.mp, 2.0);
                put(MainStatus.d, 0.5);
            }},
            0,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.Wind, 1);
                this.put(Spell.Stone, 1);
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AllPoyoGreatPlus("全ギアグレート+",
            MonsterRank.greatPlus,    //rank
            AllPoyoGreat,
            Attribute.Null,    //attribute
            8,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxMp, 2.0);
                put(MainStatus.mp, 2.0);
                put(MainStatus.d, 0.5);
            }},
            0,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.Wind, 1);
                this.put(Spell.Stone, 1);
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AllPoyoPerfect("全ギアパーフェクト",
            MonsterRank.perfect,    //rank
            AllPoyoGreatPlus,
            Attribute.Null,    //attribute
            8,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxMp, 2.0);
                put(MainStatus.mp, 2.0);
                put(MainStatus.d, 0.5);
            }},
            0,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.Wind, 1);
                this.put(Spell.Stone, 1);
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AllPoyoPerfectPlus("全ギアパーフェクト+",
            MonsterRank.perfectPlus,    //rank
            AllPoyoPerfect,
            Attribute.Null,    //attribute
            8,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxMp, 2.0);
                put(MainStatus.mp, 2.0);
                put(MainStatus.d, 0.5);
            }},
            0,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.Wind, 1);
                this.put(Spell.Stone, 1);
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AllPoyoUltimate("全ギアアルティメット",
            MonsterRank.ultimate,    //rank
            AllPoyoPerfectPlus,
            Attribute.Null,    //attribute
            8,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxMp, 2.0);
                put(MainStatus.mp, 2.0);
                put(MainStatus.d, 0.5);
            }},
            0,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.Wind, 1);
                this.put(Spell.Stone, 1);
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AllPoyoUltimatePlus("全ギアアルティメット+",
            MonsterRank.ultimatePlus,    //rank
            AllPoyoUltimate,
            Attribute.Null,    //attribute
            8,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxMp, 2.0);
                put(MainStatus.mp, 2.0);
                put(MainStatus.d, 0.5);
            }},
            0,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.Wind, 1);
                this.put(Spell.Stone, 1);
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AllPoyoGod("全ギアゴッド",
            MonsterRank.god,    //rank
            AllPoyoUltimatePlus,
            Attribute.Null,    //attribute
            12,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxMp, 2.0);
                put(MainStatus.mp, 2.0);
                put(MainStatus.d, 0.5);
            }},
            0,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.Wind, 1);
                this.put(Spell.Stone, 1);
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),
    AllPoyoGodPlus("全ギアゴッド+",
            MonsterRank.godPlus,    //rank
            AllPoyoGod,
            Attribute.Null,    //attribute
            12,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.maxMp, 2.0);
                put(MainStatus.mp, 2.0);
                put(MainStatus.d, 0.5);
            }},
            0,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.Fire, 1);
                this.put(Spell.Wind, 1);
                this.put(Spell.Stone, 1);
                this.put(Spell.Heal, 1);
                this.put(Spell.On_Joke, 1);
            }}),


    // AvoidancePoyoMini("避ギアミニ",
    //         MonsterRank.mini,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             put(MainStatus.e, 1.67);
    //         }},
    //         1,    //賞金係数
    //         Auto.aiRandom,
    //         new EnumMap<Spell, Integer>(Spell.class){{
    //         }}),
    // AvoidancePoyo( "避ギア",
    //         MonsterRank.normal,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             put(MainStatus.e, 1.67);
    //         }},
    //         1,    //賞金係数
    //         Auto.aiRandom,
    //         new EnumMap<Spell, Integer>(Spell.class){{
    //         }}),
    // AvoidancePoyoGood( "避ギアグッド",
    //         MonsterRank.good,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             put(MainStatus.e, 1.67);
    //         }},
    //         1,    //賞金係数
    //         Auto.aiRandom,
    //         new EnumMap<Spell, Integer>(Spell.class){{
    //         }}),
    // AvoidancePoyoGreat("避ギアグレート",
    //         MonsterRank.great,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             put(MainStatus.e, 1.67);
    //         }},
    //         1,    //賞金係数
    //         Auto.aiRandom,
    //         new EnumMap<Spell, Integer>(Spell.class){{
    //             this.put(Spell.Stone, 2);
    //             this.put(Spell.Quake, 1);
    //         }}),
    // AvoidancePoyoPerfect(  "避ギアパーフェクト",
    //         MonsterRank.perfect,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             put(MainStatus.e, 1.67);
    //         }},
    //         1,    //賞金係数
    //         Auto.aiRandom,
    //         new EnumMap<Spell, Integer>(Spell.class){{
    //         }}),
    // AvoidancePoyoUltimate( "避ギアアルティメット",
    //         MonsterRank.ultimate,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             put(MainStatus.e, 1.67);
    //         }},
    //         1,    //賞金係数
    //         Auto.aiRandom,
    //         new EnumMap<Spell, Integer>(Spell.class){{
    //         }}),
    // AvoidancePoyoGod( "避ギアゴッド",
    //         MonsterRank.god,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             put(MainStatus.e, 1.67);
    //         }},
    //         1,    //賞金係数
    //         Auto.aiRandom,
    //         new EnumMap<Spell, Integer>(Spell.class){{
    //         }}),

    // HpPoyo(   "でぶギア",
    //         MonsterRank.normal,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             put(MainStatus.hp, 5.0);
    //             put(MainStatus.maxHp, 5.0);
    //             put(MainStatus.a, 0.5);
    //             put(MainStatus.b, 0.0);
    //             put(MainStatus.s, 0.5);
    //         }},
    //         1,    //賞金係数
    //         Auto.aiRandom,
    //         new EnumMap<Spell, Integer>(Spell.class){{
    //         }}),
    // HpPoyoGood(   "でぶギアグッド",
    //         MonsterRank.good,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             put(MainStatus.hp, 5.0);
    //             put(MainStatus.maxHp, 5.0);
    //             put(MainStatus.a, 0.5);
    //             put(MainStatus.b, 0.0);
    //             put(MainStatus.s, 0.5);
    //         }},
    //         1,    //賞金係数 
    //         Auto.aiRandom,
    //         new EnumMap<Spell, Integer>(Spell.class){{
    //         }}),
    // HpPoyoGreat(  "でぶギアグレート",
    //         MonsterRank.great,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             put(MainStatus.hp, 5.0);
    //             put(MainStatus.maxHp, 5.0);
    //             put(MainStatus.a, 0.5);
    //             put(MainStatus.b, 0.0);
    //             put(MainStatus.s, 0.5);
    //         }},
    //         1,    //賞金係数
    //         Auto.aiRandom,
    //         new EnumMap<Spell, Integer>(Spell.class){{
    //         }}),
    // AtkPoyo(   "むきギア",
    //         MonsterRank.normal,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             put(MainStatus.hp, 0.5);
    //             put(MainStatus.maxHp, 0.5);
    //             put(MainStatus.a, 5.0);
    //             put(MainStatus.b, 0.0);
    //             put(MainStatus.s, 0.5);
    //         }},
    //         1,    //賞金係数
    //         Auto.aiRandom,
    //         new EnumMap<Spell, Integer>(Spell.class){{
    //         }}),
    // AtkPoyoGood(   "むきギアグッド",
    //         MonsterRank.good,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             put(MainStatus.hp, 0.5);
    //             put(MainStatus.maxHp, 0.5);
    //             put(MainStatus.a, 5.0);
    //             put(MainStatus.b, 0.0);
    //             put(MainStatus.s, 0.5);
    //         }},
    //         1,    //賞金係数
    //         Auto.aiRandom,
    //         new EnumMap<Spell, Integer>(Spell.class){{
    //         }}),
    // AtkPoyoGreat(  "むきギアグレート",
    //         MonsterRank.great,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             put(MainStatus.hp, 0.5);
    //             put(MainStatus.maxHp, 0.5);
    //             put(MainStatus.a, 5.0);
    //             put(MainStatus.b, 0.0);
    //             put(MainStatus.s, 0.5);
    //         }},
    //         1,    //賞金係数
    //         Auto.aiRandom,
    //         new EnumMap<Spell, Integer>(Spell.class){{
    //         }}),
    // SpdPoyo(   "ひょろギア",
    //         MonsterRank.normal,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             put(MainStatus.hp, 0.5);
    //             put(MainStatus.maxHp, 0.5);
    //             put(MainStatus.a, 0.5);
    //             put(MainStatus.b, 0.0);
    //             put(MainStatus.s, 5.0);
    //         }},
    //         1,    //賞金係数
    //         Auto.aiRandom,
    //         new EnumMap<Spell, Integer>(Spell.class){{
    //         }}),
    SpdPoyoGood(   "ひょろギアグッド",
            MonsterRank.good,    //rank
            null,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.hp, 0.5);
                put(MainStatus.maxHp, 0.5);
                put(MainStatus.a, 0.5);
                put(MainStatus.e, 0.0);
                put(MainStatus.s, 5.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
            }}),
    SpdPoyoPerfect(   "ひょろギアパーフェクト",
            MonsterRank.perfect,    //rank
            null,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.hp, 0.5);
                put(MainStatus.maxHp, 0.5);
                put(MainStatus.a, 0.5);
                put(MainStatus.e, 0.0);
                put(MainStatus.s, 5.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
            }}),
    // SpdPoyoGreat(  "ひょろギアグレート",
    //         MonsterRank.great,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             put(MainStatus.hp, 0.5);
    //             put(MainStatus.maxHp, 0.5);
    //             put(MainStatus.a, 0.5);
    //             put(MainStatus.b, 0.0);
    //             put(MainStatus.s, 5.0);
    //         }},
    //         1,    //賞金係数
    //         Auto.aiRandom,
    //         new EnumMap<Spell, Integer>(Spell.class){{
    //         }}),
    // KnifeMini("きりさき",//Miniステータス
    //         MonsterRank.mini,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             put(MainStatus.mp, 0.25);
    //             put(MainStatus.maxMp, 0.25);
    //             put(MainStatus.aNum, 2.0);
    //         }},
    //         1,    //賞金係数
    //         Auto.aiRandom,
    //         new EnumMap<Spell, Integer>(Spell.class)),
    // Knife("こまぎれ",//Normalステータス
    //         MonsterRank.normal,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             put(MainStatus.mp, 0.2);
    //             put(MainStatus.maxMp, 0.2);
    //             put(MainStatus.aNum, 3.0);
    //         }},
    //         1,    //賞金係数
    //         Auto.aiRandom,
    //         new EnumMap<Spell, Integer>(Spell.class)),
    // PoyoMini("ギアミニ",
    //         MonsterRank.mini,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             put(MainStatus.b, 1.67);
    //         }},
    //         1,    //賞金係数
    //         Auto.aiRandom,
    //         new EnumMap<Spell, Integer>(Spell.class)),
    // Poyo("ギアギア",
    //         MonsterRank.normal,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             put(MainStatus.b, 1.67);
    //         }},
    //         1,    //賞金係数
    //         Auto.aiRandom,
    //         new EnumMap<Spell, Integer>(Spell.class)),
    // RainbowPoyoMini("虹ギアミニ",//Miniステータス
    //         MonsterRank.mini,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             put(MainStatus.mp, 2.0);
    //             put(MainStatus.maxMp, 2.0);
    //             put(MainStatus.b, 0.0);
    //         }},
    //         1,    //賞金係数
    //         Auto.aiRandom,
    //         new EnumMap<Spell, Integer>(Spell.class){{
    //             this.put(Spell.Fire, 1);
    //             this.put(Spell.Stone, 1);
    //             this.put(Spell.Wind, 1);
    //             this.put(Spell.Cure, 1);
    //         }}),
    // RainbowPoyo("虹ギア",//Normalステータス
    //         MonsterRank.normal,    //rank
    //         Attribute.Null,    //attribute
    //         4,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //             put(MainStatus.mp, 2.0);
    //             put(MainStatus.maxMp, 2.0);
    //             put(MainStatus.b, 0.0);
    //         }},
    //         1,    //賞金係数
    //         Auto.aiRandom,
    //         new EnumMap<Spell, Integer>(Spell.class){{
    //             this.put(Spell.Fire, Spell.maxLevel);
    //             this.put(Spell.Stone, Spell.maxLevel);
    //             this.put(Spell.Wind, Spell.maxLevel);
    //             this.put(Spell.Cure, Spell.maxLevel);
    //         }}),
    Special(   "スぺドラ",//Goodステータス
            MonsterRank.good,    //rank
            null,
            Attribute.Null,    //attribute
                1,    //SpellSlot
                false,//useSpecial
                false,//useEscape
                new EnumMap<MainStatus, Double>(MainStatus.class){{
                    put(MainStatus.a, 1.5);
                    put(MainStatus.s, 1 / 1.5);
                }},
                1.4,    //賞金係数
                1,    // レベルアップする訓練の列数
                Auto.enemyMCTS,
                new EnumMap<Spell, Integer>(Spell.class){{
                    this.put(Spell.SpecialField, 1);
                }}),
    Turtle(   "鈍足な亀",
            MonsterRank.perfect,    //rank
            null,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                // put(MainStatus.hp, 3.0);
                // put(MainStatus.maxHp, 3.0);
                // put(MainStatus.mp, 4.0);
                // put(MainStatus.maxMp, 4.0);
                // put(MainStatus.a, 2.0);
                // put(MainStatus.b, 0.0);
                // put(MainStatus.s, 0.25);
                put(MainStatus.hp, 2.0);
                put(MainStatus.maxHp, 2.0);
                put(MainStatus.mp, 0.5);
                put(MainStatus.maxMp, 0.5);
                put(MainStatus.a, 2.0);
                put(MainStatus.e, 0.0);
                put(MainStatus.s, 0.25);
            }},
            1.4,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.enemyMCTS,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.ReverseField, 1);
            }}),
    Gorst("怨念玉",//Goodステータス
            MonsterRank.good,    //rank
            null,
            Attribute.Null,    //attribute
        5,    //SpellSlot
        false,//useSpecial
        false,//useEscape
        new EnumMap<MainStatus, Double>(MainStatus.class){{
        }},
        1.4,    //賞金係数
        1,    // レベルアップする訓練の列数
        Auto.enemyMCTS,
        new EnumMap<Spell, Integer>(Spell.class){{
            this.put(Spell.Poison, 1);
            this.put(Spell.Stomatitis, 1);
            this.put(Spell.Nervous, 1);
            this.put(Spell.Bond, 1);
            this.put(Spell.Lag, 1);
        }}),
    GamblerGood(   "クージャー",
            MonsterRank.good,    //rank
            null,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.a, 0.5);
                put(MainStatus.s, 2.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.KJA, 1);
            }}),
    GamblerPerfect(   "クージャー改",
            MonsterRank.perfect,    //rank
            null,
            Attribute.Null,    //attribute
            1,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.a, 0.5);
                put(MainStatus.s, 2.0);
            }},
            1,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.aiRandom,
            new EnumMap<Spell, Integer>(Spell.class){{
                this.put(Spell.KJA, Spell.maxLevel);
            }}),
    Dark(   "闇商人",//Perfectステータス
            MonsterRank.perfect,    //rank
            null,
            Attribute.Null,    //attribute
            5,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.e, 0.0);
                put(MainStatus.aNum, 2.0);
            }},
            2,    //賞金係数
            1,    // レベルアップする訓練の列数
            Auto.enemyMCTS,
            new EnumMap<Spell, Integer>(Spell.class){{
                // this.put(Spell.Trauma, 1);
                // this.put(Spell.Chaos, 1);
                this.put(Spell.On_StateChange, 1);
                this.put(Spell.On_SpellReflect, 1);
                // this.put(Spell.On_MoveCounter, 1);
            }}),
    // Escape(   "ぴよぴよ",//Perfectステータス
    //         MonsterRank.perfect,    //rank
    //         Attribute.Null,    //attribute
    //             1,    //SpellSlot
    //             false,//useSpecial
    //             true,//useEscape
    //             new EnumMap<MainStatus, Double>(MainStatus.class){{
    //                 put(MainStatus.hp, 2.0);
    //                 put(MainStatus.maxHp, 2.0);
    //                 put(MainStatus.mp, 0.25);
    //                 put(MainStatus.maxMp, 0.25);
    //                 put(MainStatus.a, 0.5);
    //                 put(MainStatus.b, 1.67);
    //                 put(MainStatus.s, 2.0);
    //             }},
    //             2,    //賞金係数
    //             Auto.aiRandom,
    //             new EnumMap<Spell, Integer>(Spell.class){{
    //                 this.put(Spell.Cure, 1);
    //             }}),
    // BoyoMini(  "ぼよぼよミニ",
    //         MonsterRank.mini,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //         }},
    //         0.7,    //賞金係数
    //         Auto.random,
    //         new EnumMap<Spell, Integer>(Spell.class)),
    // Boyo(  "ぼよぼよ",
    //         MonsterRank.normal,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //         }},
    //         0.7,    //賞金係数
    //         Auto.random,
    //         new EnumMap<Spell, Integer>(Spell.class)),
    // BoyoGood(  "ぼよぼよグッド",
    //         MonsterRank.good,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //         }},
    //         0.7,    //賞金係数
    //         Auto.random,
    //         new EnumMap<Spell, Integer>(Spell.class)),
    // BoyoGreat( "ぼよぼよグレート",
    //         MonsterRank.great,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //         }},
    //         0.7,    //賞金係数
    //         Auto.random,
    //         new EnumMap<Spell, Integer>(Spell.class)),
    // BoyoPerfect(   "ぼよぼよパーフェクト",
    //         MonsterRank.perfect,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //         }},
    //         0.7,    //賞金係数
    //         Auto.random,
    //         new EnumMap<Spell, Integer>(Spell.class)),
    // BoyoUltimate( "ぼよぼよアルティメット",
    //         MonsterRank.ultimate,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //         }},
    //         0.7,    //賞金係数
    //         Auto.random,
    //         new EnumMap<Spell, Integer>(Spell.class)),
    // BoyoGod( "ぼよぼよゴッド",
    //         MonsterRank.god,    //rank
    //         Attribute.Null,    //attribute
    //         1,    //SpellSlot
    //         false,//useSpecial
    //         false,//useEscape
    //         new EnumMap<MainStatus, Double>(MainStatus.class){{
    //         }},
    //         0.7,    //賞金係数
    //         Auto.random,
    //         new EnumMap<Spell, Integer>(Spell.class)),
    Tutorial( "チュートリアルモンスター",
            MonsterRank.tutorial,    //rank
            null,
            Attribute.Null,    //attribute
            0,    //SpellSlot
            false,//useSpecial
            false,//useEscape
            new EnumMap<MainStatus, Double>(MainStatus.class){{
                put(MainStatus.hp, 2.0);
                put(MainStatus.maxHp, 2.0);
                put(MainStatus.a, 0.5);
            }},
            1,    //賞金係数
            0,    // レベルアップする訓練の列数
            Auto.cycle,
            new int[]{1,2,3},
            new EnumMap<Spell, Integer>(Spell.class){{
            }}),
    ;
    public final String jName;// 名前
    public final MonsterRank rank;// ランク（基礎ステータスと落とす金を決定）
    public final Monster rankDownMonster;// ワンランク下の同系統のモンスター
    public final Attribute attribute;// 必殺技
    public final int spellSlotNum;// 呪文スロット数
    public final boolean useSpecial;// 必殺技を使えるかどうか
    public final boolean useEscape;// 逃げれるかどうか
    public final Map<MainStatus, Integer> MAIN_STATUS;// ステータス
    public final Map<Spell, Integer> spellLevel;// 呪文レベル
    private final double moneyRate;// 金係数
    public final int trainLevelUpRows;// 訓練レベルの上がる列数
    public final Auto auto;// 行動選択方法
    public int[] cycleActions;// 行動サイクル（サイクル型のみ使用）

//     private Monster(String name, MonsterRank rank, Attribute attribute ,int spellSlotNum, boolean useSpecial, boolean useEscape, int mhp, int mmp, int a, int b, int s, int aNum, double moneyRate, Auto auto, Map<Spell, Integer> spellLevel){
//         this.jName = name;
//         this.rank = rank;
//         this.attribute = attribute;
//         this.spellSlotNum = spellSlotNum;
//         this.useSpecial = useSpecial;
//         this.useEscape = useEscape;
//         this.MAIN_STATUS = Collections.unmodifiableMap(new EnumMap<>(MainStatus.class){{put(MainStatus.maxHp, mhp); put(MainStatus.hp, mhp);put(MainStatus.maxMp, mmp);put(MainStatus.mp, mmp);put(MainStatus.a, a);put(MainStatus.b, b);put(MainStatus.s, s);put(MainStatus.aNum, aNum);}});
//         spellLevel.put(Spell.NULL, 0);
//         this.spellLevel = Collections.unmodifiableMap(spellLevel);
//         this.moneyRate = moneyRate;
//         this.auto = auto;
//         this.cycleActions = null;
//     }
    // 非サイクル行動モンスター
    private Monster(String name, MonsterRank rank, Monster rankDownMonster, Attribute attribute ,int spellSlotNum, boolean useSpecial, boolean useEscape, Map<MainStatus, Double> mainStatusCoef, double moneyRate, int trainLevelUpRows, Auto auto, Map<Spell, Integer> spellLevel){
        this.jName = name;
        this.rank = rank;
        this.rankDownMonster = rankDownMonster;
        this.attribute = attribute;
        this.spellSlotNum = spellSlotNum;
        this.useSpecial = useSpecial;
        this.useEscape = useEscape;
        this.MAIN_STATUS = new EnumMap<>(MainStatus.class){{
            for(MainStatus key : MainStatus.values()){
                if(mainStatusCoef.containsKey(key)){
                    put(key, (int)(rank.baseMainStatus.get(key) * mainStatusCoef.get(key)));
                }else{
                    put(key, rank.baseMainStatus.get(key));
                }
            }
        }};
        spellLevel.put(Spell.NULL, 0);
        this.spellLevel = Collections.unmodifiableMap(spellLevel);
        this.moneyRate = moneyRate;
        this.trainLevelUpRows = trainLevelUpRows;
        this.auto = auto;
        this.cycleActions = null;
    }
//     private Monster(String name, MonsterRank rank, Attribute attribute ,int spellSlotNum, boolean useSpecial, boolean useEscape, int mhp, int mmp, int a, int b, int s, int aNum, double moneyRate, Auto auto, int[] cycleActions, Map<Spell, Integer> spellLevel){
//         this.jName = name;
//         this.rank = rank;
//         this.attribute = attribute;
//         this.spellSlotNum = spellSlotNum;
//         this.useSpecial = useSpecial;
//         this.useEscape = useEscape;
//         this.MAIN_STATUS = Collections.unmodifiableMap(new EnumMap<>(MainStatus.class){{put(MainStatus.maxHp, mhp); put(MainStatus.hp, mhp);put(MainStatus.maxMp, mmp);put(MainStatus.mp, mmp);put(MainStatus.a, a);put(MainStatus.b, b);put(MainStatus.s, s);put(MainStatus.aNum, aNum);}});
//         spellLevel.put(Spell.NULL, 0);
//         this.spellLevel = Collections.unmodifiableMap(spellLevel);
//         this.moneyRate = moneyRate;
//         this.auto = auto;
//         this.cycleActions = cycleActions;
//     }
    // サイクル行動モンスター
    private Monster(String name, MonsterRank rank, Monster rankDownMonster, Attribute attribute ,int spellSlotNum, boolean useSpecial, boolean useEscape, Map<MainStatus, Double> mainStatusCoef, double moneyRate, int trainLevelUpRows, Auto auto, int[] cycleActions, Map<Spell, Integer> spellLevel){
        this(name, rank, rankDownMonster, attribute, spellSlotNum, useSpecial, useEscape, mainStatusCoef, moneyRate, trainLevelUpRows, auto, spellLevel);
        this.cycleActions = cycleActions;
    }
//     private Monster(String name, MonsterRank rank, Attribute attribute, int spellSlotNum, boolean useSpecial, boolean useEscape, int mhp, int hp, int mmp, int mp, int a, int b, int s, int aNum, double moneyRate, Auto auto, Map<Spell, Integer> spellLevel){
//         this.jName = name;
//         this.rank = rank;
//         this.attribute = attribute;
//         this.spellSlotNum = spellSlotNum;
//         this.useSpecial = useSpecial;
//         this.useEscape = useEscape;
//         this.MAIN_STATUS = Collections.unmodifiableMap(new EnumMap<>(MainStatus.class){{put(MainStatus.maxHp, mhp); put(MainStatus.hp, hp);put(MainStatus.maxMp, mmp);put(MainStatus.mp, mp);put(MainStatus.a, a);put(MainStatus.b, b);put(MainStatus.s, s);put(MainStatus.aNum, aNum);}});
//         spellLevel.put(Spell.NULL, 0);
//         this.spellLevel = Collections.unmodifiableMap(spellLevel);
//         this.moneyRate = moneyRate;
//         this.auto = auto;
//         this.cycleActions = null;
//     }

    // ステータスを取得
    public int[] getMainStatusArray(){
        MainStatus[] values = MainStatus.values();
        int[] mainStatus = new int[MainStatus.NUM];
        for(int i = 0; i < MainStatus.NUM; i++){
            mainStatus[i] = this.MAIN_STATUS.get(values[i]);
        }
        return mainStatus;
    }

    // 総合力を取得
    public int generalPower(){
        double pow = 1.0;
        Map<MainStatus, Integer> state = this.MAIN_STATUS;
        pow *= state.get(MainStatus.a) * (1.0 - 0.4 * Math.pow(0.7, this.spellLevel.size()));
        // pow *= state.get(MainStatus.aNum);
        // pow *= 100.0 / (double)(100-state.get(MainStatus.e));
        pow *= Math.sqrt(state.get(MainStatus.d)/100.0);
        pow *= state.get(MainStatus.s);
        pow *= state.get(MainStatus.maxHp) * (1.0 - 0.4 * Math.pow(0.7, this.spellLevel.size()));
        pow *= Math.pow(state.get(MainStatus.maxMp), 0.5);
        pow *= useSpecial ? 2.0 : 1.0;
        return (int)(pow / 100000.0);
    }

    /*public static int easyNUM(){
        int count = 0;
        for(Monster monster:values()){
            if(MonsterRank.easyRank().contains(monster.rank)){
                count++;
            }
        }
        return count;
    }

    public static Monster[] easyValues(){
        Monster[] easyMonsters = new Monster[Monster.easyNUM()];
        int count = 0;
        for(Monster monster:values()){
            if(MonsterRank.easyRank().contains(monster.rank)){
                easyMonsters[count] = monster;
                count++;
            }
        }
        return easyMonsters;
    }*/

    // 落とす金を取得
    public int getMoney(){
        return (int)(this.moneyRate * this.rank.money);
    }
    
    // モンスターの数
    public static final int NUM = values().length;

}
