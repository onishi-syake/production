package data.enemy;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import battle.CalculateDamage;
import battle.InputAction.Auto;
import battle.state_change.ChangeBattleStatus;
import battle.state_change.ChangeBattleStatus.StateChangeStatus;
import battle.state_change.ChangeBattleStatus.StatusCounter;
import character.Character.MainStatus;
import data.action.Spell;

public enum BaseMonster {
    red("レッド",
        MonsterCategory.adventurer,
        1000,
        0,
        Auto.aiRandom,
        4 + Spell.Fire.ordinal(),
        false,
        null,
        1,
        new HashMap<MainStatus, Integer>(){{
            put(MainStatus.a, 1);
        }},
        new HashMap<Spell, Integer>(){{
            put(Spell.Fire, 1);
            // put(Spell.On_Joke, 1);
        }},
        new ArrayList<>(){{
            
        }}),
    brown("ブラウン",
        MonsterCategory.adventurer,
        1000,
        0,
        Auto.aiRandom,
        4 + Spell.Stone.ordinal(),
        false,
        null,
        1,
        new HashMap<MainStatus, Integer>(){{
            put(MainStatus.maxHp, 1);
            put(MainStatus.hp, 1);
        }},
        new HashMap<Spell, Integer>(){{
            put(Spell.Stone, 1);
            // put(Spell.On_Joke, 1);
        }},
        new ArrayList<>(){{
            
        }}),
    green("グリーン",
        MonsterCategory.adventurer,
        1000,
        0,
        Auto.aiRandom,
        4 + Spell.Wind.ordinal(),
        false,
        null,
        1,
        new HashMap<MainStatus, Integer>(){{
            put(MainStatus.s, 1);
        }},
        new HashMap<Spell, Integer>(){{
            put(Spell.Wind, 1);
            // put(Spell.On_Joke, 1);
        }},
        new ArrayList<>(){{
            
        }}),
    berserkerHP("ライフ・バーサーカー",
        MonsterCategory.berserker,
        1000,
        2,
        Auto.aiRandom,
        1,// 攻撃
        false,
        null,
        // new HashMap<Integer, Integer>(){{
        //     put(1, 2);
        //     put(2, 1);
        //     put(3, 1);
        // }},
        1,
        new HashMap<MainStatus, Integer>(){{
            put(MainStatus.maxHp, 1);
            put(MainStatus.hp, 1);
        }},
        new HashMap<Spell, Integer>(){{
            put(Spell.Poison, 1);
        }},
        new ArrayList<>(){{
            // List<Map<StateChangeStatus, Map<StatusCounter, Integer>>>
            add(new EnumMap<>(StateChangeStatus.class){{
                put(StateChangeStatus.A, new EnumMap<>(StatusCounter.class){{
                    put(StatusCounter.turnCount, 10.0);
                    put(StatusCounter.buffRate, -200.0 / 3);
                }});
            }});
        }}),
    berserkerA("パワー・バーサーカー",
        MonsterCategory.berserker,
        1000,
        2,
        Auto.aiRandom,
        1,// 攻撃
        false,
        null,
        // new HashMap<Integer, Integer>(){{
        //     put(1, 2);
        //     put(2, 1);
        //     put(3, 1);
        // }},
        1,
        new HashMap<MainStatus, Integer>(){{
            put(MainStatus.a, 1);
        }},
        new HashMap<Spell, Integer>(){{
            put(Spell.Stomatitis, 1);
        }},
        new ArrayList<>(){{
            // List<Map<StateChangeStatus, Map<StatusCounter, Integer>>>
            add(new EnumMap<>(StateChangeStatus.class){{
                put(StateChangeStatus.A, new EnumMap<>(StatusCounter.class){{
                    put(StatusCounter.turnCount, 10.0);
                    put(StatusCounter.buffRate, -200.0 / 3);
                }});
            }});
        }}),
    berserkerS("スピード・バーサーカー",
        MonsterCategory.berserker,
        1000,
        2,
        Auto.aiRandom,
        1,// 攻撃
        false,
        null,
        // new HashMap<Integer, Integer>(){{
        //     put(1, 2);
        //     put(2, 1);
        //     put(3, 1);
        // }},
        1,
        new HashMap<MainStatus, Integer>(){{
            put(MainStatus.s, 1);
        }},
        new HashMap<Spell, Integer>(){{
            put(Spell.Bond, 1);
        }},
        new ArrayList<>(){{
            add(new EnumMap<>(StateChangeStatus.class){{
                put(StateChangeStatus.A, new EnumMap<>(StatusCounter.class){{
                    put(StatusCounter.turnCount, 10.0);
                    put(StatusCounter.buffRate, -200.0 / 3);
                }});
            }});
        }}),
        jewelryRed(red, true),
        jewelryBrown(brown, true),
        jewelryGreen(green, true),
        jewelryBerserkerHP(berserkerHP, true),
        jewelryBerserkerA(berserkerA, true),
        jewelryBerserkerS(berserkerS, true),
        nakedRed(red, false),
        nakedBrown(brown, false),
        nakedGreen(green, false),
        nakedBerserkerHP(berserkerHP, false),
        nakedBerserkerA(berserkerA, false),
        nakedBerserkerS(berserkerS, false),
    ;

    public final String jName;// 名前
    public final MonsterCategory category;// 種類
    public final int money;// 金
    public final int trainLevelUpRows;// 訓練レベルの上がる列数
    public final Auto auto;// 行動選択方法
    public final int firstAction;// 初手の行動
    public final Map<Integer, Integer> biasedActions;// 重み付き優先行動（keyが行動、valueが割合）
    public final boolean nonInitialNervous;// 初手緊張状態なしかどうか
    public final int spellSlotNum;// 呪文スロット数
    public final Map<MainStatus, Integer> MAIN_STATUS;// ステータス
    public final Map<MainStatus, Integer> MAIN_STATUS_ONE_UP;// 1レべ上がったステータス
    public final Map<MainStatus, Integer> expertStatusLevel;// 得意ステータス
    public final Map<Spell, Integer> spellLevel;// 呪文レベル
    public final List<Map<StateChangeStatus, Map<StatusCounter, Double>>> initialStateChangeStatus;// 初期バフ・デバフ

    private BaseMonster(String jName, MonsterCategory category, int money, int trainLevelUpRows, Auto auto, int firstAction, boolean nonInitialNervous,
            Map<Integer, Integer> biasedActions, int spellSlotNum, Map<MainStatus, Integer> expertStatusLevel, Map<Spell, Integer> spellLevel, 
            List<Map<StateChangeStatus, Map<StatusCounter, Double>>> initialStateChangeStatus){

        Map<MainStatus, Integer> baseBerserkerStatus = new HashMap<>(){{
            put(MainStatus.hp, 300);
            put(MainStatus.maxHp, 300);
            put(MainStatus.mp, 8);
            put(MainStatus.maxMp, 8);
            put(MainStatus.a, 450);
            put(MainStatus.d, 100);
            put(MainStatus.e, 0);
            put(MainStatus.s, 15);
            put(MainStatus.aNum, 1);
        }};

        Map<MainStatus, Integer> baseBerserkerStatusOneUp = new HashMap<>(){{
            put(MainStatus.hp, 400);
            put(MainStatus.maxHp, 400);
            put(MainStatus.mp, 8);
            put(MainStatus.maxMp, 8);
            put(MainStatus.a, 600);
            put(MainStatus.d, 100);
            put(MainStatus.e, 0);
            put(MainStatus.s, 20);
            put(MainStatus.aNum, 1);
        }};

        Map<MainStatus, Integer> baseAdventurerStatus = new HashMap<>(){{
            put(MainStatus.hp, 250);
            put(MainStatus.maxHp, 250);
            put(MainStatus.mp, 10);
            put(MainStatus.maxMp, 10);
            put(MainStatus.a, 50);
            put(MainStatus.d, 100);
            put(MainStatus.e, 0);
            put(MainStatus.s, 50);
            put(MainStatus.aNum, 1);
        }};

        Map<MainStatus, Integer> baseAdventurerStatusOneUp = new HashMap<>(){{
            put(MainStatus.hp, 350);
            put(MainStatus.maxHp, 350);
            put(MainStatus.mp, 10);
            put(MainStatus.maxMp, 10);
            put(MainStatus.a, 70);
            put(MainStatus.d, 100);
            put(MainStatus.e, 0);
            put(MainStatus.s, 70);
            put(MainStatus.aNum, 1);
        }};

        if(category == MonsterCategory.berserker){
            this.MAIN_STATUS = baseBerserkerStatus;
            this.MAIN_STATUS_ONE_UP = baseBerserkerStatusOneUp;
        }else if(category == MonsterCategory.adventurer){
            this.MAIN_STATUS = baseAdventurerStatus;
            this.MAIN_STATUS_ONE_UP = baseAdventurerStatusOneUp;
        }else{
            this.MAIN_STATUS = baseAdventurerStatus;
            this.MAIN_STATUS_ONE_UP = baseAdventurerStatusOneUp;
            System.out.println("error make baseMonster Status");
        }
        this.jName = jName;
        this.category = category;
        this.money = money;
        this.trainLevelUpRows = trainLevelUpRows;
        this.auto = auto;
        this.firstAction = firstAction;
        this.biasedActions = biasedActions;
        this.nonInitialNervous = nonInitialNervous;
        this.spellSlotNum = spellSlotNum;
        this.expertStatusLevel = expertStatusLevel;
        this.spellLevel = new HashMap<>(spellLevel);
        this.initialStateChangeStatus = ChangeBattleStatus.deepCopyStateChangeStatus(initialStateChangeStatus);
    }

    // 「宝石の」・「裸の」用のコンストラクタ
    private BaseMonster(BaseMonster base, boolean isJewelry){
        this.jName = (isJewelry ? "宝石の " : "裸の") + base.jName;
        this.category = base.category;
        this.money = base.money;
        this.trainLevelUpRows = base.trainLevelUpRows;
        this.auto = base.auto;
        this.firstAction = base.firstAction;
        this.biasedActions = base.biasedActions == null ? null : new HashMap<>(base.biasedActions);
        this.nonInitialNervous = base.nonInitialNervous;
        this.spellSlotNum = base.spellSlotNum;
        this.MAIN_STATUS = new HashMap<>(base.MAIN_STATUS);
        this.MAIN_STATUS_ONE_UP = new HashMap<>(base.MAIN_STATUS_ONE_UP);
        this.MAIN_STATUS.replace(MainStatus.d, (isJewelry ? 200 : 50));
        this.expertStatusLevel = new HashMap<>(base.expertStatusLevel);
        this.spellLevel = new HashMap<>(base.spellLevel);
        this.initialStateChangeStatus = ChangeBattleStatus.deepCopyStateChangeStatus(base.initialStateChangeStatus);
    }

    public static final double levelStatusCoef = 1.2;
    public static final int statusMoneyExponent = 2;
    public int[] mainStatusArray(int level){
        int[] mainStatusArray = new int[MainStatus.NUM];
        int status;
        MainStatus category;
        int categoryLevel;
        int expertStatusLevelBuff;
        boolean oneUp;
        for(int i = 0; i < MainStatus.NUM; i++){
            category = MainStatus.values()[i];
            expertStatusLevelBuff = this.expertStatusLevel.containsKey(category) ? this.expertStatusLevel.get(category) : 0;
            categoryLevel = level + expertStatusLevelBuff;
            oneUp = categoryLevel % 2 == 1;
            status = oneUp ? this.MAIN_STATUS_ONE_UP.get(category) : this.MAIN_STATUS.get(category);
            if(category == MainStatus.maxHp || category == MainStatus.hp || category == MainStatus.a || category == MainStatus.s){
                status *= (int)Math.round(Math.pow(2, categoryLevel / 2));
            }
            mainStatusArray[i] = status;
        }
        return mainStatusArray;
    }
}
