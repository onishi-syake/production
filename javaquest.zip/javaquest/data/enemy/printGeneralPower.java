package data.enemy;

import character.Enemy;

public class printGeneralPower {
    public static void main(String[] args) {
        for(BaseMonster monster : BaseMonster.values()){
            System.out.println(monster.jName + new Enemy(monster, 1, 0).generalPower(true));
        }
    }
}
