package data.enemy;

public enum MonsterCategory {
    berserker,
    adventurer,
}
