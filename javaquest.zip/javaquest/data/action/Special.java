package data.action;

import java.util.Random;
import java.util.Scanner;

import battle.state_change.ChangeActionState;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import battle.state_change.ChangeField.Field;
import battle.state_change.ChangeField.FieldCounter;
import battle.CalculateDamage;
import battle.State;
import battle.InputAction.Action;
import character.Character;
import character.Character.BattleStatus;
import character.Character.MainStatus;
import character.Character.Attribute;
import log.BattleTemporaryLog;
import log.OneTurnBattleLog.Success;
import text.Print;

public enum Special {
    SpecialAttack(  "スペシャルアタック",
                    0,//priority
                    "通常攻撃の 5 倍の威力で攻撃する",
                    5.0,100,CalculateDamage.BASE_VARIANCE_RATE,true,true,true){
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, boolean changeAttribute, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            Character actor = state.getPlayer(actor_is_player1);
            Character target = state.getPlayer(target_is_player1);
            Print.println(actor.getJName() + "の" + SpecialAttack.jName + "！", true, Print.middleSpeed, text);
            Print.println("怒涛の 5 連撃！！", true, Print.middleSpeed, text);
            int hit = CalculateDamage.attackProcess((int)(actor.getBattleStatus().get(BattleStatus.a) * getDamageRate()), 1, getHitRate(), getRandomRate(), true, getUseTension(), true, getCanDefense(), true, true, state, actor_is_player1, target_is_player1, getAttack(), log, text, rand, scanner);
            // if(changeAttribute){
            //     actor.setAttribute(Attribute.A);
            //     Print.println("", true, Print.highSpeed, text);
            //     Print.println(actor.getJName() + "の属性が攻撃属性になった！", true, Print.middleSpeed, text);
            // }
            if(actor.getStateAction().get(ActionState.oldChargeSpecial).get(ActionStateCounter.flag) != 1 && state.getField().get(Field.SpecialField).get(FieldCounter.flag) != 1){
                actor.getStateAction().get(ActionState.newChargeSpecial).replace(ActionStateCounter.flag, 0);
                actor.getStateAction().get(ActionState.newChargeSpecial).replace(ActionStateCounter.count, 0);
            }
            log.setHit(actor_is_player1, hit);
            log.setSuccess(actor_is_player1, hit != 0, Success.sucSAttack);
        }
    },
    SpecialDefense( "カウンターシールド",
                    5,//priority
                    "相手の攻撃を完全に無効化し、スペシャルアタックで反撃する"){
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, boolean changeAttribute, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            ChangeActionState.onset(state, !target_is_player1, target_is_player1, ActionState.SpecialDefense, log, text, scanner, rand);
            Character actor = state.getPlayer(actor_is_player1);
            Print.println(actor.getJName() + "の" + SpecialDefense.jName + "！", true, Print.middleSpeed, text);
            // if(changeAttribute){
            //     actor.setAttribute(Attribute.D);
            //     Print.println(actor.getJName() + "の属性が防御属性になった！", true, Print.middleSpeed, text);
            // }
            if(actor.getStateAction().get(ActionState.oldChargeSpecial).get(ActionStateCounter.flag) != 1 && state.getField().get(Field.SpecialField).get(FieldCounter.flag) != 1){
                actor.getStateAction().get(ActionState.newChargeSpecial).replace(ActionStateCounter.flag, 0);
                actor.getStateAction().get(ActionState.newChargeSpecial).replace(ActionStateCounter.count, 0);
            }
        }
    },
    SpecialTension( "フルチャージ",
                    -1,//priority
                    "通常の溜めるに加えて、HP・MPが全回復し、能力減少効果・状態異常（緊張状態を除く）を全回復する"){
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, boolean changeAttribute, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            Print.println(state.getPlayer(actor_is_player1).getJName() + "の" + SpecialTension.jName + "！", true, Print.middleSpeed, text);
            Print.println("", true, Print.highSpeed, text);
            Print.nextLine(scanner, text);
            ChangeActionState.onset(state, !target_is_player1, target_is_player1, ActionState.SpecialTension, log, text, scanner, rand);
            Character actor = state.getPlayer(actor_is_player1);
            // if(changeAttribute){
            //     actor.setAttribute(Attribute.C);
            //     Print.println("", true, Print.highSpeed, text);
            //     Print.println(actor.getJName() + "の属性が溜める属性になった！", true, Print.middleSpeed, text);
            // }
            if(actor.getStateAction().get(ActionState.oldChargeSpecial).get(ActionStateCounter.flag) != 1 && state.getField().get(Field.SpecialField).get(FieldCounter.flag) != 1){
                actor.getStateAction().get(ActionState.newChargeSpecial).replace(ActionStateCounter.flag, 0);
                actor.getStateAction().get(ActionState.newChargeSpecial).replace(ActionStateCounter.count, 0);
            }
        }
    }
    ;
    //フィールド
    public final String jName;// 名前
    public final int priority;// 行動優先度
    public final String explain;// 説明
    //コンストラクタ
    private Special(String name, int priority, String explain){
        this.jName = name;
        this.priority = priority;
        this.explain = explain;
    }
    //攻撃技のフィールド
    private double damageRate;// ダメージ倍率
    private int hitRate;// 命中率（％）（今は必中）
    private double randomRate;// ダメージの振れ幅（今はなし）
    private boolean attack;// 攻撃であるか否か（溜める失敗に関わる）
    private boolean useTension;// テンションを使用する攻撃かどうか
    private boolean canDefense;// 防御可能かどうか

    public double getDamageRate(){
        return this.damageRate;
    }
    public int getHitRate(){
        return this.hitRate;
    }
    public double getRandomRate(){
        return this.randomRate;
    }
    public boolean getAttack(){
        return this.attack;
    }
    public boolean getUseTension(){
        return this.useTension;
    }
    public boolean getCanDefense(){
        return this.canDefense;
    }
    //攻撃技のコンストラクタ
    private Special(String name, int priority, String explain,
                    double damageRate, int hitRate, double randomRate, 
                    boolean attack, boolean useTension, boolean canDefense){
        this(name, priority, explain);
        this.damageRate = damageRate;
        this.hitRate = hitRate;
        this.randomRate = randomRate;
        this.attack = attack;
        this.useTension = useTension;
        this.canDefense = canDefense;
    }
    //処理の抽象メソッド
    public abstract void execute(State state, boolean actor_is_player1, boolean target_is_player1, boolean changeAttribute, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner);

    //必殺技の総数
    public static final int NUM = values().length;
}
