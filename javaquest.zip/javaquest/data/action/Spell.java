package data.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import battle.state_change.ChangeAbnormalState;
import battle.state_change.ChangeActionState;
import battle.state_change.ChangeAbnormalState.AbnormalStateCounter;
import battle.state_change.ChangeAbnormalState.AbnormalState;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import battle.state_change.ChangeBattleStatus;
import battle.state_change.ChangeField;
import battle.state_change.ChangeBattleStatus.StateChangeStatus;
import battle.state_change.ChangeBattleStatus.StatusCounter;
import battle.state_change.ChangeField.Field;
import battle.state_change.ChangeWeather;
import battle.state_change.ChangeWeather.Weather;
import battle.state_change.ChangeWeather.WeatherRelation;
import battle.CalculateDamage;
import battle.ExecuteAction;
import battle.State;
import battle.InputAction.Action;
import character.Character;
import character.Character.MainStatus;
import log.BattleTemporaryLog;
import text.Print;
import character.Character.BattleStatus;

public enum Spell {
    Fire(   "ファイア",
            // Weather.Fire, //category
            Weather.NULL, //category
            3,
            5,      //mp
            3,       //baseLevel
            0,      //priority
            1.5,    //damageRate
            // 1.5,    //damageRate
            1,      //aNum
            100,    //hitRate
            CalculateDamage.BASE_VARIANCE_RATE,//randomRate
            true,   //attack
            true,   //useTension
            false){ //canDefense
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character actor = state.getPlayer(actor_is_player1);
            WeatherRelation relation = ChangeWeather.makeRelation(ChangeWeather.nowWeather(state), this.weather, text, scanner);
            return (int)(actor.getBattleStatus().get(BattleStatus.a) * getDamageRate() * getLevelPowerBuff(actor) * relation.coef);
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self) + "  現在の予想ダメージ " + getDamage(state, actor_is_player1, false, scanner), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 火の玉で敵を攻撃！敵にダメージを与える。火の力でお互いの素早さを減少させる", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: 敵に自分の" + MainStatus.a.jName + "の " + (int)(getDamageRate() * 100 * getLevelPowerBuff(self)) + "%のダメージを与える。お互いの素早さを 3分の1 にする", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 最も基本的なダメージを与える呪文。呪文で共通した効果だが、命中が必中で相手の防御行動を貫通させてダメージを与えることもできる。確実に敵にダメージを与えたい時に撃とう。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            boolean useAttackStatus = true;
            log.setHit(actor_is_player1,
            CalculateDamage.attackProcess(getDamage(state, actor_is_player1, text, scanner), getANum(), getHitRate(), getRandomRate(), true, getUseTension(), useAttackStatus, getCanDefense(), getDoApplyDefenceStatus(), false, state, actor_is_player1, target_is_player1, getAttack(), log, text, rand, scanner));
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
            double debuffRate = -200.0 / 3;
            ChangeBattleStatus.onset(state, actor_is_player1, StateChangeStatus.S, debuffRate, 5, text, scanner);
            ChangeBattleStatus.onset(state, !actor_is_player1, StateChangeStatus.S, debuffRate, 5, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("大きな火の玉が" + state.getPlayer(target_is_player1).getJName() + "に直撃した！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    Flame(   "フレイム",
            // Weather.Fire, //category
            Weather.NULL, //category
            3,
            5,      //mp
            3,       //baseLevel
            0,      //priority
            2.0,    //damageRate
            1,      //aNum
            100,    //hitRate
            CalculateDamage.BASE_VARIANCE_RATE,//randomRate
            true,   //attack
            true,   //useTension
            false){ //canDefense
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character actor = state.getPlayer(actor_is_player1);
            WeatherRelation relation = ChangeWeather.makeRelation(ChangeWeather.nowWeather(state), this.weather, text, scanner);
            return (int)(actor.getBattleStatus().get(BattleStatus.a) * getDamageRate() * getLevelPowerBuff(actor) * relation.coef);
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self) + "  現在の予想ダメージ " + getDamage(state, actor_is_player1, false, scanner), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 炎の玉で敵を攻撃！敵に大ダメージを与える。火の力でお互いの素早さを減少させる", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: 敵に自分の" + MainStatus.a.jName + "の " + (int)(getDamageRate() * 100 * getLevelPowerBuff(self)) + "%のダメージを与える。お互いの素早さを 3分の1 にする", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 最も基本的なダメージを与える呪文。呪文で共通した効果だが、命中が必中で相手の防御行動を貫通させてダメージを与えることもできる。確実に敵にダメージを与えたい時に撃とう。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            boolean useAttackStatus = true;
            log.setHit(actor_is_player1,
            CalculateDamage.attackProcess(getDamage(state, actor_is_player1, text, scanner), getANum(), getHitRate(), getRandomRate(), true, getUseTension(), useAttackStatus, getCanDefense(), getDoApplyDefenceStatus(),false, state, actor_is_player1, target_is_player1, getAttack(), log, text, rand, scanner));
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
            double debuffRate = -200.0 / 3;
            ChangeBattleStatus.onset(state, actor_is_player1, StateChangeStatus.S, debuffRate, 5, text, scanner);
            ChangeBattleStatus.onset(state, !actor_is_player1, StateChangeStatus.S, debuffRate, 5, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("火炎地獄が" + state.getPlayer(target_is_player1).getJName() + "を焼き払う！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    Explosion(   "エプロン",
            // Weather.Fire, //category
            Weather.NULL, //category
            3,
            5,      //mp
            3,       //baseLevel
            0,      //priority
            3.0,    //damageRate
            1,      //aNum
            100,    //hitRate
            CalculateDamage.BASE_VARIANCE_RATE,//randomRate
            true,   //attack
            true,   //useTension
            false){ //canDefense
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character actor = state.getPlayer(actor_is_player1);
            WeatherRelation relation = ChangeWeather.makeRelation(ChangeWeather.nowWeather(state), this.weather, text, scanner);
            return (int)(actor.getBattleStatus().get(BattleStatus.a) * getDamageRate() * getLevelPowerBuff(actor) * relation.coef);
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self) + "  現在の予想ダメージ " + getDamage(state, actor_is_player1, false, scanner), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 爆炎で敵を攻撃！敵に特大ダメージを与える。火の力でお互いの素早さを減少させる", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: 敵に自分の" + MainStatus.a.jName + "の " + (int)(getDamageRate() * 100 * getLevelPowerBuff(self)) + "%のダメージを与える。お互いの素早さを 3分の1 にする", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 最も基本的なダメージを与える呪文。呪文で共通した効果だが、命中が必中で相手の防御行動を貫通させてダメージを与えることもできる。確実に敵にダメージを与えたい時に撃とう。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            boolean useAttackStatus = true;
            log.setHit(actor_is_player1,
            CalculateDamage.attackProcess(getDamage(state, actor_is_player1, text, scanner), getANum(), getHitRate(), getRandomRate(), true, getUseTension(), useAttackStatus, getCanDefense(), getDoApplyDefenceStatus(),false, state, actor_is_player1, target_is_player1, getAttack(), log, text, rand, scanner));
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
            double debuffRate = -200.0 / 3;
            ChangeBattleStatus.onset(state, actor_is_player1, StateChangeStatus.S, debuffRate, 5, text, scanner);
            ChangeBattleStatus.onset(state, !actor_is_player1, StateChangeStatus.S, debuffRate, 5, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("エクスプロージョン！" + Print.sleep(2), true, Print.highSpeed, text);
            
            Print.println("巨大な爆発が" + state.getPlayer(target_is_player1).getJName() + "を包み込む！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    BigBang(   "ビッグバン",
            // Weather.Fire, //category
            Weather.NULL, //category
            3,
            5,      //mp
            3,       //baseLevel
            0,      //priority
            5.0,    //damageRate
            1,      //aNum
            100,    //hitRate
            CalculateDamage.BASE_VARIANCE_RATE,//randomRate
            true,   //attack
            true,   //useTension
            false){ //canDefense
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character actor = state.getPlayer(actor_is_player1);
            WeatherRelation relation = ChangeWeather.makeRelation(ChangeWeather.nowWeather(state), this.weather, text, scanner);
            return (int)(actor.getBattleStatus().get(BattleStatus.a) * getDamageRate() * getLevelPowerBuff(actor) * relation.coef);
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self) + "  現在の予想ダメージ " + getDamage(state, actor_is_player1, false, scanner), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 爆炎で敵を攻撃！敵に超特大ダメージを与える。火の力でお互いの素早さを減少させる", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: 敵に自分の" + MainStatus.a.jName + "の " + (int)(getDamageRate() * 100 * getLevelPowerBuff(self)) + "%のダメージを与える。お互いの素早さを 3分の1 にする", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 最も基本的なダメージを与える呪文。呪文で共通した効果だが、命中が必中で相手の防御行動を貫通させてダメージを与えることもできる。確実に敵にダメージを与えたい時に撃とう。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            boolean useAttackStatus = true;
            log.setHit(actor_is_player1,
            CalculateDamage.attackProcess(getDamage(state, actor_is_player1, text, scanner), getANum(), getHitRate(), getRandomRate(), true, getUseTension(), useAttackStatus, getCanDefense(), getDoApplyDefenceStatus(),false, state, actor_is_player1, target_is_player1, getAttack(), log, text, rand, scanner));
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
            double debuffRate = -200.0 / 3;
            ChangeBattleStatus.onset(state, actor_is_player1, StateChangeStatus.S, debuffRate, 5, text, scanner);
            ChangeBattleStatus.onset(state, !actor_is_player1, StateChangeStatus.S, debuffRate, 5, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("宇宙を創造する大爆発が" + state.getPlayer(target_is_player1).getJName() + "を爆散した！！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    Wind(  "ウィンド",
            // Weather.Wind, //category
            Weather.NULL, //category
            4,
            5,     //mp
            2,       //baseLevel
            2,      //priority
            1.0,    //damageRate
            // 1.2,    //damageRate
            1,      //aNum
            100,    //hitRate
            CalculateDamage.BASE_VARIANCE_RATE,//randomRate
            true,   //attack
            true,   //useTension
            false){ //canDefense
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character actor = state.getPlayer(actor_is_player1);
            WeatherRelation relation = ChangeWeather.makeRelation(ChangeWeather.nowWeather(state), this.weather, text, scanner);
            // int tensionRate = actor.getStateAction().get(ActionState.Tension).get(ActionStateCounter.count);
            int power = actor.getBattleStatus().get(BattleStatus.s);
            return (int)(power * getDamageRate() * getLevelPowerBuff(actor) * relation.coef);
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self) + "  現在の予想ダメージ " + getDamage(state, actor_is_player1, false, scanner), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 風を起こして攻撃！先制で敵に小ダメージを与える。風の力でお互いの防御力を減少させる", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: 敵に自分の" + MainStatus.s.jName + "の " + (int)(getDamageRate() * 100 * getLevelPowerBuff(self)) + "%のダメージを与える。先制攻撃する。お互いの防御力を 3分の1 にする", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 敵にダメージを与えられる前に先制で敵のテンションを無くしたい時に使える。" + MainStatus.s.jName + "が高いキャラクターが使うと優秀な火力になる。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            boolean useAttackStatus = false;
            log.setHit(actor_is_player1,
            CalculateDamage.attackProcess(getDamage(state, actor_is_player1, text, scanner), getANum(), getHitRate(), getRandomRate(), true, getUseTension(), useAttackStatus, getCanDefense(), getDoApplyDefenceStatus(),false, state, actor_is_player1, target_is_player1, getAttack(), log, text, rand, scanner));
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
            double debuffRate = -200.0 / 3;
            ChangeBattleStatus.onset(state, actor_is_player1, StateChangeStatus.D, debuffRate, 5, text, scanner);
            ChangeBattleStatus.onset(state, !actor_is_player1, StateChangeStatus.D, debuffRate, 5, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("突風が" + state.getPlayer(target_is_player1).getJName() + "を吹き飛ばした！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    Gust(  "ガスト",
            // Weather.Wind, //category
            Weather.NULL, //category
            4,
            5,     //mp
            2,       //baseLevel
            2,      //priority
            1.5,    //damageRate
            // 1.2,    //damageRate
            1,      //aNum
            100,    //hitRate
            CalculateDamage.BASE_VARIANCE_RATE,//randomRate
            true,   //attack
            true,   //useTension
            false){ //canDefense
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character actor = state.getPlayer(actor_is_player1);
            WeatherRelation relation = ChangeWeather.makeRelation(ChangeWeather.nowWeather(state), this.weather, text, scanner);
            // int tensionRate = actor.getStateAction().get(ActionState.Tension).get(ActionStateCounter.count);
            int power = actor.getBattleStatus().get(BattleStatus.s);
            return (int)(power * getDamageRate() * getLevelPowerBuff(actor) * relation.coef);
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self) + "  現在の予想ダメージ " + getDamage(state, actor_is_player1, false, scanner), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 風を起こして攻撃！先制で敵に小ダメージを与える。風の力でお互いの防御力を減少させる", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: 敵に自分の" + MainStatus.s.jName + "の " + (int)(getDamageRate() * 100 * getLevelPowerBuff(self)) + "%のダメージを与える。先制攻撃する。お互いの防御力を 3分の1 にする", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 敵にダメージを与えられる前に先制で敵のテンションを無くしたい時に使える。" + MainStatus.s.jName + "が高いキャラクターが使うと優秀な火力になる。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            boolean useAttackStatus = false;
            log.setHit(actor_is_player1,
            CalculateDamage.attackProcess(getDamage(state, actor_is_player1, text, scanner), getANum(), getHitRate(), getRandomRate(), true, getUseTension(), useAttackStatus, getCanDefense(), getDoApplyDefenceStatus(),false, state, actor_is_player1, target_is_player1, getAttack(), log, text, rand, scanner));
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
            double debuffRate = -200.0 / 3;
            ChangeBattleStatus.onset(state, actor_is_player1, StateChangeStatus.D, debuffRate, 5, text, scanner);
            ChangeBattleStatus.onset(state, !actor_is_player1, StateChangeStatus.D, debuffRate, 5, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("疾風が" + state.getPlayer(target_is_player1).getJName() + "を舞い散らした！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    Tornado(  "トルネード",
            // Weather.Wind, //category
            Weather.NULL, //category
            4,
            5,     //mp
            2,       //baseLevel
            2,      //priority
            2.0,    //damageRate
            // 1.2,    //damageRate
            1,      //aNum
            100,    //hitRate
            CalculateDamage.BASE_VARIANCE_RATE,//randomRate
            true,   //attack
            true,   //useTension
            false){ //canDefense
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character actor = state.getPlayer(actor_is_player1);
            WeatherRelation relation = ChangeWeather.makeRelation(ChangeWeather.nowWeather(state), this.weather, text, scanner);
            // int tensionRate = actor.getStateAction().get(ActionState.Tension).get(ActionStateCounter.count);
            int power = actor.getBattleStatus().get(BattleStatus.s);
            return (int)(power * getDamageRate() * getLevelPowerBuff(actor) * relation.coef);
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self) + "  現在の予想ダメージ " + getDamage(state, actor_is_player1, false, scanner), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 竜巻を起こして攻撃！先制で敵にダメージを与える。風の力でお互いの防御力を減少させる", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: 敵に自分の" + MainStatus.s.jName + "の " + (int)(getDamageRate() * 100 * getLevelPowerBuff(self)) + "%のダメージを与える。先制攻撃する。お互いの防御力を 3分の1 にする", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 敵にダメージを与えられる前に先制で敵のテンションを無くしたい時に使える。" + MainStatus.s.jName + "が高いキャラクターが使うと優秀な火力になる。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            boolean useAttackStatus = false;
            log.setHit(actor_is_player1,
            CalculateDamage.attackProcess(getDamage(state, actor_is_player1, text, scanner), getANum(), getHitRate(), getRandomRate(), true, getUseTension(), useAttackStatus, getCanDefense(), getDoApplyDefenceStatus(),false, state, actor_is_player1, target_is_player1, getAttack(), log, text, rand, scanner));
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
            double debuffRate = -200.0 / 3;
            ChangeBattleStatus.onset(state, actor_is_player1, StateChangeStatus.D, debuffRate, 5, text, scanner);
            ChangeBattleStatus.onset(state, !actor_is_player1, StateChangeStatus.D, debuffRate, 5, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("巨大な竜巻が" + state.getPlayer(target_is_player1).getJName() + "を切り裂く！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    Storm(  "ストーム",
            // Weather.Wind, //category
            Weather.NULL, //category
            4,
            5,     //mp
            2,       //baseLevel
            2,      //priority
            3.0,    //damageRate
            // 1.2,    //damageRate
            1,      //aNum
            100,    //hitRate
            CalculateDamage.BASE_VARIANCE_RATE,//randomRate
            true,   //attack
            true,   //useTension
            false){ //canDefense
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character actor = state.getPlayer(actor_is_player1);
            WeatherRelation relation = ChangeWeather.makeRelation(ChangeWeather.nowWeather(state), this.weather, text, scanner);
            // int tensionRate = actor.getStateAction().get(ActionState.Tension).get(ActionStateCounter.count);
            int power = actor.getBattleStatus().get(BattleStatus.s);
            return (int)(power * getDamageRate() * getLevelPowerBuff(actor) * relation.coef);
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self) + "  現在の予想ダメージ " + getDamage(state, actor_is_player1, false, scanner), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 嵐を起こして攻撃！先制で敵に大ダメージを与える。風の力でお互いの防御力を減少させる", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: 敵に自分の" + MainStatus.s.jName + "の " + (int)(getDamageRate() * 100 * getLevelPowerBuff(self)) + "%のダメージを与える。先制攻撃する。お互いの防御力を 3分の1 にする", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 敵にダメージを与えられる前に先制で敵のテンションを無くしたい時に使える。" + MainStatus.s.jName + "が高いキャラクターが使うと優秀な火力になる。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            boolean useAttackStatus = false;
            log.setHit(actor_is_player1,
            CalculateDamage.attackProcess(getDamage(state, actor_is_player1, text, scanner), getANum(), getHitRate(), getRandomRate(), true, getUseTension(), useAttackStatus, getCanDefense(), getDoApplyDefenceStatus(),false, state, actor_is_player1, target_is_player1, getAttack(), log, text, rand, scanner));
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
            double debuffRate = -200.0 / 3;
            ChangeBattleStatus.onset(state, actor_is_player1, StateChangeStatus.D, debuffRate, 5, text, scanner);
            ChangeBattleStatus.onset(state, !actor_is_player1, StateChangeStatus.D, debuffRate, 5, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("辺り一帯を吹き荒らす大嵐が" + state.getPlayer(target_is_player1).getJName() + "を襲撃した！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    Stone(   "ストーン",
            // Weather.Stone, //category
            Weather.NULL, //category
            4, 
            4,      //mp
            // 50,      //mp
            1,       //baseLevel
            -1,      //priority
            1.0,      //damageRate
            // 4.5,      //damageRate
            1,      //aNum
            100,    //hitRate
            CalculateDamage.BASE_VARIANCE_RATE,//randomRate
            true,   //attack
            true,   //useTension
            true){ //canDefense
        int chainCoef = 2;// 連続使用時の倍率
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character actor = state.getPlayer(actor_is_player1);
            WeatherRelation relation = ChangeWeather.makeRelation(ChangeWeather.nowWeather(state), this.weather, text, scanner);
            return (int)(actor.getBattleStatus().get(BattleStatus.a) * getDamageRate() * getLevelPowerBuff(actor) * relation.coef * Math.pow(chainCoef, actor.getStateAction().get(ActionState.Stone).get(ActionStateCounter.count)));
        }
        @Override
        public int getCost(Character self){
            if(self.getStateAction().get(ActionState.Stone).get(ActionStateCounter.flag) == 1){
                return 0;
            }
            return this.mp;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Character enemy = state.getPlayer(!actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self) + "  現在の予想ダメージ " + (getDamage(state, actor_is_player1, false, scanner) * 100 / enemy.getBattleStatus().get(BattleStatus.d)), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 石を投げてダメージを相手に与える。連続で出すことが可能で、そのたびに威力が増加する。岩の力でお互いの攻撃力を減少させる", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: 敵に自分の" + MainStatus.a.jName + "の " + (int)(getDamageRate() * 100 * getLevelPowerBuff(self)) + "%のダメージを与える。お互いの攻撃力を 3分の1 にする。敵は防御でダメージを防ぐことが可能", Print.highSpeed, text);
            Print.println("この呪文は連続している限り緊張状態を無視して連続して使える。連続でこの呪文を使う度にダメージが " + chainCoef + " 倍になる。連続時は消費MPも0になる。しかし、相手に防御されると連続効果は途切れる", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 使うことで相手に防御をしたくさせることが出来る。その隙に溜めるのは有効な戦術だろう。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public boolean getDoApplyDefenceStatus(){
            return true;
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            boolean useAttackStatus = true;
            int hitNum = CalculateDamage.attackProcess(getDamage(state, actor_is_player1, text, scanner), getANum(), getHitRate(), getRandomRate(), true, getUseTension(), useAttackStatus, getCanDefense(), getDoApplyDefenceStatus(),false, state, actor_is_player1, target_is_player1, getAttack(), log, text, rand, scanner);
            ChangeActionState.onset(state, actor_is_player1, target_is_player1, ActionState.Stone, log, text, scanner, rand);
            if(hitNum == 0){
                Character actor = state.getPlayer(actor_is_player1);
                actor.getStateAction().get(ActionState.Stone).replace(ActionStateCounter.flag, 0);
                actor.getStateAction().get(ActionState.Stone).replace(ActionStateCounter.count, 0);
            }
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
            double debuffRate = -200.0 / 3;
            ChangeBattleStatus.onset(state, actor_is_player1, StateChangeStatus.A, debuffRate, 5, text, scanner);
            ChangeBattleStatus.onset(state, !actor_is_player1, StateChangeStatus.A, debuffRate, 5, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("鋭く尖った数々の石が" + state.getPlayer(target_is_player1).getJName() + "に突き刺さる！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    Rock(   "ロック",
            // Weather.Stone, //category
            Weather.NULL, //category
            4, 
            4,      //mp
            // 50,      //mp
            1,       //baseLevel
            -1,      //priority
            1.5,      //damageRate
            // 4.5,      //damageRate
            1,      //aNum
            100,    //hitRate
            CalculateDamage.BASE_VARIANCE_RATE,//randomRate
            true,   //attack
            true,   //useTension
            true){ //canDefense
        int chainCoef = 2;// 連続使用時の倍率
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character actor = state.getPlayer(actor_is_player1);
            WeatherRelation relation = ChangeWeather.makeRelation(ChangeWeather.nowWeather(state), this.weather, text, scanner);
            return (int)(actor.getBattleStatus().get(BattleStatus.a) * getDamageRate() * getLevelPowerBuff(actor) * relation.coef * Math.pow(chainCoef, actor.getStateAction().get(ActionState.Rock).get(ActionStateCounter.count)));
        }
        @Override
        public int getCost(Character self){
            if(self.getStateAction().get(ActionState.Rock).get(ActionStateCounter.flag) == 1){
                return 0;
            }
            return this.mp;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Character enemy = state.getPlayer(!actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self) + "  現在の予想ダメージ " + (getDamage(state, actor_is_player1, false, scanner) * 100 / enemy.getBattleStatus().get(BattleStatus.d)), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 岩を投げて大ダメージを相手に与える。連続で出すことが可能で、そのたびに威力が増加する。岩の力でお互いの攻撃力を減少させる", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: 敵に自分の" + MainStatus.a.jName + "の " + (int)(getDamageRate() * 100 * getLevelPowerBuff(self)) + "%のダメージを与える。お互いの攻撃力を 3分の1 にする。敵は防御でダメージを防ぐことが可能", Print.highSpeed, text);
            Print.println("この呪文は連続している限り緊張状態を無視して連続して使える。連続でこの呪文を使う度にダメージが " + chainCoef + " 倍になる。連続時は消費MPも0になる。しかし、相手に防御されると連続効果は途切れる", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 使うことで相手に防御をしたくさせることが出来る。その隙に溜めるのは有効な戦術だろう。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public boolean getDoApplyDefenceStatus(){
            return true;
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            boolean useAttackStatus = true;
            int hitNum = CalculateDamage.attackProcess(getDamage(state, actor_is_player1, text, scanner), getANum(), getHitRate(), getRandomRate(), true, getUseTension(), useAttackStatus, getCanDefense(), getDoApplyDefenceStatus(),false, state, actor_is_player1, target_is_player1, getAttack(), log, text, rand, scanner);
            ChangeActionState.onset(state, actor_is_player1, target_is_player1, ActionState.Rock, log, text, scanner, rand);
            if(hitNum == 0){
                Character actor = state.getPlayer(actor_is_player1);
                actor.getStateAction().get(ActionState.Rock).replace(ActionStateCounter.flag, 0);
                actor.getStateAction().get(ActionState.Rock).replace(ActionStateCounter.count, 0);
            }
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
            double debuffRate = -200.0 / 3;
            ChangeBattleStatus.onset(state, actor_is_player1, StateChangeStatus.A, debuffRate, 5, text, scanner);
            ChangeBattleStatus.onset(state, !actor_is_player1, StateChangeStatus.A, debuffRate, 5, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("大きな数々の岩が" + state.getPlayer(target_is_player1).getJName() + "目掛けて落下した！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    Lava(   "ラヴァ",
            // Weather.Stone, //category
            Weather.NULL, //category
            4, 
            4,      //mp
            // 50,      //mp
            1,       //baseLevel
            -1,      //priority
            2.0,      //damageRate
            // 4.5,      //damageRate
            1,      //aNum
            100,    //hitRate
            CalculateDamage.BASE_VARIANCE_RATE,//randomRate
            true,   //attack
            true,   //useTension
            true){ //canDefense
        int chainCoef = 2;// 連続使用時の倍率
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character actor = state.getPlayer(actor_is_player1);
            WeatherRelation relation = ChangeWeather.makeRelation(ChangeWeather.nowWeather(state), this.weather, text, scanner);
            return (int)(actor.getBattleStatus().get(BattleStatus.a) * getDamageRate() * getLevelPowerBuff(actor) * relation.coef * Math.pow(chainCoef, actor.getStateAction().get(ActionState.Lava).get(ActionStateCounter.count)));
        }
        @Override
        public int getCost(Character self){
            if(self.getStateAction().get(ActionState.Lava).get(ActionStateCounter.flag) == 1){
                return 0;
            }
            return this.mp;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Character enemy = state.getPlayer(!actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self) + "  現在の予想ダメージ " + (getDamage(state, actor_is_player1, false, scanner) * 100 / enemy.getBattleStatus().get(BattleStatus.d)), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 溶岩を投げて特大ダメージを相手に与える。連続で出すことが可能で、そのたびに威力が増加する。岩の力でお互いの攻撃力を減少させる", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: 敵に自分の" + MainStatus.a.jName + "の " + (int)(getDamageRate() * 100 * getLevelPowerBuff(self)) + "%のダメージを与える。お互いの攻撃力を 3分の1 にする。敵は防御でダメージを防ぐことが可能", Print.highSpeed, text);
            Print.println("この呪文は連続している限り緊張状態を無視して連続して使える。連続でこの呪文を使う度にダメージが " + chainCoef + " 倍になる。連続時は消費MPも0になる。しかし、相手に防御されると連続効果は途切れる", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 使うことで相手に防御をしたくさせることが出来る。その隙に溜めるのは有効な戦術だろう。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public boolean getDoApplyDefenceStatus(){
            return true;
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            boolean useAttackStatus = true;
            int hitNum = CalculateDamage.attackProcess(getDamage(state, actor_is_player1, text, scanner), getANum(), getHitRate(), getRandomRate(), true, getUseTension(), useAttackStatus, getCanDefense(), getDoApplyDefenceStatus(),false, state, actor_is_player1, target_is_player1, getAttack(), log, text, rand, scanner);
            ChangeActionState.onset(state, actor_is_player1, target_is_player1, ActionState.Lava, log, text, scanner, rand);
            if(hitNum == 0){
                Character actor = state.getPlayer(actor_is_player1);
                actor.getStateAction().get(ActionState.Lava).replace(ActionStateCounter.flag, 0);
                actor.getStateAction().get(ActionState.Lava).replace(ActionStateCounter.count, 0);
            }
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
            double debuffRate = -200.0 / 3;
            ChangeBattleStatus.onset(state, actor_is_player1, StateChangeStatus.A, debuffRate, 5, text, scanner);
            ChangeBattleStatus.onset(state, !actor_is_player1, StateChangeStatus.A, debuffRate, 5, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("灼熱の溶岩が" + state.getPlayer(target_is_player1).getJName() + "になだれ込んだ！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    Meteor(   "メテオ",
            // Weather.Stone, //category
            Weather.NULL, //category
            4, 
            4,      //mp
            // 50,      //mp
            1,       //baseLevel
            -1,      //priority
            3.0,      //damageRate
            // 4.5,      //damageRate
            1,      //aNum
            100,    //hitRate
            CalculateDamage.BASE_VARIANCE_RATE,//randomRate
            true,   //attack
            true,   //useTension
            true){ //canDefense
        int chainCoef = 2;// 連続使用時の倍率
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character actor = state.getPlayer(actor_is_player1);
            WeatherRelation relation = ChangeWeather.makeRelation(ChangeWeather.nowWeather(state), this.weather, text, scanner);
            return (int)(actor.getBattleStatus().get(BattleStatus.a) * getDamageRate() * getLevelPowerBuff(actor) * relation.coef * Math.pow(chainCoef, actor.getStateAction().get(ActionState.Meteor).get(ActionStateCounter.count)));
        }
        @Override
        public int getCost(Character self){
            if(self.getStateAction().get(ActionState.Meteor).get(ActionStateCounter.flag) == 1){
                return 0;
            }
            return this.mp;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Character enemy = state.getPlayer(!actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self) + "  現在の予想ダメージ " + (getDamage(state, actor_is_player1, false, scanner) * 100 / enemy.getBattleStatus().get(BattleStatus.d)), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 隕石を落として特大ダメージを相手に与える。連続で出すことが可能で、そのたびに威力が増加する。岩の力でお互いの攻撃力を減少させる", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: 敵に自分の" + MainStatus.a.jName + "の " + (int)(getDamageRate() * 100 * getLevelPowerBuff(self)) + "%のダメージを与える。お互いの攻撃力を 3分の1 にする。敵は防御でダメージを防ぐことが可能", Print.highSpeed, text);
            Print.println("この呪文は連続している限り緊張状態を無視して連続して使える。連続でこの呪文を使う度にダメージが " + chainCoef + " 倍になる。連続時は消費MPも0になる。しかし、相手に防御されると連続効果は途切れる", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 使うことで相手に防御をしたくさせることが出来る。その隙に溜めるのは有効な戦術だろう。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public boolean getDoApplyDefenceStatus(){
            return true;
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            boolean useAttackStatus = true;
            int hitNum = CalculateDamage.attackProcess(getDamage(state, actor_is_player1, text, scanner), getANum(), getHitRate(), getRandomRate(), true, getUseTension(), useAttackStatus, getCanDefense(), getDoApplyDefenceStatus(),false, state, actor_is_player1, target_is_player1, getAttack(), log, text, rand, scanner);
            ChangeActionState.onset(state, actor_is_player1, target_is_player1, ActionState.Meteor, log, text, scanner, rand);
            if(hitNum == 0){
                Character actor = state.getPlayer(actor_is_player1);
                actor.getStateAction().get(ActionState.Meteor).replace(ActionStateCounter.flag, 0);
                actor.getStateAction().get(ActionState.Meteor).replace(ActionStateCounter.count, 0);
            }
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
            double debuffRate = -200.0 / 3;
            ChangeBattleStatus.onset(state, actor_is_player1, StateChangeStatus.A, debuffRate, 5, text, scanner);
            ChangeBattleStatus.onset(state, !actor_is_player1, StateChangeStatus.A, debuffRate, 5, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("巨大な隕石が" + state.getPlayer(target_is_player1).getJName() + "に向けて降り注いだ！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    KJA(    "KJA",
            // Weather.NULL, //category
            Weather.NULL, //category
            -1,
            3,      //mp
            1,       //baseLevel
            0,      //priority
            1.0,    //damageRate
            1,      //aNum
            100,    //hitRate
            0.0,    //randomRate
            true,   //attack
            true,   //useTension
            false){ //canDefense
        // 乱数使っているので確定的にダメージを算出出来ない
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            return 0;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: スーパーギャンブラーの必殺手！運が良ければ敵にとんでもないダメージを与える", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: 敵に自分の" + MainStatus.a.jName + "の " + (int)(-1 * 100) + "%～ " + (int)(100 * 100) + "%（期待値 58%）のダメージを与える", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : あとスペードのQと10が揃えばロイヤルストレートフラッシュ。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            int damage;
            double DR = getDamageRate();
            for(int i = 0; i < 6; i++){
                DR *= rand.nextDouble();
            }
            DR = DR * 101.0 - 1.0;
            Character actor = state.getPlayer(actor_is_player1);
            WeatherRelation relation = ChangeWeather.makeRelation(ChangeWeather.nowWeather(state), this.weather, text, scanner);
            damage = (int)(actor.getBattleStatus().get(BattleStatus.a) * DR * getLevelPowerBuff(actor) * relation.coef);
            boolean useAttackStatus = true;
            log.setHit(actor_is_player1,
            CalculateDamage.attackProcess(damage, getANum(), getHitRate(), getRandomRate(), true, getUseTension(), useAttackStatus, getCanDefense(), getDoApplyDefenceStatus(),false, state, actor_is_player1, target_is_player1, getAttack(), log, text, rand, scanner));
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("謎の力が" + state.getPlayer(target_is_player1).getJName() + "にショックを与えた！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    Heal(   "ヒール",
            // Weather.Cure, //category
            Weather.NULL, //category
            3,
            3,      //mp
            3,       //baseLevel
            0,      //priority
            -1.0,   //damageRate
            // -0.2,   //damageRate
            0.0){   //randomRate
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            return 0;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 祝福の呪文を唱える。自分の" + MainStatus.hp.jName + "を全回復する。悪い状態を全て治す", Print.highSpeed, text);
            // Print.println("説明: 祝福の呪文を唱える。自分の" + MainStatus.hp.jName + "を全回復する。祝福の力で状況をリセットする。", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: 自分の" + MainStatus.maxHp.jName + "の " + (int)(-getDamageRate() * 100) + "%回復する。能力減少効果・状態異常（緊張状態を除く）を全て解除する", Print.highSpeed, text);
            // Print.println("詳細: 自分の" + MainStatus.maxHp.jName + "の" + (int)(-getDamageRate() * 100) + "%回復する。フィールド・能力増加効果・能力減少効果・状態異常・テンション・溜めるの成功強化を初期状態に戻す。", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : " + MainStatus.hp.jName + "を全回復して、能力減少効果・状態異常を解除出来る。致命的な状況を回避するために使おう", Print.highSpeed, text);
            // Print.println("アドバイス : " + MainStatus.hp.jName + "を全回復して盤面をリセット出来る。致命的な状況を回避するために使おう", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            Character target = state.getPlayer(!target_is_player1);
            Character actor = state.getPlayer(actor_is_player1);
            WeatherRelation relation = ChangeWeather.makeRelation(ChangeWeather.nowWeather(state), this.weather, text, scanner);
            CalculateDamage.changeParameter(target, MainStatus.hp, (int)(target.getMainStatus().get(MainStatus.maxHp) * getDamageRate() * getLevelPowerBuff(actor) * relation.coef), text);
            state.setPlayer(target, !target_is_player1);

            ChangeBattleStatus.releaseAllDebuff(actor.getStateChangeStatus(), text);
            
            for(AbnormalState aState : AbnormalState.values()){
                if(!aState.good && aState != AbnormalState.Nervous){
                    ChangeAbnormalState.cure(actor, aState, text);
                }
            }

            // state.setField(ChangeField.initializedFieldMap());
            // for(boolean SE : new boolean[]{true, false}){
            //     Character chara = state.getPlayer(SE);
            //     chara.setStateAbnormal(ChangeAbnormalState.initializedAbnormalStateMap());
            //     chara.setStateChangeStatus(new ArrayList<>());
            //     chara.getStateAction().get(ActionState.Tension).replace(ActionStateCounter.flag, 0);
            //     chara.getStateAction().get(ActionState.Tension).replace(ActionStateCounter.count, 0);
            //     chara.getStateAction().get(ActionState.sucTen).replace(ActionStateCounter.flag, 0);
            //     chara.getStateAction().get(ActionState.sucTen).replace(ActionStateCounter.count, 0);
            // }
            
            // ChangeBattleStatus.onset(state, !target_is_player1, StateChangeStatus.A, 200, 5, text, scanner);
            // ChangeBattleStatus.onset(state, target_is_player1, StateChangeStatus.A, 200, 5, text, scanner);
            // ChangeBattleStatus.onset(state, !target_is_player1, StateChangeStatus.S, 200, 5, text, scanner);
            // ChangeBattleStatus.onset(state, target_is_player1, StateChangeStatus.S, 200, 5, text, scanner);
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("祝福のオーラが" + state.getPlayer(!target_is_player1).getJName() + "を包み込む！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    Nervous(    "緊迫斬り",
            // Weather.Abnormal, //category
            Weather.NULL, //category
            1,
            4,  //mp
            // 0,  //mp
            1,       //baseLevel
            0){ //priority
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            return 0;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 敵を斬りつけて脅す！敵を攻撃しつつ" + AbnormalState.Nervous.jName + "状態にする", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: " + AbnormalState.Nervous.jName + "状態のキャラクターは連続して同じ行動が出来ない。既に" + AbnormalState.Nervous.jName + "状態の敵に使うと" + AbnormalState.SuperNervous.jName + "状態にする。防御されると失敗する", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 相手の行動を制限して有利に立ち回ろう。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            int hitNum = ExecuteAction.attack(state, actor_is_player1, target_is_player1, log, text, scanner, rand);
            if(hitNum > 0){
                ChangeAbnormalState.onset(state, target_is_player1, AbnormalState.Nervous, getLevelTurnBuff(state.getPlayer(actor_is_player1)), log, scanner, text, rand);
            }
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("ひりつく緊張の中" + state.getPlayer(target_is_player1).getJName() + "を斬り抜いた！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    Lag(    "回線斬り",
            // Weather.Abnormal, //category
            Weather.NULL, //category
            1,
            5,  //mp
            // 0,  //mp
            1,       //baseLevel
            0){ //priority
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            return 0;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 敵の回線を攻撃！敵を攻撃しつつ" + AbnormalState.Lag.jName + "状態にする", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: " + AbnormalState.Lag.jName + "状態のキャラクターは行動の入力から実行までが１ターン遅れる。既に" + AbnormalState.Lag.jName + "状態の敵に使うと" + AbnormalState.SuperLag.jName + "状態にする。防御されると失敗する", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 使われるとウザい呪文ナンバーワンと噂の呪文。ただでさえ害悪の回線切りをさらに自分ならぬ敵に仕向ける。まあ、このゲームはオフラインだが。効果も害悪そのもので使うときは他の呪文と組み合わせてハメ殺し、ニチャって相手にクソ害悪野郎と呼ばれる覚悟が必要だ。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            int hitNum = ExecuteAction.attack(state, actor_is_player1, target_is_player1, log, text, scanner, rand);
            if(hitNum > 0){
                ChangeAbnormalState.onset(state, target_is_player1, AbnormalState.Lag, getLevelTurnBuff(state.getPlayer(actor_is_player1)), log, scanner, text, rand);
            }
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("家中のLANケーブルを切り刻みつつ、" + state.getPlayer(target_is_player1).getJName() + "を斬りつけた！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    Poison(  "毒斬り",
            // Weather.Abnormal, //category
            Weather.NULL, //category
            1,
            5,  //mp
            // 0,  //mp
            1,       //baseLevel
            0){ //priority
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            return 0;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 敵を斬りつけて毒を塗る。敵を攻撃しつつ" + AbnormalState.Poison.jName + "状態にする", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: " + AbnormalState.Poison.jName + "状態のキャラクターは毎ターン終了時、" + MainStatus.maxHp.jName + "に比例したダメージを受ける。既に" + AbnormalState.Poison.jName + "状態の敵に使うと" + AbnormalState.SuperPoison.jName + "状態にする。防御されると失敗する", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 毎ターン固定でダメージを与えることができる。" + MainStatus.hp.jName + "の高い敵に使えば効果てきめんだ。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            int hitNum = ExecuteAction.attack(state, actor_is_player1, target_is_player1, log, text, scanner, rand);
            if(hitNum > 0){
                ChangeAbnormalState.onset(state, target_is_player1, AbnormalState.Poison, getLevelTurnBuff(state.getPlayer(actor_is_player1)), log, scanner, text, rand);
            }
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println(state.getPlayer(target_is_player1).getJName() + "を毒の刃で斬りつけた！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    Bond(  "臆病斬り",
            // Weather.Abnormal, //category
            Weather.NULL, //category
            1,
                4,  //mp
                // 0,  //mp
                1,       //baseLevel
                0){ //priority
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            return 0;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 敵を斬りつけて恐ろしい幻で包み込む。敵を攻撃しつつ" + AbnormalState.Bond.jName + "状態にする", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: " + AbnormalState.Bond.jName + "状態のキャラクターはそのターン既に敵が取った行動と同じ行動を取ることができない。既に" + AbnormalState.Bond.jName + "状態の敵に使うと" + AbnormalState.SuperBond.jName + "状態にする。防御されると失敗する", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 敵を" + AbnormalState.Bond.jName + "状態にしても、先に行動されてしまうと意味がない。自分より" + MainStatus.s.jName + "が遅い敵に使おう。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            int hitNum = ExecuteAction.attack(state, actor_is_player1, target_is_player1, log, text, scanner, rand);
            if(hitNum > 0){
                ChangeAbnormalState.onset(state, target_is_player1, AbnormalState.Bond, getLevelTurnBuff(state.getPlayer(actor_is_player1)), log, scanner, text, rand);
            }
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("凄まじい気迫で" + state.getPlayer(target_is_player1).getJName() + "を斬りつけた！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    Stomatitis( "沈黙斬り",
            // Weather.Abnormal, //category
            Weather.NULL, //category
            1,
                4,  //mp
                // 0,  //mp
                1,       //baseLevel
                0){ //priority
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            return 0;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 敵を斬りつけて口内に小さな傷を付ける。敵を攻撃しつつ" + AbnormalState.Stomatitis.jName + "状態にする", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: " + AbnormalState.Stomatitis.jName + "状態のキャラクターは呪文を唱える際、後攻になる。既に" + AbnormalState.Stomatitis.jName + "状態の敵に使うと" + AbnormalState.SuperStomatitis.jName + "状態にする。防御されると失敗する", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : " + AbnormalState.Stomatitis.jName + "状態になると、呪文が後攻になり、テンションを消し飛ばしたり、先手をとって呪文を失敗させることが出来る。呪文を多用する敵や" + MainStatus.s.jName + "の高い敵などに使って牽制しよう。", Print.highSpeed, text);
            //TODO MP削る説明をする
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            int hitNum = ExecuteAction.attack(state, actor_is_player1, target_is_player1, log, text, scanner, rand);
            if(hitNum > 0){
                ChangeAbnormalState.onset(state, target_is_player1, AbnormalState.Stomatitis, getLevelTurnBuff(state.getPlayer(actor_is_player1)), log, scanner, text, rand);
            }
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("無言で" + state.getPlayer(target_is_player1).getJName() + "を斬りつけた！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    AUp(    "アタックアップ",
            Weather.NULL, //category
            -1,
            4,  //mp
            1,       //baseLevel
            1){ //priority
        int buffRate = 200;
        int effectTurn = 5;// 発動ターンは含まない
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            return 0;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 強欲の呪文を自分にかける。自分の" + MainStatus.a.jName + "が増加する", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: 攻撃力が " + effectTurn + " ターンの間 " + buffRate + "%増加する。減少効果にかかっていたら解除する。先制発動する", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 攻撃力を一気に上げて究極の一撃をお見舞いしてやろう！", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            ChangeBattleStatus.onset(state, !target_is_player1, StateChangeStatus.A, buffRate, effectTurn, text, scanner);
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
        }
        @Override
        public boolean getLegal(State state, Weather stateWeather, Character self, boolean text, Scanner scanner){
            boolean isDynamic = true;
            if(self.getMainStatus().get(MainStatus.mp) < this.getCost(self)){
                Print.println("", Print.highSpeed, text);
                Print.println(self.getJName() + "は" + this.jName + "をセットしていなかった" + Print.sleep(2), isDynamic, Print.middleSpeed, text);
                
                return false;
            }else if(!self.getSpellSlot().contains(this)){
                Print.println("しかし、" + MainStatus.mp.jName + "が足りなかった" + Print.sleep(2), isDynamic, Print.middleSpeed, text);
                
                return false;
            }else if(this.weather == Weather.Abnormal && stateWeather != Weather.NULL){
                Print.println("しかし、状態異常呪文は" + Weather.NULL.jName + "天候以外では発動できない" + Print.sleep(2), isDynamic, Print.highSpeed, text);
                
                return false;
            }if(state.getSpellUsed()){
                Print.println("しかし、既にこのターン相手に呪文を使われていた" + Print.sleep(2), isDynamic, Print.highSpeed, text);
                
                return false;
            }
            return true;
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println(state.getPlayer(!target_is_player1).getJName() + "は体の底から力がみなぎった！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    SUp(   "スピードアップ",
            Weather.NULL, //category
            -1,
            3,  //mp
            1,       //baseLevel
            1){ //priority
                int buffRate = 200;
                int effectTurn = 5;// 発動ターンは含まない
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            return 0;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 神速の呪文を自分にかける。自分の" + MainStatus.s.jName + "が増加する", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: 素早さが " + effectTurn + " ターンの間 " + buffRate + "%増加する。減少効果にかかっていたら解除する。先制発動する", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 自分の" + MainStatus.s.jName + "が敵の" + MainStatus.s.jName + "の 2倍あると、敵の防御で自分の攻撃を防がれることがなくなる。上手く使いこなそう。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            ChangeBattleStatus.onset(state, !target_is_player1, StateChangeStatus.S, buffRate, effectTurn, text, scanner);
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
        }
        @Override
        public boolean getLegal(State state, Weather stateWeather, Character self, boolean text, Scanner scanner){
            boolean isDynamic = true;
            if(self.getMainStatus().get(MainStatus.mp) < this.getCost(self)){
                Print.println("", Print.highSpeed, text);
                Print.println(self.getJName() + "は" + this.jName + "をセットしていなかった" + Print.sleep(2), isDynamic, Print.middleSpeed, text);
                
                return false;
            }else if(!self.getSpellSlot().contains(this)){
                Print.println("しかし、" + MainStatus.mp.jName + "が足りなかった" + Print.sleep(2), isDynamic, Print.middleSpeed, text);
                
                return false;
            }else if(this.weather == Weather.Abnormal && stateWeather != Weather.NULL){
                Print.println("しかし、状態異常呪文は" + Weather.NULL.jName + "天候以外では発動できない" + Print.sleep(2), isDynamic, Print.highSpeed, text);
                
                return false;
            }if(state.getSpellUsed()){
                Print.println("しかし、既にこのターン相手に呪文を使われていた" + Print.sleep(2), isDynamic, Print.highSpeed, text);
                
                return false;
            }
            return true;
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println(state.getPlayer(!target_is_player1).getJName() + "は体がとても身軽になった！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    DUp(   "ディフェンスアップ",
            Weather.NULL, //category
            -1,
            3,  //mp
            1,       //baseLevel
            1){ //priority
        int buffRate = 200;
        int effectTurn = 5;
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            return 0;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 鋼鉄の呪文を自分にかける。自分の" + MainStatus.d.jName + "が増加する", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: " + MainStatus.d.jName + "が " + effectTurn + " ターンの間 " + buffRate + "%増加する。減少効果にかかっていたら解除する。先制発動する", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : " + MainStatus.d.jName + "が増えると物理攻撃に強くなる。呪文を覚えていない相手には効果的だ。上手く使いこなそう。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            ChangeBattleStatus.onset(state, !target_is_player1, StateChangeStatus.D, buffRate, effectTurn, text, scanner);
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
        }
        @Override
        public boolean getLegal(State state, Weather stateWeather, Character self, boolean text, Scanner scanner){
            boolean isDynamic = true;
            if(self.getMainStatus().get(MainStatus.mp) < this.getCost(self)){
                Print.println("", Print.highSpeed, text);
                Print.println(self.getJName() + "は" + this.jName + "をセットしていなかった" + Print.sleep(2), isDynamic, Print.middleSpeed, text);
                
                return false;
            }else if(!self.getSpellSlot().contains(this)){
                Print.println("しかし、" + MainStatus.mp.jName + "が足りなかった" + Print.sleep(2), isDynamic, Print.middleSpeed, text);
                
                return false;
            }else if(this.weather == Weather.Abnormal && stateWeather != Weather.NULL){
                Print.println("しかし、状態異常呪文は" + Weather.NULL.jName + "天候以外では発動できない" + Print.sleep(2), isDynamic, Print.highSpeed, text);
                
                return false;
            }if(state.getSpellUsed()){
                Print.println("しかし、既にこのターン相手に呪文を使われていた" + Print.sleep(2), isDynamic, Print.highSpeed, text);
                
                return false;
            }
            return true;
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println(state.getPlayer(!target_is_player1).getJName() + "の皮膚がみるみるうちに固まった！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    TensionField(   "テンションフィールド",
                    Weather.NULL, //category
                    -1,
                    3,  //mp
                    1,       //baseLevel
                    0){ //priority
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            return 0;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 構えた盾からテンションが上がる空間を展開する。ターン終了時にテンションが上昇していく", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: 防御しつつ、発動したターンを含めて 5ターンの間、ターンの終わりにお互いのテンションが上昇するフィールドを展開する。増加量は初回は 1段階で、ターンが進むごとに増加量が 1段階増える", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 手に入れられるテンションが上昇する終盤にテンションを独占出来るように立ち回ろう", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            ExecuteAction.guard(state, actor_is_player1, target_is_player1, log, text, scanner, rand);
            ChangeField.onset(state, Field.TensionField, getLevelTurnBuff(state.getPlayer(actor_is_player1)), text);
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("フィールドが陽キャ感溢れる雰囲気になった！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    SpecialField(   "スペシャルフィールド",
                    Weather.NULL, //category
                    -1, 
                    4,  //mp
                    1,       //baseLevel
                    0){ //priority
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            return 0;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 構えた盾から特別な空間を展開する。お互い必殺技を使えるようになる", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: 防御しつつ、 5ターンの間、お互いの通常行動が必殺技と入れ替わるフィールドを展開する", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 状態異常などと組み合わせて敵の行動を制約することで、一方的に有利な必殺技を使える。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            ExecuteAction.guard(state, actor_is_player1, target_is_player1, log, text, scanner, rand);
            ChangeField.onset(state, Field.SpecialField, getLevelTurnBuff(state.getPlayer(actor_is_player1)), text);
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("フィールドが特別感溢れる雰囲気になった！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    ReverseField(  "リバースフィールド",
                Weather.NULL, //category
                -1, 
                3,  //mp
                1,       //baseLevel
                0){ //priority
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            return 0;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 構えた盾から逆転の空間を展開する。お互いの" + MainStatus.s.jName + "が逆転する", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: 防御しつつ、 5ターンの間、お互いの" + MainStatus.s.jName + "が入れ替わるフィールドを展開する", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : コイツ持ってると" + MainStatus.s.jName + "育成が全く要らない。ほぼチート。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            ExecuteAction.guard(state, actor_is_player1, target_is_player1, log, text, scanner, rand);
            ChangeField.onset(state, Field.ReverseField, getLevelTurnBuff(state.getPlayer(actor_is_player1)), text);
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("フィールドが逆転感溢れる雰囲気になった！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },
    RegenField("リジェネフィールド",
                Weather.NULL,
                -1,
                3,
                1,
                0){
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            return 0;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 構えた盾から癒しの空間を展開する。毎ターン 15%回復する", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: 防御しつつ、 10ターンの間、ターン終了時にお互いの" + MainStatus.hp.jName + "が 15%回復するフィールドを展開する", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 癒されて耐久力を高めよう。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            ExecuteAction.guard(state, actor_is_player1, target_is_player1, log, text, scanner, rand);
            ChangeField.onset(state, Field.RegenField, getLevelTurnBuff(state.getPlayer(actor_is_player1)), text);
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("フィールドが癒し感満載の雰囲気になった！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }

    },
    On_StateChange(   "ONS-ステイトチェンジ",
            Weather.NULL, //category
            -1, 
            3,  //mp
            1,       //baseLevel
            3){ //priority
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            return 0;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 突然の変顔で敵を挑発！お互いの全ての状態変化を入れ替える", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: お互いの能力変化（テンションを含む）、状態異常、状態異常耐性を全て入れ替える。必ず敵より先に行動する", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 害悪パ対策にこれ一本!", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            Character actor = state.getPlayer(actor_is_player1);
            Character target = state.getPlayer(target_is_player1);
            Map<ActionState, Map<ActionStateCounter, Integer>> actorStateAction = actor.getStateAction();
            Map<ActionStateCounter,Integer> actorTension = actorStateAction.get(ActionState.Tension);
            Map<ActionState, Map<ActionStateCounter, Integer>> targetStateAction = target.getStateAction();
            Map<ActionStateCounter,Integer> targetTension = targetStateAction.get(ActionState.Tension);
            actorStateAction.replace(ActionState.Tension, targetTension);
            actor.setStateAction(actorStateAction);
            targetStateAction.replace(ActionState.Tension, actorTension);
            target.setStateAction(targetStateAction);
            List<Map<StateChangeStatus, Map<StatusCounter, Double>>> temporaryStateChangeStatus = actor.getStateChangeStatus();
            actor.setStateChangeStatus(target.getStateChangeStatus());
            target.setStateChangeStatus(temporaryStateChangeStatus);
            ChangeBattleStatus.reset(state);
            state.setPlayer(actor, actor_is_player1);
            state.setPlayer(target, target_is_player1);

            Map<AbnormalState, Map<AbnormalStateCounter, Integer>> temporaryStateAbnormal = actor.getStateAbnormal();
            actor.setStateAbnormal(target.getStateAbnormal());
            target.setStateAbnormal(temporaryStateAbnormal);
            state.setPlayer(actor, actor_is_player1);
            state.setPlayer(target, target_is_player1);
            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Character actor = state.getPlayer(actor_is_player1);
            Character target = state.getPlayer(target_is_player1);
            Print.println(actor.getJName() + "と" + target.getJName() + "の状態変化が全て入れ替わった！" + Print.sleep(2), true, Print.highSpeed, text);
            // Print.println(actor.getJName() + "と" + target.getJName() + "の装備が入れ替わった！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },

    On_SpellReflect(   "ONS-スペルリフレクト",
            Weather.NULL, //category
            -1, //weatherTurn
            5,  //mp
            1,       //baseLevel
            3){ //priority
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            return 0;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 魔法の鏡で反射させる！このターン敵の呪文を跳ね返す", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: このターン敵が" + Action.spell.jName + "を使った場合、その効果対象を自分と敵で入れ替える。必ず敵より先に行動する", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 敵が高火力呪文などを覚えている場合、最初のターンにこれを見せておくだけで、敵の呪文を牽制できる。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            ChangeActionState.onset(state, target_is_player1, !target_is_player1, ActionState.On_SpellReflect, log, text, scanner, rand);

            ChangeWeather.onset(state, this, this.weatherTurn, text, scanner);
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println(state.getPlayer(!target_is_player1).getJName() + "は魔法の鏡に覆われた！" + Print.sleep(2), true, Print.highSpeed, text);
            
        }
    },

    On_Joke("勇者ジョーク",
            Weather.NULL,
            -1,
            0,
            1,
            -3){
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            return 0;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Character self = state.getPlayer(actor_is_player1);
            Print.setFrameStart(text);
            Print.println(getLevelName(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("説明: 意味の無い呪文", Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("消費" + MainStatus.mp.jName + ": " + this.getCost(self), Print.highSpeed, text);
            Print.println("", Print.highSpeed, text);
            Print.println("詳細: 1 ターンを消費して究極のジョークを放つ", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("", Print.highSpeed, text);
            // Print.println("アドバイス : 最弱の呪文。これがドロップするのは避けよう。", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){
            Print.println("しかし、何も起こらなかった" + Print.sleep(2), true, Print.middleSpeed, text);
            
            return;
        }
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            int idx = rand.nextInt(3);
            if(idx == 0){
                Print.println(state.getPlayer(target_is_player1).getJName() + "「魔王を構おう！」" + Print.sleep(2), true, Print.highSpeed, text);
                
            }else if(idx == 1){
                Print.println(state.getPlayer(target_is_player1).getJName() + "「またオレ何かやっちゃいました？(やってません)」" + Print.sleep(2), true, Print.highSpeed, text);
                
            }else{
                Print.println(state.getPlayer(target_is_player1).getJName() + "「魔剣には負けん！」" + Print.sleep(2), true, Print.highSpeed, text);
                
            }
        }
    },
    NULL("_____", Weather.NULL, 0, 0, 0, 0){
        @Override
        public int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            return 0;
        }
        @Override
        public void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner){
            Print.setFrameStart(text);
            Print.println("何もない 空っぽの呪文", Print.highSpeed, text);
            Print.setFrameEnd(text);
        }
        @Override
        public void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner){}
        @Override
        public void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand){
            Print.println("・・・", true, Print.highSpeed, text);
        }
    }
    ;

    //フィールド
    public final String jName;// 名前
    public final Weather weather;// 呪文の天候
    public final int weatherTurn;// 天候が続くターン数
    protected final int mp;// 使用MP
    public final int baseLevel;// 基準レベル（基準レベルで同じ強さになる）
    public final int priority;// 優先度
    public static final int levelTurnBuff = 1;// 状態異常やフィールド系呪文がレベルが上がるたびに伸びるターン数
    //コンストラクタ
    private Spell(String name, Weather category, int weatherTurn, int mp, int baseLevel, int priority){
        this.jName = name;
        this.weather = category;
        this.weatherTurn = weatherTurn;
        this.mp = mp;
        this.baseLevel = baseLevel;
        this.priority = priority;
    }
    //ゲッタ
    // レベル付き名前
    public String getLevelName(Character self){
        int intLevel = getLevel(self);
        String stringLevel;
        if(intLevel <= 1){
            stringLevel = "";
        }else if(intLevel != Spell.maxLevel){
            stringLevel = "+".repeat(intLevel - 1);
        }else{
            stringLevel = "*";
        }
        return this.jName + stringLevel;
    }
    // 呪文レベルを取得
    public int getLevel(Character self){
        return self.getSpellLevel().get(this) > 0 ? self.getSpellLevel().get(this) : 1;
    }
    // 呪文コストを取得
    public int getCost(Character self){
        return this.mp;
        // List<Spell> decreaseCostSpells = new ArrayList<>(){{
        //     add(Spell.Heal);
        //     add(Spell.LargeHeal);
        //     add(Spell.Update);
        //     add(Spell.On_SpellReflect);
        //     add(Spell.On_StateChange);
        // }};

        // if(!decreaseCostSpells.contains(this)){
        //     return this.mp;
        // }

        // if(getLevel(self) == maxLevel){
        //     if(this == On_SpellReflect || this == On_StateChange){
        //         return 0;
        //     }
        //     return this.mp / 2;
        // }else{
        //     return this.mp - (this.mp >= 20 ? 3 : (this.mp >= 10 ? 2 : 1)) * (getLevel(self) - 1);
        // }
    }
    // レベルによる火力系呪文の火力能力増加効果
    public double getLevelPowerBuff(Character self){
        int level = getLevel(self);
        switch(level){
            case 1:
                return 1;
            // case 2:
            //     return 1.2;
            // case 3:
            //     return 1.5;
            // case Spell.maxLevel:
            //     return 2;
            default:
                System.out.println("レベルバグってる");
                return 1;
        }
    }
    // ターン効果の延長
    public int getLevelTurnBuff(Character self){
        return 0;
        // int level = getLevel(self);
        // return (level - 1) * levelTurnBuff;
    }
    // ポット・ヘイストの効果量
    public int getLevelBuffMount(Character self){
        int level = getLevel(self);
        switch(level){
            case 1:
                return 100;
            // case 2:
            //     return 85;
            // case 3:
            //     return 100;
            // case Spell.maxLevel:
            //     return 150;
            default:
                System.out.println("レベルバグってる");
                return 100;
        }
    }
    // 呪文のダメージ量を取得（各呪文でオーバーライド）
    public abstract int getDamage(State state, boolean actor_is_player1, boolean text, Scanner scanner);
    // コストを支払う
    public void spendCost(Character self, boolean text){
        Map<MainStatus, Integer> newMainStatus = self.getMainStatus();
        int cost = this.getCost(self);
        newMainStatus.replace(MainStatus.mp, self.getMainStatus().get(MainStatus.mp) - cost);
        self.setMainStatus(newMainStatus);
    }
    // 合法判定
    public boolean getLegal(State state, Weather stateWeather, Character self, boolean text, Scanner scanner){
        boolean isDynamic = true;
        if(self.getMainStatus().get(MainStatus.mp) < this.getCost(self)){
            Print.println("", Print.highSpeed, text);
            Print.println(self.getJName() + "は" + this.jName + "をセットしていなかった" + Print.sleep(2), isDynamic, Print.middleSpeed, text);
            
            return false;
        }else if(!self.getSpellSlot().contains(this)){
            Print.println("しかし、" + MainStatus.mp.jName + "が足りなかった" + Print.sleep(2), isDynamic, Print.middleSpeed, text);
            
            return false;
        }else if(ChangeWeather.makeRelation(stateWeather, this.weather, text, scanner) == WeatherRelation.nonActivation){
            return false;
        }if(state.getSpellUsed()){
            Print.println("しかし、既にこのターン相手に呪文を使われていた" + Print.sleep(2), isDynamic, Print.highSpeed, text);
            
            return false;
        }
        return true;
    }
    public double getDamageRate(){
        return this.damageRate;
    }
    public int getANum(){
        return this.aNum;
    }
    public int getHitRate(){
        return this.hitRate;
    }
    public double getRandomRate(){
        return this.randomRate;
    }
    public boolean getAttack(){
        return this.attack;
    }
    public boolean getUseTension(){
        return this.useTension;
    }
    public boolean getCanDefense(){
        return this.canDefense;
    }
    public boolean getDoApplyDefenceStatus(){
        return false;
    }

    //攻撃呪文と回復呪文のフィールド
    private double damageRate;// ダメージ倍率
    private int aNum;// 攻撃回数
    private int hitRate;// 命中率（現在は必中）
    private double randomRate;// ダメージの振れ幅
    //攻撃呪文のフィールド
    private boolean attack;// 攻撃であるか否か（溜める失敗に関わる）
    private boolean useTension;// テンションを使用するかどうか
    private boolean canDefense;// 防御可能かどうか
    //回復呪文のコンストラクタ
    private Spell(  String name, Weather category, int weatherTurn, int mp, int baseLevel, int priority,
                    double damageRate, double randomRate){
        this(name, category, weatherTurn, mp, baseLevel, priority);
        this.damageRate = damageRate;
        this.randomRate = randomRate;
    }
    //攻撃呪文のコンストラクタ
    private Spell(  String name, Weather category, int weatherTurn, int mp, int baseLevel, int priority,
                    double damageRate, int aNum, int hitRate, double randomRate,
                    boolean attack, boolean useTension, boolean canDefense){
        this(name, category, weatherTurn, mp, baseLevel, priority, damageRate, randomRate);
        this.aNum = aNum;
        this.hitRate = hitRate;
        this.attack = attack;
        this.useTension = useTension;
        this.canDefense = canDefense;
    }
    
    //メッセージの抽象メソッド
    public abstract void explain(State state, boolean actor_is_player1, boolean text, Scanner scanner);
    //処理の抽象メソッド
    public abstract void execute(State state, boolean actor_is_player1, boolean target_is_player1, BattleTemporaryLog log, boolean text, Random rand, Scanner scanner);
    //実行時の専用テキスト
    public abstract void executePrint(State state, boolean actor_is_player1, boolean target_is_player1, boolean text, Random rand);
    // 呪文の総数
    public static final int NUM = values().length - 1;

    // TODO 個別でレベル設定した方がよくね
    public static final int maxLevel = 1;

    public static final Map<Spell, List<Spell>> strengthenSpellCategory(){
        return new HashMap<>(){{
            put(Fire, new ArrayList<>(){{
                add(Fire);
                add(Flame);
                add(Explosion);
                add(BigBang);
            }});
            put(Wind, new ArrayList<>(){{
                add(Wind);
                add(Gust);
                add(Tornado);
                add(Storm);
            }});
            put(Stone, new ArrayList<>(){{
                add(Stone);
                add(Rock);
                add(Lava);
                add(Meteor);
            }});
            put(On_Joke, new ArrayList<>(){{
                add(On_Joke);
                add(KJA);
            }});
        }};
    }

    public static List<Spell> removeNULLFromList(List<Spell> spellList){
        spellList = new ArrayList<>(spellList);
        spellList.removeAll(new ArrayList<>(){{add(NULL);}});
        return spellList;
    }
}