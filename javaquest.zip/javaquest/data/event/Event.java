package data.event;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import battle.CalculateDamage;
import battle.CalculateDamage.CostCategory;
import battle.CalculateDamage.CostParameter;
import character.Enemy;
import character.Player;
import character.Skill;
import character.Character.MainStatus;
import character.Player.TrainStatus;
import data.enemy.BaseMonster;
import data.enemy.Monster;
import data.item.BattleItem;
import data.item.DisposableItem;
import data.item.ImmediateItem;
import data.item.Item;
import data.item.Item.Shop;
import limitation.TrainLimitation;
import limitation.TrainLimitation.TrainLimitationCounter;
import log.TrainTemporaryLog;
import text.Print;
import text.Print.Color;
import train.Train;
import train.TrainState;
import train.TrainState.Mode;

// ターン終了時に発生するイベントのクラス
public enum Event {
    battle("強制戦闘",
            0,
            "改装中です。"){
        @Override
        public TrainState execute(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner, Random rand){

            Player self = trainState.getSelf();

            Print.println("・・・", Print.middleSpeed, text);
            Print.nextLine(scanner, text);
            Print.println("ぼよぼよが降ってきた！", Print.middleSpeed, text);
            Print.nextLine(scanner, text);
            Print.println("戦わざるを得ない！", Print.middleSpeed, text);
            Print.nextLine(scanner, text);

            self.trainToBattleStatus();
            Enemy enemy;

            // if(trainState.getTurn() <= 6){
            //     enemy = new Enemy(Monster.BoyoMini);
            // }else if(trainState.getTurn() <= 12){
            //     enemy = new Enemy(Monster.Boyo);
            // }else if(trainState.getTurn() <= 18){
            //     enemy = new Enemy(Monster.BoyoGood);
            // }else if(trainState.getTurn() <= 24){
            //     enemy = new Enemy(Monster.BoyoGreat);
            // }else{
            //     enemy = new Enemy(Monster.BoyoPerfect);
            // }
            // trainState = Train.battle(trainState, beforeTrainState, enemy, true, log, text, scanner, rand);
            return trainState;
        }

        @Override
        public boolean useAble(TrainState trainState) {
            return true;
        }

        @Override
        public int[] legalActions(TrainState trainState){
            return new int[0];
        }
    },
    tutorialBattle("チュートリアル戦闘",
            0,
            "改装中です。"){
        @Override
        public TrainState execute(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner, Random rand){
            Player self = trainState.getSelf();

            Print.println("・・・", Print.middleSpeed, text);
            Print.nextLine(scanner, text);
            /*Print.println("よくぞ来てくださいました" + self.jName + "よ", Print.middleSpeed, text);
            Print.nextLine(scanner, text);*/
            Print.println("チュートリアルが降ってきた！", Print.middleSpeed, text);
            Print.nextLine(scanner, text);
            Print.println("戦わざるを得ない！", Print.middleSpeed, text);
            Print.nextLine(scanner, text);

            self.trainToBattleStatus();
            boolean useItem = self.getUseItem();
            boolean useSpecial = self.getUseSpecial();
            boolean useSpell = self.getUseSpell();
            self.setUseItem(false);
            self.setUseSpecial(false);
            self.setUseSpell(false);
            Enemy enemy = new Enemy(BaseMonster.red, 1, 1);

            trainState = Train.battle(trainState, beforeTrainState, enemy, true, log, text, scanner, rand);
            trainState.getSelf().setUseItem(useItem);
            trainState.getSelf().setUseSpecial(useSpecial);
            trainState.getSelf().setUseSpell(useSpell);
            return trainState;
        }

        @Override
        public boolean useAble(TrainState trainState) {
            return true;
        }

        @Override
        public int[] legalActions(TrainState trainState){
            return new int[0];
        }
    },
    // DarkShop("闇商人",
    //         10,
    //         "特殊なアイテムを販売する。"){
    //     @Override
    //     public TrainState execute(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner, Random rand){

    //         Player self = trainState.getSelf();
    //         int idx, num, cost;
    //         List<Integer> legalActionsList = new ArrayList<Integer>();

    //         Print.println("・・・", Print.middleSpeed, text);
    //         Print.nextLine(scanner, text);
    //         Print.println("1ターンごとの値段の上昇を受けていない店。", Print.middleSpeed, text);
    //         Print.nextLine(scanner, text);
    //         Print.println("特殊なアイテムを売っている。1回に1つのアイテムしか買えない。", Print.middleSpeed, text);
    //         Print.nextLine(scanner, text);
    //         /*Print.println("ひっひっひ", Print.middleSpeed, text);
    //         Print.nextLine(scanner, text);
    //         Print.println("あなた、なかなか腕が立つようじゃあないですかぁ", Print.middleSpeed, text);
    //         Print.nextLine(scanner, text);
    //         Print.println("そこで、あなたにイイ商品があるんですよぉ", Print.middleSpeed, text);
    //         Print.nextLine(scanner, text);
    //         Print.println("うちの店は所謂“裏”の店なんで税金はかかりませんよぉ", Print.middleSpeed, text);
    //         Print.nextLine(scanner, text);
    //         Print.println("どうぞお手に取って試してみてくださいなぁ", Print.middleSpeed, text);
    //         Print.nextLine(scanner, text);
    //         Print.println("しかし、うちの商品はレアものばかり", Print.middleSpeed, text);
    //         Print.nextLine(scanner, text);
    //         Print.println("1回に1個しか買えないので慎重に選んでくださいねぇ", Print.middleSpeed, text);*/
    //         Print.nextLine(scanner, text);
    //         while(true){
    //             //Print.println("<br>何をお買い上げになるので", Print.middleSpeed, text);
    //             Print.println("<br>何を買いますか(-番号入力で詳細)    <br>現在の所持金 : " + self.getTrainStatus().get(TrainStatus.money) + "円<br>", Print.middleSpeed, text);
    //             for(int i = 0; i < Item.shopNUM(trainState, Shop.Dark, trainState.getMode()); i++){
    //                 Item darkItem = Item.shopItemList(trainState, Shop.Dark).get(i);
    //                 if(!trainState.getBuyAble().get(darkItem) || (darkItem instanceof ImmediateItem && !((ImmediateItem)darkItem).useAble(trainState))){
    //                     Print.println((i + 1) + ":" + darkItem.getJName(trainState) + "  うりきれ", Print.highSpeed, text);
    //                 }else{
    //                     cost = Item.shopItemList(trainState, Shop.Dark).get(i).getCost(self);
    //                     cost *= trainState.getMode().scale;
    //                     if(self.getSkill() == Skill.trader){
    //                         cost *= 3;
    //                         cost /= 4;
    //                     }
    //                     Print.println((i + 1) + ":" + darkItem.getJName(trainState) + "  " + cost + "円", Print.highSpeed, text);
    //                     if(cost <= self.getTrainStatus().get(TrainStatus.money)){
    //                         legalActionsList.add(i+1);
    //                     }
    //                 }
    //             }
    //             Print.println((Item.shopNUM(trainState, Shop.Dark, trainState.getMode()) + 1) + ":買わない", Print.highSpeed, text);
    //             legalActionsList.add(Item.shopNUM(trainState, Shop.Dark, trainState.getMode())+1);

    //             idx = Train.makeAction(trainState, beforeTrainState, scanner, text, rand);
    //             if(idx == Item.shopNUM(trainState, Shop.Dark, trainState.getMode()) + 1){
    //                 break;
    //             }
    //             if(idx < -Item.shopNUM(trainState, Shop.Dark, trainState.getMode()) || idx == 0 || idx > Item.shopNUM(trainState, Shop.Dark, trainState.getMode()) + 1){
    //                 //Print.println("ちゃんと入力しなさんな", Print.highSpeed, text);
    //                 Print.println("正しく入力してください", Print.highSpeed, text);
    //                 continue;
    //             }
    //             if (idx < 0) {
    //                 Print.println(Item.shopItemList(trainState, Shop.Dark).get(-idx - 1).getExplain(), Print.highSpeed, text);
    //                 Print.nextLine(scanner, text);
    //                 continue;
    //             }

    //             Item darkItem = Item.shopItemList(trainState, Shop.Dark).get(idx - 1);
    //             if(!trainState.getBuyAble().get(darkItem) || (darkItem instanceof ImmediateItem && !((ImmediateItem)darkItem).useAble(trainState))){
    //                 //Print.println("すみませんねぇ、もう売ってないんですよ", Print.middleSpeed, text);
    //                 Print.println("売り切れです", Print.middleSpeed, text);
    //                 continue;
    //             }
    //             if(darkItem.getSomeBuyAble()){
    //                 //Print.println(darkItem.getJName(trainState) + "を幾つ買いますかい", Print.highSpeed, text);
    //                 Print.println(darkItem.getJName(trainState) + "を幾つ買いますか", Print.highSpeed, text);
    //                 num = Train.makeAction(trainState, beforeTrainState, scanner, text, rand);

    //                 if(num < 0){
    //                     //Print.println("おっと、ズルはいけませんねぇ、ズルは", Print.middleSpeed, text);
    //                     Print.println("アイテムをマイナス個買うことは出来ません", Print.middleSpeed, text);
    //                     continue;
    //                 }

    //                 if(num > 99){
    //                     //Print.println("すみませんねぇ、うちにはそんな在庫はありませんよ", Print.middleSpeed, text);
    //                     Print.println("一度に100個以上買うことは出来ません", Print.middleSpeed, text);
    //                     continue;
    //                 }
    //             }else{
    //                 //Print.println("これはとても珍しくてねぇ、一つしか仕入れられてないんですよ<br>このアイテムを買いますかい<br>1:はい" + Print.space(2, text) + "2:いいえ", Print.highSpeed, text);
    //                 Print.println("このアイテムは1つしか買うことが出来ません<br>このアイテムを買いますか<br>1:はい" + Print.space(2, text) + "2:いいえ", Print.highSpeed, text);
    //                 if(Train.makeAction(trainState, beforeTrainState, scanner, text, rand) != 1){
    //                     continue;
    //                 }
    //                 num = 1;
    //             }

    //             cost = darkItem.getCost(self) * num;
    //             cost *= trainState.getMode().scale;
    //             if(self.getSkill() == Skill.trader){
    //                 cost *= 3;
    //                 cost /= 4;
    //             }

    //             if(self.getTrainStatus().get(TrainStatus.money) < cost){
    //                 //Print.println("おやおや、お金が足りないみたいですねぇ", Print.middleSpeed, text);
    //                 Print.println("お金が足りません", Print.middleSpeed, text);
    //                 Print.nextLine(scanner, text);
    //                 continue;
    //             }
        
    //             CalculateDamage.trainDamage(self, TrainStatus.money, cost, false);

    //             if(darkItem instanceof BattleItem){
    //                 if(!log.getBuyB().containsKey((BattleItem)darkItem)){
    //                     log.getBuyB().put((BattleItem)darkItem, num);
    //                 }else{
    //                     log.getBuyB().replace((BattleItem)darkItem, log.getBuyB().get((BattleItem)darkItem) + num);
    //                 }
    //                 self.getItemList().replace((BattleItem)darkItem, self.getItemList().get((BattleItem)darkItem) + num);
    //                 BattleItem.dromItem(self, trainState.getAuto(), rand, scanner, text);

    //             }
    //             if(darkItem instanceof DisposableItem){
    //                 if(!log.getBuyD().containsKey((DisposableItem)darkItem)){
    //                     log.getBuyD().put((DisposableItem)darkItem, num);
    //                 }else{
    //                     log.getBuyD().replace((DisposableItem)darkItem, log.getBuyD().get((DisposableItem)darkItem) + num);
    //                 }
    //                 self.getDisposableItemList().replace((DisposableItem)darkItem, self.getDisposableItemList().get((DisposableItem)darkItem) + num);
    //             }
    //             if(darkItem instanceof ImmediateItem){
    //                 if(!log.getBuyI().containsKey((ImmediateItem)darkItem)){
    //                     log.getBuyI().put((ImmediateItem)darkItem, num);
    //                 }else{
    //                     log.getBuyI().replace((ImmediateItem)darkItem, log.getBuyI().get((ImmediateItem)darkItem) + num);
    //                 }
    //                 trainState.setSelf(self);
    //                 for(int i = 0; i < num; i++){
    //                     trainState = ((ImmediateItem)darkItem).execute(trainState, text, scanner, rand);
    //                 }
    //                 self = trainState.getSelf();
    //             }
    //             //Print.println(cost + "円頂戴いたしますよ", Print.middleSpeed, text);
    //             Print.println(cost + "円になります", Print.middleSpeed, text);
    //             break;
    //         }
    //         trainState.setSelf(self);
    //         return trainState;
    //     }

    //     @Override
    //     public boolean useAble(TrainState trainState) {
    //         return true;
    //     }

    //     @Override
    //     public int[] legalActions(TrainState trainState){
    //         Player self = trainState.getSelf();
    //         List<Integer> legalActionsList = new ArrayList<Integer>();

    //         for(int i = 0; i < Item.shopNUM(trainState, Shop.Dark, trainState.getMode()); i++){
    //             Item darkItem = Item.shopItemList(trainState, Shop.Dark).get(i);
    //             if(trainState.getBuyAble().get(darkItem) && !(darkItem instanceof ImmediateItem && !((ImmediateItem)darkItem).useAble(trainState))){
    //                 if(Item.shopItemList(trainState, Shop.Dark).get(i).getCost(self) <= self.getTrainStatus().get(TrainStatus.money)){
    //                     legalActionsList.add(i+1);
    //                 }
    //             }
    //         }
    //         legalActionsList.add(Item.shopNUM(trainState, Shop.Dark, trainState.getMode())+1);//不購入

    //         return legalActionsList.stream().mapToInt(i->i).toArray();
    //     }
    // },
    DarkShop("闇商人",
            0,
            "ステータスをコストにアイテムを販売する。"){
        @Override
        public TrainState execute(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner, Random rand){

            Player self = trainState.getSelf();

            BattleItem item = BattleItem.Elixir;
            TrainStatus costCategory = TrainStatus.maxHp;
            int cost = 1000;
            TrainStatus presentCategory = TrainStatus.maxHp;
            int present = 100;
            int act;
            Print.println("・・・", Print.middleSpeed, text);
            Print.nextLine(scanner, text);
            Print.println(Color.yellow.toColor("選択してください"), Print.middleSpeed, text);
            Print.println("1:" + costCategory.jName + "を " + cost + " 支払って" + item.jName + "を手に入れる", Print.middleSpeed, text);
            Print.println("2:" + presentCategory.jName + "を " + present + " 手に入れる", Print.middleSpeed, text);
            do{
                act = Train.makeAction(trainState, beforeTrainState, scanner, text, rand);
            }while(act != 1 && act != 2);
            if(act == 1){
                CalculateDamage.trainDamage(self, new CalculateDamage().new CostParameter(costCategory, cost, CostCategory.direct), false);
                if(costCategory.child != null){
                    CalculateDamage.trainDamage(self, costCategory.child, 0, false);
                }
                if(!log.getBuyB().containsKey(item)){
                    log.getBuyB().put(item, 1);
                }else{
                    log.getBuyB().replace(item, log.getBuyB().get(item) + 1);
                }
                self.getItemList().replace(item, self.getItemList().get(item) + 1);
                BattleItem.dromItem(self, trainState.getAuto(), rand, scanner, text);
                Print.println(costCategory + "を " + cost + " 支払い" + item.jName + "を購入した", Print.middleSpeed, text);
                Print.nextLine(scanner, false);
            }else{
                CalculateDamage.trainProgress(self, presentCategory, false, present, text);
                CalculateDamage.trainDamage(self, new CalculateDamage().new CostParameter(presentCategory.child, -present, CostCategory.direct), false);
            }
            trainState.setSelf(self);
            return trainState;
        }

        @Override
        public boolean useAble(TrainState trainState) {
            return true;
        }

        @Override
        public int[] legalActions(TrainState trainState){
            return new int[]{1, 2};
        }
    },
    /*accident("アクシデント",
            5,
            "改装中です。"){
        @Override
        public TrainState execute(TrainState trainState, TrainTemporaryLog log, boolean text, Scanner scanner, Random rand){

            Player self = trainState.getSelf();
            Map<TrainStatus, Integer> trainStatus = self.getTrainStatus();

            Print.println("・・・", Print.middleSpeed, text);
            Print.nextLine(scanner, text);
            Print.println("鉄骨が降ってきた！", Print.middleSpeed, text);
            Print.nextLine(scanner, text);
            Print.println("<br>選べ！<br>1:耐える2:殴り返す", Print.highSpeed, text);
            int choice = Train.makeAction(trainState, scanner, text, rand);
            Print.println("ボカン！", Print.middleSpeed, text);
            Print.nextLine(scanner, text);

            if(choice == 1){
                Print.println("鉄骨により" + (trainStatus.get(TrainStatus.maxHp) * 0.15) + "のダメージを受けた", Print.middleSpeed, text);
                Print.nextLine(scanner, text);
                trainStatus.replace(TrainStatus.hp, (int)(trainStatus.get(TrainStatus.hp) - trainStatus.get(TrainStatus.maxHp) * 0.15));
            }else if(choice == 2){
                if(rand.nextDouble() < 0.5){
                    Print.println("鉄骨を跳ね返した！", Print.middleSpeed, text);
                    Print.nextLine(scanner, text);
                    Print.println("自分の力に自信を持った", Print.middleSpeed, text);
                    Print.nextLine(scanner, text);
                    trainStatus.replace(TrainStatus.a, (int)(trainStatus.get(TrainStatus.a) * 1.1));
                    Print.println("攻撃力が10%上昇した", Print.middleSpeed, text);
                    Print.nextLine(scanner, text);
                }else{
                    Print.println("鉄骨が直撃した！", Print.middleSpeed, text);
                    Print.nextLine(scanner, text);
                    Print.println("鉄骨により" + (trainStatus.get(TrainStatus.maxHp) * 0.25) + "のダメージを受けた", Print.middleSpeed, text);
                    Print.nextLine(scanner, text);
                    trainStatus.replace(TrainStatus.hp, (int)(trainStatus.get(TrainStatus.hp) - trainStatus.get(TrainStatus.maxHp) * 0.25));
                }
            }
            self.setTrainStatus(trainStatus);
            trainState.setSelf(self);
            return trainState;
        }

        @Override
        public boolean useAble(TrainState trainState) {
            return true;
        }

        @Override
        public int[] legalActions(TrainState trainState){
            return new int[]{1, 2};
        }
    },*/
    gambling("ギャンブル",
            0,
            "ギャンブル。"){
        @Override
        public TrainState execute(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner, Random rand){

            Player self = trainState.getSelf();
            TrainStatus money = TrainStatus.money;
            int minReward = 5;

            Print.println("・・・", Print.middleSpeed, text);
            Print.nextLine(scanner, text);
            /* Print.println("ギャンブル！", Print.middleSpeed, text);
            Print.nextLine(scanner, text); */
            Print.println("所持金が 2 倍になるか半分になるかの賭けです。", Print.middleSpeed, text);
            Print.println(Color.scarlet.toColor("※ 勝率は五分五分です"), Print.highSpeed, text);
            Print.println("現在の所持金 : " + self.getTrainStatus().get(money), Print.middleSpeed, text);
            Print.nextLine(scanner, text);
            if(self.getTrainStatus().get(money) < minReward){
                Print.println("おっと、所持金が少ないですね", Print.middleSpeed, text);
                Print.nextLine(scanner, text);
                Print.println("もし参加してくれたら掛け金を 5 円にしてあげましょう", Print.middleSpeed, text);
                Print.nextLine(scanner, text);
            }
            Print.println("", Print.middleSpeed, text);
            Print.println("しますか？", Print.highSpeed, text);
                Print.println("", true, Print.highSpeed, text);
                Print.println("1:はい" + Print.space(2, text) + "2:いいえ", Print.middleSpeed, text);
    
            if(Train.makeAction(trainState, beforeTrainState, scanner, text, rand) == 1){
                // Print.println("<br>何円賭ける    " + money.jName + "：" + self.getTrainStatus().get(money) + "円", Print.highSpeed, text);
                // int reward = Train.makeAction(trainState, beforeTrainState, scanner, text, rand);
                int reward = self.getTrainStatus().get(money);
                // if(reward > self.getTrainStatus().get(money)){
                //     //Print.println("ズルはいけませんねぇ", Print.middleSpeed, text);
                //     Print.println("自分の所持金を超える金額は賭けることが出来ません", Print.middleSpeed, text);
                //     Print.nextLine(scanner, text);
                //     trainState.setSelf(self);
                //     return trainState;
                // }
                CalculateDamage.trainDamage(self, money, reward, false);
                if(reward < minReward){
                    reward = minReward;
                }
                // while(true){
                    Print.println("賭けた！", Print.middleSpeed, text);
                    Print.nextLine(scanner, text);
                    if(rand.nextDouble() > 0.5){
                        Print.println("勝った！", Print.middleSpeed, text);
                        Print.nextLine(scanner, text);
                        Print.println("賭け金が 2 倍になった", Print.middleSpeed, text);
                        Print.nextLine(scanner, text);
                        reward *= 2;

                    }else{
                        Print.println("負けた！", Print.middleSpeed, text);
                        Print.nextLine(scanner, text);
                        Print.println("賭け金が半分になった", Print.middleSpeed, text);
                        Print.nextLine(scanner, text);
                        trainState.setSelf(self);
                        reward /= 2;
                    }
                    Print.println("現在の所持金 : " + reward, Print.highSpeed, text);
                //     Print.println("さらに続けますか<br>1:はい" + Print.space(2, text) + "2:いいえ", Print.highSpeed, text);
                //     if(Train.makeAction(trainState, beforeTrainState, scanner, text, rand) != 1){
                //         break;
                //     }
                // }
                CalculateDamage.trainDamage(self, money, -reward, false);
                trainState.setSelf(self);
                return trainState;
            }else{
                /*Print.println("せっかくのギャンブルの機会を投げ捨てた！", Print.middleSpeed, text);
                Print.nextLine(scanner, text);
                Print.println("残念な気持ちになった", Print.middleSpeed, text);
                Print.nextLine(scanner, text);*/
                Print.println("ギャンブルはしなかった", Print.middleSpeed, text);
                Print.nextLine(scanner, text);
            }
            trainState.setSelf(self);
            return trainState;
        }

        @Override
        public boolean useAble(TrainState trainState) {
            return true;
        }

        @Override
        public int[] legalActions(TrainState trainState){//不参加
            return new int[]{0};
        }
    },
    Moti("ギアもち",
            6,
            "おもち。"){
        @Override
        public TrainState execute(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner, Random rand){
            Player self = trainState.getSelf();
            boolean noHeal = true;

            Print.println("・・・", Print.middleSpeed, text);
            Print.nextLine(scanner, text);
            /* Print.println("棚からギアもちが降ってきた！", Print.middleSpeed, text);
            Print.nextLine(scanner, text); */
            List<TrainStatus> healTrainStatusList = new ArrayList<TrainStatus>(){{
                add(TrainStatus.maxHp);
                add(TrainStatus.maxMotivation);
                add(TrainStatus.maxConcentration);
                // add(TrainStatus.maxGasoline);
            }};
            Print.println("", Print.middleSpeed, text);
            Print.println("どれか一つのステータスを 30%回復できます", Print.middleSpeed, text);
            for(TrainStatus category : healTrainStatusList){
                if(!self.getTrainStatus().get(category).equals(self.getTrainStatus().get(category.child))){
                    noHeal = false;
                    break;
                }
            }
            if(noHeal){
                Print.nextLine(scanner, text);
                Print.println("どうやら回復できるステータスが存在しないようですね", Print.middleSpeed, text);
                Print.nextLine(scanner, text);
                Print.println("特別に次の日に消費するパラメータを0にしてあげましょう", Print.middleSpeed, text);
                Print.nextLine(scanner, text);
                int elixirTurn = 2;//1だとこのターンで終わってしまう
                self.setElixirTurn(elixirTurn);
                trainState.setSelf(self);
                return trainState;
            }
            Print.displayTrainCostStatus(trainState, text);
            for(int i = 0; i < healTrainStatusList.size(); i++){
                Print.println((i+1) + ":" + healTrainStatusList.get(i).child.jName, Print.middleSpeed, text);
            }
            // Print.println("1:", Print.middleSpeed, text);
            // Print.println("2:HPが全回復するか、全く回復しない（確率は半々）", Print.middleSpeed, text);
            //Print.println("<br>食べますか<br>1:はい" + Print.space(2, text) + "2:いいえ", Print.highSpeed, text);
            // Print.println("<br>挑戦しますか<br>1:はい" + Print.space(2, text) + "2:いいえ", Print.highSpeed, text);
            int act = -1;
            do{
                if(act != -1){
                    Print.println("正しく入力してください", Print.highSpeed, text);
                }
                act = Train.makeAction(trainState, beforeTrainState, scanner, text, rand);
            }while(act <= 0 || healTrainStatusList.size() < act);
            CalculateDamage.trainDamage(self, healTrainStatusList.get(act-1), -30, text);
            Print.nextLine(scanner, text);
            trainState.setSelf(self);
            return trainState;
            
        }

        @Override
        public boolean useAble(TrainState trainState) {
            return true;
        }

        @Override
        public int[] legalActions(TrainState trainState){
            return new int[]{1, 2};
        }
    },
    StatusShuffle("ステータスシャッフル",
            0,
            "ステータスシャッフル"){
        @Override
        public TrainState execute(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner, Random rand){

            Player self = trainState.getSelf();
            Map<TrainStatus, Integer> trainStatus = self.getTrainStatus();

            Print.println("・・・", Print.middleSpeed, text);
            Print.nextLine(scanner, text);
            /* Print.println("棚からギアもちが降ってきた！", Print.middleSpeed, text);
            Print.nextLine(scanner, text); */
            //Print.println("<br>食べますか<br>1:はい" + Print.space(2, text) + "2:いいえ", Print.highSpeed, text);
            // Print.println("<br>挑戦しますか<br>1:はい" + Print.space(2, text) + "2:いいえ", Print.highSpeed, text);
    

            Print.println("現在のステータス", Print.highSpeed, text);
            Print.print(TrainStatus.hp.jName + " : " + trainStatus.get(TrainStatus.hp) + " / " + trainStatus.get(TrainStatus.maxHp), Print.highSpeed, text);
            Print.print("    " + TrainStatus.a.jName + " : " + trainStatus.get(TrainStatus.a), Print.highSpeed, text);
            Print.println("    " + TrainStatus.s.jName + " : " + trainStatus.get(TrainStatus.s), Print.highSpeed, text);
            Print.println("", Print.middleSpeed, text);
            Print.println(Color.yellow.toColor("選択してください"), Print.middleSpeed, text);
            Print.println("1:" + TrainStatus.hp.jName + "と" + TrainStatus.a.jName + "と" + TrainStatus.s.jName + "がランダムに入れ替わります", Print.middleSpeed, text);
            Print.println("ボーナスとして" + TrainStatus.hp.jName + "が全回復します", Print.middleSpeed, text);
            Print.println(Color.scarlet.toColor("  ※ " + MainStatus.hp.jName + "とその他のステータスの交換比率は 10 : 1 で扱われます"), Print.middleSpeed, text);
            Print.println("2:" + TrainStatus.hp.jName + "が 10%回復する", Print.middleSpeed, text);
            if(Train.makeAction(trainState, beforeTrainState, scanner, text, rand) == 1){
                int statusIdx;
                TrainStatus[] trainStatusArray = new TrainStatus[]{TrainStatus.maxHp, TrainStatus.a, TrainStatus.s};
                // double hpRate = (double)self.getTrainStatus().get(TrainStatus.hp) / (double)self.getTrainStatus().get(TrainStatus.maxHp);
                List<Integer> statusList = new ArrayList<Integer>(){{
                    add(trainStatus.get(TrainStatus.maxHp) / 10);
                    add(trainStatus.get(TrainStatus.a));
                    add(trainStatus.get(TrainStatus.s));
                }};
                for(TrainStatus category : trainStatusArray){
                    statusIdx = rand.nextInt(statusList.size());
                    trainStatus.replace(category, statusList.get(statusIdx) * (category == TrainStatus.maxHp ? 10 : 1));
                    statusList.remove(statusIdx);
                }
                statusIdx = rand.nextInt(trainStatusArray.length);
                // trainStatus.replace(trainStatusArray[statusIdx], (int)(trainStatus.get(trainStatusArray[statusIdx]) * 1.5));
                // trainStatus.replace(TrainStatus.hp, (int)(trainStatus.get(TrainStatus.maxHp) * hpRate));
                CalculateDamage.trainDamage(self, TrainStatus.maxHp, -100, text);
                self.setTrainStatus(trainStatus);
                Print.println("ステータスをシャッフルした。", Print.highSpeed, text);
                Print.nextLine(scanner, text);
                Print.println("シャッフル後のステータス", Print.highSpeed, text);
                Print.print(TrainStatus.hp.jName + " : " + trainStatus.get(TrainStatus.hp) + " / " + trainStatus.get(TrainStatus.maxHp), Print.highSpeed, text);
                Print.print("    " + TrainStatus.a.jName + " : " + trainStatus.get(TrainStatus.a), Print.highSpeed, text);
                Print.println("    " + TrainStatus.s.jName + " : " + trainStatus.get(TrainStatus.s), Print.highSpeed, text);
                Print.nextLine(scanner, text);
            }else{
                CalculateDamage.trainDamage(self, TrainStatus.maxHp, -10, text);
                Print.nextLine(scanner, text);
            }

            trainState.setSelf(self);
            return trainState;
            
        }

        @Override
        public boolean useAble(TrainState trainState) {
            return true;
        }

        @Override
        public int[] legalActions(TrainState trainState){
            return new int[]{1, 2};
        }
    },
    SpellUnlimit("ランダム呪文解放",
            6,
            "解放されていない呪文が一つ解放される。"){
        @Override
        public TrainState execute(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner, Random rand){
            Print.println("・・・", Print.middleSpeed, text);
            Print.println("今まで解放していない呪文がランダムに一つ解放されます！", Print.highSpeed, text);
            Print.println("さて、今回解放されるのはどの呪文でしょう！", Print.highSpeed, text);
            Print.println("・・・", Print.highSpeed, text);
            Print.nextLine(scanner, text);
            Print.println("・・・・・・", Print.highSpeed, text);
            Print.nextLine(scanner, text);
            Print.println("・・・・・・・・・", Print.highSpeed, text);
            Print.nextLine(scanner, text);
            List<TrainLimitation> unlimitSpells = TrainLimitation.unlimitLimitations(trainState, new ArrayList<>(TrainLimitation.spellWithNormalSpellLimitation().keySet()));
            unlimitSpells.addAll(TrainLimitation.unlimitLimitations(trainState, TrainLimitation.strengthenSpellLimitation(trainState)));
            TrainLimitation unlimitSpell = unlimitSpells.get(rand.nextInt(unlimitSpells.size()));
            TrainLimitation.unlimit(trainState, unlimitSpell, unlimitSpell.unlimitCount, text, scanner);
            Print.println("ぜひ、ショップで買ってあげましょう！", Print.highSpeed, text);
            Print.nextLine(scanner, text);
            return trainState;
            
        }

        @Override
        public boolean useAble(TrainState trainState) {
            return true;
        }

        @Override
        public int[] legalActions(TrainState trainState){
            return new int[]{1, 2};
        }
    },
    /*accident("アクシデント",
            10,
            "改装中です。"){
        @Override
        public void execute(Player self, boolean text, Scanner scanner, Random rand){
            Map<TrainStatus, Integer> trainStatus = self.getTrainStatus();
            TrainStatus category;

            Print.println("・・・", Print.middleSpeed, text);
            Print.nextLine(scanner, text);
            Print.println("ギャンブラーが勝負を強要してきた！", Print.middleSpeed, text);
            Print.nextLine(scanner, text);
            Print.println("<br>選べ！<br>1:HP2:精神力3:行動力", Print.highSpeed, text);
            int choice = Print.nextLine(scanner, text);
            Print.println("ボカン！", Print.middleSpeed, text);
            Print.nextLine(scanner, text);

            if(choice == 1){
                category = TrainStatus.maxHp;
            }else if(choice == 2){
                category = TrainStatus.maxMp;
            }else{
                category = TrainStatus.maxActivity;
            }
    
            if(rand.nextDouble() < 0.5){
                Print.println(category.child.jName + "が回復した！", Print.middleSpeed, text);
                Print.nextLine(scanner, text);

                if(trainStatus.get(category) < trainStatus.get(category.child) + trainStatus.get(category) * 0.3){
                    trainStatus.replace(category.child, trainStatus.get(category));
                }else{
                    trainStatus.replace(category.child, (int)(trainStatus.get(category.child) + trainStatus.get(category) * 0.3));
                }
                return;
            }else{
                Print.println(TrainStatus.hp.jName + "が減少した！", Print.middleSpeed, text);
                Print.nextLine(scanner, text);

                if(0 > (int)(trainStatus.get(TrainStatus.hp) - trainStatus.get(TrainStatus.maxHp) * 0.3)){
                    trainStatus.replace(TrainStatus.hp, 0);
                }else{
                    trainStatus.replace(TrainStatus.hp, (int)(trainStatus.get(TrainStatus.hp) - trainStatus.get(TrainStatus.maxHp) * 0.3));
                }
                return;
            }
        }

        @Override
        public boolean useAble(Player self) {
            return true;
        }
    },*/
    ;   

    //フィールド
    public final String jName;// 名前
    public final int probability;// 発生確率
    public final String explain;// 説明
    //コンストラクタ
    private Event(String name, int probability, String explain){
        this.jName = name;
        this.probability = probability;
        this.explain = explain;
    }

    // public static int easyLimit = 10;//10ターン目までイベントが発生しない

    //処理の抽象メソッド
    public abstract TrainState execute(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner, Random rand);

    //使用可能判定の抽象メソッド
    public abstract boolean useAble(TrainState trainState);

    // 合法選択肢
    public abstract int[] legalActions(TrainState trainState);

    //アイテムの総数
    public static final int NUM = values().length;

    //鍛錬後、戦闘後のイベントを行う（固定イベントはturnUpdata時に行う）
    public static TrainState turnendExecute(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner, Random rand){
        if((trainState.getTrainLimitations().get(TrainLimitation.fixedEvent).get(TrainLimitationCounter.flag) == 1 && TrainLimitation.fixedEvent.fixedEvents().keySet().contains(trainState.getTurn())) || 
            trainState.getTrainLimitations().get(TrainLimitation.randomEvent).get(TrainLimitationCounter.flag) != 1 || 
            trainState.getSelf().getSkill() == Skill.KJA){
            return trainState;
        }
        List<Event> eventList = Arrays.asList(Event.values());
        boolean eventHappen = false;
        Collections.shuffle(eventList, rand);
        for (Event event : eventList) {
            // if (event == Event.DarkShop || (event == Event.battle && trainState.getMode() == Mode.easy
            //         && trainState.getTurn() <= Event.easyLimit)) {
            //     continue;
            // }
            if (rand.nextInt(100) < event.probability * (1 + trainState.getMissedEventChainNum())) {
                trainState = event.execute(trainState, beforeTrainState, log, text, scanner, rand);
                eventHappen = true;
            }
        }
        if(!eventHappen){
            trainState.setMissedEventChainNum(trainState.getMissedEventChainNum() + 1);
        }else{
            trainState.setMissedEventChainNum(0);
        }
        return trainState;
    }
}
