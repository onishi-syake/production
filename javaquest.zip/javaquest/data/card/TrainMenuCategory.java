package data.card;

public enum TrainMenuCategory {
    HP("HP"),
    A("攻撃力"),
    S("素早さ"),
    MP("スロット増強"),
    ;
    public final String jName;
    private TrainMenuCategory(String jName){
        this.jName = jName;
    }
    
}
