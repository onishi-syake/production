package data.card;

import java.io.ObjectInputFilter.Status;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import battle.CalculateDamage;
import battle.state_change.ChangeBattleStatus;
import character.Enemy;
import character.Player;
import character.Character.BattleStatus;
import character.Character.MainStatus;
import character.Player.TrainStatus;
import data.enemy.BaseMonster;
import data.enemy.MonsterCategory;
import game.LocationCategory;
import game.SwingTest;
import limitation.TrainLimitation;
import log.TrainTemporaryLog;
import text.Print;
import text.Print.Color;
import train.Train;
import train.TrainState;
import train.TrainState.Mode;
import train.TrainState.TimeFrame;
import train.TrainState.shuffleModeWithAddCard;

public enum Guild implements Card{
    red(
        "[冒険者 レッド]",
        BaseMonster.red,
        0,// 報酬段階のボーナス
        1,// 使用行動数
        1,// 枠の大きさ
        0,// 解放時にデッキに追加する枚数
        new ArrayList<Card>(){{
            add(TrainMenu.mp);
        }},
        new ArrayList<TimeFrame>(){{
            add(TimeFrame.morning);
            add(TimeFrame.afternoon);
            add(TimeFrame.night);
        }},
        new HashMap<>(){{
            put(TrainMenuCategory.A, 1);
        }}),
    brown(
        "[冒険者 ブラウン]",
        BaseMonster.brown,
        0,// 報酬段階のボーナス
        1,// 使用行動数
        1,// 枠の大きさ
        0,// 解放時にデッキに追加する枚数
        new ArrayList<Card>(){{
            add(TrainMenu.mp);
        }},
        new ArrayList<TimeFrame>(){{
            add(TimeFrame.morning);
            add(TimeFrame.afternoon);
            add(TimeFrame.night);
        }},
        new HashMap<>(){{
            put(TrainMenuCategory.HP, 1);
        }}),
    green(
        "[冒険者 グリーン]",
        BaseMonster.green,
        0,// 報酬段階のボーナス
        1,// 使用行動数
        1,// 枠の大きさ
        0,// 解放時にデッキに追加する枚数
        new ArrayList<Card>(){{
            add(TrainMenu.mp);
        }},
        new ArrayList<TimeFrame>(){{
            add(TimeFrame.morning);
            add(TimeFrame.afternoon);
            add(TimeFrame.night);
        }},
        new HashMap<>(){{
            put(TrainMenuCategory.S, 1);
        }}),
    berserkerHP(
        "[ライフ・バーサーカー]",
        BaseMonster.berserkerHP,
        0,// 報酬段階のボーナス
        1,// 使用行動数
        1,// 枠の大きさ
        0,// 解放時にデッキに追加する枚数
        new ArrayList<Card>(){{
            
        }},
        new ArrayList<TimeFrame>(){{
            add(TimeFrame.morning);
            add(TimeFrame.afternoon);
            add(TimeFrame.night);
        }},
        new HashMap<>(){{
            put(TrainMenuCategory.HP, 2);
        }}),
    berserkerA(
        "[パワー・バーサーカー]",
        BaseMonster.berserkerA,
        0,// 報酬段階のボーナス
        1,// 使用行動数
        1,// 枠の大きさ
        0,// 解放時にデッキに追加する枚数
        new ArrayList<Card>(){{
            
        }},
        new ArrayList<TimeFrame>(){{
            add(TimeFrame.morning);
            add(TimeFrame.afternoon);
            add(TimeFrame.night);
        }},
        new HashMap<>(){{
            put(TrainMenuCategory.A, 2);
        }}),
    berserkerS(
        "[スピード・バーサーカー]",
        BaseMonster.berserkerS,
        0,// 報酬段階のボーナス
        1,// 使用行動数
        1,// 枠の大きさ
        0,// 解放時にデッキに追加する枚数
        new ArrayList<Card>(){{
            
        }},
        new ArrayList<TimeFrame>(){{
            add(TimeFrame.morning);
            add(TimeFrame.afternoon);
            add(TimeFrame.night);
        }},
        new HashMap<>(){{
            put(TrainMenuCategory.S, 2);
        }}),
    
    jewelryRed("[宝石の 冒険者 レッド]", red, BaseMonster.jewelryRed, 1),
    jewelryBrown("[宝石の 冒険者 ブラウン]", brown, BaseMonster.jewelryBrown, 1),
    jewelryGreen("[宝石の 冒険者 グリーン]", green, BaseMonster.jewelryGreen, 1),
    jewelryBerserkerHP("[宝石の ライフ・バーサーカー]", berserkerHP, BaseMonster.jewelryBerserkerHP, 1),
    jewelryBerserkerA("[宝石の パワー・バーサーカー]", berserkerA, BaseMonster.jewelryBerserkerA, 1),
    jewelryBerserkerS("[宝石の スピード・バーサーカー]", berserkerS, BaseMonster.jewelryBerserkerS, 1),
    nakedRed("[裸の 冒険者 レッド]", red, BaseMonster.nakedRed, 0),
    nakedBrown("[裸の 冒険者 ブラウン]", brown, BaseMonster.nakedBrown, 0),
    nakedGreen("[裸の 冒険者 グリーン]", green, BaseMonster.nakedGreen, 0),
    nakedBerserkerHP("[裸の ライフ・バーサーカー]", berserkerHP, BaseMonster.nakedBerserkerHP, 0),
    nakedBerserkerA("[裸の パワー・バーサーカー]", berserkerA, BaseMonster.nakedBerserkerA, 0),
    nakedBerserkerS("[裸の スピード・バーサーカー]", berserkerS, BaseMonster.nakedBerserkerS, 0),
    ;
    public final String properName;
    public final BaseMonster baseMonster;
    public final int rewardBonus;
    public final int spendActionNum;
    public final int cardSize;
    public final int unlimitAddToDeckNum;
    public final List<Card> cardToAddWithExecute;// 実行時にデッキに追加するカード
    public final List<TimeFrame> ableTimeFrameList;
    public static final int nightLevelUpNum = 1;
    public static final int nightRewardBonus = 1;
    public final Map<TrainMenuCategory, Integer> trainMenuLevelReward;
    Guild(String properName, BaseMonster baseMonster, int rewardBonus, int spendActionNum, int cardSize, int unlimitAddToDeckNum, List<Card> cardToAddWithExecute, List<TimeFrame> ableTimeFrameList, Map<TrainMenuCategory, Integer> trainMenuLevelReward){
        this.properName = properName;
        this.baseMonster = baseMonster;
        this.rewardBonus = rewardBonus;
        this.spendActionNum = spendActionNum;
        this.cardSize = cardSize;
        this.unlimitAddToDeckNum = unlimitAddToDeckNum;
        this.cardToAddWithExecute = cardToAddWithExecute;
        this.ableTimeFrameList = ableTimeFrameList;
        this.trainMenuLevelReward = trainMenuLevelReward;
    }
    // Guild(String jName, BaseMonster baseMonster, int rewardBonus, int spendActionNum, int cardSize, int unlimitAddToDeckNum, List<Card> cardToAddWithExecute, List<TimeFrame> ableTimeFrameList){
    //     this(jName, baseMonster, rewardBonus, spendActionNum, cardSize, unlimitAddToDeckNum, cardToAddWithExecute, ableTimeFrameList, new HashMap<>());
    // }
    // 「宝石の」・「裸の」用のコンストラクタ
    Guild(String jName, Guild base, BaseMonster baseMonster, int addRewardBonus){
        this(jName, baseMonster, base.rewardBonus + addRewardBonus, base.spendActionNum, base.cardSize, base.unlimitAddToDeckNum, new ArrayList<>(base.cardToAddWithExecute), new ArrayList<>(base.ableTimeFrameList), base.trainMenuLevelReward);
    }
    

    public TrainState[] execute(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner, Random rand){
        Player self;

        //for executeCard
        final int BATTLE = 1;
        final int SHOP = 2;
        switch(trainState.getSavedLocation(LocationCategory.executeCard)){
            case LocationCategory.NO_CHOICE:
                trainState.removeUnbeatenGuild(this);
                int nightLevelUp = trainState.getTimeFrame() == TimeFrame.night ? nightLevelUpNum : 0;
                self = trainState.getSelf();
                self.trainToBattleStatus();
                trainState.tempEnemy = new Enemy(this.baseMonster, trainState.getBattlePowerLevel() + nightLevelUp, trainState.getBattleRewardLevel() + this.rewardBonus + nightLevelUp);// nightRewardBonusを入れないのは後で差額を夜追加として出すため
                Print.printBigSeparater(true, text);
                Print.println(trainState.tempEnemy.getJName() + "が現れた", true, Print.middleSpeed, text);
                Print.nextLine(scanner, text);
                trainState = Train.battle(trainState, beforeTrainState, trainState.tempEnemy, false, log, text, scanner, rand);//TODO
                trainState.saveLocation(LocationCategory.executeCard, BATTLE);
                return new TrainState[]{trainState, beforeTrainState};

            case BATTLE:
                trainState = Train.battle(trainState, beforeTrainState, trainState.tempEnemy, false, log, text, scanner, rand);//TODO
                if(trainState.getSavedLocation(LocationCategory.battleInTrain) != LocationCategory.FINISH){
                    return new TrainState[]{trainState, beforeTrainState};
                }
                trainState.saveLocation(LocationCategory.battleInTrain, LocationCategory.NO_CHOICE);
                if(trainState.isEnd()){
                    trainState.saveLocation(LocationCategory.executeCard, LocationCategory.FINISH);
                    return new TrainState[]{trainState, beforeTrainState};
                }

                // 報酬
                boolean isWithStar = false;
                for(TrainMenuCategory category : this.trainMenuLevelReward.keySet()){
                    TrainMenu.levelUp(trainState, category, this.trainMenuLevelReward.get(category), isWithStar, text);
                }

                trainState.addBattleNum();
                Print.println("闘技場のレベルが 1 増加した", true, Print.highSpeed, text);
                
                if(trainState.getTimeFrame() == TimeFrame.night) {
                    Print.println("", true, Print.highSpeed, text);
                    Print.println("深夜戦闘で追加報酬を手に入れた！", true, Print.highSpeed, text);
                    
                    nightLevelUp = trainState.getTimeFrame() == TimeFrame.night ? nightLevelUpNum : 0;
                    int money = new Enemy(this.baseMonster, trainState.getBattlePowerLevel() + nightLevelUp, trainState.getBattleRewardLevel() - 1 + this.rewardBonus + nightLevelUp + nightRewardBonus).money - new Enemy(this.baseMonster, trainState.getBattlePowerLevel() + nightLevelUp, trainState.getBattleRewardLevel() - 1 + this.rewardBonus + nightLevelUp).money;
                    self = trainState.getSelf();
                    CalculateDamage.trainDamage(self, TrainStatus.money, -money, false);
                    Print.println((int)(money) + "円手に入れた！", true, Print.middleSpeed, text);

                    for(TrainMenuCategory category : this.trainMenuLevelReward.keySet()){
                        TrainMenu.levelUp(trainState, category, 1, isWithStar, text);
                    }

                    Print.println("闘技場のレベルが " + nightLevelUpNum + " 増加した", true, Print.highSpeed, text);
                    
                    for(int i = 0; i < nightLevelUpNum; i++){
                        trainState.addBattleNum();
                    }
                }
                
                CalculateDamage.trainDamage(trainState.getSelf(), TrainStatus.maxHp, -100, false);
                CalculateDamage.trainDamage(trainState.getSelf(), TrainStatus.maxMp, -100, false);

                TrainState[] trainStateNB = new TrainState[]{trainState, beforeTrainState};
                Print.nextLine(scanner, text);
                Print.changeWaitTextToLT(text);
                trainStateNB[0].saveLocation(LocationCategory.executeCard, SHOP);
                return trainStateNB;
            
            case SHOP:
                Train.shop(trainState, beforeTrainState, log, text, scanner, rand);
                if(trainState.getSavedLocation(LocationCategory.shopStep) == LocationCategory.FINISH){
                    trainState.saveLocation(LocationCategory.shopStep, LocationCategory.NO_CHOICE);
                    trainState.saveLocation(LocationCategory.executeCard, LocationCategory.FINISH);
                }
                return new TrainState[]{trainState, beforeTrainState};
            
            default:
                System.out.println("error executeCard battle");
                return new TrainState[]{trainState, beforeTrainState};
        }
    }

    public void explain(TrainState trainState, List<TrainLimitation> unlimits, TimeFrame timeFrame, boolean text, Scanner scanner){
        // TODO 作成
        boolean isDynamic = false;
        Print.startFrame(isDynamic, text);
        int nightLevelUp = timeFrame == TimeFrame.night ? nightLevelUpNum : 0;
        int powerLevel = trainState.getBattlePowerLevel() + nightLevelUp;
        int rewardLevel = trainState.getBattleRewardLevel() + nightLevelUp;
        Print.println(this.jName() + "Lv" + (rewardLevel + 1), isDynamic, Print.highSpeed, text);
        Print.println("", isDynamic, Print.highSpeed, text);
        boolean isFreeWidthFrame = true;
        if(timeFrame == TimeFrame.night){
            rewardLevel += nightRewardBonus;
        }
        Print.displayDoubleCharacterStatus(trainState, new Enemy(this.baseMonster, powerLevel, rewardLevel + rewardBonus), false, isDynamic, isFreeWidthFrame, text, scanner);
        // if(this == berserkerHP || this == berserkerA || this == berserkerS){
        //     for(TrainMenuCategory category : this.trainMenuLevelReward.keySet()){
        //         Print.println(category.jName + "訓練レベルを" + this.trainMenuLevelReward.get(category) + "レベル上げる。", true, Print.highSpeed, text);
        //     }
        // }
        if(this.cardToAddWithExecute.size() != 0){
            Print.println("", isDynamic, Print.highSpeed, text);
            Print.println("デッキに追加するカードは", isDynamic, Print.highSpeed, text);
            
            for(Card card : this.cardToAddWithExecute){
                Print.println(card.jName(), isDynamic, Print.highSpeed, text);
                
            }
        }
        if(unlimits.size() != 0){
            Print.print("ショップに", isDynamic, Print.highSpeed, text);
            for(int i = 0; i < unlimits.size(); i++){
                Print.print(Print.space(2, text) + unlimits.get(i).jName, isDynamic, Print.highSpeed, text);
                if(i != 0){
                    Print.print("と", isDynamic, Print.highSpeed, text);
                }
            }
            Print.println("が追加されます", isDynamic, Print.highSpeed, text);
        }
        if(timeFrame == TimeFrame.night){
            Print.println(Color.scarlet.toColor("※夜は敵が強くなっています"), isDynamic, Print.highSpeed, text);
        }
        Print.endFrame(isDynamic, text);
        trainState.saveLocation(LocationCategory.explainCard, LocationCategory.FINISH);
        return;
    }

    @Override
    public void miniExplain(TrainState trainState, List<TrainLimitation> unlimits, TimeFrame timeFrame, TrainStatus beforeMenu, boolean choiced, int choicedIdx, boolean isNew, TrainTemporaryLog log, boolean text, Random rand){
        int nameLength = 24;
        int nightLevelUp = timeFrame == TimeFrame.night ? nightLevelUpNum : 0;
        int level = trainState.getBattleRewardLevel() + 1 + nightLevelUp;
        Color color = Color.white;
        if(choiced){
            color = Color.yellow;
        }else if(!getLegal(trainState, timeFrame, trainState.getMode())){
            color = Color.gray;
        }
        String printText = this.jName() + " Lv" + level;
        Print.startCardFlame(Color.brown, false, text);
        color.startColor(false, text);
        Print.print(printText, Print.highSpeed, text);
        if(isNew){
            if(color == Color.white){
                Print.print(Print.space(2, text) + Color.whiteOrange.toColor("NEW！ "), Print.highSpeed, text);
            }else{
                Print.print(Print.space(2, text) + color.toColor("NEW！ "), Print.highSpeed, text);
            }
        }

        int powerLevel = trainState.getBattlePowerLevel() + nightLevelUp;
        int rewardLevel = trainState.getBattleRewardLevel() + nightLevelUp;
        Enemy enemy = new Enemy(this.baseMonster, powerLevel, rewardLevel + this.rewardBonus + (timeFrame == TimeFrame.night ? nightRewardBonus : 0));
        Print.println("", Print.highSpeed, text);
        Print.print(Print.format(MainStatus.maxHp.shortName + ":" + enemy.getMainStatus().get(MainStatus.maxHp), 10), Print.highSpeed, text);
        Print.print(Print.format(BattleStatus.a.status.shortName + ":" + enemy.getBattleStatus().get(BattleStatus.a), 10), Print.highSpeed, text);
        Print.print(Print.format(BattleStatus.s.status.shortName + ":" + enemy.getBattleStatus().get(BattleStatus.s), 10), Print.highSpeed, text);

        // 今は出てくることが無いから良いけど、修正必須
        if(unlimits.size() != 0){
            Print.print("[", Print.highSpeed, text);
        }
        for(int i = 0; i < unlimits.size(); i++){
            Print.print(Print.space(2, text) + unlimits.get(i).jName, Print.highSpeed, text);
            if(i != 0){
                Print.print("と", Print.highSpeed, text);
            }
        }
        if(unlimits.size() != 0){
            Print.print("が販売解禁！]", Print.highSpeed, text);
        }
        color.endColor(false, text);
        Print.endFrame(false, text);
    };

    public static String categoryName = "闘技場カード";

    @Override
    public String categoryName(){
        return Guild.categoryName;
    }

    @Override
    public String properName(){
        return this.properName;
    }

    // 名前
    public String jName(){
        return this.properName + Print.space(2, true) + Guild.categoryName;
    }

    // 戦闘の総数
    public static final int NUM = values().length;

    // カード全体の通し番号
    public int getOrdinalNumber(){
        return TrainMenu.NUM + RestMenu.NUM + TrainEvent.NUM + this.ordinal();
    }

    // 使用行動数
    public int getSpendActionNum(){
        return this.spendActionNum;
    };

    // カードの枠数
    public int getCardSize(){
        return this.cardSize;
    }

    // 解放時にデッキに追加する枚数
    public int unlimitAddToDeckNum(){
        return this.unlimitAddToDeckNum;
    }

    // 実行時にデッキにカードを追加する
    public void addCardToDeckWithExecute(TrainState trainState, boolean text){
        trainState.saveAddCard(this.cardToAddWithExecute, shuffleModeWithAddCard.BeforeLast);
    }

    public boolean getLegal(TrainState trainState, TimeFrame timeFrame, Mode mode){
        if(!TimeFrame.checkLegal(timeFrame, mode, this.spendActionNum)){
            return false;
        }
        if(!this.ableTimeFrameList.contains(timeFrame)){
            return false;
        }
        return true;
    }

    // 制限されていない戦闘メニューの配列
    public static Guild[] generalValues(TrainState trainState){
        return new ArrayList<Guild>(){{
            add(red);
        }}.toArray(new Guild[0]);
    }

    public Guild toNaked(){
        if(this == red){
            return nakedRed;
        }
        if(this == brown){
            return nakedBrown;
        }
        if(this == green){
            return nakedGreen;
        }
        if(this == berserkerHP){
            return nakedBerserkerHP;
        }
        if(this == berserkerA){
            return nakedBerserkerA;
        }
        if(this == berserkerS){
            return nakedBerserkerS;
        }
        return this;
    }

    public Guild toJewelry(){
        if(this == red){
            return jewelryRed;
        }
        if(this == brown){
            return jewelryBrown;
        }
        if(this == green){
            return jewelryGreen;
        }
        if(this == berserkerHP){
            return jewelryBerserkerHP;
        }
        if(this == berserkerA){
            return jewelryBerserkerA;
        }
        if(this == berserkerS){
            return jewelryBerserkerS;
        }
        return this;
    }

    public Guild toNormal(){
        if(this == jewelryRed || this == nakedRed){
            return red;
        }
        if(this == jewelryBrown || this == nakedBrown){
            return brown;
        }
        if(this == jewelryGreen || this == nakedGreen){
            return green;
        }
        if(this == jewelryBerserkerHP || this == nakedBerserkerHP){
            return berserkerHP;
        }
        if(this == jewelryBerserkerA || this == nakedBerserkerA){
            return berserkerA;
        }
        if(this == jewelryBerserkerS || this == nakedBerserkerS){
            return berserkerS;
        }
        return this;
    }

    public static final List<Guild> berserkerCards = new ArrayList<>(){{
        add(Guild.berserkerHP);
        add(Guild.berserkerA);
        add(Guild.berserkerS);
    }};

    public static final List<Guild> adventurerCards = new ArrayList<>(){{
        add(Guild.red);
        add(Guild.green);
        add(Guild.brown);
    }};

    public static final List<Guild> nakedCards = new ArrayList<>(){{
        add(Guild.nakedBerserkerHP);
        add(Guild.nakedBerserkerA);
        add(Guild.nakedBerserkerS);
        add(Guild.nakedRed);
        add(Guild.nakedGreen);
        add(Guild.nakedBrown);
    }};

    public static final List<Guild> jewelryCards = new ArrayList<>(){{
        add(Guild.jewelryBerserkerHP);
        add(Guild.jewelryBerserkerA);
        add(Guild.jewelryBerserkerS);
        add(Guild.jewelryRed);
        add(Guild.jewelryGreen);
        add(Guild.jewelryBrown);
    }};
}
