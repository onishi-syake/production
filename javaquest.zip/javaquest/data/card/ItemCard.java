package data.card;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import battle.CalculateDamage;
import character.Player;
import character.Player.TrainStatus;
import data.card.TrainMenu.TrainResult;
import game.LocationCategory;
import limitation.TrainLimitation;
import log.TrainTemporaryLog;
import text.Print;
import text.Print.Color;
import train.TrainState;
import train.TrainState.Mode;
import train.TrainState.TimeFrame;
import train.TrainState.shuffleModeWithAddCard;

public enum ItemCard implements Card{
    HPMedicine(
        "[HP剤]",
        0,// 使用行動数
        1,// 枠の大きさ
        0,// 解放時にデッキに追加する枚数
        new ArrayList<Card>(){{

        }},
        new ArrayList<TimeFrame>(){{
            add(TimeFrame.morning);
            add(TimeFrame.afternoon);
            add(TimeFrame.night);
        }},
        new HashMap<TrainStatus, Integer>(){{
            put(TrainStatus.maxHp, 70);
            put(TrainStatus.concentration, 0);
            put(TrainStatus.motivation, 0);
        }}
    ),
    ConMedicine(
        "[集中力剤]",
        0,// 使用行動数
        1,// 枠の大きさ
        0,// 解放時にデッキに追加する枚数
        new ArrayList<Card>(){{

        }},
        new ArrayList<TimeFrame>(){{
            add(TimeFrame.morning);
            add(TimeFrame.afternoon);
            add(TimeFrame.night);
        }},
        new HashMap<TrainStatus, Integer>(){{
            put(TrainStatus.maxHp, 0);
            put(TrainStatus.concentration, 50);
            put(TrainStatus.motivation, 0);
        }}
    ),
    MotivMedicine(
        "[やる気剤]",
        0,// 使用行動数
        1,// 枠の大きさ
        0,// 解放時にデッキに追加する枚数
        new ArrayList<Card>(){{

        }},
        new ArrayList<TimeFrame>(){{
            add(TimeFrame.morning);
            add(TimeFrame.afternoon);
            add(TimeFrame.night);
        }},
        new HashMap<TrainStatus, Integer>(){{
            put(TrainStatus.maxHp, 0);
            put(TrainStatus.concentration, 0);
            put(TrainStatus.motivation, 50);
        }}
    ),
    // HandMulligan(
    //     "手札入れ替え",
    //     0,// 使用行動数
    //     1,// 枠の大きさ
    //     0,// 解放時にデッキに追加する枚数
    //     new HashMap<Card, Integer>(){{

    //     }},
    //     new ArrayList<TimeFrame>(){{
    //         add(TimeFrame.morning);
    //         add(TimeFrame.afternoon);
    //         add(TimeFrame.night);
    //     }},
    //     new HashMap<TrainLimitation, Integer>(){{

    //     }},
    //     new HashMap<TrainStatus, Integer>(){{
            
    //     }}
    // ){
        
    //     public TrainState[] execute(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner, Random rand){
    //         // TODO 手札入れ替えを実装
    //         return new TrainState[] {trainState, beforeTrainState};
    //     };

    //     // 詳細説明
    //     public void explain(TrainState trainState, TimeFrame timeFrame, boolean text, Scanner scanner){
    //         // TODO 手札入れ替えの説明を実装
    //         trainState.saveLocation(LocationCategory.explainCard, LocationCategory.FINISH);
    //     };
    // },
    ;
    public final String properName;// 名前
    public final int spendActionNum;// 使用行動数
    public final int cardSize;// カードの枠数
    public final int unlimitAddToDeckNum;// 解放時にデッキに追加する枚数
    public final List<Card> cardToAddWithExecute;// 実行時にデッキに追加するカード
    public final List<TimeFrame> ableTimeFrameList;// 使用可能な時間帯
    public final Map<TrainStatus, Integer> heal;// 回復

    ItemCard(String properName, int spendActionNum, int cardSize, int unlimitAddToDeckNum, List<Card> cardToAddWithExecute, List<TimeFrame> ableTimeFrameList, Map<TrainStatus, Integer> heal){
        this.properName = properName;
        this.spendActionNum = spendActionNum;
        this.cardSize = cardSize;
        this.unlimitAddToDeckNum = unlimitAddToDeckNum;
        this.cardToAddWithExecute = cardToAddWithExecute;
        this.ableTimeFrameList = ableTimeFrameList;
        this.heal = heal;
    }
    
    // 効果処理
    // ターンアプデ合わせる
    public TrainState[] execute(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner, Random rand){
        // Print.println(this.jName() + "を使用した", true, Print.highSpeed, text);
        Player self = trainState.getSelf();
        for(TrainStatus key: this.heal.keySet()){
            CalculateDamage.trainDamage(self, key, -this.heal.get(key), false);
        }
        
        trainState.setSelf(self);
        trainState.saveLocation(LocationCategory.executeCard, LocationCategory.FINISH);
        return new TrainState[]{trainState, beforeTrainState};
    };

    // 詳細説明
    public void explain(TrainState trainState, List<TrainLimitation> unlimits, TimeFrame timeFrame, boolean text, Scanner scanner){
        int heal;
        String direction;
        boolean isDynamic = false;
        Print.startFrame(isDynamic, text);
        Print.println(this.jName(), isDynamic, Print.highSpeed, text);
        Print.println("", isDynamic, Print.highSpeed, text);
        
        for(TrainStatus key: this.heal.keySet()){
            heal = this.heal.get(key);
            if(heal == 0){
                continue;
            }
            direction = "回復する";
            if(key.child != null){
                Print.println(key.child.jName + "を" + key.jName + "の " + heal + "%" + direction, isDynamic, Print.highSpeed, text);
                
            }else{
                Print.println(key.jName + "を " + heal + " " + direction, isDynamic, Print.highSpeed, text);
                
            }
        }
        Print.println("アイテムカードは他のカードと一緒に使える", isDynamic, Print.highSpeed, text);
        
        if(this.cardToAddWithExecute.size() != 0){
            Print.println("デッキに追加するカードは", isDynamic, Print.highSpeed, text);
            
            for(Card card : this.cardToAddWithExecute){
                Print.println(card.jName(), isDynamic, Print.highSpeed, text);
                
            }
        }
        if(unlimits.size() != 0){
            Print.print("ショップに", isDynamic, Print.highSpeed, text);
            for(int i = 0; i < unlimits.size(); i++){
                Print.print(Print.space(2, text) + unlimits.get(i).jName, isDynamic, Print.highSpeed, text);
                if(i != 0){
                    Print.print("と", isDynamic, Print.highSpeed, text);
                }
            }
            Print.println("が追加されます", isDynamic, Print.highSpeed, text);
            
        }
        Print.println("アイテムカードは連続して使用できない", isDynamic, Print.highSpeed, text);
        Print.endFrame(isDynamic, text);
        trainState.saveLocation(LocationCategory.explainCard, LocationCategory.FINISH);
    };

    @Override
    public void miniExplain(TrainState trainState, List<TrainLimitation> unlimits, TimeFrame timeFrame, TrainStatus beforeMenu, boolean choiced, int choicedIdx, boolean isNew, TrainTemporaryLog log, boolean text, Random rand){
        int nameLength = 24;
        Color color = Color.white;
        if(choiced){
            color = Color.yellow;
        }else if(!getLegal(trainState, timeFrame, trainState.getMode())){
            color = Color.gray;
        }
        String printText = this.jName();
        Print.startCardFlame(Color.miyamotoBlue, false, text);
        color.startColor(false, text);
        Print.print(printText, Print.highSpeed, text);
        if(isNew){
            if(color == Color.white){
                Print.print(Print.space(2, text) + Color.whiteOrange.toColor("NEW！ "), Print.highSpeed, text);
            }else{
                Print.print(Print.space(2, text) + color.toColor("NEW！ "), Print.highSpeed, text);
            }
        }
        Print.println("", Print.highSpeed, text);
        if(unlimits.size() != 0){
            Print.print("[", Print.highSpeed, text);
        }
        for(int i = 0; i < unlimits.size(); i++){
            Print.print(Print.space(2, text) + unlimits.get(i).jName, Print.highSpeed, text);
            if(i != 0){
                Print.print("と", Print.highSpeed, text);
            }
        }
        if(unlimits.size() != 0){
            Print.print("が販売解禁！]", Print.highSpeed, text);
        }



        if(choiced){
            trainState = CardWithParams.getNextStateFromChoice(trainState, trainState, choicedIdx, log, rand).get(TrainResult.success);
        }else{
            trainState = CardWithParams.getNextStateFromChoice(trainState, trainState, log, rand).get(TrainResult.success);
        }
        int costCount = 0;
        for(TrainStatus key: TrainStatus.values()){
            if(!this.heal.keySet().contains(key)){
                continue;
            }
            int heal = this.heal.get(key);
            int length = 5;
            if(key == TrainStatus.maxHp || key == TrainStatus.hp){
                length = 13;
            }
            String direction = "↑";
            if(costCount != 0){
                Print.print(Print.space(1, text), Print.highSpeed, text);
            }
            costCount++;
            if(key.child != null){
                if(heal == 100){
                    Print.print(key.child.shortName + ":" + Print.format("全回復", length), Print.highSpeed, text);
                }else if(heal == 0){
                    Print.print(key.child.shortName + ":" + Print.format("--", length), Print.highSpeed, text);
                }else{
                    Print.print(key.child.shortName + ":" + Print.format((trainState.getSelf().getTrainStatus().get(key) * heal / 100) + direction, length), Print.highSpeed, text);
                }
            }else{
                if(heal == 0){
                    Print.print(key.shortName + ":" + Print.format("--", length), Print.highSpeed, text);
                }else{
                    Print.print(key.shortName + ":" + Print.format(heal + direction, length), Print.highSpeed, text);
                }
            }
        }


        color.endColor(false, text);
        Print.endFrame(false, text);
    };

    // カテゴリー名
    @Override
    public String categoryName(){
        return "アイテムカード";
    }

    // 固有名
    @Override
    public String properName(){
        return this.properName;
    }

    // 名前
    public String jName(){
        return this.properName() + Print.space(2, true) + this.categoryName();
    }

    // 戦闘の総数
    public static final int NUM = values().length;

    // カード全体の通し番号
    public int getOrdinalNumber(){
        return TrainMenu.NUM + RestMenu.NUM + TrainEvent.NUM + Guild.NUM + this.ordinal();
    }

    // 使用行動数
    public int getSpendActionNum(){
        return this.spendActionNum;
    };

    // カードの枠数
    public int getCardSize(){
        return this.cardSize;
    };

    // 解放時にデッキに追加する枚数
    public int unlimitAddToDeckNum(){
        return this.unlimitAddToDeckNum;
    };

    // 実行時にデッキにカードを追加する
    public void addCardToDeckWithExecute(TrainState trainState, boolean text){
        trainState.saveAddCard(this.cardToAddWithExecute, shuffleModeWithAddCard.BeforeLast);
    }

    public boolean getLegal(TrainState trainState, TimeFrame timeFrame, Mode mode){
        if(!this.ableTimeFrameList.contains(timeFrame)){
            return false;
        }
        if(trainState.trainings.size() != 0 && trainState.trainings.get(trainState.trainings.size() - 1).card instanceof ItemCard){
            return false;
        }
        return true;
    }

    // 制限されていないアイテムメニューの配列
    public static ItemCard[] generalValues(TrainState trainState){
        return new ArrayList<ItemCard>(){{
            add(HPMedicine);
            add(ConMedicine);
            add(MotivMedicine);
            // add(HandMulligan);
        }}.toArray(new ItemCard[0]);
    }
}
