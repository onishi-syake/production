package data.card;

public enum TrainMenuSize {
    A("A"),
    B("B"),
    C("C"),
    ;
    public final String jName;
    private TrainMenuSize(String jName){
        this.jName = jName;
    }
}
