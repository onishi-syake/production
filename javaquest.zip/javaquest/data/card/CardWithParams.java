package data.card;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import character.Player;
import character.Player.TrainStatus;
import data.action.Spell;
import data.card.TrainMenu.TrainResult;
import game.LocationCategory;
import limitation.TrainLimitation;
import limitation.TrainLimitation.TrainLimitationCounter;
import log.TrainTemporaryLog;
import text.Print;
import train.TrainState;
import train.TrainState.TimeFrame;

public class CardWithParams implements Serializable {
    public int index;
    public Card card;
    public List<TrainLimitation> unlimitTrainLimitation;
    public boolean isNew;
    public CardWithParams(int index, Card card, List<TrainLimitation> unlimitTrainLimitation, boolean isNew){
        this.index = index;
        this.card = card;
        this.unlimitTrainLimitation = unlimitTrainLimitation;
        this.isNew = isNew;
    }
    
    // 特定の位置から取ったカードを含んでいるかどうかを出力
    public static boolean containsIndex(List<CardWithParams> cardWithIndexs, int idx){
        for(CardWithParams cardWithIndex : cardWithIndexs){
            if(cardWithIndex.index == idx){
                return true;
            }
        }
        return false;
    }
    
    // 特定の位置から取ったカードを出力(無ければnull)
    public static CardWithParams getFromIndex(List<CardWithParams> cardWithIndexs, int idx){
        for(CardWithParams cardWithIndex : cardWithIndexs){
            if(cardWithIndex.index == idx){
                return cardWithIndex;
            }
        }
        return null;
    }

    // 特定の位置から取ったカードを削除（削除成功でtrue, それ以外はfalse）
    public static boolean removeFromIndex(List<CardWithParams> cardWithIndexs, int idx){
        for(CardWithParams cardWithIndex : new ArrayList<>(cardWithIndexs)){
            if(cardWithIndex.index == idx){
                cardWithIndexs.remove(cardWithIndex);
                return true;
            }
        }
        return false;
    }

    // そのカードの解放内容をtrainStateに保存する
    public void unlimitTrainLimitation(TrainState trainState){
        trainState.saveUnlimits(this.unlimitTrainLimitation);
    }

    // 初期手札
    public static final List<CardWithParams> startHand = new ArrayList<CardWithParams>(){{
        add(new CardWithParams(-1, TrainMenu.normalHp, new ArrayList<>(){{
            add(TrainLimitation.stoneSpell);
        }}, false));
        add(new CardWithParams(-1, TrainMenu.normalA, new ArrayList<>(){{
            add(TrainLimitation.fireSpell);
        }}, false));
        add(new CardWithParams(-1, TrainMenu.normalS, new ArrayList<>(){{
            add(TrainLimitation.windSpell);
        }}, false));
        // add(new CardWithParams(-1, Guild.berserkerA, new ArrayList<>(){{//debug
        //     add(TrainLimitation.windSpell);
        // }}, false));
    }};

    // リストに含まれるカードのサイズの合計
    public static int cardsSize(List<CardWithParams> cardsList){
        int count = 0;
        for(CardWithParams card : cardsList){
            count += (card.card.getCardSize());
        }
        return count;
    }

    // カードリストの行動数を返す
    public static int sumSpendAction(List<CardWithParams> cards){
        int result = 0;
        for(CardWithParams card : cards){
            result += card.card.getSpendActionNum();
        }
        return result;
    }

    // カードが手札のどの位置に存在していたかを示すリストを返す
    public static List<Integer> indexList(List<CardWithParams> cardWithParams){
        return new ArrayList<>(){{
            for(CardWithParams cards : cardWithParams){
                add(cards.index);
            }
        }};
    }

    // カードの通し番号を元にソートする
    public static void sortCardWithParams(List<CardWithParams> cardWithParams){
        Comparator<CardWithParams> comparator = new Comparator<CardWithParams>() { // cardのordinalNumberを元に昇順にするコンパレータを作成
            @Override
            public int compare(CardWithParams cardWithParams1, CardWithParams cardWithParams2) {
                return  cardWithParams1.card.getOrdinalNumber() - cardWithParams2.card.getOrdinalNumber();
            }
        };
        Collections.sort(cardWithParams, comparator);
    }

    // デッキからカードを引く
    public static List<CardWithParams> drawCard(TrainState trainState, int addNum, boolean text, Random rand) {
        List<CardWithParams> oldHands = new ArrayList<>(trainState.getHands());// 現状の選択肢
        List<Card> newHands = new ArrayList<>();// 追加される選択肢
        List<CardWithParams> newHandWithParams = new ArrayList<>();
        List<Card> deck = trainState.deck;// 山札
        boolean isHandMax = false;// 手札いっぱいになるまで引いたか
        if(CardWithParams.cardsSize(oldHands) + addNum > Card.maxHandNum){
            isHandMax = true;
            addNum = Card.maxHandNum - CardWithParams.cardsSize(oldHands);
        }
        // 山札から補充するカードをnewHandsに取り込む
        for(int addedCount = 0; addedCount < addNum && deck.size() != 0; addedCount++){
            Card trainMenu = deck.get(deck.size() - 1);// 一番後ろのカード
            if(trainMenu.getCardSize() != 1){
                addedCount += trainMenu.getCardSize() - 1;
            }
            newHands.add(trainMenu);
            deck.remove(deck.size() - 1);

            // 溢れたときの処理
            int fillCount = 0;
            if(addedCount > addNum){
                fillCount++;
                // int difference = addedCount - addNum;
                // for(int removeIdx = newHands.size()-1; removeIdx != 0 && difference != 0; removeIdx--){
                //     trainMenu = newHands.get(removeIdx);
                //     if(trainMenu.getCardSize() <= difference){
                //         difference -= trainMenu.getCardSize();
                //         newHands.remove(removeIdx);
                //         deck.add(trainMenu);
                //     }
                // }
                if(fillCount < 100){
                    addedCount -= trainMenu.getCardSize();
                    newHands.remove(trainMenu);
                    deck.add(rand.nextInt(deck.size()), trainMenu);
                }
            }
        }
        while(cardsSize(oldHands) + Card.cardsSize(newHands) > Card.maxHandNum && newHands.size() != 0){
            Card lastCard = newHands.get(newHands.size() - 1);
            newHands.remove(lastCard);
            deck.add(rand.nextInt(deck.size()), lastCard);
        }
        if(deck.size() == 0){
            Print.println("デッキが無くなった" + Print.sleep(10), true, Print.highSpeed, text);
            
        }else if(isHandMax){
            Print.println("手札の枚数が最大になった" + Print.sleep(10), true, Print.highSpeed, text);
            
        }
        
        // 解放する内容を新しく引くカードに追加する
        newHandWithParams = changeCardToCardWithParams(trainState, oldHands, newHands, true);

        if(newHandWithParams.size() != 0){
            Print.println("", true, Print.highSpeed, text);
        }
        // Print.changeFontSizeStart(4, true, text);
        // for(CardWithParams newCard : newHandWithParams){
        //     Print.println(newCard.card.jName() + "を引いた" + Print.sleep(15), true, Print.highSpeed, text);
            
        // }
        // Print.changeFontSizeEnd(true, text);

        oldHands.addAll(newHandWithParams);
        CardWithParams.sortCardWithParams(oldHands);
        trainState.deck = deck;
        return oldHands;
    }

    // Cardのリストに解放する内容を付けてCardWithParamsのリストにする
    public static List<CardWithParams> changeCardToCardWithParams(TrainState trainState, List<CardWithParams> nowHands, List<Card> addCards, boolean isNew){
        Player self = trainState.getSelf();
        List<TrainLimitation> unlimits;
        List<TrainLimitation> unlimitedSpell = new ArrayList<>(TrainLimitation.spellWithNormalSpellLimitation().keySet());
        // unlimitedSpell.addAll(TrainLimitation.strengthenSpellLimitation(trainState));
        List<CardWithParams> addHands = new ArrayList<>();
        // 既に解放済みは削除
        for(TrainLimitation limit : new ArrayList<>(unlimitedSpell)){
            if(trainState.getTrainLimitations().get(limit).get(TrainLimitationCounter.flag) == 1){
                unlimitedSpell.remove(limit);
            }
        }
        // 既に手札に有ったら削除
        for(CardWithParams oldHand : nowHands){
            for(TrainLimitation limit : oldHand.unlimitTrainLimitation){
                if(unlimitedSpell.contains(limit)){
                    unlimitedSpell.remove(limit);
                }
            }
        }
        // 覚えてたら削除
        out:
        for(TrainLimitation spellLimit : TrainLimitation.spellWithNormalSpellLimitation().keySet()){
            if(self.getLearnedSpellLevel().keySet().contains(TrainLimitation.spellWithNormalSpellLimitation().get(spellLimit))){
                if(unlimitedSpell.contains(spellLimit)){
                    unlimitedSpell.remove(spellLimit);
                    continue out;
                }
            }
            if(Spell.strengthenSpellCategory().keySet().contains(TrainLimitation.spellWithNormalSpellLimitation().get(spellLimit))){
                for(Spell spell : Spell.strengthenSpellCategory().get(TrainLimitation.spellWithNormalSpellLimitation().get(spellLimit))){
                    if(self.getLearnedSpellLevel().keySet().contains(spell)){
                        if(unlimitedSpell.contains(spellLimit)){
                            unlimitedSpell.remove(spellLimit);
                            continue out;
                        }
                    }
                }
            }
        }
        // mp訓練専用の呪文を削除
        unlimitedSpell.remove(TrainLimitation.On_SpellReflectSpell);
        unlimitedSpell.remove(TrainLimitation.On_StateChangeSpell);
        Collections.shuffle(unlimitedSpell);// TODO rand使え
        List<Card> unlimitSpellTrain = new ArrayList<>(){{
            add(TrainMenu.normalA);
            add(TrainMenu.normalS);
            add(TrainMenu.normalHp);
        }};
        List<Card> unlimitStrengthenTrain = new ArrayList<>(){{
            add(TrainMenu.bigA);
            add(TrainMenu.bigS);
            add(TrainMenu.bigHp);
        }};
        Map<Card, TrainLimitation> unlimitLabTrain = new HashMap<>(){{
            put(TrainMenu.superA, TrainLimitation.labCon);
            put(TrainMenu.superS, TrainLimitation.labMoti);
            put(TrainMenu.superHp, TrainLimitation.labHP);
        }};

        int i = 0;
        for(Card card : addCards){
            if(unlimitSpellTrain.contains(card)){
                unlimits = new ArrayList<>();
                if(unlimitedSpell.size() != 0){
                    unlimits.add(unlimitedSpell.get(i++ % unlimitedSpell.size()));
                }
            }else if(unlimitStrengthenTrain.contains(card)){
                Spell baseSpell;
                unlimits = new ArrayList<>();
                if(card == TrainMenu.bigA){
                    baseSpell = Spell.Fire;
                }else if(card == TrainMenu.bigS){
                    baseSpell = Spell.Wind;
                }else{// bigHp
                    baseSpell = Spell.Stone;
                }
                if(Spell.strengthenSpellCategory().containsKey(baseSpell)){
                    List<Spell> unlimitStrengthens = Spell.strengthenSpellCategory().get(baseSpell);
                    for(Spell unlimitStrengthen : unlimitStrengthens){
                        if(self.getLearnedSpellLevel().containsKey(unlimitStrengthen) && 
                        TrainLimitation._strengthenSpellLimitation().containsKey(unlimitStrengthen)){
                            unlimits.add(TrainLimitation._strengthenSpellLimitation().get(unlimitStrengthen));
                        }
                    }
                }
            }else if(unlimitLabTrain.containsKey(card)){
                unlimits = new ArrayList<>();
                if(trainState.getTrainLimitations().get(unlimitLabTrain.get(card)).get(TrainLimitationCounter.flag) != 1){
                    unlimits.add(unlimitLabTrain.get(card));
                }
            }else if(card == TrainMenu.mp){
                unlimits = new ArrayList<TrainLimitation>(){{
                    if(trainState.getTrainLimitations().get(TrainLimitation.On_SpellReflectSpell).get(TrainLimitationCounter.flag) == 1){
                        add(TrainLimitation.On_StateChangeSpell);
                    }else{
                        add(TrainLimitation.On_SpellReflectSpell);
                    }
                }};
            }else{
                unlimits = new ArrayList<>();
            }
            addHands.add(new CardWithParams(-1, card, unlimits, isNew));
        }
        return addHands;
    }

    // リストの後ろから見て一番初めの行動を消費するカードを返す（なければnullを返す）
    public static CardWithParams lastCardWithSpendAction(List<CardWithParams> cards){
        for(int i = cards.size() - 1; i >= 0; i--){
            if(cards.get(i).card.getSpendActionNum() != 0){
                return cards.get(i);
            }
        }
        return null;
    }

    // 選択中のカードによるステータスの変化後の値を算出
    public static Map<TrainStatus, Map<TrainResult, Integer>> getChangeParameterFromChoice(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, Random rand){
        Map<TrainResult, TrainState> resultStates = getNextStateFromChoice(trainState, beforeTrainState, log, rand);
        return new HashMap<TrainStatus, Map<TrainResult, Integer>>(){{
            for(TrainStatus trainStatus : new TrainStatus[]{TrainStatus.hp, TrainStatus.concentration, TrainStatus.motivation, TrainStatus.maxHp, TrainStatus.a, TrainStatus.s}){
                put(trainStatus, new HashMap<>(){{
                    for(TrainResult result : TrainResult.values()){
                        put(result, resultStates.get(result).getSelf().getTrainStatus().get(trainStatus));
                    }
                }});
            }
        }};
    }

    // 選択中のカードから行動後のtrainStateを予測（闘技場・ラボ・mpは簡略）
    public static Map<TrainResult, TrainState> getNextStateFromChoice(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, Random rand){
        return getNextStateFromChoice(trainState, beforeTrainState, trainState.trainings.size(), log, rand);
    }
    // 何枚目のtrainingsまでをとるかを指定する
    public static Map<TrainResult, TrainState> getNextStateFromChoice(TrainState trainState, TrainState beforeTrainState, int trainingIdx, TrainTemporaryLog log, Random rand){
        Map<TrainResult, TrainState> resultStates = new HashMap<>(){{
            for(TrainResult result : TrainResult.values()){
                put(result, trainState.modifiableCopy());
            }
        }};
        TrainState resultState;
        TrainState beforeTrainStateCopy = beforeTrainState.modifiableCopy();
        for(TrainResult result : TrainResult.values()){
            resultStates.get(result).setTrainResult(result);
        }
        Player self;
        for(CardWithParams card : trainState.trainings.subList(0, trainingIdx)){
            if(card.card instanceof Guild){
                for(TrainResult result : TrainResult.values()){
                    resultState = resultStates.get(result);
                    self = resultState.getSelf();
                    self.getTrainStatus().replace(TrainStatus.hp, self.getTrainStatus().get(TrainStatus.maxHp));
                    resultState.setSelf(self);
                }
            }else if(card.card instanceof TrainEvent){
                if(card.card == TrainEvent.labHP || card.card == TrainEvent.labCon || card.card == TrainEvent.labMoti){
                    for(TrainResult result : TrainResult.values()){
                        resultState = resultStates.get(result);
                        self = resultState.getSelf();
                        self.getTrainStatus().replace(TrainStatus.hp, 1);
                        self.getTrainStatus().replace(TrainStatus.concentration, 0);
                        self.getTrainStatus().replace(TrainStatus.motivation, 0);
                        resultState.setSelf(self);
                    }
                }
            }else{
                if(card.card == TrainMenu.mp){
                    continue;
                }
                for(TrainResult result : TrainResult.values()){
                    resultState = resultStates.get(result);
                    resultState.saveLocation(LocationCategory.executeCard, LocationCategory.NO_CHOICE);
                    card.card.execute(resultState, beforeTrainStateCopy, log, false, null, rand);
                    resultState.saveLocation(LocationCategory.executeCard, LocationCategory.NO_CHOICE);
                }
            }

            // 時間帯と連続トレの処理
            for(TrainResult result : TrainResult.values()){
                resultState = resultStates.get(result);
                resultState.setTimeFrame(TimeFrame.returnNextTimeFrame(resultState.getTimeFrame(), resultState.getMode(), card.card.getSpendActionNum()));
                // 連続鍛錬処理
                TrainStatus beforeTrainMenu = null;
                if(card.card instanceof TrainMenu){
                    TrainMenu menu = (TrainMenu)card.card;
                    beforeTrainMenu = (TrainStatus)menu.trainCategory.keySet().toArray()[0];
                }
                resultState.setBeforeTrainMenu(beforeTrainMenu);
                if (beforeTrainMenu == null || beforeTrainMenu == TrainStatus.mp) {
                    resultState.setChainTrainNum(0);
                    resultState.setChainSameTrainNum(0);
                } else {
                    resultState.setChainTrainNum(resultState.getChainTrainNum() + 1);
                }
            }
        }
        return resultStates;
    }

    // Cardの取り出し
    public static List<Card> takeCard(List<CardWithParams> cardWithParams){
        return new ArrayList<>(){{
            for(CardWithParams card : cardWithParams){
                add(card.card);
            }
        }};
    }

    // リスト内のisNewを全てfalseにする
    public static List<CardWithParams> notNew(List<CardWithParams> cardWithParams){
        cardWithParams = new ArrayList<>(cardWithParams);
        for(int i = 0; i < cardWithParams.size(); i++){
            cardWithParams.get(i).isNew = false;
        }
        return cardWithParams;
    }
}
