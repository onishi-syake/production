package data.card;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import battle.CalculateDamage;
import battle.CalculateDamage.CostCategory;

import java.util.Random;

import character.Player;
import character.Player.TrainStatus;
import game.LocationCategory;
import limitation.TrainLimitation;
import log.TrainTemporaryLog;
import text.Print;
import text.Print.Color;
import train.TrainState;
import train.TrainState.Mode;
import train.TrainState.TimeFrame;
import train.TrainState.shuffleModeWithAddCard;

public enum RestMenu implements Card{
    maintenance("[宿屋]", 
    1,// 使用行動数
    1,// 枠の大きさ
    0,// 解放時にデッキに追加する枚数
    new ArrayList<Card>(){{
        add(ItemCard.MotivMedicine);
        add(ItemCard.HPMedicine);
        add(ItemCard.ConMedicine);
    }},
    new EnumMap<>(TrainStatus.class){{
    }}, new EnumMap<>(TrainStatus.class){{
        put(TrainStatus.maxHp, 100);
        // put(TrainStatus.maxGasoline, 100);
        put(TrainStatus.concentration, 0);
        put(TrainStatus.motivation, 50);
        // put(TrainStatus.maxOil, 100);
    }}, new EnumMap<>(TrainStatus.class){{
        
    }},
    true, // 手札リセット
    new ArrayList<TimeFrame>(){{
        add(TimeFrame.morning);
        add(TimeFrame.afternoon);
        add(TimeFrame.night);
    }}) {
        final int baseCost = 0;
        final int coefCost = 0;

        @Override
        public TrainState[] execute(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner, Random rand) {
            switch(trainState.getSavedLocation(LocationCategory.executeCard)){
                case LocationCategory.NO_CHOICE:
                    Player self = trainState.getSelf();
                    int cost = baseCost + self.getInnNum() * coefCost;
                    cost *= trainState.getMode().scale;
                    if(self.getTrainStatus().get(TrainStatus.money) - cost < 0){
                        Print.println("しかし、所持金が足りなかった", true, Print.middleSpeed, text);
                        Print.println("所持金が足りない分ボコボコにされた", true, Print.highSpeed, text);
                        Print.println(TrainStatus.maxHp.jName + "が足りないコストの 100 倍削られた", true, Print.highSpeed, text);
                        CalculateDamage.trainDamage(self, new CalculateDamage().new CostParameter(TrainStatus.maxHp, (cost - self.getTrainStatus().get(TrainStatus.money)) * 100, CostCategory.direct), text);
                        // if(trainStateNB[0].getAuto() != Auto.select){
                        //     CalculateDamage.trainDamage(self, TrainStatus.maxHp, 100, text);
                        // }
                        // return trainStateNB;
                    }
                    for(TrainStatus key: this.enhance.keySet()){
                        CalculateDamage.trainProgress(self, key, false, this.enhance.get(key), false);
                    }
                    Print.println("", true, Print.highSpeed, false);
                    for(TrainStatus key: this.heal.keySet()){
                        CalculateDamage.trainDamage(self, key, -this.heal.get(key), false);
                    }
                    // Print.println(self.getColorJName() + "の" + TrainStatus.concentration.jName + "以外の全ステータスが全回復した", Print.highSpeed, text);
                    Print.println("", true, Print.highSpeed, false);
                    // CalculateDamage.trainDamage(self, TrainStatus.money, cost, text);
                    Print.println("", true, Print.highSpeed, false);
                    self.setInnNum(self.getInnNum() + 1);
                    // Print.nextLine(scanner, text);
                    // Print.println("次からの料金が上がった", Print.highSpeed, text);
                    // int drawNum = trainState.getHands().size();
                    // trainState.setHands(new ArrayList<>());
                    // trainState.setHands(CardWithParams.drawCard(trainState, drawNum, text, rand));
                    // Print.println("手札を全て引き直した", true, Print.highSpeed, text);
                    trainState.setInnRedraw();
                    trainState.saveLocation(LocationCategory.executeCard, LocationCategory.FINISH);
                    return new TrainState[]{trainState, beforeTrainState};

                default:
                    System.out.println("error maintenance execute");
                    return new TrainState[]{trainState, beforeTrainState};
            }
        }

        @Override
        public void miniExplain(TrainState trainState, List<TrainLimitation> unlimits, TimeFrame timeFrame, TrainStatus beforeMenu, boolean choiced, int choicedIdx, boolean isNew, TrainTemporaryLog log, boolean text, Random rand){
            Player self = trainState.getSelf();
            int cost = baseCost + self.getInnNum() * coefCost;
            int heal;
            String direction = "";
            int nameLength = 24;
            int actNameLength = 11;
            int costLength = 10;
            cost *= trainState.getMode().scale;
            Color color = Color.white;
            if(choiced){
                color = Color.yellow;
            }else if(!getLegal(trainState, timeFrame, trainState.getMode())){
                color = Color.gray;
            }
            String printText = this.jName();
            Print.startCardFlame(Color.darkBlue, false, text);
            color.startColor(false, text);
            Print.print(Print.format(printText, nameLength), Print.highSpeed, text);
            if(isNew){
                if(color == Color.white){
                    Print.print(Print.space(2, text) + Color.whiteOrange.toColor("NEW！ "), Print.highSpeed, text);
                }else{
                    Print.print(Print.space(2, text) + color.toColor("NEW！ "), Print.highSpeed, text);
                }
            }
            Print.println("", Print.highSpeed, text);
            if(unlimits.size() != 0){
                Print.print("[", Print.highSpeed, text);
            }
            for(int i = 0; i < unlimits.size(); i++){
                Print.print(Print.space(2, text) + unlimits.get(i).jName, Print.highSpeed, text);
                if(i != 0){
                    Print.print("と", Print.highSpeed, text);
                }
            }
            if(unlimits.size() != 0){
                Print.print("が販売解禁！]", Print.highSpeed, text);
            }
            // Print.print(Print.format((gray ? Color.gray.toColor(jName) : jName) + "(" + cost + ")", nameLength, gray ? 1 : 0), Print.highSpeed, text);
            // Print.print(Print.format(TrainStatus.money.jName + "：", actNameLength) + Print.format(self.getTrainStatus().get(TrainStatus.money) + "円", costLength-1) + Print.format("料金：", actNameLength) + Print.toRed(Print.format(cost + direction + "円", costLength-1)), Print.highSpeed, text);
            int costCount = 0;
            for(TrainStatus key: TrainStatus.values()){
                if(!this.heal.keySet().contains(key)){
                    continue;
                }
                heal = this.heal.get(key);
                int length = 5;
                if(key == TrainStatus.maxHp || key == TrainStatus.hp){
                    length = 13;
                }
                direction = "↑";
                if(costCount != 0){
                    Print.print(Print.space(1, text), Print.highSpeed, text);
                }
                costCount++;
                if(key.child != null){
                    if(heal == 100){
                        Print.print(key.child.shortName + ":" + Print.format("全回復", length), Print.highSpeed, text);
                    }else{
                        Print.print(key.child.shortName + ":" + Print.format(heal + "%" + direction, length), Print.highSpeed, text);
                    }
                }else{
                    if(heal == 0){
                        Print.print(key.shortName + ":" + Print.format("--", length), Print.highSpeed, text);
                    }else{
                        Print.print(key.shortName + ":" + Print.format(heal + direction, length), Print.highSpeed, text);
                    }
                }
            }
            // Print.println("", Print.highSpeed, text);
            color.endColor(false, text);
            Print.endFrame(false, text);
        }

        @Override
        public boolean getLegal(TrainState trainState, TimeFrame timeFrame, Mode mode){
            if(!this.ableTimeFrameList.contains(timeFrame)){
                return false;
            }else if(!TimeFrame.checkLegal(timeFrame, mode, this.spendActionNum)){
                return false;
            }
            // if(!useCost){
            //     return true;
            // }
            // Player self = trainState.getSelf();
            // return self.getTrainStatus().get(TrainStatus.money) >= baseCost + self.getInnNum() * coefCost;
            return true;
        }

        @Override
        public boolean getAiLegal(TrainState trainState, TimeFrame timeFrame, Mode mode){
            if(!getLegal(trainState, timeFrame, mode)){
                return false;
            }
            for(TrainStatus key: this.heal.keySet()){
                if(trainState.getSelf().getTrainStatus().get(key.child) <= trainState.getSelf().getTrainStatus().get(key) * 0.5){
                    return true;
                }
            }
            return false;
        }
    },

    /*miniInn("ぼろ宿屋", new EnumMap<>(TrainStatus.class){{
    }}, new EnumMap<>(TrainStatus.class){{
        put(TrainStatus.maxHp, 30);
        put(TrainStatus.maxMp, 30);
        put(TrainStatus.maxActivity, 30);
    }}),

    bigInn("高級宿", new EnumMap<>(TrainStatus.class){{
        put(TrainStatus.money, 1000);
    }}, new EnumMap<>(TrainStatus.class){{
        put(TrainStatus.maxHp, 100);
        put(TrainStatus.maxMp, 100);
        put(TrainStatus.maxActivity, 100);
    }}),*/

    // hotSpring("温泉", null, 
    // new EnumMap<>(TrainStatus.class){{
    // }}, new EnumMap<>(TrainStatus.class){{
    //     put(TrainStatus.maxHp, 100);
    // }}, new EnumMap<>(TrainStatus.class){{
    //     put(TrainStatus.maxHp, 20);
    // }}),

    // gasolineMainte("ガソリンメンテ", false,
    // new HashMap<TrainLimitation, Integer>(){{

    // }}, 
    // new EnumMap<>(TrainStatus.class){{
    // }}, new EnumMap<>(TrainStatus.class){{
    //     put(TrainStatus.maxGasoline, 100);
    // }}, new EnumMap<>(TrainStatus.class){{
    //     put(TrainStatus.maxGasoline, 30);
    // }},
    // new ArrayList<TimeFrame>(){{
    //     add(TimeFrame.morning);
    //     add(TimeFrame.afternoon);
    //     add(TimeFrame.night);
    // }}),

    // elecMainte("エレキメンテ", 
    // 1,// 使用行動数
    // 1,// 枠の大きさ
    // 5,// 解放時にデッキに追加する枚数
    // new HashMap<TrainLimitation, Integer>(){{
        
    // }}, 
    // new EnumMap<>(TrainStatus.class){{
    // }}, new EnumMap<>(TrainStatus.class){{
    //     put(TrainStatus.maxMotivation, 100);
    // }}, new EnumMap<>(TrainStatus.class){{
    //     put(TrainStatus.maxMotivation, 30);
    // }},
    // new ArrayList<TimeFrame>(){{
    //     add(TimeFrame.morning);
    //     add(TimeFrame.afternoon);
    //     add(TimeFrame.night);
    // }}),

    // oilMainte("やる気メンテ", 
    // 1,// 使用行動数
    // 1,// 枠の大きさ
    // 5,// 解放時にデッキに追加する枚数
    // new HashMap<TrainLimitation, Integer>(){{
        
    // }}, 
    // new EnumMap<>(TrainStatus.class){{
    // }}, new EnumMap<>(TrainStatus.class){{
    //     put(TrainStatus.maxEngine, 100);
    // }}, new EnumMap<>(TrainStatus.class){{
    //     put(TrainStatus.maxEngine, 30);
    // }},
    // new ArrayList<TimeFrame>(){{
    //     add(TimeFrame.morning);
    //     add(TimeFrame.afternoon);
    //     add(TimeFrame.night);
    // }}),
    ;

    public final String properName;// 名前
    public final int spendActionNum;// 使用行動数
    public final int cardSize;// カードの枠数
    public final int unlimitAddToDeckNum;// 解放時にデッキに追加する枚数
    public final List<Card> cardToAddWithExecute;// 実行時にデッキに追加するカード
    public final Map<TrainStatus, Integer> cost;// コスト
    public final Map<TrainStatus, Integer> heal;// 回復
    public final Map<TrainStatus, Integer> enhance;// 成長
    public final boolean handReset;// 手札を引き直すがどうか
    public final List<TimeFrame> ableTimeFrameList;// 使える時間帯
    private RestMenu(String properName, int spendActionNum, int cardSize, int unlimitAddToDeckNum, List<Card> cardToAddWithExecute, Map<TrainStatus, Integer> cost, Map<TrainStatus, Integer> heal, Map<TrainStatus, Integer> enhance, boolean handReset, List<TimeFrame> ableTimeFrameList){
        this.properName = properName;
        this.spendActionNum = spendActionNum;
        this.cardSize = cardSize;
        this.unlimitAddToDeckNum = unlimitAddToDeckNum;
        this.cardToAddWithExecute = cardToAddWithExecute;
        this.cost = cost;
        this.heal = heal;
        this.enhance = enhance;
        this.handReset = handReset;
        this.ableTimeFrameList = ableTimeFrameList;
    }

    // 詳細な説明
    public void explain(TrainState trainState, List<TrainLimitation> unlimits, TimeFrame timeFrame, boolean text, Scanner scanner){
        int cost, heal, enhance;
        boolean isDynamic = false;
        String direction = "";
        Print.startFrame(isDynamic, text);
        Print.println("", isDynamic, Print.highSpeed, text);
        Print.println(Print.space(2, text) + this.jName(), isDynamic, Print.highSpeed, text);
        
        Print.startTable(isDynamic, text);
        if(this.cost.size() != 0){
            Print.startRowDoubleHorizontal(isDynamic, text);
            Print.printHorizontalLine(isDynamic, text);
            Print.println("", isDynamic, Print.highSpeed, text);
            Print.endRow(isDynamic, text);
            Print.startRow(isDynamic, text);
            Print.print("コスト", Print.highSpeed, text);
            Print.separateRow(isDynamic, text);
            for(TrainStatus key: this.cost.keySet()){
                cost = this.cost.get(key);
                if(key == TrainStatus.money){
                    cost *= trainState.getMode().scale;
                }
                if(key.child != null){
                    Print.println(key.child.jName + ": " + key.jName + "の " + cost + "%", isDynamic, Print.highSpeed, text);
                    
                }else{
                    Print.println(key.jName + ": " + cost, isDynamic, Print.highSpeed, text);
                    
                }
            }
            Print.endRow(isDynamic, text);
        }
        if(this.heal.size() != 0){
            Print.startRowDoubleHorizontal(isDynamic, text);
            Print.printHorizontalLine(isDynamic, text);
            Print.println("", isDynamic, Print.highSpeed, text);
            Print.endRow(isDynamic, text);
            Print.startRow(isDynamic, text);
            Print.print("回復", Print.highSpeed, text);
            Print.separateRow(isDynamic, text);
            for(TrainStatus key: this.heal.keySet()){
                heal = this.heal.get(key);
                if(key.child != null){
                    Print.println(key.child.jName + ": " + key.jName + "の " + heal + "%", isDynamic, Print.highSpeed, text);
                    
                }else{
                    Print.println(key.jName + ": " + heal, isDynamic, Print.highSpeed, text);
                    
                }
            }
            Print.endRow(isDynamic, text);
        }
        if(this.enhance.size() != 0){
            Print.startRowDoubleHorizontal(isDynamic, text);
            Print.printHorizontalLine(isDynamic, text);
            Print.println("", isDynamic, Print.highSpeed, text);
            Print.endRow(isDynamic, text);
            Print.startRow(isDynamic, text);
            Print.print("成長", Print.highSpeed, text);
            Print.separateRow(isDynamic, text);
            for(TrainStatus key: this.enhance.keySet()){
                enhance = this.enhance.get(key);
                Print.println(key.jName + ": " + enhance + "%", isDynamic, Print.highSpeed, text);
                
            }
            Print.endRow(isDynamic, text);
        }
        if(this.cardToAddWithExecute.size() != 0){
            Print.startRowDoubleHorizontal(isDynamic, text);
            Print.printHorizontalLine(isDynamic, text);
            Print.println("", isDynamic, Print.highSpeed, text);
            Print.endRow(isDynamic, text);
            Print.startRow(isDynamic, text);
            Print.print("デッキ効果", isDynamic, Print.highSpeed, text);
            Print.separateRow(isDynamic, text);
            for(Card card : this.cardToAddWithExecute){
                Print.println(card.jName(), isDynamic, Print.highSpeed, text);
                
            }
            Print.println("の " + this.cardToAddWithExecute.size() + "枚のカードをデッキに加えた後、シャッフルする", isDynamic, Print.highSpeed, text);
            Print.endRow(isDynamic, text);
        }
        if(this.handReset){
            Print.startRowDoubleHorizontal(isDynamic, text);
            Print.printHorizontalLine(isDynamic, text);
            Print.println("", isDynamic, Print.highSpeed, text);
            Print.endRow(isDynamic, text);
            Print.startRow(isDynamic, text);
            Print.print("手札効果", isDynamic, Print.highSpeed, text);
            Print.separateRow(isDynamic, text);
            Print.println("手札のカードを全て捨てた後、同じ枚数デッキからカードを引く", isDynamic, Print.highSpeed, text);
            Print.endRow(isDynamic, text);
        }
        if(unlimits.size() != 0){
            Print.startRowDoubleHorizontal(isDynamic, text);
            Print.printHorizontalLine(isDynamic, text);
            Print.println("", isDynamic, Print.highSpeed, text);
            Print.endRow(isDynamic, text);
            Print.startRow(isDynamic, text);
            Print.print("発売カード", isDynamic, Print.highSpeed, text);
            Print.separateRow(isDynamic, text);
            for(int i = 0; i < unlimits.size(); i++){
                Print.println(unlimits.get(i).jName, isDynamic, Print.highSpeed, text);
                
            }
            Print.endRow(isDynamic, text);
        }
        Print.endTable(isDynamic, text);
        Print.endFrame(isDynamic, text);
        trainState.saveLocation(LocationCategory.explainCard, LocationCategory.FINISH);
    }

    // 省略説明（選択肢に表示）
    public void miniExplain(TrainState trainState, TimeFrame timeFrame, TrainStatus beforeMenu, boolean text){
        // int cost, heal, enhance;
        // String direction = "";
        int nameLength = 24;
        // int actNameLength = 11;
        // int costLength = 10;
        boolean gray = !getLegal(trainState, timeFrame, trainState.getMode());
        String printText = this.jName();
        Print.startCardFlame(Color.darkBlue, false, text);
        Print.print(Print.format(gray ? Color.gray.toColor(printText) : printText, nameLength, gray ? 1 : 0), Print.highSpeed, text);
        // for(TrainStatus key: this.cost.keySet()){
        //     cost = this.cost.get(key);
        //     if(key == TrainStatus.money){
        //         cost *= trainState.getMode().scale;
        //     }
        //     direction = "↓";
        //     if(key.child != null){
        //         Print.print(Print.format(key.child.jName + "：", actNameLength) + Print.toRed(Print.format(cost + "%" + direction, costLength)), Print.highSpeed, text);
        //     }else{
        //         Print.print(Print.format(key.jName + "：", actNameLength) + Print.toRed(Print.format(cost + direction, costLength)), Print.highSpeed, text);
        //     }
        // }
        // for(TrainStatus key: this.heal.keySet()){
        //     heal = this.heal.get(key);
        //     direction = "↑";
        //     if(key.child != null){
        //         if(heal == 100){
        //             Print.print(Print.format(key.child.jName + "：", actNameLength) + Color.blue.toColor(Print.format("全回復", costLength-1)), Print.highSpeed, text);
        //         }else{
        //             Print.print(Print.format(key.child.jName + "：", actNameLength) + Color.blue.toColor(Print.format(heal + "%" + direction, costLength)), Print.highSpeed, text);
        //         }
        //     }else{
        //         Print.print(Print.format(key.jName + "：", actNameLength) + Color.blue.toColor(Print.format(heal + direction, costLength)), Print.highSpeed, text);
        //     }
        // }
        // for(TrainStatus key: this.enhance.keySet()){
        //     enhance = this.enhance.get(key);
        //     // enhance = trainState.getSelf().getTrainStatus().get(key) * this.enhance.get(key) / 100;
        //     direction = "↑";
        //     Print.print(Print.format(key.jName + "：", actNameLength) + Color.blue.toColor(Print.format(enhance + direction, costLength)), Print.highSpeed, text);
        // }
        // // Print.println("", Print.highSpeed, text);
        Print.endFrame(false, text);
    }

    // 固有名
    @Override
    public String properName(){
        return this.properName;
    }

    // カテゴリ名
    @Override
    public String categoryName(){
        return "休憩カード";
    }

    // 名前
    public String jName(){
        return this.properName() + Print.space(2, true) + this.categoryName();
    }

    // 合法かどうか
    public boolean getLegal(TrainState trainState, TimeFrame timeFrame, Mode mode){
        if(!this.ableTimeFrameList.contains(timeFrame)){
            return false;
        }else if(!TimeFrame.checkLegal(timeFrame, mode, this.spendActionNum)){
            return false;
        }
        return true;
    }
    
    // ある程度有力かどうか
    public boolean getAiLegal(TrainState trainState, TimeFrame timeFrame, Mode mode){
        if(!getLegal(trainState, timeFrame, mode)){
            return false;
        }
        for(TrainStatus key: this.heal.keySet()){
            if(trainState.getSelf().getTrainStatus().get(key.child) <= trainState.getSelf().getTrainStatus().get(key) * 0.5){
                return true;
            }
        }
        return false;
    }
    
    // 実行
    public TrainState[] execute(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner, Random rand){
        switch(trainState.getSavedLocation(LocationCategory.executeCard)){
            case LocationCategory.NO_CHOICE:
                Player self = trainState.getSelf();
                Print.println(this.jName() + "を使用した", true, Print.highSpeed, text);
                for(TrainStatus key: this.cost.keySet()){
                    int cost = this.cost.get(key);
                    if(key == TrainStatus.money){
                        cost *= trainState.getMode().scale;
                    }
                    if(key.child != null){
                        if(self.getTrainStatus().get(key.child) < self.getTrainStatus().get(key) * cost / 100){
                            Print.print("しかし、" + key.child.jName + "が足りなかった", true, Print.middleSpeed, text);
                            trainState.setSelf(self);
                            return new TrainState[]{trainState, beforeTrainState};
                        }
                    } else if(self.getTrainStatus().get(key) < cost){
                        Print.print("しかし、" + key.jName + "が足りなかった", true, Print.middleSpeed, text);
                        trainState.setSelf(self);
                        return new TrainState[]{trainState, beforeTrainState};
                    }
                }
        
                for(TrainStatus key: this.enhance.keySet()){
                    CalculateDamage.trainProgress(self, key, false, this.enhance.get(key), text);
                }
                for(TrainStatus key: this.cost.keySet()){
                    CalculateDamage.trainDamage(self, key, this.cost.get(key), text);
                }
                for(TrainStatus key: this.heal.keySet()){
                    CalculateDamage.trainDamage(self, key, -this.heal.get(key), text);
                }
        
                trainState.setSelf(self);
                trainState.saveLocation(LocationCategory.executeCard, LocationCategory.FINISH);
                return new TrainState[]{trainState, beforeTrainState};

            default:
                System.out.println("error rest execute");
                return new TrainState[]{trainState, beforeTrainState};
        }
    }

    // メニューの数
    public static final int NUM = values().length;

    // カード全体の通し番号
    public int getOrdinalNumber(){
        return TrainMenu.NUM + this.ordinal();
    }

    // 使用行動数
    public int getSpendActionNum(){
        return this.spendActionNum;
    };

    // カードの枠数
    public int getCardSize(){
        return this.cardSize;
    };

    // 解放時にデッキに追加する枚数
    public int unlimitAddToDeckNum(){
        return this.unlimitAddToDeckNum;
    };

    // 実行時にデッキにカードを追加する
    @Override
    public void addCardToDeckWithExecute(TrainState trainState, boolean text){
        trainState.saveAddCard(this.cardToAddWithExecute, shuffleModeWithAddCard.Last);
    }

    // 制限されていないメニューの数
    public static RestMenu[] generalValues(TrainState trainState){
        return new ArrayList<>(){{
            add(maintenance);
            // add(hotSpring);
            // for(RestMenu key : new RestMenu[]{elecMainte, oilMainte}){
            //     if(trainState.getTrainLimitations().get(TrainLimitation.valueOf(key.name())).get(TrainLimitationCounter.flag) == 1){
            //         add(key);
            //     }
            // }
        }}.toArray(new RestMenu[0]);
    }
}
