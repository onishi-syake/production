package data.card;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import character.Player.TrainStatus;
import limitation.TrainLimitation;
import log.TrainTemporaryLog;
import train.TrainState;
import train.TrainState.Mode;
import train.TrainState.TimeFrame;

public interface Card {
    // 効果処理
    // ターンアプデ合わせる
    public abstract TrainState[] execute(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner, Random rand);

    // 詳細説明
    public abstract void explain(TrainState trainState, List<TrainLimitation> unlimits, TimeFrame timeFrame, boolean text, Scanner scanner);

    // 短縮説明
    public abstract void miniExplain(TrainState trainState, List<TrainLimitation> unlimits, TimeFrame timeFrame, TrainStatus beforeMenu, boolean choiced, int choicedIdx, boolean isNew, TrainTemporaryLog log, boolean text, Random rand);

    // インスタンス名
    public abstract String name();

    // 名前
    public abstract String jName();

    // カード固有名（[]の付いている部分）
    public abstract String properName();

    // カードカテゴリ名(〇〇カードの部分)
    public abstract String categoryName();

    // 合法判定
    public abstract boolean getLegal(TrainState trainState, TimeFrame timeFrame, Mode mode);

    // カード全体の通し番号
    public abstract int getOrdinalNumber();

    // 使用行動数
    public abstract int getSpendActionNum();

    // カードの枠数
    public abstract int getCardSize();

    // 解放された時にデッキに追加する枚数
    public abstract int unlimitAddToDeckNum();

    // 実行時にデッキにカードを追加する
    public abstract void addCardToDeckWithExecute(TrainState trainState, boolean text);

    // 手札の最大枚数
    public static final int maxHandNum = 12;

    // カードの総数
    public static final int NUM = Guild.NUM + ItemCard.NUM + RestMenu.NUM + TrainEvent.NUM + TrainMenu.NUM;

    // リストに含まれるカードのサイズの合計
    public static int cardsSize(List<Card> cardsList){
        int count = 0;
        for(Card card : cardsList){
            count += (card.getCardSize());
        }
        return count;
    }

    // // 解放されているカード全ての配列
    // public static List<Card> allGeneralValues(TrainState trainState){
    //     return new ArrayList<Card>(){{
    //         for(Card card : TrainMenu.generalValues(trainState)){
    //             add(card);
    //         }
    //         for(Card card : RestMenu.generalValues(trainState)){
    //             add(card);
    //         }
    //         for(Card card : TrainEvent.generalValues(trainState)){
    //             add(card);
    //         }
    //         for(Card card : Guild.generalValues(trainState)){
    //             add(card);
    //         }
    //         for(Card card : ItemCard.generalValues(trainState)){
    //             add(card);
    //         }
    //     }};
    // }

    // カード全ての配列
    public static List<Card> values(){
        return new ArrayList<Card>(){{
            for(Card card : TrainMenu.values()){
                add(card);
            }
            for(Card card : RestMenu.values()){
                add(card);
            }
            for(Card card : TrainEvent.values()){
                add(card);
            }
            for(Card card : Guild.values()){
                add(card);
            }
            for(Card card : ItemCard.values()){
                add(card);
            }
        }};
    }

    // カードの通し番号を元にカードを取り出す
    public static Card getCard(int ordinalNumber){
        if(ordinalNumber < 0){
            System.out.println("out of bounds getCard");
            return values().get(0);
        }
        return values().get(ordinalNumber);
    }

    // 手札のカードから選ばれたカードを除いたカードのリストを返す
    public static List<CardWithParams> remainingCards(List<CardWithParams> baseCards, List<CardWithParams> choicedCards){
        baseCards = new ArrayList<>(baseCards);
        for(CardWithParams choicedCard : choicedCards){
            for(CardWithParams baseCard : new ArrayList<>(baseCards)){
                if(baseCard.card == choicedCard.card){
                    baseCards.remove(baseCard);
                    break;
                }
            }
        }
        return baseCards;
    }

    // カードの通し番号を元にソートする
    public static void sortCards(List<Card> cards){
        Comparator<Card> comparator = new Comparator<Card>() { // cardのordinalNumberを元に昇順にするコンパレータを作成
            @Override
            public int compare(Card card1, Card card2) {
                return  card1.getOrdinalNumber() - card2.getOrdinalNumber();
            }
        };
        Collections.sort(cards, comparator);
    }

    // 初期デッキ
    public static List<Card> startDeck(Random rand){
        return new ArrayList<Card>(){{
            for(int i = 0; i < 2; i++){
                add(RestMenu.maintenance);
            }
            List<Card> berserkers = new ArrayList<>(){{
                add(Guild.berserkerHP);
                add(Guild.berserkerA);
                add(Guild.berserkerS);
            }};
            for(int i = 0; i < 2; i++){
                int idx = rand.nextInt(berserkers.size());
                add(berserkers.get(idx));
                berserkers.remove(idx);
            }
        }};
    }
}