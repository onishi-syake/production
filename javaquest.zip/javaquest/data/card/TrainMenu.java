package data.card;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import battle.CalculateDamage;
import battle.CalculateDamage.CostCategory;
import battle.CalculateDamage.CostParameter;

import java.util.ArrayList;
import java.util.Collections;

import character.Player;
import character.Skill;
import character.Character.MainStatus;
import character.Player.TrainStatus;
import data.item.BattleItem;
import game.LocationCategory;
import limitation.TrainLimitation;
import limitation.TrainLimitation.TrainLimitationCounter;
import log.TrainTemporaryLog;
import log.OneTurnBattleLog.Success;
import text.Print;
import text.Print.Color;
import train.Train;
import train.TrainState;
import train.TrainState.Mode;
import train.TrainState.TimeFrame;
import train.TrainState.shuffleModeWithAddCard;


public enum TrainMenu implements Card{
    // //miniHp("すいえい", new EnumMap<>(TrainStatus.class){{
    // miniHp("HPトレーニング小", false, TrainLimitation.normalHp, 
    // new EnumMap<>(TrainStatus.class){{
    //     put(TrainStatus.maxHp, 100);
    // }}, new EnumMap<>(TrainStatus.class){{
    //     // put(TrainStatus.hp, 100);
    //     // put(TrainStatus.maxMotivation, 10);
    // }}),
    //normalHp("スタミナパックG", new EnumMap<>(TrainStatus.class){{
    normalHp(
    TrainMenuCategory.HP,
    TrainMenuSize.A,
    Color.yellowDarked,
    1, 
    1, 
    0,// 解放時にデッキに追加する枚数
    new EnumMap<>(TrainStatus.class){{// 成長
        put(TrainStatus.maxHp, 50);
    }}, new ArrayList<>(){{// 通常コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.hp, 150, CostCategory.direct));
    }}, new ArrayList<>(){{// 大成功コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.maxHp, 7.5, CostCategory.ratioFromMax));
    }}, new ArrayList<>(){{// 共通コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.concentration, 7, CostCategory.ratioFromCurrentValue));
        add(new CalculateDamage().new CostParameter(TrainStatus.motivation, 10, CostCategory.ratioFromCurrentValue));
    }},
    new ArrayList<TimeFrame>(){{
        add(TimeFrame.morning);
        add(TimeFrame.afternoon);
        add(TimeFrame.night);
    }}),
    //bigHp("真空耐久訓練", new EnumMap<>(TrainStatus.class){{
    bigHp(
    TrainMenuCategory.HP,
    TrainMenuSize.B,
    Color.yellow,
    1, 
    1, 
    0,// 解放時にデッキに追加する枚数
    new EnumMap<>(TrainStatus.class){{// 成長
        put(TrainStatus.maxHp, 100);
    }}, new ArrayList<>(){{// 通常コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.hp, 300, CostCategory.direct));
    }}, new ArrayList<>(){{// 大成功コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.maxHp, 15, CostCategory.ratioFromMax));
    }}, new ArrayList<>(){{// 共通コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.concentration, 15, CostCategory.ratioFromCurrentValue));
        add(new CalculateDamage().new CostParameter(TrainStatus.motivation, 20, CostCategory.ratioFromCurrentValue));
    }},
    new ArrayList<TimeFrame>(){{
        add(TimeFrame.morning);
        add(TimeFrame.afternoon);
        add(TimeFrame.night);
    }}),
    //bigHp("真空耐久訓練", new EnumMap<>(TrainStatus.class){{
    superHp(
    TrainMenuCategory.HP,
    TrainMenuSize.C,
    Color.yellowLighted,
    2, 
    2, 
    0,// 解放時にデッキに追加する枚数
    new EnumMap<>(TrainStatus.class){{// 成長
        put(TrainStatus.maxHp, 400);
    }}, new ArrayList<>(){{// 通常コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.hp, 1200, CostCategory.direct));
    }}, new ArrayList<>(){{// 大成功コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.maxHp, 60, CostCategory.ratioFromMax));
    }}, new ArrayList<>(){{// 共通コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.concentration, 40, CostCategory.ratioFromCurrentValue));
        add(new CalculateDamage().new CostParameter(TrainStatus.motivation, 60, CostCategory.ratioFromCurrentValue));
    }},
    new ArrayList<TimeFrame>(){{
        add(TimeFrame.morning);
        add(TimeFrame.afternoon);
        add(TimeFrame.night);
    }}),
    
    // //miniA("うでたて", new EnumMap<>(TrainStatus.class){{
    // miniA("攻撃力トレーニング小", false, TrainLimitation.normalA, 
    // new EnumMap<>(TrainStatus.class){{
    //     put(TrainStatus.a, 10);
    // }}, new EnumMap<>(TrainStatus.class){{
    //     // put(TrainStatus.hp, 100);
    //     // put(TrainStatus.health, 10);
    // }}),
    //normalA("マッスルジムH", new EnumMap<>(TrainStatus.class){{
    normalA(
    TrainMenuCategory.A,
    TrainMenuSize.A,
    Color.purpleDarked,
    1, 
    1, 
    0,// 解放時にデッキに追加する枚数
    new EnumMap<>(TrainStatus.class){{// 成長
        put(TrainStatus.a, 5);
    }}, new ArrayList<>(){{// 通常コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.hp, 100, CostCategory.direct));
    }}, new ArrayList<>(){{// 大成功コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.maxHp, 5, CostCategory.ratioFromMax));
    }},  new ArrayList<>(){{// 共通コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.concentration, 7, CostCategory.ratioFromCurrentValue));
        add(new CalculateDamage().new CostParameter(TrainStatus.motivation, 0, CostCategory.ratioFromCurrentValue));
    }}, 
    new ArrayList<TimeFrame>(){{
        add(TimeFrame.morning);
        add(TimeFrame.afternoon);
        add(TimeFrame.night);
    }}),
    //bigA("全身筋肉改造", new EnumMap<>(TrainStatus.class){{
    bigA(
    TrainMenuCategory.A,
    TrainMenuSize.B,
    Color.purple,
    1, 
    1, 
    0,// 解放時にデッキに追加する枚数
    new EnumMap<>(TrainStatus.class){{// 成長
        put(TrainStatus.a, 10);
    }}, new ArrayList<>(){{// 通常コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.hp, 200, CostCategory.direct));
    }}, new ArrayList<>(){{// 大成功コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.maxHp, 10, CostCategory.ratioFromMax));
    }},  new ArrayList<>(){{// 共通コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.concentration, 15, CostCategory.ratioFromCurrentValue));
        add(new CalculateDamage().new CostParameter(TrainStatus.motivation, 10, CostCategory.ratioFromCurrentValue));
    }}, 
    new ArrayList<TimeFrame>(){{
        add(TimeFrame.morning);
        add(TimeFrame.afternoon);
        add(TimeFrame.night);
    }}),
    //bigA("全身筋肉改造", new EnumMap<>(TrainStatus.class){{
    superA(
    TrainMenuCategory.A,
    TrainMenuSize.C,
    Color.purpleLighted,
    2, 
    2, 
    0,// 解放時にデッキに追加する枚数
    new EnumMap<>(TrainStatus.class){{// 成長
        put(TrainStatus.a, 40);
    }}, new ArrayList<>(){{// 通常コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.hp, 800, CostCategory.direct));
    }}, new ArrayList<>(){{// 大成功コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.maxHp, 40, CostCategory.ratioFromMax));
    }},  new ArrayList<>(){{// 共通コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.concentration, 40, CostCategory.ratioFromCurrentValue));
        add(new CalculateDamage().new CostParameter(TrainStatus.motivation, 10, CostCategory.ratioFromCurrentValue));
    }}, 
    new ArrayList<TimeFrame>(){{
        add(TimeFrame.morning);
        add(TimeFrame.afternoon);
        add(TimeFrame.night);
    }}),
    
    // //miniS("そくてん", new EnumMap<>(TrainStatus.class){{
    // miniS("素早さトレーニング小", false, TrainLimitation.normalS, 
    // new EnumMap<>(TrainStatus.class){{
    //     put(TrainStatus.s, 10);
    // }}, new EnumMap<>(TrainStatus.class){{
    //     // put(TrainStatus.hp, 100);
    //     // put(TrainStatus.activity, 15);
    // }}),
    //normalS("ダッシュマシンS", new EnumMap<>(TrainStatus.class){{
    normalS(
    TrainMenuCategory.S,
    TrainMenuSize.A,
    Color.greenDarked,
    1, 
    1, 
    0,// 解放時にデッキに追加する枚数
    new EnumMap<>(TrainStatus.class){{// 成長
        put(TrainStatus.s, 5);
    }}, new ArrayList<>(){{// 通常コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.hp, 100, CostCategory.direct));
    }}, new ArrayList<>(){{// 大成功コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.maxHp, 5, CostCategory.ratioFromMax));
    }},  new ArrayList<>(){{// 共通コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.concentration, 0, CostCategory.ratioFromCurrentValue));
        add(new CalculateDamage().new CostParameter(TrainStatus.motivation, 10, CostCategory.ratioFromCurrentValue));
    }}, 
    new ArrayList<TimeFrame>(){{
        add(TimeFrame.morning);
        add(TimeFrame.afternoon);
        add(TimeFrame.night);
    }}),
    //bigS("飛翔能力強化", new EnumMap<>(TrainStatus.class){{
    bigS(
    TrainMenuCategory.S,
    TrainMenuSize.B,
    Color.green,
    1, 
    1, 
    0,// 解放時にデッキに追加する枚数
    new EnumMap<>(TrainStatus.class){{// 成長
        put(TrainStatus.s, 10);
    }}, new ArrayList<>(){{// 通常コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.hp, 200, CostCategory.direct));
    }}, new ArrayList<>(){{// 大成功コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.maxHp, 10, CostCategory.ratioFromMax));
    }},  new ArrayList<>(){{// 共通コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.concentration, 7, CostCategory.ratioFromCurrentValue));
        add(new CalculateDamage().new CostParameter(TrainStatus.motivation, 20, CostCategory.ratioFromCurrentValue));
    }}, 
    new ArrayList<TimeFrame>(){{
        add(TimeFrame.morning);
        add(TimeFrame.afternoon);
        add(TimeFrame.night);
    }}),
    //bigS("飛翔能力強化", new EnumMap<>(TrainStatus.class){{
    superS(
    TrainMenuCategory.S,
    TrainMenuSize.C,
    Color.greenLighted,
    2, 
    2, 
    0,// 解放時にデッキに追加する枚数
    new EnumMap<>(TrainStatus.class){{// 成長
        put(TrainStatus.s, 40);
    }}, new ArrayList<>(){{// 通常コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.hp, 800, CostCategory.direct));
    }}, new ArrayList<>(){{// 大成功コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.maxHp, 40, CostCategory.ratioFromMax));
    }},  new ArrayList<>(){{// 共通コスト
        add(new CalculateDamage().new CostParameter(TrainStatus.concentration, 7, CostCategory.ratioFromCurrentValue));
        add(new CalculateDamage().new CostParameter(TrainStatus.motivation, 60, CostCategory.ratioFromCurrentValue));
    }}, 
    new ArrayList<TimeFrame>(){{
        add(TimeFrame.morning);
        add(TimeFrame.afternoon);
        add(TimeFrame.night);
    }}),

    mp(
    TrainMenuCategory.MP,
    TrainMenuSize.A,
    Color.white,
    1, 
    1, 
    0,// 解放時にデッキに追加する枚数
    new EnumMap<>(TrainStatus.class){{// 成長
        //スロット数1
        put(TrainStatus.maxMp, 1);//夜は4
    }}, new ArrayList<>(){{// 通常コスト
        // 昼・手札1枚/夜・手札2枚
    }}, new ArrayList<>(){{// 大成功コスト
        
    }}, new ArrayList<>(){{// 共通コスト
        
    }}, 
    new ArrayList<TimeFrame>(){{
        add(TimeFrame.morning);
        add(TimeFrame.afternoon);
        add(TimeFrame.night);
    }}){
        final int mpNightCoef = 2;
        final int handCost = 2;
        final int handNightCoef = 2;
        final int addSpellSlotNum = 1;
        @Override
        public String levelName(TrainState state){
            return "[MP・スロット増加]" + Print.space(2, true) + this.categoryName();
        }
        @Override
        public String jName(){
            return "[MP・スロット増加]" + Print.space(2, true) + this.categoryName();
        }
        @Override
        public String properName(){
            return "[MP・スロット増加]";
        }
        @Override
        public void explain(TrainState trainState, List<TrainLimitation> unlimits, TimeFrame timeFrame, boolean text, Scanner scanner){
            int cost;
            String direction = "";
            Player self = trainState.getSelf();
            boolean isDynamic = false;

            int handCost = this.handCost * (timeFrame == TimeFrame.night ? handNightCoef : 1);
            int addMp = this.trainCategory.get(TrainStatus.maxMp) * (timeFrame == TimeFrame.night ? handNightCoef : 1);


            Print.startFrame(isDynamic, text);
            Print.println("", isDynamic, Print.highSpeed, text);
            Print.println(Print.space(2, text) + this.levelName(trainState), isDynamic, Print.highSpeed, text);
            Print.startTable(isDynamic, text);

            Print.startRowDoubleHorizontal(isDynamic, text);
            Print.printHorizontalLine(isDynamic, text);
            Print.endRow(isDynamic, text);
    
            Print.startRow(isDynamic, text);
            Print.print("成長", isDynamic, Print.highSpeed, text);
            Print.separateRow(isDynamic, text);
            Print.println(TrainStatus.maxMp.jName + ": " + addMp, isDynamic, Print.highSpeed, text);
            Print.println("呪文スロット: " + addSpellSlotNum + "個", isDynamic, Print.highSpeed, text);
            Print.endRow(isDynamic, text);

            Print.startRowDoubleHorizontal(isDynamic, text);
            Print.printHorizontalLine(isDynamic, text);
            Print.endRow(isDynamic, text);

            Print.startRow(isDynamic, text);
            Print.print("コスト", isDynamic, Print.highSpeed, text);
            Print.separateRow(isDynamic, text);
            Print.println("手札: " + handCost + "枚", isDynamic, Print.highSpeed, text);
            Print.endRow(isDynamic, text);

            Print.startRowDoubleHorizontal(isDynamic, text);
            Print.printHorizontalLine(isDynamic, text);
            Print.endRow(isDynamic, text);

            if(this.getCardToAddWithExecute().size() != 0){
                Print.startRow(isDynamic, text);
                Print.print("デッキ効果", isDynamic, Print.highSpeed, text);
                Print.separateRow(isDynamic, text);
                for(Card card : this.getCardToAddWithExecute().subList(0, (this.getCardToAddWithExecute().size() == 0 ? 0 : this.getCardToAddWithExecute().size() - 1))){
                    Print.println(card.jName() + "をデッキに加える", isDynamic, Print.highSpeed, text);
                    
                }
                Print.println("デッキをシャッフルし、その後" + this.getCardToAddWithExecute().get(this.getCardToAddWithExecute().size() - 1).jName() + "をデッキの一番上に加える", isDynamic, Print.highSpeed, text);
                Print.endRow(isDynamic, text);

                Print.startRowDoubleHorizontal(isDynamic, text);
                Print.printHorizontalLine(isDynamic, text);
                Print.endRow(isDynamic, text);
            }


            Print.startRow(isDynamic, text);
            Print.print("発売カード", isDynamic, Print.highSpeed, text);
            Print.separateRow(isDynamic, text);
            for(int i = 0; i < unlimits.size(); i++){
                Print.println(unlimits.get(i).jName, isDynamic, Print.highSpeed, text);
                
            }
            Print.endRow(isDynamic, text);

            Print.endTable(isDynamic, text);
            Print.endFrame(isDynamic, text);



            // Print.startFrame(isDynamic, text);
            // Print.println(this.levelName(trainState), isDynamic, Print.highSpeed, text);
            // Print.println("", isDynamic, Print.highSpeed, text);
            
            // Print.println(TrainStatus.maxMp.jName + "が " + this.trainCategory.get(TrainStatus.maxMp) + " 増加する", isDynamic, Print.highSpeed, text);
            
            // // for(TrainStatus key: this.costCategory.keySet()){
            // //     cost = this.costCategory.get(key);
            // //     if(cost < 0){
            // //         direction = "回復する";
            // //         cost *= -1;
            // //     }else{
            // //         direction = "消費する";
            // //     }
            // //     // if(key == TrainStatus.hp){
            // //     //     cost *= Math.pow(innCostCoef, self.getInnNum());
            // //     // }
            // //     if(key == TrainStatus.money){
            // //         Print.println(key.jName + "を" + cost + "円 x 今まで" + this.jName + "をした回数" + direction, Print.highSpeed, text);
            // //     }else if(key.child != null){
            // //         Print.println(key.child.jName + "を" + key.jName + "の" + cost + "%" + direction, Print.highSpeed, text);
            // //     }else{
            // //         Print.println(key.jName + "を" + cost + direction, Print.highSpeed, text);
            // //     }
            // // }
            // Print.println("呪文スロットが " + addSpellSlotNum + "こ増える", isDynamic, Print.highSpeed, text);
            
            // Print.println("実行時に手札を " + handCost + "枚消費する", isDynamic, Print.highSpeed, text);
            
            // Print.println("夜は手札消費が " + (handCost * handNightCoef) + "枚になり、" + TrainStatus.maxMp.jName + "が " + (this.trainCategory.get(TrainStatus.maxMp) * mpNightCoef) + " 増加する", isDynamic, Print.highSpeed, text);
            
            // if(this.getCardToAddWithExecute().size() != 0){
            //     Print.println("デッキに追加するカードは", isDynamic, Print.highSpeed, text);
                
            //     for(Card card : this.getCardToAddWithExecute()){
            //         Print.println(card.jName(), isDynamic, Print.highSpeed, text);
                    
            //     }
            // }
            // if(unlimits.size() != 0){
            //     Print.print("ショップに", isDynamic, Print.highSpeed, text);
            //     for(int i = 0; i < unlimits.size(); i++){
            //         Print.print(Print.space(2, text) + unlimits.get(i).jName, isDynamic, Print.highSpeed, text);
            //         if(i != 0){
            //             Print.print("と", isDynamic, Print.highSpeed, text);
            //         }
            //     }
            //     Print.println("が追加されます", isDynamic, Print.highSpeed, text);
                
            // }
            // if(this.spendActionNum != 0){
            //     Print.println(this.spendActionNum + " 行動消費する", isDynamic, Print.highSpeed, text);
                
            // }
            // Print.endFrame(isDynamic, text);
            trainState.saveLocation(LocationCategory.explainCard, LocationCategory.FINISH);
        }

        @Override
        public void miniExplain(TrainState trainState, List<TrainLimitation> unlimits, TimeFrame timeFrame, TrainStatus beforeMenu, boolean choiced, int choicedIdx, boolean isNew, TrainTemporaryLog log, boolean text, Random rand){
            int cost;
            Player self = trainState.getSelf();
            String direction = "";
            int nameLength = 24;
            int actNameLength = 11;
            int costLength = 10;
            int exp = this.trainCategory.get(TrainStatus.maxMp);
            String printText = "";
            int colorCount = 0;
            if(trainState.getMode() == Mode.easy){
                exp *= 2;
            }
            // Print.print(Print.format(jName + star + "(" + exp + ")", nameLength), Print.highSpeed, text);
            
            Color color = Color.white;
            if(choiced){
                color = Color.yellow;
            }else if(!getLegal(trainState, timeFrame, trainState.getMode())){
                color = Color.gray;
            }
            if(color != Color.white) colorCount++;
            // String unlimitText = "";
            // if(unlimits.size() != 0){
            //     for(int i = 0; i < unlimits.size(); i++){
            //         unlimitText += "[" + unlimits.get(i).jName + "]";
            //         if(i != 0){
            //             unlimitText += "と";
            //         }
            //     }
            //     unlimitText += "発売！";
            //     unlimitText = Color.blue.toColor(unlimitText);
            // }
            // Print.print(Print.space(1, text), Print.highSpeed, text);
            // Print.print(unlimitText, Print.highSpeed, text);
            Print.startCardFlame(this.frameColor, false, text);
            color.startColor(false, text);
            Print.print(levelName(trainState), Print.highSpeed, text);
            if(isNew){
                if(color == Color.white){
                    Print.print(Print.space(2, text) + Color.whiteOrange.toColor("NEW！ "), Print.highSpeed, text);
                }else{
                    Print.print(Print.space(2, text) + color.toColor("NEW！ "), Print.highSpeed, text);
                }
            }
            // if(unlimits.size() != 0){
            //     Print.print("[", Print.highSpeed, text);
            // }
            // for(int i = 0; i < unlimits.size(); i++){
            //     Print.print(Print.space(2, text) + unlimits.get(i).jName, Print.highSpeed, text);
            //     if(i != 0){
            //         Print.print("と", Print.highSpeed, text);
            //     }
            // }
            // if(unlimits.size() != 0){
            //     Print.print("が販売解禁！]", Print.highSpeed, text);
            // }
            Print.println("", Print.highSpeed, text);
            Print.print("手札消費:" + handCost * (timeFrame == TimeFrame.night ? handNightCoef : 1), Print.highSpeed, text);
            color.endColor(false, text);
            Print.endFrame(false, text);
        }

        @Override
        public boolean getLegal(TrainState trainState, TimeFrame timeFrame, Mode mode){
            Player self = trainState.getSelf();
            //TODO 勇者ターン超えるとアウトという判定を入れる
            if(!this.ableTimeFrameList.contains(timeFrame)){
                return false;
            }else if(!TimeFrame.checkLegal(timeFrame, mode, this.spendActionNum)){
                return false;
            }else if(self.getElixirTurn() != 0){
                return true;
            }else{
                return true;
            }
            // }else if(costCategory.containsKey(TrainStatus.hp)){
            //     return costCategory.get(TrainStatus.hp) * Math.pow(battleCostCoef, self.getInnNum()) < self.getTrainStatus().get(TrainStatus.hp);
            // }else{
            //     return costCategory.get(TrainStatus.maxHp) * self.getTrainStatus().get(TrainStatus.maxHp) / 100 < self.getTrainStatus().get(TrainStatus.hp);
            // }
        }
        @Override
        public TrainState[] execute(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner, Random rand){
            final int DROP_CARD = 1;
            final int CARD_EXECUTE = 2;
            switch(trainState.getSavedLocation(LocationCategory.executeCard)){
                case LocationCategory.NO_CHOICE:
                    Print.skipStart(true, text);
                    Print.println(Color.yellow.toColor(this.jName() + "を使用したコストで、手札を捨ててください"), true, Print.highSpeed, text);
                    Print.skipEnd(true, text);
                    trainState.saveLocation(LocationCategory.executeCard, DROP_CARD);
                    trainState.saveLocation(LocationCategory.dropTrainMenuNum, handCost * (trainState.getTimeFrame() == TimeFrame.night ? handNightCoef : 1));
                    return execute(trainState, beforeTrainState, log, text, scanner, rand);

                case DROP_CARD:
                    trainState.dropTrainMenu(text);
                    if(trainState.getSavedLocation(LocationCategory.dropTrainMenu) == LocationCategory.FINISH){
                        trainState.saveLocation(LocationCategory.dropTrainMenu, LocationCategory.NO_CHOICE);
                        trainState.saveLocation(LocationCategory.executeCard, CARD_EXECUTE);
                        return execute(trainState, beforeTrainState, log, text, scanner, rand);
                    }
                    return new TrainState[]{trainState, beforeTrainState};


                case CARD_EXECUTE:
                    Player self = trainState.getSelf();
                    self.setSpellSlotNum(self.getSpellSlotNum() + addSpellSlotNum);
                    int exp = this.trainCategory.get(TrainStatus.maxMp) * (trainState.getTimeFrame() == TimeFrame.night ? mpNightCoef : 1);
                    CalculateDamage.trainProgress(self, TrainStatus.maxMp, false, exp, false);
                    CalculateDamage.trainDamage(self, TrainStatus.mp, -exp, false);
                    self.setMpTrainNum(self.getMpTrainNum() + 1);
                    trainState.setSelf(self);
                    trainState.saveLocation(LocationCategory.executeCard, LocationCategory.FINISH);
                    return new TrainState[]{trainState, beforeTrainState};

                default:
                    System.out.println("error mpTrain execute");
                    return new TrainState[]{trainState, beforeTrainState};
            }
        }
    },
    
    /*easyA("マッスルジムH", new EnumMap<>(TrainStatus.class){{
        put(TrainStatus.a, 20);
    }}, new EnumMap<>(TrainStatus.class){{
        put(TrainStatus.hp,200);
    }}),
    easyHp("スタミナパックG", new EnumMap<>(TrainStatus.class){{
        put(TrainStatus.maxHp, 200);
    }}, new EnumMap<>(TrainStatus.class){{
        put(TrainStatus.hp, 200);
    }}),
    easyS("ダッシュマシンS", new EnumMap<>(TrainStatus.class){{
        put(TrainStatus.s, 20);
    }}, new EnumMap<>(TrainStatus.class){{
        put(TrainStatus.hp, 200);
    }}),*/
    ;

    public final TrainMenuCategory trainMenuCategory;// 種類
    public final TrainMenuSize trainMenuSize;// 大きさ
    public final Color frameColor;// 枠の色
    public final int spendActionNum;// 消費行動数
    public final int cardSize;// カードの枠数
    public final int unlimitAddToDeckNum;// 解放時にデッキに追加する枚数
    public final Map<TrainStatus, Integer> trainCategory;// 成長量
    public final List<CostParameter> costCategory;// コスト
    public final List<CostParameter> greatCostCategory;// 大成功コスト
    public final List<CostParameter> commonCostCategory;// 成功と大成功に共通のコスト
    public final List<TimeFrame> ableTimeFrameList;// 使用できる時間帯
    // public static final double innCostCoef = 1.4;
    // public static final int sameTrainAddCoef = 1;
    public static final double sameTrainBuff = 1.0;// 連続同種強化時の能力増加効果量
    // public static final double chainTrainCoef = 1.0;
    // コンストラクタ
    private TrainMenu(TrainMenuCategory trainMenuCategory, TrainMenuSize trainMenuSize, Color frameColor, int spendActionNum, int cardSize, int unlimitAddToDeckNum, Map<TrainStatus, Integer> trainCategory, List<CostParameter> costArray, List<CostParameter> greatCostCategory, List<CostParameter> commonCostCategory, List<TimeFrame> ableTimeFrameList){
        this.trainMenuCategory = trainMenuCategory;
        this.trainMenuSize = trainMenuSize;
        this.frameColor = frameColor;
        this.spendActionNum = spendActionNum;
        this.cardSize = cardSize;
        this.unlimitAddToDeckNum = unlimitAddToDeckNum;
        this.trainCategory  = Collections.unmodifiableMap(trainCategory);
        this.costCategory = Collections.unmodifiableList(costArray);
        this.greatCostCategory = Collections.unmodifiableList(greatCostCategory);
        this.commonCostCategory = Collections.unmodifiableList(commonCostCategory);
        this.ableTimeFrameList = ableTimeFrameList;
        System.out.println("");
    }

    private Map<TrainStatus, Integer> getRealExp(TrainState trainState, boolean isGuts, TimeFrame timeFrame, TrainStatus beforeTrainMenu){
        int baseExp, exp;
        Player self = trainState.getSelf();
        Map<TrainStatus, Integer> realExp = new HashMap<>();
        for(TrainStatus key: this.trainCategory.keySet()){
            baseExp = this.trainCategory.get(key);
            baseExp *= levelBuff(trainState);
            exp = baseExp;
            if(beforeTrainMenu == key && trainState.getTrainLimitations().get(TrainLimitation.sameTrain).get(TrainLimitationCounter.flag) == 1){
                exp += baseExp * sameTrainBuff;
            }
            if(isGuts){
                exp += baseExp;
            }
            if(timeFrame == TimeFrame.morning){
                exp /= 2;
            }
            if(timeFrame == TimeFrame.night){
                exp *= 2;
            }
            if(trainState.getMode() == Mode.easy){
                exp *= 2;
            }
            if(trainState.getTrainLimitations().get(TrainLimitation.chainTrain).get(TrainLimitationCounter.flag) == 1){
                // exp *= Math.pow(chainTrainCoef, trainState.getChainTrainNum());
            }
            realExp.put(key, exp);
        }
        return realExp;
    }

    private Map<TrainStatus, Integer> getRealCost(TrainState trainState, TimeFrame timeFrame, boolean great){
        final List<CostParameter> costCategories = Stream.concat((great ? this.greatCostCategory : this.costCategory).stream(), this.commonCostCategory.stream()).collect(Collectors.toList());
        List<CostParameter> directCostCategory = new ArrayList<>(){{
            for(CostParameter param : new ArrayList<>(costCategories)){
                add(CalculateDamage.changeToDirect(trainState.getSelf(), param));
            }
        }};
        double cost;
        Map<TrainStatus, Integer> realCost = new HashMap<>();
        for(CostParameter param: directCostCategory){
            cost = param.value;
            if(param.statusCategory == TrainStatus.hp && !great){
                cost *= levelBuff(trainState);
            }
            if(timeFrame == TimeFrame.morning){
                cost /= 2;
            }
            if(timeFrame == TimeFrame.night){
                cost *= 2;
            }
            if(trainState.getSelf().getNoCostStatus().contains(param.statusCategory)){
                cost = 0;
            }
            realCost.put(param.statusCategory, (int)cost);
        }
        return realCost;
    }

    private boolean isBiggerGreatCost(TrainState trainState, TimeFrame timeFrame){
        boolean isGreat = true;
        Map<TrainStatus, Integer> greatCost = getRealCost(trainState, timeFrame, isGreat);
        isGreat = false;
        Map<TrainStatus, Integer> normalCost = getRealCost(trainState, timeFrame, isGreat);
        if(!greatCost.keySet().contains(TrainStatus.hp)){
            return false;
        }
        if(!normalCost.keySet().contains(TrainStatus.hp)){
            return false;
        }
        return greatCost.get(TrainStatus.hp) > normalCost.get(TrainStatus.hp);
    }

    // 詳細説明
    public void explain(TrainState trainState, List<TrainLimitation> unlimits, TimeFrame timeFrame, boolean text, Scanner scanner){
        int cost;
        String direction = "";
        boolean isDynamic = false;
        int nightCostCoef = timeFrame == TimeFrame.night ? 2 : 1;
        int nightExpCoef = timeFrame == TimeFrame.night ? 2 : 1;
        Print.startFrame(isDynamic, text);
        Print.println("", isDynamic, Print.highSpeed, text);
        Print.println(Print.space(2, text) + this.levelName(trainState), isDynamic, Print.highSpeed, text);
        
        Print.startTable(isDynamic, text);

        Print.startRowDoubleHorizontal(isDynamic, text);
        Print.printHorizontalLine(isDynamic, text);
        Print.endRow(isDynamic, text);

        Print.startRow(isDynamic, text);
        Print.print("成長", isDynamic, Print.highSpeed, text);
        Print.separateRow(isDynamic, text);
        for(TrainStatus key: this.trainCategory.keySet()){
            Print.println(key.jName + ":" + (int)(this.trainCategory.get(key) * levelBuff(trainState)) * nightExpCoef, isDynamic, Print.highSpeed, text);
        }
        Print.endRow(isDynamic, text);
        Print.startRowDoubleHorizontal(isDynamic, text);
        Print.printHorizontalLine(isDynamic, text);
        Print.endRow(isDynamic, text);
        Print.startRow(isDynamic, text);
        Print.print("コスト", isDynamic, Print.highSpeed, text);
        Print.separateRow(isDynamic, text);
        for(int i = 0; i < this.costCategory.size() && i < this.greatCostCategory.size(); i++){
            Print.println(this.costCategory.get(i).statusCategory.jName + ": " + Print.removeZero(this.costCategory.get(i).value * nightCostCoef * this.levelBuff(trainState)) + " (成功時) ・ 最大値から " + Print.removeZero(this.greatCostCategory.get(i).value * nightCostCoef) + "%(大成功時)", isDynamic, Print.highSpeed, text);
        }
        
        for(int i = 0; i < this.commonCostCategory.size(); i++){
            if(this.commonCostCategory.get(i).value == 0){
                Print.println(this.commonCostCategory.get(i).statusCategory.jName + ": --", isDynamic, Print.highSpeed, text);
            }else{
                Print.println(this.commonCostCategory.get(i).statusCategory.jName + ": 現在値の " + Print.removeZero(this.commonCostCategory.get(i).value * nightCostCoef) + "%", isDynamic, Print.highSpeed, text);
            }
        }
        
        if(this.getCardToAddWithExecute().size() != 0){
            Print.endRow(isDynamic, text);
            Print.startRowDoubleHorizontal(isDynamic, text);
            Print.printHorizontalLine(isDynamic, text);
            Print.endRow(isDynamic, text);
            Print.startRow(isDynamic, text);
            Print.print("デッキ効果", isDynamic, Print.highSpeed, text);
            Print.separateRow(isDynamic, text);
            for(Card card : this.getCardToAddWithExecute().subList(0, (this.getCardToAddWithExecute().size() == 0 ? 0 : this.getCardToAddWithExecute().size() - 1))){
                Print.println(card.jName() + "をデッキに加える", isDynamic, Print.highSpeed, text);
                
            }
            Print.println("デッキをシャッフルし、その後" + this.getCardToAddWithExecute().get(this.getCardToAddWithExecute().size() - 1).jName() + "をデッキの一番上に加える", isDynamic, Print.highSpeed, text);
        }
        
        Print.endRow(isDynamic, text);
        Print.startRowDoubleHorizontal(isDynamic, text);
        Print.printHorizontalLine(isDynamic, text);
        Print.endRow(isDynamic, text);
        Print.startRow(isDynamic, text);
        Print.print("発売カード", isDynamic, Print.highSpeed, text);
        Print.separateRow(isDynamic, text);
        for(int i = 0; i < unlimits.size(); i++){
            Print.println(unlimits.get(i).jName, isDynamic, Print.highSpeed, text);
            
        }
        Print.endRow(isDynamic, text);
        Print.endTable(isDynamic, text);
        Print.endFrame(isDynamic, text);
        trainState.saveLocation(LocationCategory.explainCard, LocationCategory.FINISH);
    }

    // 簡略説明
    @Override
    public void miniExplain(TrainState trainState, List<TrainLimitation> unlimits, TimeFrame timeFrame, TrainStatus beforeMenu, boolean choiced, int choicedIdx, boolean isNew, TrainTemporaryLog log, boolean text, Random rand){
        Map<TrainStatus, Integer> exps;
        Map<TrainStatus, Integer> costs;
        double efficiency = 1;
        // double efficiency = self.getTrainStatus().get(TrainStatus.gasoline) / 100.0;
        // double efficiency = Math.pow(self.getTrainStatus().get(TrainStatus.motivation), 2) / 10000;
        String direction = "", chainTrainText = "", fixedGreatSuccessText = "";
        int nameLength = 25;
        int actNameLength = 11;
        int costLength = 10;
        String printText = "";
        int colorCount = 0;
        int costCount;
        int expCount;
        if(choiced){
            trainState = CardWithParams.getNextStateFromChoice(trainState, trainState, choicedIdx, log, rand).get(TrainResult.success);
        }else{
            trainState = CardWithParams.getNextStateFromChoice(trainState, trainState, log, rand).get(TrainResult.success);
        }
        if(this.cardSize != 1){
            nameLength += (this.cardSize - 1) * (nameLength + 1);
        }
        Color color = Color.white;
        if(choiced){
            color = Color.yellow;
        }else if(!getLegal(trainState, timeFrame, trainState.getMode())){
            color = Color.gray;
            if(this.spendActionNum == 2){
                timeFrame = TimeFrame.afternoon;
            }
        }
        if(color != Color.white) colorCount++;
        String nameText = levelName(trainState);
        for(boolean isGreat : new boolean[]{false}){
            costs = getRealCost(trainState, timeFrame, isGreat);
            costCount = 0;
            for(TrainStatus key: TrainStatus.values()){
                if(!costs.containsKey(key)){
                    continue;
                }
                if(costCount != 0){
                    printText += Print.space(1, text);
                }
                costCount++;
                if(key.color != Color.white) colorCount++;
                printText += key.shortName + ":";
                if(key == TrainStatus.hp){
                    if(costs.get(key) == 0){
                        printText += Print.format("--", 13);
                    }else if(isBiggerGreatCost(trainState, timeFrame)){
                        printText += Print.format(String.valueOf(getRealCost(trainState, timeFrame, true).get(key)) + "·" + String.valueOf(getRealCost(trainState, timeFrame, true).get(key)) + "↓", 13);
                    }else{
                        printText += Print.format(String.valueOf(costs.get(key)) + "·" + String.valueOf(getRealCost(trainState, timeFrame, true).get(key)) + "↓", 13);
                    }
                }else{
                    if(costs.get(key) == 0){
                        printText += Print.format("--", 5);
                    }else{
                        printText += Print.format(String.valueOf(costs.get(key)) + "↓", 5);
                    }
                }
            }
        }
        expCount = 0;
        exps = getRealExp(trainState, guts(trainState.getSelf()), timeFrame, trainState.getProvisionalBeforeTrainMenu());
        for(TrainStatus key: TrainStatus.values()){
            if(!exps.containsKey(key)){
                continue;
            }
            if(expCount != 0){
                printText += ", ";
            }else{
                printText += Print.space(1, text) + "→" + Print.space(2, text);
            }
            expCount++;
            if(beforeMenu == key && trainState.getTrainLimitations().get(TrainLimitation.sameTrain).get(TrainLimitationCounter.flag) == 1){
                chainTrainText = Color.blue.toColor("[同訓練チェイン! 効率 100%増加中!]") + Print.space(3, text);
                nameLength += 1;
            }
            StringBuilder sbExp = new StringBuilder();
            sbExp.append(String.valueOf(exps.get(key)));
            // if(key == TrainStatus.maxHp){
            //     sbExp.insert(sbExp.length() - 1, " ");
            // }
            printText += key.shortName + ":";
            printText += sbExp.toString() + "↑";
        }
        if(isBiggerGreatCost(trainState, timeFrame)){
            fixedGreatSuccessText += Color.blue.toColor("[確定大成功！]") + Print.space(3, text);
        }
        String unlimitText = "";
        if(unlimits.size() != 0){
            for(int i = 0; i < unlimits.size(); i++){
                unlimitText += "[" + unlimits.get(i).jName + "]";
                if(i != 0){
                    unlimitText += "と";
                }
            }
            unlimitText += "発売！";
            unlimitText = Color.blue.toColor(unlimitText);
        }
        boolean isFirstSubText = true;
        if(chainTrainText.length() != 0){
            if(isFirstSubText){
                isFirstSubText = false;
                Print.print(Print.space(1, text), Print.highSpeed, text);
            }else{
                Print.println("", Print.highSpeed, text);
                
                Print.print(Print.space(4, text), Print.highSpeed, text);
            }
            Print.print(chainTrainText, Print.highSpeed, text);
        }
        if(fixedGreatSuccessText.length() != 0){
            if(isFirstSubText){
                isFirstSubText = false;
                Print.print(Print.space(1, text), Print.highSpeed, text);
            }else{
                Print.println("", Print.highSpeed, text);
                
                Print.print(Print.space(4, text), Print.highSpeed, text);
            }
            Print.print(fixedGreatSuccessText, Print.highSpeed, text);
        }
        // if(unlimitText.length() != 0){
        //     if(isFirstSubText){
        //         isFirstSubText = false;
        //         Print.print(Print.space(1, text), Print.highSpeed, text);
        //     }else{
        //         Print.println("", Print.highSpeed, text);
                
        //         Print.print(Print.space(4, text), Print.highSpeed, text);
        //     }
        //     Print.print(unlimitText, Print.highSpeed, text);
        // }
        if(this.cardSize == 2){
            Print.startCardDoubleFlame(this.frameColor, false, text);
        }else{
            Print.startCardFlame(this.frameColor, false, text);
        }
        color.startColor(false, text);
        Print.print(nameText, Print.highSpeed, text);
        if(isNew){
            if(color == Color.white){
                Print.print(Print.space(2, text) + Color.whiteOrange.toColor("NEW！ "), Print.highSpeed, text);
            }else{
                Print.print(Print.space(2, text) + color.toColor("NEW！ "), Print.highSpeed, text);
            }
        }
        Print.println("", Print.highSpeed, text);
        
        // Print.println("", Print.highSpeed, text);
        Print.print(printText, Print.highSpeed, text);

        color.endColor(false, text);
        Print.endFrame(false, text);
        if(this.spendActionNum != 0){
            // Print.print(Print.toRed(Print.format("1ターン消費", actNameLength) + Print.format("", costLength)), Print.highSpeed, text);
        }
        // Print.println("", Print.highSpeed, text);
    }

    // 固有名
    @Override
    public String properName(){
        return "[" + this.trainMenuCategory.jName + "・" + this.trainMenuSize.jName + "]";
    }

    // カテゴリ名
    @Override
    public String categoryName(){
        return "訓練カード";
    }

    // 名前
    public String jName(){
        return "[" + this.trainMenuCategory.jName + "・" + this.trainMenuSize.jName + "]" + Print.space(2, true) + this.categoryName();
    }

    // 合法かどうか
    public boolean getLegal(TrainState trainState, TimeFrame timeFrame, Mode mode){
        Player self = trainState.getSelf();
        if(!this.ableTimeFrameList.contains(timeFrame)){
            return false;
        }else if(!TimeFrame.checkLegal(timeFrame, mode, this.spendActionNum)){
            return false;
        }else if(self.getElixirTurn() != 0){
            return true;
        }else{
            return true;
        }
        // }else if(costCategory.containsKey(TrainStatus.hp)){
        //     return costCategory.get(TrainStatus.hp) * Math.pow(battleCostCoef, self.getInnNum()) < self.getTrainStatus().get(TrainStatus.hp);
        // }else{
        //     return costCategory.get(TrainStatus.maxHp) * self.getTrainStatus().get(TrainStatus.maxHp) / 100 < self.getTrainStatus().get(TrainStatus.hp);
        // }
    }

    // 実行
    @Override
    public TrainState[] execute(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner, Random rand){
        switch(trainState.getSavedLocation(LocationCategory.executeCard)){
            case LocationCategory.NO_CHOICE:
                Player self = trainState.getSelf();
                boolean isGuts = false;
                // Print.println(this.jName() + "を使用した", true, Print.highSpeed, text);
                // double efficiency = self.getTrainStatus().get(TrainStatus.gasoline) / 100.0;
                // double efficiency = Math.pow(self.getTrainStatus().get(TrainStatus.motivation), 2) / 10000;
                // TrainResult result = isBiggerGreatCost(trainState, trainState.getTimeFrame()) ? TrainResult.greatSuccess : drawResult(self, rand);
                TrainResult result = trainState.getTrainResult();
                if(isBiggerGreatCost(trainState, trainState.getTimeFrame()) && result != TrainResult.fault){
                    result = TrainResult.greatSuccess;
                    trainState.addDefinitedGreatSuccessTrainMenu(this);
                }
                if(guts(self)){
                    trainState.addGutsTrainMenu(this);
                    isGuts = true;
                }
                if(result == TrainResult.fault){
                    trainState.saveLocation(LocationCategory.executeCard, LocationCategory.FINISH);
                    return new TrainState[]{trainState, beforeTrainState};
                }
                Map<TrainStatus, Integer> costs = getRealCost(trainState, trainState.getTimeFrame(), result == TrainResult.greatSuccess);
                for(TrainStatus key: costs.keySet()){
                    CalculateDamage.trainDamage(self, key, costs.get(key), false);
                }
                Map<TrainStatus, Integer> exps = getRealExp(trainState, isGuts, trainState.getTimeFrame(), trainState.getBeforeTrainMenu());
                for(TrainStatus key: exps.keySet()){
                    if(trainState.getBeforeTrainMenu() == key && trainState.getTrainLimitations().get(TrainLimitation.sameTrain).get(TrainLimitationCounter.flag) == 1){
                        trainState.setChainSameTrainNum(trainState.getChainSameTrainNum() + 1);
                    }else{
                        trainState.setChainSameTrainNum(0);
                    }
                    CalculateDamage.trainProgress(self, key, false, exps.get(key), false);
                }
                trainState.setSelf(self);
                trainState.saveLocation(LocationCategory.executeCard, LocationCategory.FINISH);
                return new TrainState[]{trainState, beforeTrainState};

            default:
                System.out.println("error train execute " + trainState.getSavedLocation(LocationCategory.executeCard));
                return new TrainState[]{trainState, beforeTrainState};
        }
    }

    // 訓練メニューの総数
    public static final int NUM = values().length;

    // カード全体の通し番号
    public int getOrdinalNumber(){
        return this.ordinal();
    }

    // 使用行動数
    public int getSpendActionNum(){
        return this.spendActionNum;
    };

    // カードの枠数
    public int getCardSize(){
        return this.cardSize;
    };

    // 解放時にデッキに追加する枚数
    public int unlimitAddToDeckNum(){
        return this.unlimitAddToDeckNum;
    };

    protected List<Card> getCardToAddWithExecute(){
        List<Card> cardToAddWithExecute;
        if(this == normalA){
            cardToAddWithExecute = new ArrayList<>(){{
                add(bigA);
            }};
        }else if(this == bigA){
            cardToAddWithExecute = new ArrayList<>(){{
                add(superA);
            }};
        }else if(this == superA){
            cardToAddWithExecute = new ArrayList<>(){{
                add(normalA);
                add(normalA);
            }};
        }else if(this == normalHp){
            cardToAddWithExecute = new ArrayList<>(){{
                add(bigHp);
            }};
        }else if(this == bigHp){
            cardToAddWithExecute = new ArrayList<>(){{
                add(superHp);
            }};
        }else if(this == superHp){
            cardToAddWithExecute = new ArrayList<>(){{
                add(normalHp);
                add(normalHp);
            }};
        }else if(this == normalS){
            cardToAddWithExecute = new ArrayList<>(){{
                add(bigS);
            }};
        }else if(this == bigS){
            cardToAddWithExecute = new ArrayList<>(){{
                add(superS);
            }};
        }else if(this == superS){
            cardToAddWithExecute = new ArrayList<>(){{
                add(normalS);
                add(normalS);
            }};
        }else if(this == mp){
            cardToAddWithExecute = new ArrayList<>(){{
                // add(mp);
            }};
        }else{
            cardToAddWithExecute = new ArrayList<>();
            System.out.println("error add card error");
        }
        return cardToAddWithExecute;
    }

    // 実行時にデッキにカードを追加する
    public void addCardToDeckWithExecute(TrainState trainState, boolean text){
        trainState.saveAddCard(getCardToAddWithExecute(), shuffleModeWithAddCard.BeforeLast);
    }

    // 制限されていない訓練メニューの配列
    public static TrainMenu[] generalValues(TrainState trainState){
        return new ArrayList<TrainMenu>(){{
            add(normalA);
            add(normalHp);
            add(normalS);
            for(TrainMenu key : new TrainMenu[]{bigA, bigHp, bigS, superA, superHp, superS, mp}){
                if(trainState.getTrainLimitations().get(TrainLimitation.valueOf(key.name())).get(TrainLimitationCounter.flag) == 1){
                    add(key);
                }
            }
        }}.toArray(new TrainMenu[0]);
    }

    public static boolean guts(Player self){
        return self.getTrainStatus().get(TrainStatus.hp) <= self.getTrainStatus().get(TrainStatus.maxHp) / 3 && !self.getNoCostStatus().contains(TrainStatus.hp);
    }
    
    public enum TrainResult{
        fault("失敗", Color.purple),
        success("成功", Color.yellow),
        greatSuccess("大成功", Color.red),
        ;
        public String jName;
        public Color color;
        private TrainResult(String jName, Color color){
            this.jName = jName;
            this.color = color;
        }
    }
    // 強化の成功判定
    public static TrainResult drawResult(Player self, Random rand){
        int oil = self.getTrainStatus().get(TrainStatus.concentration);
        if(oil < 100){
            if(rand.nextInt(100) < oil){
                return TrainResult.success;
            }else{
                return TrainResult.fault;
            }
        }else{
            if(rand.nextInt(100) < oil - 100){
                return TrainResult.greatSuccess;
            }else{
                return TrainResult.success;
            }
        }
    }
    // 訓練レベルによる能力増加効果量
    public double levelBuff(TrainState state){
        return CalculateDamage.clearFourthRootOfTwo(state.trainCategoryLevel.get(this.trainMenuCategory) - 1);
    }
    // メニューを指定してレベルアップ
    public static void levelUp(TrainState state, TrainMenuCategory menu, int upLevel, boolean isWithStar, boolean text){
        state.trainCategoryLevel.replace(menu, state.trainCategoryLevel.get(menu) + upLevel);
        String startText = isWithStar ? "" : "";
        Print.println(startText + menu.jName + "訓練のレベルが " + upLevel + " 増加した" + startText, true, Print.highSpeed, text);
        
    }
    // // 列数を指定してレベルアップ
    // public static void levelUpWithColumnOrRow(TrainState state, int num, boolean text, Random rand){
    //     for(int i = 0; i < num; i++){
    //         TrainMenu.levelUp(state, TrainMenuCategory.values()[rand.nextInt(3)], 1, text);
    //     }
    // }
    // // 行ごとの訓練メニュー
    // public static List<List<TrainMenu>> rowTrainMenus(){
    //     return new ArrayList<>(){{
    //         add(new ArrayList<>(){{
    //             add(normalHp);
    //             add(normalS);
    //             add(normalA);
    //         }});
    //         add(new ArrayList<>(){{
    //             add(bigHp);
    //             add(bigS);
    //             add(bigA);
    //         }});
    //         add(new ArrayList<>(){{
    //             add(superHp);
    //             add(superS);
    //             add(superA);
    //         }});
    //     }};
    // }
    // // 列ごとの訓練メニュー
    // public static List<List<TrainMenu>> colmunTrainMenus(){
    //     return new ArrayList<>(){{
    //         add(new ArrayList<>(){{
    //             add(normalHp);
    //             add(bigHp);
    //             add(superHp);
    //         }});
    //         add(new ArrayList<>(){{
    //             add(normalS);
    //             add(bigS);
    //             add(superS);
    //         }});
    //         add(new ArrayList<>(){{
    //             add(normalA);
    //             add(bigA);
    //             add(superA);
    //         }});
    //     }};
    // }
    // レベル付き名前
    public String levelName(TrainState state){
        return "[" + this.trainMenuCategory.jName + " Lv" + state.trainCategoryLevel.get(this.trainMenuCategory) + "・" + this.trainMenuSize.jName + "]" + Print.space(2, true) + this.categoryName();
    }
}
