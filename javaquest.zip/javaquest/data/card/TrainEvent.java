package data.card;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import battle.CalculateDamage;
import character.Player;
import character.Player.TrainStatus;
import game.LocationCategory;
import limitation.TrainLimitation;
import limitation.TrainLimitation.TrainLimitationCounter;
import log.TrainTemporaryLog;
import text.Print;
import text.Print.Color;
import train.Train;
import train.TrainState;
import train.TrainState.Mode;
import train.TrainState.TimeFrame;
import train.TrainState.shuffleModeWithAddCard;

//itemをbattleItemに変更する必要がある
public enum TrainEvent implements Card{
    labHP("[肉体改造ラボ]", 
        2,// 使用行動数
        2,// 枠の大きさ
        0,// 解放時にデッキに追加する枚数
        new ArrayList<Card>(){{
            
        }},
        "HPが残り1になる",
        "肉体",
        TrainStatus.hp,
        new ArrayList<TimeFrame>(){{
            add(TimeFrame.morning);
            add(TimeFrame.afternoon);
            add(TimeFrame.night);
        }}),
    labCon("[精神改造ラボ]", 
        2,// 使用行動数
        2,// 枠の大きさ
        0,// 解放時にデッキに追加する枚数
        new ArrayList<Card>(){{
            
        }},
        "集中力を全て消費する",
        "精神",
        TrainStatus.concentration,
        new ArrayList<TimeFrame>(){{
            add(TimeFrame.morning);
            add(TimeFrame.afternoon);
            add(TimeFrame.night);
        }}),
    labMoti("[感情改造ラボ]", 
        2,// 使用行動数
        2,// 枠の大きさ
        0,// 解放時にデッキに追加する枚数
        new ArrayList<Card>(){{
            
        }},
        "やる気を全て消費する",
        "感情",
        TrainStatus.motivation,
        new ArrayList<TimeFrame>(){{
            add(TimeFrame.morning);
            add(TimeFrame.afternoon);
            add(TimeFrame.night);
        }}),
    ;   

    //フィールド
    public final String properName;
    public final int spendActionNum;
    public final int cardSize;
    public final int unlimitAddToDeckNum;
    public final List<Card> cardToAddWithExecute;// 実行時にデッキに追加するカード
    public final String explain;
    public final String modificationName;// 改造するモノの名前
    public final TrainStatus noCostStatus;// コスト消費を0にするステータス
    public final List<TimeFrame> ableTimeFrameList;
    //コンストラクタ
    private TrainEvent(String properName, int spendActionNum, int cardSize, int unlimitAddToDeckNum, List<Card> cardToAddWithExecute, String explain, String modificationName, TrainStatus noCostStatus, List<TimeFrame> ableTimeFrameList){
        this.properName = properName;
        this.spendActionNum = spendActionNum;
        this.cardSize = cardSize;
        this.unlimitAddToDeckNum = unlimitAddToDeckNum;
        this.cardToAddWithExecute = cardToAddWithExecute;
        this.explain = explain;
        this.modificationName = modificationName;
        this.noCostStatus = noCostStatus;
        this.ableTimeFrameList = ableTimeFrameList;
    }


    public boolean getLegal(TrainState trainState, TimeFrame timeFrame, Mode mode){
        if(!TimeFrame.checkLegal(timeFrame, mode, this.spendActionNum)){
            return false;
        }
        if(!this.ableTimeFrameList.contains(timeFrame)){
            return false;
        }
        return true;
    }

    //処理メソッド
    @Override
    public TrainState[] execute(TrainState trainState, TrainState beforeTrainState, TrainTemporaryLog log, boolean text, Scanner scanner, Random rand){
        switch(trainState.getSavedLocation(LocationCategory.executeCard)){
            case LocationCategory.NO_CHOICE:

                Player self = trainState.getSelf();
    
                // 実行
                Print.println(this.modificationName + "を改造した", true, Print.middleSpeed, text);
                Print.nextLine(scanner, text);
    
                // コスト
                int damage = self.getTrainStatus().get(this.noCostStatus);
                if(this.noCostStatus == TrainStatus.hp){
                    damage -= 1;
                }
                // CalculateDamage.trainDamage(self, TrainStatus.hp, self.getTrainStatus().get(TrainStatus.hp) - 1, text);
                // CalculateDamage.trainDamage(self, TrainStatus.concentration, self.getTrainStatus().get(TrainStatus.concentration), text);
                // CalculateDamage.trainDamage(self, TrainStatus.motivation, self.getTrainStatus().get(TrainStatus.motivation), text);
                CalculateDamage.trainDamage(self, this.noCostStatus, damage, text);
                Print.nextLine(scanner, text);
    
                Print.println(this.noCostStatus.jName + "が消費されなくなった", true, Print.middleSpeed, text);
                Print.nextLine(scanner, text);

                trainState.labPastJump(text);
    
                self.addNoCostStatus(this.noCostStatus);
                trainState.setSelf(self);
                trainState.saveLocation(LocationCategory.executeCard, LocationCategory.FINISH);
                return new TrainState[]{trainState, beforeTrainState};

            default:
                System.out.println("error lab execute");
                return new TrainState[]{trainState, beforeTrainState};
        }
    }

    // 詳細説明
    @Override
    public void explain(TrainState trainState, List<TrainLimitation> unlimits, TimeFrame timeFrame, boolean text, Scanner scanner){
        boolean isDynamic = false;
        Print.startFrame(isDynamic, text);
        Print.println(this.jName(), isDynamic, Print.highSpeed, text);
        Print.println("", isDynamic, Print.highSpeed, text);
        
        Print.println(this.explain, isDynamic, Print.highSpeed, text);
        
        Print.println("全ての訓練での" + this.noCostStatus.jName + "の消費が無くなる", isDynamic, Print.highSpeed, text);
        Print.println("日付を 1日 巻き戻す", isDynamic, Print.highSpeed, text);
        
        if(this.cardToAddWithExecute.size() != 0){
            Print.println("デッキに追加するカードは", isDynamic, Print.highSpeed, text);
            
            for(Card card : this.cardToAddWithExecute){
                Print.println(card.jName(), isDynamic, Print.highSpeed, text);
                
            }
        }
        if(unlimits.size() != 0){
            Print.print("ショップに", isDynamic, Print.highSpeed, text);
            for(int i = 0; i < unlimits.size(); i++){
                Print.print(Print.space(2, text) + unlimits.get(i).jName, isDynamic, Print.highSpeed, text);
                if(i != 0){
                    Print.print("と", isDynamic, Print.highSpeed, text);
                }
            }
            Print.println("が追加されます", isDynamic, Print.highSpeed, text);
            
        }
        Print.endFrame(isDynamic, text);
        trainState.saveLocation(LocationCategory.explainCard, LocationCategory.FINISH);
    }

    // 短縮説明
    @Override
    public void miniExplain(TrainState trainState, List<TrainLimitation> unlimits, TimeFrame timeFrame, TrainStatus beforeMenu, boolean choiced, int choicedIdx, boolean isNew, TrainTemporaryLog log, boolean text, Random rand){
        int nameLength = 24;
        Color color = Color.white;
        if(choiced){
            color = Color.yellow;
        }else if(!getLegal(trainState, timeFrame, trainState.getMode())){
            color = Color.gray;
        }
        String printText = this.jName();
        if(this.getCardSize() == 1){
            Print.startCardFlame(Color.whiteGreen, false, text);
        }else{
            Print.startCardDoubleFlame(Color.whiteGreen, false, text);
        }
        color.startColor(false, text);
        Print.print(Print.format(printText, nameLength), Print.highSpeed, text);
        if(isNew){
            if(color == Color.white){
                Print.print(Print.space(2, text) + Color.whiteOrange.toColor("NEW！ "), Print.highSpeed, text);
            }else{
                Print.print(Print.space(2, text) + color.toColor("NEW！ "), Print.highSpeed, text);
            }
        }
        if(unlimits.size() != 0){
            Print.print(Print.space(2, text) + "[", Print.highSpeed, text);
        }
        for(int i = 0; i < unlimits.size(); i++){
            Print.print(unlimits.get(i).jName, Print.highSpeed, text);
            if(i != 0){
                Print.print("と", Print.highSpeed, text);
            }
        }
        if(unlimits.size() != 0){
            Print.print("が販売解禁！]", Print.highSpeed, text);
        }
        // Print.print(this.explain, Print.highSpeed, text);
        color.endColor(false, text);
        Print.endFrame(false, text);
    }

    // 固有名
    @Override
    public String properName(){
        return this.properName;
    }

    // カテゴリ名
    @Override
    public String categoryName(){
        return "ラボカード";
    }

    // 名前
    public String jName(){
        return this.properName() + Print.space(2, true) + this.categoryName();
    }

    // イベントの総数
    public static final int NUM = values().length;

    // カード全体の通し番号
    public int getOrdinalNumber(){
        return TrainMenu.NUM + RestMenu.NUM + this.ordinal();
    }

    // 使用行動数
    public int getSpendActionNum(){
        return this.spendActionNum;
    };

    // カードの枠数
    public int getCardSize(){
        return this.cardSize;
    };

    // 解放時にデッキに追加する枚数
    public int unlimitAddToDeckNum(){
        return this.unlimitAddToDeckNum;
    };

    // 実行時にデッキにカードを追加する
    public void addCardToDeckWithExecute(TrainState trainState, boolean text){
        trainState.saveAddCard(this.cardToAddWithExecute, shuffleModeWithAddCard.BeforeLast);
    }

    // // 制限されていないイベントの配列
    // public static TrainEvent[] generalValues(TrainState trainState){
    //     return new ArrayList<TrainEvent>(){{
    //         // if(trainState.getTrainLimitations().get(TrainLimitation.shineShop).get(TrainLimitationCounter.flag) == 1){
    //         //     add(SpellShop);
    //         // }
    //         if(trainState.getTrainLimitations().get(TrainLimitation.bodyModification).get(TrainLimitationCounter.flag) == 1){
    //             add(lab);
    //         }
    //     }}.toArray(new TrainEvent[0]);
    // }
}
