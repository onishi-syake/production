package character;

import java.util.ArrayList;
import java.util.List;

import character.Player.TrainStatus;
import data.card.RestMenu;
import data.card.TrainEvent;
import data.card.TrainMenu;
import limitation.TrainLimitation;
import text.Print;
import train.Train;
import train.TrainState;
import train.TrainState.Mode;

public enum Skill{
    zeroInn("0 番宿屋",
    "選択肢の 0 番目に宿屋が追加される"){
        @Override
        public boolean useAble(Player self){
            return true;
        }
    },
    // guts("根性",
    // "HPが半分以下での強化時に経験値が2倍になる"
    // ){
    //     @Override
    //     public boolean useAble(Player self){
    //         return self.getTrainStatus().get(TrainStatus.hp) <= self.getTrainStatus().get(TrainStatus.maxHp) / 2;
    //     }
    // },
    // spellTaker("呪文テイカー",
    // "戦闘後、相手が最後に使った呪文を奪う"
    // ){
    //     @Override
    //     public boolean useAble(Player self){
    //         return true;
    //     }
    // },
    // TODO 戦闘薬無料に変更
    trader("トレーダー",
    "商品の価格が安くなる"
    ){
        @Override
        public boolean useAble(Player self){
            return true;
        }
    },
    // prophet("未来予知",//戦闘する敵は見えない（総合力で敵を決める所為で事前に把握できない）
    // "将来の行動を知ることが出来る"
    // ){
    //     @Override
    //     public boolean useAble(Player self) {
    //         return true;
    //     }
    //     @Override
    //     public void infomation(TrainState trainState, boolean text) {
    //         super.infomation(trainState, text);
    //         int count = 0;
    //         for(int idx : trainState.getTrainMenus()[trainState.getTurn()]){
    //             if(count % 5 == 0){
    //                 Print.println("", 0, text);
    //             }
    //             Print.print((count + 1) + ":", Print.highSpeed, text);
    //             count++;
    //             if (idx < TrainMenu.generalNUM(trainState)) {
    //                 Print.print(TrainMenu.generalValues(trainState)[idx].jName, Print.highSpeed, text);
    //             } else if (idx < TrainMenu.generalNUM(trainState) + RestMenu.generalNUM(trainState)) {
    //                 Print.print(RestMenu.generalValues(trainState)[idx - TrainMenu.generalNUM(trainState)].jName, Print.highSpeed, text);
    //             } else if(idx < TrainMenu.generalNUM(trainState) + RestMenu.generalNUM(trainState) + TrainEvent.generalNUM(trainState)) {
    //                 Print.print(TrainEvent.values()[idx - TrainMenu.generalNUM(trainState) - RestMenu.generalNUM(trainState)].jName, Print.highSpeed, text);
    //             } else if(idx < TrainMenu.generalNUM(trainState) + RestMenu.generalNUM(trainState) + TrainEvent.generalNUM(trainState) + (TrainLimitation.battle.useAble() ? 1 : 0)){
    //                 Print.print("ギルド", Print.highSpeed, text);
    //             }
    //             Print.print("    ", Print.highSpeed, text);
    //         }
    //         Print.println("", 0, text);
    //     }
    // },
    // TODO 消滅
    longevity("長寿",
    "ゲームの終了ターンが伸びる"){
        @Override
        public boolean useAble(Player self) {
            return true;
        }
    },
    // TODO 消滅
    KJA("KJA",
    "最凶のギャンブル呪文「KJA」を習得した状態でゲームを開始する。また、毎ターンギャンブルイベントが発生する"){
        @Override
        public boolean useAble(Player self) {
            return true;
        }
    },
    NULL("スキルなし",
    "スキルなし"){
        @Override
        public boolean useAble(Player self){
            return false;
        }
    }
    ;
    public final String jName;
    public final String explain;
    private Skill(String jName, String explain){
        this.jName = jName;
        this.explain = explain;
    }

    // 発動中かどうか
    public abstract boolean useAble(Player self);

    // 情報表示
    public void infomation(TrainState trainState, boolean text){
        Print.println(jName, Print.middleSpeed, text);
        Print.println(explain, Print.middleSpeed, text);
    }

    // 使えるスキルリスト
    public static List<Skill> skillList(Mode mode){
        return new ArrayList<Skill>(){{
            this.add(Skill.zeroInn);
            // if(TrainLimitation.guts.useAble(mode)){
            //     this.add(Skill.guts);
            // }
            // if(TrainLimitation.spellTaker.useAble(mode)){
            //     this.add(Skill.spellTaker);
            // }
            if(TrainLimitation.trader.useAble(mode)){
                this.add(Skill.trader);
            }
            // if(TrainLimitation.prophet.useAble(mode)){
            //     this.add(Skill.prophet);
            // }
            if(TrainLimitation.longevity.useAble(mode)){
                this.add(Skill.longevity);
            }
            if(TrainLimitation.KJA.useAble(mode)){
                this.add(Skill.KJA);
            }
        }};
    }
}
