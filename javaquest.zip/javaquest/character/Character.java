package character;

import java.util.Random;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.EnumMap;
import java.util.HashMap;

import battle.state_change.ChangeAbnormalState;
import battle.state_change.ChangeActionState;
import battle.state_change.ChangeBattleStatus;
import battle.state_change.ChangeAbnormalState.AbnormalState;
import battle.state_change.ChangeAbnormalState.AbnormalStateCounter;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import battle.state_change.ChangeActionState.UpdateBackup;
import battle.state_change.ChangeBattleStatus.StateChangeStatus;
import battle.state_change.ChangeBattleStatus.StatusCounter;
import battle.state_change.ChangeField.Field;
import battle.state_change.ChangeField.FieldCounter;
import battle.state_change.ChangeWeather.Weather;
import battle.Battle;
import battle.ExecuteAction;
import battle.InputAction;
import battle.State;
import data.action.Special;
import data.action.Spell;
import data.item.BattleItem;
import game.LocationCategory;
import limitation.TrainLimitation;
import text.Print.Color;

public abstract class Character implements Serializable {

    private String jName;// 名前
    public Color nameColor;// 名前の色
    //属性
    private Attribute attribute;
    public enum Attribute{
        A("スペシャルアタック", "攻"), 
        D("カウンターシールド", "防"), 
        C("フルチャージ", "複"), 
        Null("必殺技なし", "無"), 
        ;
        public final String jName;// 必殺技名
        public final String jNameShort;// 短縮名
        private Attribute(String jName, String jNameShort){
            this.jName = jName;
            this.jNameShort = jNameShort;
        }
        // 自分にとっての不利属性を返す
        public Attribute disadvantage(){
            if(this == A){
                return D;
            }
            if(this == D){
                return C;
            }
            if(this == C){
                return A;
            }
            return Null;
        }
        // 自分にとっての有利属性を返す
        public Attribute advantage(){
            if(this == A){
                return C;
            }
            if(this == D){
                return A;
            }
            if(this == C){
                return D;
            }
            return Null;
        }
        // ランダムに属性決定
        public static Attribute randomAttribute(Random rand){
            double category = rand.nextDouble();
            if(category < 1.0 / 3){
                return Attribute.A;
            }else if(category < 2.0 / 3){
                return Attribute.D;
            }else{
                return Attribute.C;
            }
        }
    }
    private int spellSlotNum;//戦闘中に使える呪文の数
    private boolean useSpecial;//必殺技を使えるかどうか
    public final boolean useEscape;// 逃げれるかどうか
    private boolean isDamaged;// 戦闘中にダメージを1度でも食らったかどうか
    private Spell tempSpell;// 使用呪文の一時保存
    //メインステータス
    private Map<MainStatus, Integer> mainStatus = new EnumMap<>(MainStatus.class);
    public enum MainStatus{
        hp("HP", "H"),
        maxHp("最大HP", "最H"),
        mp("MP", "M"),
        maxMp("最大MP", "最M"),
        a("攻撃力", "攻"),
        d("防御力", "防"),
        e("回避率(%)", "避"),
        s("素早さ", "素"),
        aNum("攻撃回数", "攻数"),
        ;
        public final String jName;
        public final String shortName;
        private MainStatus(String name, String shortName){
            this.jName = name;
            this.shortName = shortName;
        }
        public static final int NUM = values().length;
    }
    //バトルステータス
    private Map<BattleStatus, Integer> battleStatus = new EnumMap<>(BattleStatus.class);
    public enum BattleStatus{
        a(MainStatus.a),
        s(MainStatus.s),
        d(MainStatus.d),
        ;
        public final MainStatus status;
        public final String jName;
        private BattleStatus(MainStatus status){
            this.status = status;
            this.jName = status.jName;
        }
    }
    //戦闘のステータス変化
    private List<Map<StateChangeStatus, Map<StatusCounter, Double>>> stateChangeStatus = new ArrayList<>();
    //状態異常
    private Map<AbnormalState, Map<AbnormalStateCounter, Integer>> stateAbnormal = new EnumMap<>(AbnormalState.class);
    // 呪文「アップデート」で保存するバックアップ
    private UpdateBackup updateBackup;
    //防御、溜めるなど戦闘中の特殊な状態
    private Map<ActionState, Map<ActionStateCounter, Integer>> stateAction = new EnumMap<>(ActionState.class);
    //覚えている呪文の名前とレベル
    private Map<Spell, Integer> spellLevel;
    private List<Spell> spellSlot = new ArrayList<>();//戦闘中に使える呪文の名前リスト
    //アイテムスロットの数
    private int itemSlotNum;
    //持っているアイテムと個数
    private Map<BattleItem, Integer> itemList = new EnumMap<>(BattleItem.class);
    // 即時使用されるアイテム
    public BattleItem passiveItem;
    // 初回の強制行動
    private int firstAction;
    // 重み付き優先行動
    private Map<Integer, Integer> biasedActions;
    // 初期状態異常なし
    private boolean nonInitialNervous;
    //前回の行動
    private int lastAction;
    // 前々回の行動
    private int secondLastAction;

    // for state
    private Map<LocationCategory, Integer> savedAction;
    private int nextAction;

    // //メインコンストラクタ
    // Character(String name, Attribute attribute, int spellSlotNum, boolean useSpecial, boolean useEscape, Map<MainStatus, Integer> mainStatus, Map<BattleStatus, Integer> battleStatus, List<Map<StateChangeStatus, Map<StatusCounter, Integer>>> stateChangeStatus, Map<AbnormalState, Map<AbnormalStateCounter, Integer>> stateAbnormal, UpdateBackup updateBackup, Map<ActionState, Map<ActionStateCounter, Integer>> stateAction, Map<Spell, Integer>spellLevel, List<Spell> spellSlot, int itemSlotNum, Map<BattleItem, Integer> itemList, BattleItem passiveItem, int firstAction, Map<Integer, Integer> biasedActions, boolean nonInitialNervous, int lastAction, int secondLastAction, Map<LocationCategory, Integer> savedAction){
    //     this.jName = name;
    //     this.attribute = attribute;
    //     this.spellSlotNum = spellSlotNum;
    //     this.useSpecial = useSpecial;
    //     this.useEscape = useEscape;
    //     this.mainStatus = mainStatus;
    //     this.battleStatus = battleStatus;
    //     this.stateChangeStatus = stateChangeStatus;
    //     this.stateAbnormal = stateAbnormal;
    //     this.updateBackup = updateBackup;
    //     this.stateAction = stateAction;
    //     this.spellLevel = spellLevel;
    //     this.spellSlot = spellSlot;
    //     this.itemSlotNum = itemSlotNum;
    //     this.itemList = itemList;
    //     this.passiveItem = passiveItem;
    //     this.firstAction = firstAction;
    //     this.biasedActions = biasedActions;
    //     this.nonInitialNervous = nonInitialNervous;
    //     this.lastAction = lastAction;
    //     this.secondLastAction = secondLastAction;
    //     this.savedAction = savedAction;
    // }

    // コピーコンストラクタ
    Character(Character chara){
        this.jName = chara.jName;
        this.nameColor = chara.nameColor;
        this.attribute = chara.attribute;
        this.spellSlotNum = chara.spellSlotNum;
        this.useSpecial = chara.useSpecial;
        this.useEscape = chara.useEscape;
        this.isDamaged = chara.isDamaged;
        this.tempSpell = chara.tempSpell;
        this.mainStatus = new EnumMap<>(chara.mainStatus);
        this.battleStatus = new EnumMap<>(chara.battleStatus);
        this.stateChangeStatus = ChangeBattleStatus.deepCopyStateChangeStatus(chara.stateChangeStatus);
        for(AbnormalState key : AbnormalState.values()){
            this.stateAbnormal.put(key, new EnumMap<>(chara.stateAbnormal.get(key)));
        }
        this.updateBackup = chara.updateBackup != null ? new ChangeActionState().new UpdateBackup(chara.updateBackup) : null;
        for(ActionState key : ActionState.values()){
            this.stateAction.put(key, new EnumMap<>(chara.stateAction.get(key)));
        }
        this.spellLevel = new EnumMap<>(chara.spellLevel);
        this.spellSlot = new ArrayList<>(chara.spellSlot);
        this.itemSlotNum = chara.itemSlotNum;
        this.itemList = new EnumMap<>(chara.itemList);
        this.passiveItem = chara.passiveItem;
        this.firstAction = chara.firstAction;
        this.biasedActions = chara.biasedActions != null ? new HashMap<>(chara.biasedActions) : null;
        this.nonInitialNervous = chara.nonInitialNervous;
        this.lastAction = chara.lastAction;
        this.secondLastAction = chara.secondLastAction;
        this.savedAction = new HashMap<>(chara.savedAction);
    }

    //初期状態の生成コンストラクタ(初手強制行動指定、バイアス付き行動指定、状態異常無効指定)
    Character(String name, Color nameColor, Attribute attribute, int spellSlotNum, boolean useSpecial, boolean useEscape, int[] mainStatus, Map<Spell, Integer> spellLevel, BattleItem passiveItem, int firstAction, Map<Integer, Integer> biasedActions, boolean nonInitialNervous, List<Map<StateChangeStatus, Map<StatusCounter, Double>>> stateChangeStatus){
        this.jName = name;
        this.nameColor = nameColor;
        this.attribute = attribute;
        this.spellSlotNum = spellSlotNum;
        this.useSpecial = useSpecial;
        this.useEscape = useEscape;
        this.isDamaged = false;
        this.tempSpell = Spell.NULL;
        MainStatus[] keys = MainStatus.values();
        for(int i = 0; i < keys.length; i++){
            this.mainStatus.put(keys[i], mainStatus[i]);
        }

        this.nonInitialNervous = nonInitialNervous;
        this.endBattle();
        this.stateChangeStatus = ChangeBattleStatus.deepCopyStateChangeStatus(stateChangeStatus);
        ChangeBattleStatus.execute(this);


        this.updateBackup = null;
        this.spellLevel = new EnumMap<Spell, Integer>(Spell.class){{
            for(Spell spell : Spell.values()){
                put(spell, 0);
            }
        }};
        for(Spell spell : spellLevel.keySet()){
            this.spellLevel.replace(spell, spellLevel.get(spell));
        }

        this.spellSlot = new ArrayList<>(){{
            for(int i = 0; i < spellSlotNum; i++){
                add(Spell.NULL);
            }
        }};

        this.itemSlotNum = 2;
        for(BattleItem key : BattleItem.values()){
            if(key == BattleItem.None){
                this.itemList.put(key, this.itemSlotNum);
                continue;
            }
            this.itemList.put(key,0);
        }
        this.passiveItem = passiveItem;
        this.firstAction = firstAction;
        this.biasedActions = biasedActions;
        this.lastAction = -1;
        this.secondLastAction = -1;
        this.savedAction = new HashMap<>(){{
            for(LocationCategory act : LocationCategory.values()){
                put(act, LocationCategory.NO_CHOICE);
            }
        }};
    }
    //初期状態の生成コンストラクタ
    Character(String name, Color nameColor, Attribute attribute, int spellSlotNum, boolean useSpecial, boolean useEscape, int[] mainStatus, Map<Spell, Integer> spellLevel, BattleItem passiveItem){
        this(name, nameColor, attribute, spellSlotNum, useSpecial, useEscape, mainStatus, spellLevel, passiveItem, -1, new HashMap<>(), false, new ArrayList<>());
    }



    // 変更可能コピー
    public abstract Character modifiableCopy();
    // 変更不能コピー
    public abstract Character unmodifiableCopy();
    // ？
    public CharacterForAI forAI(){
        return new CharacterForAI(this);
    }

    //バトルの開始。戦闘ステータスを用意する。
    public void readyBattleState(){
        for(BattleStatus key : BattleStatus.values()){
            this.battleStatus.put(key, this.getMainStatus().get(MainStatus.valueOf(key.name())));
        }
    }

    //各種戦闘用フィールドの初期化
    private void readyBattleField(){
        this.stateChangeStatus = new ArrayList<>();
        this.stateAbnormal = ChangeAbnormalState.initializedAbnormalStateMap();
        if(this.nonInitialNervous){
            this.stateAbnormal.get(AbnormalState.Nervous).replace(AbnormalStateCounter.flag, 0);
            this.stateAbnormal.get(AbnormalState.Nervous).replace(AbnormalStateCounter.count, 0);
        }
        this.stateAction = ChangeActionState.initializedActionStateMap();
        if(this.spellSlot.size() > this.spellSlotNum){
            for(int i = 0; i < this.spellSlot.size() - this.spellSlotNum; i++){
                this.spellSlot.remove(this.spellSlotNum);
            }
        }
        if(this.spellSlot.size() < this.spellSlotNum){
            for(int i = 0; i < this.spellSlotNum - this.spellSlot.size(); i++){
                this.spellSlot.add(Spell.NULL);
            }
        }
        this.lastAction = -1;
        this.secondLastAction = -1;
        this.isDamaged = false;
        this.tempSpell = Spell.NULL;
    }

    //バトルの終了。戦闘ステータスを消し飛ばす。
    public void endBattle(){
        this.readyBattleState();
        this.readyBattleField();
    }

    // 総合力の算出（最大HPか現在HPかを選択可能）
    public int generalPower(Boolean useMaxHp){
        double pow = 1.0;
        Map<MainStatus, Integer> state = this.getMainStatus();
        pow *= state.get(MainStatus.a) * (1.0 - 0.4 * Math.pow(0.7, this.getSpellArray().length));
        // pow *= state.get(MainStatus.aNum);
        // pow *= 100.0 / (double)(100-state.get(MainStatus.e));
        pow *= Math.sqrt(state.get(MainStatus.d) / 100.0);
        pow *= state.get(MainStatus.s);
        pow *= state.get(useMaxHp ? MainStatus.maxHp : MainStatus.hp) * (1.0 - 0.4 * Math.pow(0.7, this.getSpellArray().length));
        pow *= Math.pow(state.get(MainStatus.maxMp), 0.5);
        pow *= useSpecial ? 2.0 : 1.0;
        return (int)(pow / 100000.0);
    }

    //ゲッター、セッター群

    public String getJName(){
        return this.jName;
    }

    public void setJName(String jName){
        this.jName = jName;
    }

    public String getColorJName(){
        return this.nameColor.toColor(this.jName);
    }

    public Attribute getAttribute(){
        return this.attribute;
    }

    public void setAttribute(Attribute attribute){
        this.attribute = attribute;
    }

    public int getSpellSlotNum(){
        return this.spellSlotNum;
    }

    public void setSpellSlotNum(int spellSlotNum){
        this.spellSlotNum = spellSlotNum;
    }

    public boolean getUseSpecial(){
        return this.useSpecial;
    }

    public void setUseSpecial(Boolean useSpecial){
        this.useSpecial = useSpecial;
    }

    public boolean getIsDamaged(){
        return this.isDamaged;
    }

    public void damaged(){
        this.isDamaged = true;
    }

    public Spell getTempSpell(){
        return this.tempSpell;
    }

    public void setTempSpell(Spell spell){
        this.tempSpell = spell;
    }

    public Map<MainStatus, Integer> getMainStatus(){
        return new EnumMap<>(this.mainStatus);
    }

    public void setMainStatus(Map<MainStatus, Integer> mainStatus){
        this.mainStatus = mainStatus;
    }

    public Map<BattleStatus, Integer> getBattleStatus(){
        return this.battleStatus;
    }

    public void setBattleStatus(Map<BattleStatus, Integer> battleStatus){
        this.battleStatus = battleStatus;
    }

    public List<Map<StateChangeStatus, Map<StatusCounter, Double>>> getStateChangeStatus(){
        return this.stateChangeStatus;
    }

    public void setStateChangeStatus(List<Map<StateChangeStatus, Map<StatusCounter, Double>>> stateChangeStatus){
        this.stateChangeStatus = stateChangeStatus;
    }

    public Map<AbnormalState, Map<AbnormalStateCounter, Integer>> getStateAbnormal(){
        return this.stateAbnormal;
    }

    public void setStateAbnormal(Map<AbnormalState, Map<AbnormalStateCounter, Integer>> stateAbnormal){
        this.stateAbnormal = stateAbnormal;
    }

    public UpdateBackup getUpdateBackup(){
        return this.updateBackup;
    }

    public void setUpdateBackup(UpdateBackup updateBackup){
        this.updateBackup = updateBackup;
    }

    public Map<ActionState, Map<ActionStateCounter, Integer>> getStateAction(){
        return this.stateAction;
    }

    public void setStateAction(Map<ActionState, Map<ActionStateCounter, Integer>> stateAction){
        this.stateAction = stateAction;
    }

    public Map<Spell, Integer> getSpellLevel(){
        return this.spellLevel;
    }
    
    public void getNextAction(int action){
        this.nextAction = action;
    }

    public int takeNextAction(){
        int temp = this.nextAction;
        this.nextAction = LocationCategory.NO_CHOICE;
        return temp;
    }

    public void saveLocation(LocationCategory category, Integer location){
        this.savedAction.replace(category, location);
    }
    
    public int getSavedLocation(LocationCategory category){
        return this.savedAction.get(category);
    }

    // 覚えている呪文のみを返す
    public Map<Spell, Integer> getLearnedSpellLevel(){
        Map<Spell, Integer> learnedSpellLevel = new EnumMap<>(Spell.class);
        for(Spell spell : this.spellLevel.keySet()){
            if(this.spellLevel.get(spell) != 0){
                learnedSpellLevel.put(spell, this.spellLevel.get(spell));
            }
        }
        return learnedSpellLevel;
    }

    public void setSpellLevel(Map<Spell, Integer> spellLevel){
        this.spellLevel = spellLevel;
    }

    public Spell[] getSpellArray(){
        return getLearnedSpellLevel().keySet().toArray(new Spell[0]);
    }

    public List<Spell> getSpellSlot(){
        return this.spellSlot;
    }

    public void setSpellSlot(List<Spell> spellSlot){
        this.spellSlot = spellSlot;
    }

    public int getItemSlotNum(){
        return this.itemSlotNum;
    }

    public void setItemSlotNum(int itemSlotNum){
        this.itemSlotNum = itemSlotNum;
    }

    public int getFirstAction(){
        return this.firstAction;
    }

    public Map<BattleItem, Integer> getItemList(){
        return this.itemList;
    }

    public void setItemList(Map<BattleItem, Integer> itemList){
        this.itemList = itemList;
    }

    public int getLastAction(){
        return this.lastAction;
    }

    public int getSecondLastAction(){
        return this.secondLastAction;
    }

    public void setLastAction(int lastAction){
        this.secondLastAction = this.lastAction;
        this.lastAction = lastAction;
    }

    //合法手を取得
    //配列の一つ目の値は攻撃・防御・溜める・呪文・アイテムの選択
    //配列の二つ目の値は何番目の魔法・アイテムかを指定
    public int[] getLegalAction (State state, Weather stateWeather, Map<Field,Map<FieldCounter, Integer>> field, int turn){
        // 気絶してたら合法手なし
        if(this.getStateAction().get(ActionState.Swoon).get(ActionStateCounter.flag) == 1){
            return new int[]{-1};
        }
        List<Integer> legalActionList= new ArrayList<>();
        List<Integer> legalItemList= new ArrayList<>();
        int[] legalActions;
        for (Spell spell : this.spellSlot){
            if (spell != Spell.NULL && 
            spell.getLegal(state, stateWeather, this, false, null)){
                legalActionList.add(4 + spell.ordinal());
            }
        }
        if(this.useSpecial && 
        this.getStateAction().get(ActionState.UsedSpecial).get(ActionStateCounter.flag) != 1){
            legalActionList.add(4 + Spell.NUM);
        }
        if(this.getStateAction().get(ActionState.oldChargeSpecial).get(ActionStateCounter.flag) == 1 || field.get(Field.SpecialField).get(FieldCounter.flag) == 1){
            for(int i = 1; i <= Special.NUM; i++){
                legalActionList.add(4 + Spell.NUM + i);
            }
        }else if(stateWeather != Weather.Abnormal){
            for (int i = 1; i <= 3; i++){
                int act = i;
                if(this.stateAction.get(ActionState.newChargeSpecial).get(ActionStateCounter.flag) == 1 && this.attribute.ordinal() + 1 == i){
                    act = 4 + Spell.NUM + i;
                }
                if(TrainLimitation.newAttribute.useAble() && turn == 1 && (this.attribute == Attribute.A || this.attribute == Attribute.D || this.attribute == Attribute.C)){
                    if(this.attribute.ordinal() == act - 1){
                        legalActionList.add(act);
                    }
                }else{
                    legalActionList.add(act);
                }
            }
        }
        for(Spell spell : this.getLearnedSpellLevel().keySet()){
            if(spell != Spell.NULL && !this.spellSlot.contains(spell)){
                legalActionList.add(4 + Spell.NUM + 1 + Special.NUM + spell.ordinal());
            }
        }
        for(Integer act : new ArrayList<>(legalActionList)){
            if(ChangeAbnormalState.execute(this, field, AbnormalState.Nervous, act, 0, false) || 
            ChangeAbnormalState.execute(this, field, AbnormalState.SuperNervous, act, 0, false) || 
            ChangeAbnormalState.execute(this, field, AbnormalState.SuperStomatitis, act, 0, false)){
                legalActionList.remove(act);
            }
        }
        //アイテムを使用しないときの0を追加
        legalItemList.add(0);
        for (int i = 0; i < BattleItem.NUM; i++){
            if (ExecuteAction.legalItem(BattleItem.values()[i], this, false)){
                legalItemList.add(i+1);
            }
        }
        if(this.useEscape){
            legalActions = new int[legalActionList.size() * legalItemList.size() + 1];
            legalActions[legalActions.length - 1] = 0;
        }else{
            legalActions = new int[legalActionList.size() * legalItemList.size()];
        }
        for (int i = 0; i < legalActionList.size(); i++){
            legalActions[i] = legalActionList.get(i);
        }
        for(int i = 0; i < legalActionList.size(); i++){
            for(int j  = 0; j < legalItemList.size(); j++){
                legalActions[i+j*legalActionList.size()] = legalActionList.get(i) + legalItemList.get(j) * InputAction.ACTION_NUM;
            }
        }
        if(legalActions.length == 0){
            legalActions = new int[]{-1};
        }
        if(state.getTurn() == 1){
            for(int act : legalActions){
                if(act == this.firstAction){
                    return new int[]{this.firstAction};
                }
            }
        }
        return legalActions;
    }

    public int[] biasedAction(State state, boolean self_is_player1, Weather stateWeather, Map<Field,Map<FieldCounter, Integer>> field, int turn){
        List<Integer> biasedAction = new ArrayList<>();
        int[] biasedActionArray;
        int[] legalActions = state.getLegalAction(self_is_player1);
        List<Integer> legalBiasedAction = new ArrayList<>();
        for(int legalAct : legalActions){
            if(this.biasedActions.keySet().contains(legalAct)){
                legalBiasedAction.add(legalAct);
            }
        }
        for(Integer act : legalBiasedAction){
            for(int i = 0; i < this.biasedActions.get(act); i++){
                biasedAction.add(act);
            }
        }
        biasedActionArray = new int[biasedAction.size()];
        for(int i = 0; i < biasedAction.size(); i++){
            biasedActionArray[i] = biasedAction.get(i);
        }
        if(biasedActionArray.length == 0){
            return legalActions;
        }
        return biasedActionArray;
    }

    // データをIntegerリスト化して返す
    public List<Integer> getDataArray(){
        List<Integer> dataList = new ArrayList<>();
        dataList.add(this.spellSlotNum);
        dataList.add(this.useSpecial ? 1 : 0);
        for(MainStatus key : MainStatus.values()){
            dataList.add(this.mainStatus.get(key));
        }
        for(BattleStatus key : BattleStatus.values()){
            dataList.add(this.battleStatus.get(key));
        }
        // errorが出るのでコメントアウト
        // for(StateChangeStatus key : StateChangeStatus.values()){
        //     for(StatusCounter counter : StatusCounter.values()){
        //         dataList.add(this.stateChangeStatus.get(key).get(counter));
        //     }
        // }
        for(AbnormalState key : AbnormalState.values()){
            for(AbnormalStateCounter counter : AbnormalStateCounter.values()){
                dataList.add(this.stateAbnormal.get(key).get(counter));
            }
        }
        for(ActionState key : ActionState.values()){
            for(ActionStateCounter counter : ActionStateCounter.values()){
                dataList.add(this.stateAction.get(key).get(counter));
            }
        }
        for(Spell key : Spell.values()){
            dataList.add(this.spellLevel.containsKey(key) ? this.spellLevel.get(key) : 0);
        }
        for(BattleItem key : BattleItem.values()){
            dataList.add(this.itemList.containsKey(key) ? (this.itemList.get(key) != 0 ? 1 : 0) : 0);
        }
        dataList.add(this.lastAction);//TODO secondLastAction
        return dataList;
    }

}