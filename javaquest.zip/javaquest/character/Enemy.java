package character;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import battle.CalculateDamage;
import battle.InputAction.Auto;
import battle.state_change.ChangeAbnormalState.AbnormalState;
import battle.state_change.ChangeAbnormalState.AbnormalStateCounter;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import battle.state_change.ChangeActionState.UpdateBackup;
import battle.state_change.ChangeBattleStatus.StateChangeStatus;
import battle.state_change.ChangeBattleStatus.StatusCounter;
import data.action.Spell;
import data.enemy.BaseMonster;
import data.enemy.Boss;
import data.enemy.Monster;
import data.item.BattleItem;
import game.LocationCategory;
import log.unmodifiable.UnmodifiableEnemy;
import text.Print.Color;

public class Enemy extends Character{
    private Spell lastSpell = Spell.NULL;//最後に使った呪文を保存する（ドロップ用）
    public final int money;// 落とす金
    public final int trainLevelUpRows;// 訓練レベルの上がる列数
    public final Auto auto;// 行動選択方法
    public final int[] cycleActions;// 行動サイクル（サイクル行動のみ）
    // メインコンストラクタ
    // private Enemy(String name, Attribute attribute, int spellSlotNum, boolean useSpecial, boolean useEscape, Map<MainStatus, Integer> mainStatus, Map<BattleStatus, Integer> battleStatus, List<Map<StateChangeStatus, Map<StatusCounter, Integer>>> stateChangeStatus, Map<AbnormalState, Map<AbnormalStateCounter, Integer>> stateAbnormal, UpdateBackup updateBackup, Map<ActionState, Map<ActionStateCounter, Integer>> stateAction, Map<Spell, Integer> spellLevel, List<Spell> spellSlot, int itemSlotNum, Map<BattleItem, Integer> itemList, BattleItem passiveItem, int lastAction, int secondLastAction, Map<LocationCategory, Integer> savedAction, Spell lastSpell, int money, int trainLevelUpRows, Auto auto){
    //     super(name, attribute, spellSlotNum, useSpecial, useEscape, mainStatus, battleStatus, stateChangeStatus, stateAbnormal, updateBackup, stateAction, spellLevel, spellSlot, itemSlotNum, itemList, passiveItem, lastAction, secondLastAction, savedAction);
    //     this.lastSpell = lastSpell;
    //     this.money = money;
    //     this.trainLevelUpRows = trainLevelUpRows;
    //     this.auto = auto;
    //     this.cycleActions = null;
    // }
    // コピーコンストラクタ
    protected Enemy(Enemy enemy){
        super(enemy);
        this.lastSpell = enemy.lastSpell;
        this.money = enemy.money;
        this.trainLevelUpRows = enemy.trainLevelUpRows;
        this.auto = enemy.auto;
        this.cycleActions = enemy.cycleActions;
    }
    // // モンスターデータからの生成
    // public Enemy(Monster monster){
    //     super(monster.jName, monster.attribute, monster.spellSlotNum, monster.useSpecial, monster.useEscape, monster.getMainStatusArray(), new EnumMap<>(monster.spellLevel), BattleItem.None);
    //     this.money = monster.getMoney();
    //     this.trainLevelUpRows = monster.trainLevelUpRows;
    //     this.auto = monster.auto;
    //     this.cycleActions = monster.cycleActions;
    // }
    // // モンスターデータからの生成（行動方法のみ指定）
    // public Enemy(Monster monster, Auto auto){
    //     super(monster.jName, monster.attribute, monster.spellSlotNum, monster.useSpecial, monster.useEscape, monster.getMainStatusArray(), new EnumMap<>(monster.spellLevel), BattleItem.None);
    //     this.money = monster.getMoney();
    //     this.trainLevelUpRows = monster.trainLevelUpRows;
    //     this.auto = auto;
    //     this.cycleActions = monster.cycleActions;
    // }
    // ベースモンスターからの生成
    public Enemy(BaseMonster baseMonster, int powerLevel, int rewardLevel){
        super(baseMonster.jName, Color.red, Attribute.Null, baseMonster.spellSlotNum, false, false, baseMonster.mainStatusArray(powerLevel), (baseMonster.spellLevel.size() == 0 ? new EnumMap<Spell, Integer>(Spell.class) : new EnumMap<>(baseMonster.spellLevel)), BattleItem.None, baseMonster.firstAction, baseMonster.biasedActions, baseMonster.nonInitialNervous, baseMonster.initialStateChangeStatus);
        this.money = (int)(baseMonster.money * CalculateDamage.clearFourthRootOfTwo(rewardLevel * BaseMonster.statusMoneyExponent));
        this.trainLevelUpRows = baseMonster.trainLevelUpRows;
        this.auto = baseMonster.auto;
        this.cycleActions = null;
    }
    // 勇者生成（必殺技・ランダムステータス生成を指定）
    public Enemy(Boss boss, Attribute attribute, BattleItem battleItem, Random rand, boolean randomStatus){
        super(boss.jName, Color.red, attribute, boss.spellSlotNum, boss.useSpecial, false, randomStatus ? boss.getRandomMainStatusArray(rand) : boss.getFixedMainStatusArray()
        , new EnumMap<>(Collections.unmodifiableMap(
            new EnumMap<>(Spell.class){{
                for(Map<Spell, Integer> categorySpell : boss.spellCategoryNum.keySet()){
                    Map<Spell, Integer> categorySpellCopy = new EnumMap<>(categorySpell);
                    for(int i = 0; i < boss.spellCategoryNum.get(categorySpell); i++){
                        int idx = rand.nextInt(categorySpellCopy.size());
                        Spell spell = categorySpellCopy.keySet().toArray(new Spell[0])[idx];
                        this.put(spell, categorySpellCopy.get(spell));
                        categorySpellCopy.remove(spell);
                    }
                }
            }}
        )), battleItem, boss.firstAction, new HashMap<>(), false, new ArrayList<>());
        this.money = boss.money;
        this.trainLevelUpRows = 0;
        this.auto = boss.auto;
        // for(BattleItem key : BattleItem.values()){
        //     this.getItemList().put(key, boss.useItem ? 1 : 0);
        // }
        // BattleItem.randomDropItem(this, rand);
        this.cycleActions = boss.cycleActions;
    }

    // 変更可能コピー
    @Override
    public Enemy modifiableCopy(){
        return new Enemy(this);
    }

    // 変更不能コピー
    @Override
    public UnmodifiableEnemy unmodifiableCopy(){
        return new UnmodifiableEnemy(this);
    }

    public Spell getLastSpell(){
        return this.lastSpell;
    }

    public void setLastSpell(Spell lastSpell){
        this.lastSpell = lastSpell;
    }

    // サイクル行動の行動を返す
    public int getCycleAction(int turn){
        if(turn == 0){
            return -1;
        }
        return this.cycleActions[(turn - 1) % cycleActions.length];
    }

}
