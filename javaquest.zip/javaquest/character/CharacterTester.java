package character;

import java.util.List;
import java.util.Map;

import battle.Battle;
import battle.state_change.ChangeAbnormalState.AbnormalState;
import battle.state_change.ChangeAbnormalState.AbnormalStateCounter;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import battle.state_change.ChangeActionState.UpdateBackup;
import battle.state_change.ChangeBattleStatus.StateChangeStatus;
import battle.state_change.ChangeBattleStatus.StatusCounter;
import data.action.Spell;
import data.item.BattleItem;
import game.LocationCategory;
import log.unmodifiable.UnmodifiableCharacterTester;
import text.Print.Color;

// 使用用途不明
public class CharacterTester extends Character{
    // private CharacterTester(String name, Attribute attribute, int spellSlotNum, boolean useSpecial, boolean useEscape, int attackTime, Map<MainStatus, Integer> mainStatus, Map<BattleStatus, Integer> battleStatus, List<Map<StateChangeStatus, Map<StatusCounter, Integer>>> stateChangeStatus, Map<AbnormalState, Map<AbnormalStateCounter, Integer>> stateAbnormal, UpdateBackup updateBackup, Map<ActionState, Map<ActionStateCounter, Integer>> stateAction, Map<Spell, Integer> spellLevel, List<Spell> spellSlot, int itemSlotNum, Map<BattleItem, Integer> itemList, BattleItem passiveItem, int lastAction, int secondLastAction, Map<LocationCategory, Integer> savedAction){
    //     super(name, attribute, spellSlotNum, useSpecial, useEscape, mainStatus, battleStatus, stateChangeStatus, stateAbnormal, updateBackup, stateAction, spellLevel, spellSlot, itemSlotNum, itemList, passiveItem, lastAction, secondLastAction, savedAction);
    // }
    protected CharacterTester(CharacterTester chara){
        super(chara);
    }
    public CharacterTester(String name, Color nameColor, Attribute attribute, int spellSlotNum, boolean useSpecial, int[] mainStatus, Map<Spell, Integer> spellLevel,BattleItem passiveItem){
        super(name, nameColor, attribute, spellSlotNum, useSpecial, false, mainStatus, spellLevel, passiveItem);
    }
    @Override
    public CharacterTester modifiableCopy(){
        return new CharacterTester(this);
    }
    @Override
    public UnmodifiableCharacterTester unmodifiableCopy(){
        return new UnmodifiableCharacterTester(this);
    }
}
