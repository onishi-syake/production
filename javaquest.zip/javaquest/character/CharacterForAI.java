package character;

import java.util.List;
import java.util.Map;

import battle.InputAction;
import battle.state_change.ChangeAbnormalState.AbnormalState;
import battle.state_change.ChangeAbnormalState.AbnormalStateCounter;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import battle.state_change.ChangeActionState.UpdateBackup;
import battle.state_change.ChangeBattleStatus.StateChangeStatus;
import battle.state_change.ChangeBattleStatus.StatusCounter;
import data.action.Special;
import data.action.Spell;
import data.item.BattleItem;
import game.LocationCategory;
import log.unmodifiable.UnmodifiableCharacterTester;

public final class CharacterForAI extends Character{
    // 多分AI用にラグ時の行動を保存していると思われるが詳しくは分からん
    public enum LagAct{
        NULL,
        escape,
        nomalAction,
        spell,
        special,
        other
    }
    private LagAct lagAct = LagAct.NULL;
    // private CharacterForAI(String name, Attribute attribute, int spellSlotNum, boolean useSpecial, boolean useEscape, int attackTime, Map<MainStatus, Integer> mainStatus, Map<BattleStatus, Integer> battleStatus, List<Map<StateChangeStatus, Map<StatusCounter, Integer>>> stateChangeStatus, Map<AbnormalState, Map<AbnormalStateCounter, Integer>> stateAbnormal, UpdateBackup updateBackup, Map<ActionState, Map<ActionStateCounter, Integer>> stateAction, Map<Spell, Integer> spellLevel, List<Spell> spellSlot, int itemSlotNum, Map<BattleItem, Integer> itemList, BattleItem passiveItem, int lastAction, int secondLastAction, Map<LocationCategory, Integer> savedAction, LagAct lagAct){
    //     super(name, attribute, spellSlotNum, useSpecial, useEscape, mainStatus, battleStatus, stateChangeStatus, stateAbnormal, updateBackup, stateAction, spellLevel, spellSlot, itemSlotNum, itemList, passiveItem, lastAction, secondLastAction, savedAction);
    //     this.lagAct = lagAct;
    // }
    // コピーコンストラクタ
    private CharacterForAI(CharacterForAI chara){
        super(chara);
        this.lagAct = chara.lagAct;
    }
    CharacterForAI(Character chara){
        super(chara);
    }
    public LagAct getLagAct(){
        return this.lagAct;
    }
    public void setLagAct(LagAct act){
        this.lagAct = act;
    }
    public void setLagAct(int act){
        if(act == 0){
            this.lagAct =  LagAct.escape;
        }if((act-1) % InputAction.ACTION_NUM + 1 <= 3){
            this.lagAct = LagAct.nomalAction;
        }else if((act-1) % InputAction.ACTION_NUM + 1 < 4 + Spell.NUM){
            this.lagAct = LagAct.spell;
        }else if((act-1) % InputAction.ACTION_NUM + 1 <= 4 + Spell.NUM + Special.NUM){
            this.lagAct = LagAct.special;
        }else{
            this.lagAct = LagAct.other;
        }
    }
    @Override
    public List<Integer> getDataArray(){
        List<Integer> dataList = super.getDataArray();
        dataList.add(this.lagAct.ordinal());
        return dataList;
    }
    @Override
    public CharacterForAI modifiableCopy(){
        return new CharacterForAI(this);
    }
    @Override
    public UnmodifiableCharacterTester unmodifiableCopy(){
        throw new UnsupportedOperationException();
    }
    @Override
    public CharacterForAI forAI(){
        return new CharacterForAI(this);
    }
}
