package character;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import battle.CalculateDamage;
import battle.state_change.ChangeAbnormalState.AbnormalState;
import battle.state_change.ChangeAbnormalState.AbnormalStateCounter;
import battle.state_change.ChangeActionState.ActionState;
import battle.state_change.ChangeActionState.ActionStateCounter;
import battle.state_change.ChangeActionState.UpdateBackup;
import battle.state_change.ChangeBattleStatus.StateChangeStatus;
import battle.state_change.ChangeBattleStatus.StatusCounter;
import data.action.Spell;
import data.item.BattleItem;
import data.item.DisposableItem;
import game.LocationCategory;
import limitation.BattleLimitation;
import log.unmodifiable.UnmodifiablePlayer;
import text.Print.Color;
import train.TrainState.Mode;

//必要です。
public class Player extends Character{
    private boolean useSpell;// スペルを使うかどうか
    private boolean useItem;// アイテムを使うかどうか
    private Skill skill;// スキル
    private Map<DisposableItem, Integer> disposableItemList = new EnumMap<>(DisposableItem.class);// 使い切りアイテムリスト
    private Map<TrainStatus, Integer> trainStatus = new EnumMap<>(TrainStatus.class);// ステータス
    private Map<SpellBookLevel, Integer> spellBookLevel = new EnumMap<>(SpellBookLevel.class);// スペルオーブのレベル
    private int innNum;// 宿屋を使った回数
    private int mpTrainNum;// MP強化をした回数
    private int elixirTurn;// エリクサーの残りターン
    private List<TrainStatus> noCostStatus;// ラボで減ることの無くなったコスト

    public enum TrainStatus{
        hp(MainStatus.hp.jName, MainStatus.hp.shortName, Color.yellow, 1000, 1000, Integer.MAX_VALUE, null),
        maxHp(MainStatus.maxHp.jName, MainStatus.maxHp.shortName, Color.yellow, 1000, 1000, Integer.MAX_VALUE, TrainStatus.hp),
        mp(MainStatus.mp.jName, MainStatus.mp.shortName, Color.white, 5, 5, Integer.MAX_VALUE, null),
        maxMp(MainStatus.maxMp.jName, MainStatus.maxMp.shortName, Color.white, 5, 5, Integer.MAX_VALUE, TrainStatus.mp),
        a(MainStatus.a.jName, MainStatus.a.shortName, Color.white, 100, 100, Integer.MAX_VALUE, null),
        d(MainStatus.d.jName, MainStatus.d.shortName, Color.white, 100, 100, Integer.MAX_VALUE, null),
        e(MainStatus.e.jName, MainStatus.e.shortName, Color.white, 10, 10, Integer.MAX_VALUE, null),
        s(MainStatus.s.jName, MainStatus.s.shortName, Color.white, 100, 100, Integer.MAX_VALUE, null),
        aNum(MainStatus.aNum.jName, MainStatus.aNum.shortName, Color.white, 2, 2, Integer.MAX_VALUE, null),
        concentration("集中力", "集", Color.purple, 200, 200, Integer.MAX_VALUE, null),// 成功率
        maxConcentration("最大集中力", "最集", Color.purple, 200, 200, Integer.MAX_VALUE, TrainStatus.concentration),
        motivation("やる気", "気", Color.green, 50, 50, Integer.MAX_VALUE, null),// 行動力
        maxMotivation("最大やる気", "最気", Color.green, 70, 70, Integer.MAX_VALUE, TrainStatus.motivation),
        gasoline("ガソリン", "ガソリン", Color.blue, 100, 100, Integer.MAX_VALUE, null),
        maxGasoline("最大ガソリン", "最大ガソリン", Color.blue, 100, 100, 400, TrainStatus.gasoline),
        money("所持金", "金", Color.white, 0, 0, Integer.MAX_VALUE, null),
        ;
        public final String jName;// 名前
        public final String shortName;// 短縮名
        public final Color color;// 文字の色
        public final int defaultNum;// 初期値
        public final int easyDefaultNum;// イージーモードの初期値
        public final int maxNum;// 最大値
        public final TrainStatus child;// 最大値のステータスが実数値のステータスを持つフィールド
        private TrainStatus(String name, String shortName, Color color, int defaultNum, int easyDefaultNum, int maxNum, TrainStatus child){
            this.jName = name;
            this.shortName = shortName;
            this.color = color;
            this.defaultNum = defaultNum;
            this.maxNum = maxNum;
            this.easyDefaultNum = easyDefaultNum;
            this.child = child;
        }
    }
    
    public enum SpellBookLevel{
        Fire("ファイアのオーブ"),
        Flame("ファイアの強化石"),
        Explosion("フレイムの強化石"),
        BigBang("エプロンの強化石"),
        Wind("ウィンドのオーブ"),
        Gust("ウィンドの強化石"),
        Tornado("ガストの強化石"),
        Storm("トルネードの強化石"),
        Stone("ストーンのオーブ"),
        Rock("ストーンの強化石"),
        Lava("ロックの強化石"),
        Meteor("ラヴァの強化石"),
        Heal("ヒールのオーブ"),
        AUp("アタックアップのオーブ"),
        SUp("スピードアップのオーブ"),
        DUp("ディフェンスアップのオーブ"),
        Nervous("緊迫斬りのオーブ"),
        Lag("回線斬りのオーブ"),
        Poison("毒斬りのオーブ"),
        Bond("臆病斬りのオーブ"),
        Stomatitis("沈黙斬りのオーブ"),
        // Trauma("トラウマのオーブ"),
        // Chaos("カオスのオーブ"),
        On_StateChange("ONS-ステイトチェンジのオーブ"),
        On_SpellReflect("ONS-スペルリフレクトのオーブ"),
        TensionField("テンションフィールドのオーブ"),
        SpecialField("スペシャルフィールドのオーブ"),
        // PassionField("パッションフィールドのオーブ"),
        ReverseField("リバースフィールドのオーブ"),
        RegenField("サドンデスフィールドのオーブ"),
        ;
        public final String jName;// 名前
        private SpellBookLevel(String name){
            this.jName = name;
        }
    }

    // メインコンストラクタ
    // private Player(String name, Attribute baseAttribute, Skill skill, int spellSlotNum, boolean useSpell, boolean useItem, boolean useSpecial, boolean useEscape, Map<MainStatus, Integer> mainStatus, Map<BattleStatus, Integer> battleStatus, List<Map<StateChangeStatus, Map<StatusCounter, Integer>>> stateChangeStatus, Map<AbnormalState, Map<AbnormalStateCounter, Integer>> stateAbnormal, UpdateBackup updateBackup, Map<ActionState, Map<ActionStateCounter, Integer>> stateAction, Map<Spell, Integer> spellLevel, List<Spell> spellSlot, int itemSlotNum, Map<BattleItem, Integer> itemList, BattleItem passiveItem, int lastAction, int secondLastAction, Map<LocationCategory, Integer> savedAction, Map<TrainStatus, Integer> trainStatus, Map<DisposableItem, Integer> trainItemList, Map<SpellBookLevel, Integer> spellBookLevel, int innNum, int mpTrainNum, int battleNum, int elixirTurn, List<TrainStatus> noCostStatus){
    //     super(name, baseAttribute, spellSlotNum, useSpecial, useEscape, mainStatus, battleStatus, stateChangeStatus, stateAbnormal, updateBackup, stateAction, spellLevel, spellSlot, itemSlotNum, itemList, passiveItem, lastAction, secondLastAction, savedAction);
    //     this.useSpell = useSpell;
    //     this.useItem = useItem;
    //     this.baseAttribute = baseAttribute;
    //     this.skill = skill;
    //     this.trainStatus = trainStatus;
    //     this.disposableItemList = trainItemList;
    //     this.spellBookLevel = spellBookLevel;
    //     this.innNum = innNum;
    //     this.mpTrainNum = mpTrainNum;
    //     this.battleNum = battleNum;
    //     this.elixirTurn = elixirTurn;
    //     this.noCostStatus = noCostStatus;
    // }

    // コピーコンストラクタ
    protected Player(Player player){
        super(player);
        this.useSpell = player.useSpell;
        this.useItem = player.useItem;
        this.skill = player.skill;
        this.trainStatus = new EnumMap<>(player.trainStatus);
        this.disposableItemList = new EnumMap<>(player.disposableItemList);
        this.spellBookLevel = new EnumMap<>(player.spellBookLevel);
        this.innNum = player.innNum;
        this.mpTrainNum = player.mpTrainNum;
        this.elixirTurn = player.elixirTurn;
        this.noCostStatus = new ArrayList<>(player.noCostStatus);
    }

    //ステータス指定生成
    public Player(String name, Attribute attribute, Skill skill, int[] trainStatus, Map<Spell, Integer> spellLevel, Mode mode){
        super(name, Color.blue, attribute, 1, mode == Mode.debug ? BattleLimitation.useSpecial.useAble() : BattleLimitation.useSpecial.useAble(mode), false, new ArrayList<Integer>(){{for(int i = 0; i < MainStatus.NUM; i++){this.add(trainStatus[i]);}}}.stream().mapToInt(i->i).toArray(), spellLevel, BattleItem.None);
        this.useSpell = mode == Mode.debug ? BattleLimitation.useSpell.useAble() : BattleLimitation.useSpell.useAble(mode);
        this.useItem = mode == Mode.debug ? BattleLimitation.useItem.useAble() : BattleLimitation.useItem.useAble(mode);
        this.skill = skill;
        this.trainStatus = new EnumMap<>(TrainStatus.class);
        for(int i = 0; i < trainStatus.length; i++){
            this.trainStatus.put(TrainStatus.values()[i], trainStatus[i]);
        }
        this.disposableItemList = new EnumMap<>(DisposableItem.class){{
            for(DisposableItem key: DisposableItem.values()){
                this.put(key, 0);
            }
        }};
        this.spellBookLevel = new EnumMap<>(SpellBookLevel.class){{for(SpellBookLevel key : SpellBookLevel.values()){this.put(key, 0);}}};
        this.innNum = 0;
        this.mpTrainNum = 0;
        this.elixirTurn = 0;
        this.noCostStatus = new ArrayList<TrainStatus>();
    }

    //初期生成
    public Player(String name, Attribute attribute, Skill skill, Mode mode){
        super(name, Color.blue, attribute, 1, mode == Mode.debug ? BattleLimitation.useSpecial.useAble() : BattleLimitation.useSpecial.useAble(mode), false, new ArrayList<Integer>(){{for(int i = 0; i < MainStatus.NUM; i++){this.add(mode == Mode.easy ? TrainStatus.values()[i].easyDefaultNum : TrainStatus.values()[i].defaultNum);}}}.stream().mapToInt(i->i).toArray(), new EnumMap<Spell, Integer>(Spell.class), BattleItem.None);
        this.useSpell = mode == Mode.debug ? BattleLimitation.useSpell.useAble() : BattleLimitation.useSpell.useAble(mode);
        this.useItem = mode == Mode.debug ? BattleLimitation.useItem.useAble() : BattleLimitation.useItem.useAble(mode);
        this.skill = skill;
        this.trainStatus = new EnumMap<>(TrainStatus.class);
        for(int i = 0; i < TrainStatus.values().length; i++){
            this.trainStatus.put(TrainStatus.values()[i], mode == Mode.easy ? TrainStatus.values()[i].easyDefaultNum : TrainStatus.values()[i].defaultNum);
        }
        this.disposableItemList = new EnumMap<>(DisposableItem.class){{
            for(DisposableItem key: DisposableItem.values()){
                this.put(key, 0);
            }
        }};
        this.spellBookLevel = new EnumMap<>(SpellBookLevel.class){{for(SpellBookLevel key : SpellBookLevel.values()){this.put(key, 0);}}};
        this.innNum = 0;
        this.mpTrainNum = 0;
        this.elixirTurn = 0;
        this.noCostStatus = new ArrayList<TrainStatus>();
    }

    // 訓練ステータスを元に戦闘ステータスを更新する
    public void trainToBattleStatus(){
        Map<MainStatus,Integer> mainStatus = this.getMainStatus();
        for(MainStatus key : MainStatus.values()){
            mainStatus.replace(key, this.trainStatus.get(TrainStatus.valueOf(key.name())));
        }
        this.setMainStatus(mainStatus);
        return;
    }

    // 戦闘ステータスを元に訓練ステータスを更新する
    public void battleToTrainStatus(){
        Map<MainStatus,Integer> mainStatus = this.getMainStatus();
        for(MainStatus key : MainStatus.values()){
            if(key == MainStatus.maxHp || key == MainStatus.maxMp){
                continue;
            }
            this.trainStatus.replace(TrainStatus.valueOf(key.name()), mainStatus.get(key));
        }
        for(TrainStatus key : TrainStatus.values()){
            CalculateDamage.trainDamage(this, key, 0, false);
        }
        this.setTrainStatus(trainStatus);
        return;
    }

    @Override
    public Player modifiableCopy(){
        return new Player(this);
    }

    @Override
    public UnmodifiablePlayer unmodifiableCopy(){
        return new UnmodifiablePlayer(this);
    }

    public boolean getUseSpell(){
        return this.useSpell;
    }

    public void setUseSpell(boolean useSpell){
        this.useSpell = useSpell;
    }

    public boolean getUseItem(){
        return this.useItem;
    }

    public void setUseItem(boolean useItem){
        this.useItem = useItem;
    }

    public Skill getSkill(){
        return this.skill;
    }

    public void setSkill(Skill skill){
        this.skill = skill;
    }

    public Map<DisposableItem, Integer> getDisposableItemList(){
        return this.disposableItemList;
    }

    public void setDisposableItemList(Map<DisposableItem, Integer> trainItemList){
        this.disposableItemList = trainItemList;
    }
    
    public Map<TrainStatus, Integer> getTrainStatus(){
        return this.trainStatus;
    }

    public void setTrainStatus(Map<TrainStatus, Integer> trainStatus){
        this.trainStatus = trainStatus;
    }

    public Map<SpellBookLevel, Integer> getSpellBookLevel(){
        return this.spellBookLevel;
    }

    public void setSpellBookLevel(Map<SpellBookLevel, Integer> spellBookLevel){
        this.spellBookLevel = spellBookLevel;
    }

    public int getInnNum(){
        return this.innNum;
    }

    public void setInnNum(int innNum){
        this.innNum = innNum;
    }

    public int getMpTrainNum(){
        return this.mpTrainNum;
    }

    public void setMpTrainNum(int mpTrainNum){
        this.mpTrainNum = mpTrainNum;
    }

    public int getElixirTurn(){
        return this.elixirTurn;
    }

    public void setElixirTurn(int elixirTurn){
        this.elixirTurn = elixirTurn;
    }

    public List<TrainStatus> getNoCostStatus(){
        return this.noCostStatus;
    }

    public void addNoCostStatus(TrainStatus noCostStatus){
        this.noCostStatus.add(noCostStatus);
    }

    public void resetNoCostStatus(){
        this.noCostStatus = new ArrayList<>();
    }

    public void resetMoney(){
        this.trainStatus.replace(TrainStatus.money, 0);
    }
}